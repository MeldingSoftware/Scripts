[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# DLL's for show and hide console
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'

function Show-Console
{
    $consolePtr = [Console.Window]::GetConsoleWindow()

    # Hide = 0,
    # ShowNormal = 1,
    # ShowMinimized = 2,
    # ShowMaximized = 3,
    # Maximize = 3,
    # ShowNormalNoActivate = 4,
    # Show = 5,
    # Minimize = 6,
    # ShowMinNoActivate = 7,
    # ShowNoActivate = 8,
    # Restore = 9,
    # ShowDefault = 10,
    # ForceMinimized = 11

    [Console.Window]::ShowWindow($consolePtr, 3)
}

Show-Console | Out-Null

# Get the current date and format it as "Day, Month Date, Year"
(Get-Date).ToString("dddd, MMMM dd, yyyy")

Write-Host ""


# THIS DAY IN HISTORY
# https://rapidapi.com/auth/sign-up?referral=/hub - Sign-up for a free RapidAPI account
# https://rapidapi.com/divad12/api/numbers-1 Subscribe to API Numbers
$headers=@{}
$headers.Add("X-RapidAPI-Key", "REPLACE WITH RAPIDAPI KEY")
$headers.Add("X-RapidAPI-Host", "numbersapi.p.rapidapi.com")

# Get today's date in the format required by the API (month/day)
$date = Get-Date -Format "MM/dd"

# Make the API call with the current date
$response = Invoke-RestMethod -Uri "https://numbersapi.p.rapidapi.com/${date}/date?fragment=true&json=true" -Method GET -Headers $headers

if ($response) {
    $year = $response.year
    $text = $response.text

    Write-Host "On this day in ${year}:`n$text"
} else {
    Write-Host "Failed to fetch the date fact."
}

Write-Host ""


# QUOTE OF THE DAY
# https://theysaidso.com/api Get Key
$apiKey = "REPLACE WITH API KEY"
$apiUrl = "https://quotes.rest/qod"

# Create a headers object with the API key
$headers = @{
    "X-TheySaidSo-Api-Secret" = $apiKey
}

try {
    $response = Invoke-RestMethod -Uri $apiUrl -Headers $headers
    # Process the response as before
    $quote = $response.contents.quotes[0].quote
    $author = $response.contents.quotes[0].author

    Write-Output "Quote of the Day:"
    Write-Output "$quote - $author"
} catch [System.Net.HttpStatusCode] {
    if ($_.Exception.Response.StatusCode -eq '429') {
        Write-Host "Error: Too many requests. Please try again later."
    } else {
        Write-Host "An error occurred: $($_.Exception.Message)"
    }
} catch {
    Write-Host "An unexpected error occurred: $_"
}

Write-Host ""


# WEATHER
try {
    # Use a web service to get the public IP address of the user
    $ip = (Invoke-RestMethod -uri "https://api.ipify.org/?format=json").ip

    # Use the IP address to get the location (latitude and longitude)
    $location = Invoke-RestMethod -uri "http://ip-api.com/json/$ip"

    # Use the National Weather Service API to get the weather data
    $weatherData = Invoke-RestMethod -uri "https://api.weather.gov/points/$($location.lat),$($location.lon)"
    $forecastUrl = $weatherData.properties.forecast
    $forecastData = Invoke-RestMethod -uri $forecastUrl

    # Filter for Today/This Afternoon and Tonight periods
    $filteredPeriods = $forecastData.properties.periods | Where-Object {
    $_.name -eq "Today" -or $_.name -eq "This Afternoon" -or $_.name -eq "Tonight"
    }

    # Display the filtered weather information
    Write-Host "Weather forecast for $($location.city), $($location.country):"
    foreach ($period in $filteredPeriods) {
        Write-Host "$($period.name): $($period.temperature)'$($period.temperatureUnit) - $($period.detailedForecast)"
    }

    # Get and display weather alerts
    if ($weatherData.properties.alerts -ne $null) {
        $alertsUrl = $weatherData.properties.alerts
        $alertsData = Invoke-RestMethod -uri $alertsUrl
        if ($alertsData.features.Count -eq 0) {
            Write-Host "No active weather alerts for your area."
        } else {
            Write-Host "Active weather alerts:"
            foreach ($alert in $alertsData.features) {
                $title = $alert.properties.headline
                $description = $alert.properties.description
                Write-Host "Title: $title"
                Write-Host "Description: $description"
                Write-Host "-----"
            }
        }
    } else {
        Write-Host "There are no weather alerts for your area."
    }
} catch {
    Write-Host "An error occurred while fetching weather data: $($_.Exception.Message)"
}

Write-Host ""

# NEWS
Write-Host -NoNewline "News:"

try {
    $RSS_URL = "https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"
    $maxLines = 10

    [xml]$content = (Invoke-WebRequest -URI $RSS_URL -useBasicParsing).Content

    $URL = $content.rss.channel.link
    ""

    [int]$count = 1
    foreach ($item in $content.rss.channel.item) {
        $title = $item.title -replace '^News\s+', '' -replace '\s+\d{4}$', ''  # Remove "News" prefix and year at the end
        $description = $item.description -replace '<[^>]+>', ''  # Strip HTML tags

        Write-Host "$title"
        if ($count++ -eq $maxLines) { break }
    }
} catch {
    Write-Host "An error occurred while fetching news data: $($_.Exception.Message)"
}

Write-Host ""

# SPORTS
Write-Host "Sports:"
# Get today's date
$date = Get-Date -Format "yyyy-MM-dd"

# Timezone for API 
# See Sports Timezones.txt for correct timezone
$timezone = "REPLACE WITH TIMEZONE" 

# API headers for NBA
# https://rapidapi.com/api-sports/api/api-basketball Subscribe to API-Basketball
$headersNBA = @{
    "X-RapidAPI-Key" = "REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host" = "api-basketball.p.rapidapi.com"
}

# API headers for NFL and NCAA Football
# https://rapidapi.com/api-sports/api/api-american-football Subscribe to API-Football
$headersNFLNCAA = @{
    "X-RapidAPI-Key" = "REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host" = "api-american-football.p.rapidapi.com"
}

# API headers for NHL
# https://rapidapi.com/api-sports/api/api-hockey Subscribe to API-Hockey
$headersNHL = @{
    "X-RapidAPI-Key" = "REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host" = "api-hockey.p.rapidapi.com"
}

# API headers for MLB
# https://rapidapi.com/api-sports/api/api-baseball Subscribe to API-Baseball
$headersMLB = @{
    "X-RapidAPI-Key" = "REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host" = "api-baseball.p.rapidapi.com"
}

# API requests for NBA, NFL, NHL, and MLB games
$responseNBA = Invoke-RestMethod -Uri "https://api-basketball.p.rapidapi.com/games?timezone=$timezone&date=$date" -Method GET -Headers $headersNBA
$responseNFLNCAA = Invoke-RestMethod -Uri "https://api-american-football.p.rapidapi.com/games?date=$date&timezone=$timezone" -Method GET -Headers $headersNFLNCAA
$responseNHL = Invoke-RestMethod -Uri "https://api-hockey.p.rapidapi.com/games/?date=$date&timezone=$timezone" -Method GET -Headers $headersNHL
$responseMLB = Invoke-RestMethod -Uri "https://api-baseball.p.rapidapi.com/games?timezone=$timezone&date=$date" -Method GET -Headers $headersMLB

# Check if there are NBA games today
if ($responseNBA.response) {
    foreach ($game in $responseNBA.response) {
        if ($game.league.name -eq "NBA" -or $game.league.name -eq "NBA In-Season Tournament") {
            $gameTime = [datetime]::ParseExact($game.time, "HH:mm", $null)
            $gameTimeHHmm = $gameTime.ToString("HHmm")
            $awayTeamNBA = $game.teams.away.name
            $homeTeamNBA = $game.teams.home.name
            Write-Output "$gameTimeHHmm $awayTeamNBA @ $homeTeamNBA"
        }
    }
    Write-Output ""
} 

# Check if there are NFL games today
if ($responseNFLNCAA.response) {
    foreach ($game in $responseNFLNCAA.response) {
		if ($game.league.name -eq "NFL") {
			$gameTime = [datetime]::ParseExact($game.time, "HH:mm", $null)
            $gameTimeHHmm = $gameTime.ToString("HHmm")
			$awayTeamNFL = $game.teams.away.name
			$homeTeamNFL = $game.teams.home.name
			Write-Output "$gameTimeHHmm $awayTeamNFL @ $homeTeamNFL"
		}
	}
    Write-Output ""
} 


# Check if there are NCAA Football games today
if ($responseNFLNCAA.response) {
    foreach ($game in $responseNFLNCAA.response) {
		if ($game.league.name -eq "NCAA") {
			$gameTime = [datetime]::ParseExact($game.time, "HH:mm", $null)
            $gameTimeHHmm = $gameTime.ToString("HHmm")
			$awayTeamNCAAFootball = $game.teams.away.name
			$homeTeamNCAAFootball = $game.teams.home.name
			Write-Output "$gameTimeHHmm $awayTeamNCAAFootball @ $homeTeamNCAAFootball"
		}
	}
    Write-Output ""
} 

# Check if there are NHL games today
if ($responseNHL.response ) {
    foreach ($game in $responseNHL.response) {
		 if ($game.league.name -eq "NHL") {
            $gameTime = [datetime]::ParseExact($game.time, "HH:mm", $null)
            $gameTimeHHmm = $gameTime.ToString("HHmm")
            $awayTeamNHL = $game.teams.away.name
            $homeTeamNHL = $game.teams.home.name
            Write-Output "$gameTimeHHmm $awayTeamNHL @ $homeTeamNHL"
        }
    }
    Write-Output ""
} 

# Check if there are MLB games today
if ($responseMLB.response) {
    foreach ($game in $responseMLB.response) {
        if ($game.league.name -eq "MLB") {
            $gameTime = [datetime]::ParseExact($game.time, "HH:mm", $null)
            $gameTimeHHmm = $gameTime.ToString("HHmm")
            $awayTeamMLB = $game.teams.away.name
            $homeTeamMLB = $game.teams.home.name
            Write-Output "$gameTimeHHmm $awayTeamMLB @ $homeTeamMLB"
        }
    }
    Write-Output ""
}  

# LOTTO
Write-Host "Lotto:"

# Mega Millions
# https://rapidapi.com/avoratechnology/api/mega-millions Subscribe to API Mega Millions
Write-Output "Lotto:"
$headers=@{}
$headers.Add("X-RapidAPI-Key", "REPLACE WITH RAPIDAPI KEY")
$headers.Add("X-RapidAPI-Host", "mega-millions.p.rapidapi.com")
$response = Invoke-RestMethod -Uri 'https://mega-millions.p.rapidapi.com/latest' -Method GET -Headers $headers
$data = $response.data[0]
$numberSet = $data.NumberSet
$nextJackPot = $data.NextJackPot
Write-Output "Mega Millions Last Drawing: $numberSet - Next Jackpot is $nextJackPot"

# Powerball
# https://rapidapi.com/avoratechnology/api/powerball Subscribe to API Powerball
$headers=@{}
$headers.Add("X-RapidAPI-Key", "REPLACE WITH RAPIDAPI KEY")
$headers.Add("X-RapidAPI-Host", "powerball.p.rapidapi.com")
$response = Invoke-RestMethod -Uri 'https://powerball.p.rapidapi.com/latest' -Method GET -Headers $headers
$data = $response.data[0]
$numberSet = $data.NumberSet
$nextJackPot = $data.NextJackPot
Write-Output "Powerball Last Drawing: $numberSet - Next Jackpot is $nextJackPot"`n


# STOCKS
# https://rapidapi.com/sparior/api/yahoo-finance15 Subscribe to API Yahoo Finance
$headers=@{}
$headers.Add("X-RapidAPI-Key", "REPLACE WITH RAPIDAPI KEY")
$headers.Add("X-RapidAPI-Host", "yahoo-finance15.p.rapidapi.com")
$response = Invoke-RestMethod -Uri 'https://yahoo-finance15.p.rapidapi.com/api/v1/markets/stock/quotes?ticker=%5EDJI%2C%5EIXIC%2C%5ESPX%2CGC%3DF%2CCL%3DF' -Method GET -Headers $headers

if ($response.meta.status -eq 200) {
    $quotes = $response.body
    $table = @()
    foreach ($quote in $quotes) {
        $symbol = $quote.symbol
        $name = $quote.shortName
        $price = "{0:N2}" -f $quote.regularMarketPrice
		$low = "{0:N2}" -f $quote.regularMarketDayLow
		$high = "{0:N2}" -f $quote.regularMarketDayHigh
		$change = "{0:N2}" -f $quote.regularMarketChangePercent

        $row = [PSCustomObject]@{
            Symbol = $symbol
            Name = $name
            Price = $price
			Low = $low
			High = $high
			Change = $change + '%'
        }
        $table += $row
    }

    $table | Format-Table
} else {
    Write-Host "Failed to fetch stock data."`n
}

# CRYPTO
function ListCryptoRate { 
    param([string]$Symbol, [string]$Name)
    $Rates = (Invoke-WebRequest -URI "https://min-api.cryptocompare.com/data/price?fsym=$Symbol&tsyms=USD,EUR,RUB,CNY" -userAgent "curl" -useBasicParsing).Content | ConvertFrom-Json
    $USD = "{0:N2}" -f $Rates.USD
    New-Object PSObject -property @{ 'Cryptocurrency' = "$Name ($Symbol) ="; 'USD' = $USD; }
}

function ListCryptoRates { 
    ListCryptoRate BTC   "Bitcoin"
    ListCryptoRate ETH   "Ethereum"
    ListCryptoRate DOGE  "Dogecoin"
}

try {
    ListCryptoRates | Format-Table -property @{e='Cryptocurrency';width=28},USD
    # Wait for user input before closing
    Read-Host "Press Enter to exit"
    exit 0 # success
} catch {
    "⚠️ Error in line $($_.InvocationInfo.ScriptLineNumber): $($Error[0])"
    exit 1
}

Read-Host "Press Enter to exit"