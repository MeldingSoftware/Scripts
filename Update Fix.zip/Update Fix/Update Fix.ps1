# Stop Windows Update service
Stop-Service -Name wuauserv -Force

# Reset Windows Update components
$components = @("wuauserv", "cryptSvc", "bits", "msiserver")
foreach ($component in $components) {
    Stop-Service -Name $component -Force
}

Remove-Item -Path C:\Windows\SoftwareDistribution -Recurse -Force
Remove-Item -Path C:\Windows\System32\catroot2 -Recurse -Force

foreach ($component in $components) {
    Start-Service -Name $component
}

# Start Windows Update service
Start-Service -Name wuauserv

Write-Host "[DONE] Update Fix completed"`n -ForegroundColor Green
Read-Host "Press Enter to exit"