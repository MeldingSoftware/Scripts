Write-Host "This can take several minutes"
Write-Host "Checking for largest files..." -ForegroundColor Cyan

# Get the largest files
$largestFiles = Get-ChildItem -Path C:\ -Recurse -File -ErrorAction SilentlyContinue |
    Sort-Object Length -Descending | 
    Select-Object -First 10 @{Name="Gigabytes";Expression={[Math]::Round($_.Length / 1GB, 2)}}, FullName

$largestFiles | Format-Table -AutoSize

# Get the directory of the currently executing script
$scriptDirectory = $PSScriptRoot

# Save the information about the largest files to a text file in the script's directory
$largestFiles | Out-File -FilePath "$scriptDirectory\Largest Files.txt" -Encoding ASCII

Write-Host "[Done] Largest Files.txt saved"`n -ForegroundColor Green

Read-Host "Press Enter to exit"