# Change the current directory to the directory containing the script
Set-Location -Path $PSScriptRoot

# Get a list of specific .mum files and store in List.txt
Get-ChildItem "$env:SystemRoot\servicing\Packages\Microsoft-Windows-GroupPolicy-ClientExtensions-Package~3*.mum" | Select-Object -ExpandProperty Name | Out-File -FilePath .\List.txt -Encoding ASCII
Get-ChildItem "$env:SystemRoot\servicing\Packages\Microsoft-Windows-GroupPolicy-ClientTools-Package~3*.mum" | Select-Object -ExpandProperty Name | Out-File -FilePath .\List.txt -Encoding ASCII -Append

# Loop through each line in List.txt and execute DISM command for each .mum file found
Get-Content .\List.txt | ForEach-Object {
    $packagePath = Join-Path $env:SystemRoot\servicing\Packages $_
    dism /online /norestart /add-package:"$packagePath"
}

Write-Host ""
Write-Host "[DONE] Installing Group Policy Editor completed"`n -ForegroundColor Green 
Read-Host "Press Enter to exit"