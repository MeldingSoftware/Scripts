Stop-Service -Name Spooler
Remove-Item -Path "$env:windir\system32\spool\printers\*.shd" -Force
Remove-Item -Path "$env:windir\system32\spool\printers\*.spl" -Force
Start-Service -Name Spooler

Write-Host "[Done] Print Spooler Fix completed"`n -ForegroundColor Green

Read-Host "Press Enter to exit"