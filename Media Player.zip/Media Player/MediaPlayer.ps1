# DLLs for show and hide console
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'

# Function to hide the console window
function Hide-Console {
    $consolePtr = [Console.Window]::GetConsoleWindow()
    [Console.Window]::ShowWindow($consolePtr, 0)  # 0 = Hide the window
}

# Add necessary WPF and Windows Forms assemblies
Add-Type -AssemblyName PresentationCore, PresentationFramework
Add-Type -AssemblyName System.Windows.Forms

# Hide the PowerShell console window at the start
Hide-Console

# Define emojis
$LoadEmoji = [char]0x2630  # ☰
$PlayEmoji = [char]0x25B6   # ▶
$PauseEmoji = [char]0x23F8  # ⏸
$RewindEmoji = [char]0x23EA  # ⏪
$FastForwardEmoji = [char]0x23E9  # ⏩
$FullscreenEmoji = [char]0x2921 
$CloseEmoji = [char]0x274C  # ❌

# XAML Definition
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Media Player" ResizeMode="CanResizeWithGrip" 
        WindowStartupLocation="CenterScreen" Width="1200" Height="600" Background="Black">
    <Grid>
        <MediaElement Stretch="Fill" Name="MediaPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" VerticalAlignment="Bottom" Margin="0,0,0,20" Name="ButtonPanel">
            <Button Content="$LoadEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="LoadButton" />
            <Button Content="$PlayEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="PlayButton" />
            <Button Content="$PauseEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="PauseButton" />
            <Button Content="$RewindEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="RewindButton" />
            <Button Content="$FastForwardEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="FastForwardButton" />
            <Button Width="80" Height="40" Name="FullscreenButton">
			<TextBlock Text="$FullscreenEmoji" FontSize="35" FontFamily="Segoe UI Emoji" VerticalAlignment="Center" Margin="0,-5,0,0" />
			</Button>
            <Button Content="$CloseEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="CloseButton" />
            <Slider Orientation="Horizontal" Width="200" Height="25" Minimum="0" Maximum="1" Name="VolumeSlider" 
        Value="1" IsMoveToPointEnabled="True" VerticalAlignment="Center" Margin="10,0,0,0" />

        </StackPanel>
    </Grid>
</Window>
"@

# Load XAML
$reader = New-Object System.Xml.XmlNodeReader $XAML
$window = [Windows.Markup.XamlReader]::Load($reader)

# Access elements
$mediaPlayer = $window.FindName("MediaPlayer")
$loadButton = $window.FindName("LoadButton")
$playButton = $window.FindName("PlayButton")
$pauseButton = $window.FindName("PauseButton")
$rewindButton = $window.FindName("RewindButton")
$fastForwardButton = $window.FindName("FastForwardButton")
$fullscreenButton = $window.FindName("FullscreenButton")
$closeButton = $window.FindName("CloseButton")
$volumeSlider = $window.FindName("VolumeSlider")
$buttonPanel = $window.FindName("ButtonPanel")

# Save the original window position and size
$originalWindowState = @{
    Left   = $window.Left
    Top    = $window.Top
    Width  = $window.Width
    Height = $window.Height
}

# Timer to hide buttons and slider after 1 second
$hideButtonsTimer = New-Object System.Windows.Threading.DispatcherTimer
$hideButtonsTimer.Interval = [System.TimeSpan]::FromSeconds(1)
$hideButtonsTimer.Add_Tick({
    if ($mediaPlayer.HasVideo -or $mediaPlayer.HasAudio) {
        Hide-Controls
    }
})

# Function to start the timer to hide buttons and slider
function Start-HideButtonsTimer {
    $hideButtonsTimer.Start()
}

# Function to hide buttons, slider, and cursor when the media is playing
function Hide-Controls {
    $playButton.Visibility = "Collapsed"
    $pauseButton.Visibility = "Collapsed"
    $rewindButton.Visibility = "Collapsed"
    $fastForwardButton.Visibility = "Collapsed"
    $closeButton.Visibility = "Collapsed"
    $loadButton.Visibility = "Collapsed"
    $fullscreenButton.Visibility = "Collapsed"
    $volumeSlider.Visibility = "Collapsed"  # Hide the volume slider
    $window.Cursor = "None"  # Hide the cursor
}

# Function to show buttons, slider, and cursor when mouse moves
function Show-Controls {
    $playButton.Visibility = "Visible"
    $pauseButton.Visibility = "Visible"
    $rewindButton.Visibility = "Visible"
    $fastForwardButton.Visibility = "Visible"
    $closeButton.Visibility = "Visible"
    $loadButton.Visibility = "Visible"
    $fullscreenButton.Visibility = "Visible"
    $volumeSlider.Visibility = "Visible"  # Show the volume slider
    $window.Cursor = "Arrow"  # Show the cursor
}

# Button Actions
$loadButton.Add_Click({
    $fileDialog = New-Object Windows.Forms.OpenFileDialog
    $fileDialog.Filter = "Media Files|*.mp4;*.mp3;*.wmv;*.avi;*.mkv|All Files|*.*"
    if ($fileDialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) {
        $mediaPlayer.Source = New-Object Uri($fileDialog.FileName)
        $fileLoaded = $true
        $mediaPlayer.Play()
        $hideButtonsTimer.Start()
    }
})

$playButton.Add_Click({ $mediaPlayer.Play() })
$pauseButton.Add_Click({ $mediaPlayer.Pause() })
$rewindButton.Add_Click({ $mediaPlayer.Position = $mediaPlayer.Position.Add([TimeSpan]::FromSeconds(-10)) })
$fastForwardButton.Add_Click({ $mediaPlayer.Position = $mediaPlayer.Position.Add([TimeSpan]::FromSeconds(10)) })
$fullscreenButton.Add_Click({ Toggle-Fullscreen })
$closeButton.Add_Click({ $mediaPlayer.Stop(); $window.Close() })

# Volume Slider
$volumeSlider.Add_ValueChanged({
    $mediaPlayer.Volume = $volumeSlider.Value
})

# Fullscreen Functionality
function Toggle-Fullscreen {
    $currentPosition = $mediaPlayer.Position

    # Check if the window is maximized and restore to normal windowed mode
    if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
        $window.WindowState = [System.Windows.WindowState]::Normal
    }

    if ($window.WindowStyle -eq "None") {
        # Restore original window state
        $window.WindowStyle = "SingleBorderWindow"
        $window.ResizeMode = "CanResizeWithGrip"
        $window.Topmost = $false
        $window.Left = $originalWindowState.Left
        $window.Top = $originalWindowState.Top
        $window.Width = $originalWindowState.Width
        $window.Height = $originalWindowState.Height
    } else {
        # Save current window state
        $originalWindowState.Left = $window.Left
        $originalWindowState.Top = $window.Top
        $originalWindowState.Width = $window.Width
        $originalWindowState.Height = $window.Height

        # Get the current screen of the window
        $screen = [System.Windows.Forms.Screen]::FromHandle([System.Windows.Interop.WindowInteropHelper]::new($window).Handle)

        # Enter fullscreen on the current monitor
        $window.WindowStyle = "None"
        $window.ResizeMode = "NoResize"
        $window.Topmost = $true
        $window.Left = $screen.Bounds.Left
        $window.Top = $screen.Bounds.Top
        $window.Width = $screen.Bounds.Width
        $window.Height = $screen.Bounds.Height
    }

    # Restore the playback position
    $mediaPlayer.Position = $currentPosition
}

# Mouse Events
$window.Add_MouseMove({
    if ($mediaPlayer.HasVideo -or $mediaPlayer.HasAudio) {
        Show-Controls
        $hideButtonsTimer.Stop()
        $hideButtonsTimer.Start()
    }
})

# Double-click to toggle fullscreen, excluding buttons and volume slider
$window.Add_MouseDoubleClick({
    $source = $_.OriginalSource
    # Traverse up the visual tree to check if the source is a Button or within a Button/Slider
    while ($source -ne $null) {
        if ($source -is [System.Windows.Controls.Button] -or $source -is [System.Windows.Controls.Slider]) {
            return  # Exit without toggling fullscreen if a button or slider was double-clicked
        }
        $source = [System.Windows.Media.VisualTreeHelper]::GetParent($source)
    }

    # If the click is outside of buttons and slider, toggle fullscreen
    Toggle-Fullscreen
})

# Exit fullscreen with ESC
$window.Add_KeyDown({
    if ($_.Key -eq [System.Windows.Input.Key]::Escape -and $window.WindowStyle -eq "None") {
        Toggle-Fullscreen
    }
})

# Start Timer
$hideButtonsTimer.Start()

# Show Window
$window.ShowDialog()
