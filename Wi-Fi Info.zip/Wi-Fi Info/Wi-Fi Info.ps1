# Get Wi-Fi profiles
$profiles = (netsh wlan show profiles) | Select-String "All User Profile\s+:\s(.+)"

# Array to store Wi-Fi information
$wifiInfo = @()

if ($profiles) {
    # Loop through each Wi-Fi profile
    foreach ($profile in $profiles) {
        $profileName = $profile.Matches.Groups[1].Value.Trim()
        $profileInfo = (netsh wlan show profile name="$profileName" key=clear)
        
        # Get the Wi-Fi password
        $password = $profileInfo | Select-String "Key Content\s+:\s(.+)" | 
            ForEach-Object { $_.Matches.Groups[1].Value.Trim() }

        # Store Wi-Fi profile and password information
        $wifiInfo += [PSCustomObject]@{
            SSID = $profileName
            PASSWORD = $password
        }
    }

    # Output Wi-Fi information to console
    $wifiInfo | Format-Table -AutoSize
} else {
    Write-Host "No Wi-Fi profiles found on this computer."
}

# Get the directory of the currently executing script
$scriptDirectory = $PSScriptRoot

# Save Wi-Fi information to a text file in the script's directory
$wifiInfo | Out-File -FilePath "$scriptDirectory\Wifi Info.txt" -Encoding ASCII

Write-Host "[DONE] Wi-Fi Info.txt saved"`n -ForegroundColor Green
Read-Host "Press Enter to exit"