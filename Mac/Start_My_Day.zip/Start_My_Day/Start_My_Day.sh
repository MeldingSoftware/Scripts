#!/bin/bash

# Maximize the terminal window
osascript -e 'tell application "Terminal" to tell window 1 to set zoomed to true'

# Check if jq is installed
if ! command -v jq &> /dev/null; then
    # If jq is not installed, install it
    echo "Installing jq..."
    brew install jq
fi

# Clear the screen
clear


# Display the current day and date
formattedDate=$(date +"%A, %B %d, %Y")
echo "$formattedDate"


echo ""


# API key and host
API_KEY="REPLACE WITH RAPIDAPI KEY"
API_HOST="numbersapi.p.rapidapi.com"

# Get today's date in the format required by the API (month/day)
DATE=$(date "+%m/%d")

# Make the API call
RESPONSE=$(curl -s -X GET "https://numbersapi.p.rapidapi.com/${DATE}/date?fragment=true&json=true" -H "X-RapidAPI-Key: $API_KEY" -H "X-RapidAPI-Host: $API_HOST")

# Extract the year and text from the response
YEAR=$(echo "$RESPONSE" | jq -r ".year")
TEXT=$(echo "$RESPONSE" | jq -r ".text")

# Display the result
echo "On this day in $YEAR:"
echo "$TEXT"


echo ""


# API key
API_KEY="REPLACE WITH KEY"

# API URL
API_URL="https://quotes.rest/qod"

# Make the API call
RESPONSE=$(curl -s -H "X-TheySaidSo-Api-Secret: $API_KEY" $API_URL)

# Extract the quote and author from the response
QUOTE=$(echo "$RESPONSE" | jq -r ".contents.quotes[0].quote")
AUTHOR=$(echo "$RESPONSE" | jq -r ".contents.quotes[0].author")

# Display the quote of the day
echo "Quote of the Day:"
echo "$QUOTE - $AUTHOR"


echo ""


# Get the public IP address of the user
ip=$(curl -s "https://api.ipify.org/?format=json" | jq -r '.ip')

# Get the location (latitude and longitude) using the IP address
location=$(curl -s "http://ip-api.com/json/$ip")

# Extract the city and country from the location data
city=$(echo $location | jq -r '.city')
country=$(echo $location | jq -r '.country')

# Use the National Weather Service API to get the weather data
weatherData=$(curl -s "https://api.weather.gov/points/$(echo $location | jq -r '.lat'),$(echo $location | jq -r '.lon')")

# Get the forecast URL from the weather data
forecastUrl=$(echo $weatherData | jq -r '.properties.forecast')

# Get the forecast data from the forecast URL
forecastData=$(curl -s $forecastUrl)

# Filter for This Afternoon and Tonight periods
filteredPeriods=$(echo $forecastData | jq -r '.properties.periods[] | select(.name == "Today" or .name == "This Afternoon" or .name == "Tonight")')

# Display the weather forecast
echo "Weather forecast for $city, $country:"
echo "$filteredPeriods" | jq -r '"\(.name): \(.temperature)°\(.temperatureUnit) - \(.detailedForecast)"'

# Get and display weather alerts
alertsUrl=$(echo $weatherData | jq -r '.properties.alerts')
if [ "$alertsUrl" != "null" ]; then
    alertsData=$(curl -s $alertsUrl)
    if [ $(echo $alertsData | jq '.features | length') -eq 0 ]; then
        echo "No active weather alerts for your area."
    else
        echo "Active weather alerts:"
        echo $alertsData | jq -r '.features[] | "Title: \(.properties.headline)\nDescription: \(.properties.description)\n-----"'
    fi
else
    echo "There are no weather alerts for your area."
fi


echo ""


# News Script
echo "News:"
RSS_URL="https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en"
maxLines=10

content=$(curl -s $RSS_URL | grep -o '<title>[^<]*' | sed 's/<title>//')

count=0
while read -r line; do
    if [[ $line =~ "Top stories" ]]; then
        continue
    fi
    if [ $count -ge $maxLines ]; then
        break
    fi
    title=$(echo "$line" | sed 's/News\s*//;s/\s*[0-9]\{4\}$//')  # Remove "News" prefix and year at the end
    echo "$title"
    ((count++))
done <<< "$content"


echo ""


# SPORTS
# Function to fetch and display sports games
function GetSportsGames {
    local api_url=$1
    local headers=$2
    local league=$3

    response=$(curl -s -H "${headers[0]}" -H "${headers[1]}" "$api_url" | jq -r '.response[] | select(.league.name == "NBA" or .league.name == "NFL" or .league.name == "NCAA" or .league.name == "NHL" or .league.name == "MLB")')

    if [[ "$response" == "[]" ]]; then
        echo "No $league games found."
    else
        if [ "$sportDisplayed" == "true" ]; then
            echo ""
        fi
        echo "$league -"
        echo "$response" | jq -r '. | "\(.teams.away.name) @ \(.teams.home.name)"' | sed '$!s/$/\n/'
        sportDisplayed="true"
    fi
}


# Sports section with a single blank line before and after
echo ""
echo "Sports:"
echo ""

# Get today's date
date=$(date +"%Y-%m-%d")

# Timezone for API 
# See Sports Time Zones.txt
timezone="America%2FDetroit"

# API headers for NBA
headersNBA=(
    "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host: api-basketball.p.rapidapi.com"
)

# API headers for NFL and NCAA Football
headersNFLNCAA=(
    "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host: api-american-football.p.rapidapi.com"
)

# API headers for NHL
headersNHL=(
    "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host: api-hockey.p.rapidapi.com"
)

# API headers for MLB
headersMLB=(
    "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host: api-baseball.p.rapidapi.com"
)

# Get NBA games
GetSportsGames "https://api-basketball.p.rapidapi.com/games?timezone=$timezone&date=$date" "$headersNBA" "NBA"

# Get NFL games
GetSportsGames "https://api-american-football.p.rapidapi.com/games?date=$date&timezone=$timezone" "$headersNFLNCAA" "NFL"

# Get NCAA Football games
GetSportsGames "https://api-american-football.p.rapidapi.com/games?date=$date&timezone=$timezone" "$headersNFLNCAA" "NCAA Football"

# Get NHL games
GetSportsGames "https://api-hockey.p.rapidapi.com/games/?date=$date&timezone=$timezone" "$headersNHL" "NHL"

# Get MLB games
GetSportsGames "https://api-baseball.p.rapidapi.com/games?timezone=$timezone&date=$date" "$headersMLB" "MLB"



echo ""



# LOTTO
echo "Lotto:"

# Mega Millions
curl -s -H "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY" -H "X-RapidAPI-Host: mega-millions.p.rapidapi.com" "https://mega-millions.p.rapidapi.com/latest" | jq -r '.data[0] | "Mega Millions Last Drawing: \(.NumberSet) - Next Jackpot is \(.NextJackPot)"'

# Powerball
curl -s -H "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY" -H "X-RapidAPI-Host: powerball.p.rapidapi.com" "https://powerball.p.rapidapi.com/latest" | jq -r '.data[0] | "Powerball Last Drawing: \(.NumberSet) - Next Jackpot is \(.NextJackPot)"'


echo ""


# STOCKS
echo "Stocks:"
# Define the API endpoint and headers for stocks
API_URL="https://yahoo-finance15.p.rapidapi.com/api/v1/markets/stock/quotes?ticker=%5EDJI%2C%5EIXIC%2C%5ESPX%2CGC%3DF%2CCL%3DF"
HEADERS=(
    "X-RapidAPI-Key: REPLACE WITH RAPIDAPI KEY"
    "X-RapidAPI-Host: yahoo-finance15.p.rapidapi.com"
)

# Make the API request for stocks and format the output using jq
curl -s -H "${HEADERS[0]}" -H "${HEADERS[1]}" "$API_URL" | jq -r '["Symbol", "Name", "Price", "Low", "High", "Percent"], (.body[] | [.symbol, .shortName, (.regularMarketPrice | tonumber | tostring | split(".") | .[0] + "." + .[1][0:2]), (.regularMarketDayLow | tonumber | tostring | split(".") | .[0] + "." + .[1][0:2]), (.regularMarketDayHigh | tonumber | tostring | split(".") | .[0] + "." + .[1][0:2]), (.regularMarketChangePercent | tostring | split(".") | .[0] + "." + .[1][0:2])]) | @tsv' | column -s $'\t' -t


echo ""


# CRYPTO
function ListCryptoRate { 
    Symbol=$1
    Name=$2
    Rates=$(curl -s "https://min-api.cryptocompare.com/data/price?fsym=$Symbol&tsyms=USD,EUR,RUB,CNY" | jq -r '.USD')
    USD=$(printf "%.2f" $Rates)
    printf "%s\n" "$Name ($Symbol) = \$$USD"
}

function ListCryptoRates { 
    ListCryptoRate BTC   "Bitcoin"
    ListCryptoRate ETH   "Ethereum"
    ListCryptoRate DOGE  "Dogecoin"
}

echo "Crypto:"
ListCryptoRates
