# Create System Info Directory
$desktopPath = [Environment]::GetFolderPath("Desktop") + "\System Info"

if (!(Test-Path $desktopPath)) {
    New-Item $desktopPath -ItemType Directory
}

# Set output file path
$outputFilePath = "$desktopPath\System Info.txt"

# Redirect output to file
$out = New-Object -TypeName System.IO.StreamWriter -ArgumentList $outputFilePath

# Get OS version
$os = Get-WmiObject Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture

# Get computer manufacturer and model
$computerSystem = Get-WmiObject Win32_ComputerSystem | Select-Object Manufacturer, Model

# Get system serial number
$serialNumber = Get-WmiObject Win32_BIOS | Select-Object SerialNumber

# Get BIOS version
$bios = Get-WmiObject Win32_BIOS | Select-Object Manufacturer, SMBIOSBIOSVersion

# Get network adapter info
$networkAdapters = Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true } | Select-Object Description, IPAddress

# Get RAM information
$ramModules = Get-WmiObject Win32_PhysicalMemory
$ramCapacity = ($ramModules | Measure-Object Capacity -Sum).Sum / 1GB
$ramSpeeds = $ramModules | Select-Object -ExpandProperty Speed
$ramSpeed = ($ramSpeeds | Measure-Object -Minimum).Minimum

# Get CPU information
$cpu = Get-WmiObject Win32_Processor | Select-Object Name, MaxClockSpeed

# Get GPU information
$gpu = Get-WmiObject Win32_VideoController | Select-Object Name

# Function to determine drive type (HDD or SSD)
function Get-DriveType {
    param (
        [string]$DriveLetter
    )
    $drive = Get-WmiObject Win32_DiskDrive | Where-Object { $_.DeviceID -eq $DriveLetter }
    if ($drive.MediaType -eq 'Fixed hard disk media') {
        return 'SSD'
    } else {
        return 'HDD'
    }
}

# Get storage drive information
$drives = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 } | Select-Object DeviceID, VolumeName, Size, FreeSpace
$drives | ForEach-Object {
    $driveType = Get-DriveType $_.DeviceID
    $_ | Add-Member -MemberType NoteProperty -Name 'DriveType' -Value $driveType
}

# Output system information to file
$out.WriteLine("Operating System: $($os.Caption) $($os.Version) $($os.OSArchitecture)")
$out.WriteLine()
$out.WriteLine("Manufacturer: $($computerSystem.Manufacturer)")
$out.WriteLine()
$out.WriteLine("Model: $($computerSystem.Model)")
$out.WriteLine()
$out.WriteLine("Serial Number: $($serialNumber.SerialNumber)")
$out.WriteLine()
$out.WriteLine("BIOS:")
$out.WriteLine("Manufacturer: $($bios.Manufacturer)")
$out.WriteLine("Version: $($bios.SMBIOSBIOSVersion)")
$out.WriteLine()
$out.WriteLine("Network Adapters:")
$networkAdapters | ForEach-Object {
    $out.WriteLine("Description: $($_.Description)")
    $out.WriteLine("IP Address: $($_.IPAddress)")
    $out.WriteLine()
}
$out.WriteLine("CPU: $($cpu.Name) - Max Clock Speed: $($cpu.MaxClockSpeed) MHz")
$out.WriteLine()
$out.WriteLine("GPU: $($gpu.Name)")
$out.WriteLine()
$out.WriteLine("RAM: $($ramCapacity) GB - Speed: $($ramSpeed) MHz")
$out.WriteLine()
$out.WriteLine("Storage Drives:")
$drives | ForEach-Object {
    $out.WriteLine("Drive Letter: $($_.DeviceID)")
    $out.WriteLine("Volume Name: $($_.VolumeName)")
    $out.WriteLine("Size: $([math]::Round(($_.Size / 1GB), 2)) GB")
    $out.WriteLine("Free Space: $([math]::Round(($_.FreeSpace / 1GB), 2)) GB")
    $out.WriteLine("Drive Type: $($_.DriveType)")
    $out.WriteLine()
}

# Close output file
$out.Close()

# Generate battery report
powercfg /batteryreport /output "$desktopPath/battery-report.html"

