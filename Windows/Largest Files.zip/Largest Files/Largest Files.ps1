Write-Host "This can take several minutes"`n
Write-Host "Checking for largest files on all drives..." -ForegroundColor Cyan

# Helper function to format file sizes
function Format-FileSize {
    param ([long]$size)
    switch ($true) {
        { $size -ge 1TB } { return "{0:N2} TB" -f ($size / 1TB) }
        { $size -ge 1GB } { return "{0:N2} GB" -f ($size / 1GB) }
        { $size -ge 1MB } { return "{0:N2} MB" -f ($size / 1MB) }
        { $size -ge 1KB } { return "{0:N2} KB" -f ($size / 1KB) }
        default { return "$size B" }
    }
}

# Get all filesystem drives (e.g., C:, D:, E:, etc.)
$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match '^[A-Z]:\\$' }

# Collect files from all drives, excluding the Windows folder (system root)
$allFiles = foreach ($drive in $drives) {
    Get-ChildItem -Path $drive.Root -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { -not ($_.FullName -like "$($env:SystemRoot)\*") }
}

# Get the largest files across all drives
$largestFiles = $allFiles |
    Sort-Object Length -Descending |
    Select-Object -First 10 @{
        Name       = "Size"
        Expression = { Format-FileSize $_.Length }
    }, FullName

$largestFiles | Format-Table -AutoSize

# Get the directory of the currently executing script
$scriptDirectory = $PSScriptRoot

# Save the information about the largest files to a text file in the script's directory
$largestFiles | Out-File -FilePath "$scriptDirectory\Largest Files.txt" -Encoding ASCII

Write-Host "[Done] Largest Files.txt saved"`n -ForegroundColor Green

Read-Host "Press Enter to exit"
