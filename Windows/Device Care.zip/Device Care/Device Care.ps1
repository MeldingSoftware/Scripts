﻿#requires -Version 5.1
#requires -RunAsAdministrator
[CmdletBinding()]
param([switch]$PreflightOnly)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$base = 'https://raw.githubusercontent.com/MeldingSoftware/Scripts/main/Windows/'
$stage = Join-Path $env:LOCALAPPDATA ('Device Care Staging\' + [guid]::NewGuid().ToString('N'))
$desktop = [Environment]::GetFolderPath('Desktop')
$downloads = Join-Path $env:USERPROFILE 'Downloads'
$helper = Join-Path $env:TEMP '.ThreatInspectionLink.ps1'
$ps = Join-Path $PSHOME 'powershell.exe'
function Assert-Syntax([string]$path) {
    $tokens = $null; $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$errors)
    if ($errors.Count) { throw "Invalid PowerShell: $path : $($errors[0].Message)" }
    return $ast
}
function Replace-One([string]$source,[string]$pattern,[string]$replacement,[string]$label) {
    $rx = [regex]::new($pattern)
    if ($rx.Matches($source).Count -ne 1) { throw "Unsupported upstream layout: $label. No maintenance will run." }
    return $rx.Replace($source,[System.Text.RegularExpressions.MatchEvaluator]{param($m) $replacement},1)
}
function Get-Tool([string]$name,[string]$pattern) {
    $zip = Join-Path $stage ($name + '.zip')
    $dest = Join-Path $stage $name
    Invoke-WebRequest -UseBasicParsing -Uri ($base + [uri]::EscapeDataString($name + '.zip')) -OutFile $zip
    Expand-Archive -LiteralPath $zip -DestinationPath $dest
    $matches = @(Get-ChildItem -LiteralPath $dest -Recurse -File -Filter '*.ps1' | Where-Object { $_.Name -match $pattern })
    if ($matches.Count -ne 1) { throw "Expected one main script in $name ZIP; found $($matches.Count)." }
    $null = Assert-Syntax $matches[0].FullName
    return $matches[0].FullName
}
function Encode([string]$s) { [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($s)) }
try {
    Write-Host 'Checking scripts...' -ForegroundColor Cyan
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $maint = Get-Tool 'Maintenance' '^Maintenance\.ps1$'
    $threat = Get-Tool 'Threat Inspection' '^(?:Threat[ _-]*Inspection)(?:[ _-]*v?[\d.]+)?\.ps1$'
    $t = [IO.File]::ReadAllText($threat)
    $m = [IO.File]::ReadAllText($maint)
    $ast = Assert-Syntax $threat
    if ('NoOpenReport' -notin @($ast.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })) { throw 'Threat Inspection does not support NoOpenReport.' }
    # Find a single literal Deep Scan prompt, not a comment or unrelated prompt.
    # Only supported prompt forms are replaced; fail before Maintenance otherwise.
    $deepPrompts = @($ast.FindAll({ param($node)
        if ($node -isnot [System.Management.Automation.Language.CommandAst]) { return $false }
        if ($node.GetCommandName() -notin @('Read-Host','Read-YesNoPrompt')) { return $false }
        return @($node.CommandElements | Where-Object {
            $_ -is [System.Management.Automation.Language.StringConstantExpressionAst] -and
            $_.Value -match '(?i)\bdeep[\s-]*scan\b'
        }).Count -eq 1
    }, $true))
    if ($deepPrompts.Count -ne 1) { throw 'Unsupported Threat Inspection Deep Scan prompt; expected one literal Read-Host or Read-YesNoPrompt call. No maintenance will run.' }
    $deepPrompt = $deepPrompts[0]
    $deepPromptText = @($deepPrompt.CommandElements | Where-Object {
        $_ -is [System.Management.Automation.Language.StringConstantExpressionAst] -and $_.Value -match '(?i)\bdeep[\s-]*scan\b'
    })[0].Value
    # Avoid changing prompts that use custom arguments, pipelines or output redirection.
    if ($deepPrompt.Redirections.Count -or $deepPrompt.CommandElements.Count -gt 3 -or
        ($deepPrompt.CommandElements.Count -eq 3 -and $deepPrompt.CommandElements[1].Extent.Text -ine '-Prompt')) {
        throw 'Unsupported Deep Scan prompt arguments. No maintenance will run.'
    }
    $deepReplacement = 'Write-Output $env:DEVICE_CARE_DEEP_SCAN'
    if ($deepPrompt.GetCommandName() -ieq 'Read-YesNoPrompt') {
        $deepFunctions = @($ast.FindAll({ param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ieq 'Read-YesNoPrompt' }, $true))
        if ($deepFunctions.Count -ne 1 -or $deepFunctions[0].Extent.Text -notmatch '(?im)\breturn\s*\(\s*\$\w+\s+-eq\s+[''"]y[''"]\s*\)') { throw 'Unsupported Deep Scan yes/no helper return type. No maintenance will run.' }
        $deepReplacement = 'Write-Output ($env:DEVICE_CARE_DEEP_SCAN -eq ''y'')'
    }
    $t = $t.Substring(0,$deepPrompt.Extent.StartOffset) + $deepReplacement + $t.Substring($deepPrompt.Extent.EndOffset)
    # Keep the persistent report-link helper as a single file directly in user Temp.
    $t = Replace-One $t '(?m)^([ \t]*)\$helperPath\s*=\s*[^\r\n]*[\r]?$' '        $helperPath = Join-Path $env:TEMP ''.ThreatInspectionLink.ps1''' 'Threat Inspection helper assignment'
    # Exclude exactly that file; leave all other Temp cleanup untouched.
    $m = Replace-One $m '(?m)^([ \t]*)Get-ChildItem -LiteralPath \$cleanPath -Force -ErrorAction SilentlyContinue \|\r?\n[ \t]*Remove-Item -Recurse -Force -ErrorAction SilentlyContinue' @'
                    Get-ChildItem -LiteralPath $cleanPath -Force -ErrorAction SilentlyContinue |
                        Where-Object { $_.FullName -ine (Join-Path $env:TEMP '.ThreatInspectionLink.ps1') } |
                        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
'@ 'Maintenance Temp cleanup'
    # The post-restart helper reads the threat report path recorded after inspection.
    # First verify the expected hook and reboot instruction before any system maintenance.
    $hook = '(?m)^[ \t]*Start-Process `\$finalReportPath[ \t]*\r?$'
    if ([regex]::Matches($m,$hook).Count -ne 1) { throw 'Unsupported Maintenance post-restart report hook.' }
    if ($m -notmatch '(?im)^\s*Shutdown /r /t 0\s*$') { throw 'Unsupported Maintenance restart behavior.' }
    [IO.File]::WriteAllText($threat,$t,[Text.UTF8Encoding]::new($true))
    [IO.File]::WriteAllText($maint,$m,[Text.UTF8Encoding]::new($true))
    $null = Assert-Syntax $threat; $null = Assert-Syntax $maint
    $stage64 = Encode $stage
    # Recognize both direct and double-nested extractions of the package.
    # Snapshot exact file hashes and folder creation times before maintenance.
    $folder64 = ''
    $folder = Join-Path $downloads 'Device Care'
    $inner = Join-Path $folder 'Device Care'
    if ($PSScriptRoot -ieq $folder -or $PSScriptRoot -ieq $inner) {
        try {
            $outer = Get-Item -LiteralPath $folder -Force
            $root = Get-Item -LiteralPath $PSScriptRoot -Force
            $cutoff = (Get-Date).AddHours(-24)
            $expected = @('Device Care.ps1','Run Me.bat','Read Me.txt')
            $children = @(Get-ChildItem -LiteralPath $root.FullName -Force)
            $outerChildren = @(Get-ChildItem -LiteralPath $folder -Force)
            $nested = $root.FullName -ieq $inner
            if ($outer.Attributes -band [IO.FileAttributes]::ReparsePoint -or $root.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse point' }
            if ($outer.CreationTime -lt $cutoff -and $outer.LastWriteTime -lt $cutoff) { throw 'Folder older than 24 hours' }
            if ($nested -and ($outerChildren.Count -ne 1 -or $outerChildren[0].FullName -ine $inner)) { throw 'Extra outer folder contents' }
            if ($children.Count -ne 3 -or @($children | Where-Object { $_.PSIsContainer -or $_.Attributes -band [IO.FileAttributes]::ReparsePoint -or $_.Name -notin $expected }).Count -ne 0) { throw 'Unexpected package contents' }
            $manifest = [ordered]@{ Folder=$outer.FullName; Root=$root.FullName; Nested=$nested; OuterCreated=$outer.CreationTimeUtc.Ticks.ToString(); RootCreated=$root.CreationTimeUtc.Ticks.ToString(); Files=@($children | ForEach-Object { @{ Name=$_.Name; Hash=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash } }) }
            $folder64 = Encode ($manifest | ConvertTo-Json -Depth 4 -Compress)
        } catch { Write-Host "Downloads folder cleanup skipped: $($_.Exception.Message)" -ForegroundColor Yellow }
    } else { Write-Host 'Downloads folder cleanup skipped: not launched from Downloads\Device Care.' -ForegroundColor Yellow }
    $zip64 = Encode (Join-Path $downloads 'Device Care.zip')
    # Inject into Maintenance's existing RunOnce script, after final report creation.
    $post = @'
    try { Start-Process `$finalReportPath } catch { }
    try {
        `$dcStage = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__STAGE__'))
        `$dcPathFile = Join-Path `$dcStage 'ThreatReportPath.txt'
        if (Test-Path -LiteralPath `$dcPathFile -PathType Leaf) {
            `$dcThreat = [IO.File]::ReadAllText(`$dcPathFile)
            if (Test-Path -LiteralPath `$dcThreat -PathType Leaf) { Start-Process `$dcThreat }
        }
    } catch { }
    try {
        `$dcStage = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__STAGE__'))
        if (Test-Path -LiteralPath `$dcStage -PathType Container) { Remove-Item -LiteralPath `$dcStage -Recurse -Force }
    } catch { }
    try {
        `$dcManifestText = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__FOLDER__'))
        if (`$dcManifestText) {
            `$dcManifest = `$dcManifestText | ConvertFrom-Json
            `$dcOuter = Get-Item -LiteralPath `$dcManifest.Folder -Force -ErrorAction Stop
            `$dcRoot = Get-Item -LiteralPath `$dcManifest.Root -Force -ErrorAction Stop
            if (`$dcOuter.Attributes -band [IO.FileAttributes]::ReparsePoint -or `$dcRoot.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Folder is a reparse point' }
            if (`$dcOuter.CreationTimeUtc.Ticks.ToString() -ne `$dcManifest.OuterCreated -or `$dcRoot.CreationTimeUtc.Ticks.ToString() -ne `$dcManifest.RootCreated) { throw 'Folder identity changed' }
            `$dcChildren = @(Get-ChildItem -LiteralPath `$dcRoot.FullName -Force -ErrorAction Stop)
            if (`$dcChildren.Count -ne 3) { throw 'Package contents changed' }
            if (`$dcManifest.Nested) {
                `$dcOuterChildren = @(Get-ChildItem -LiteralPath `$dcOuter.FullName -Force -ErrorAction Stop)
                if (`$dcOuterChildren.Count -ne 1 -or `$dcOuterChildren[0].FullName -ine `$dcRoot.FullName) { throw 'Outer package contents changed' }
            }
            foreach (`$dcFile in `$dcManifest.Files) {
                `$dcEntry = Get-Item -LiteralPath (Join-Path `$dcRoot.FullName `$dcFile.Name) -Force -ErrorAction Stop
                if (`$dcEntry.PSIsContainer -or `$dcEntry.Attributes -band [IO.FileAttributes]::ReparsePoint -or (Get-FileHash -LiteralPath `$dcEntry.FullName -Algorithm SHA256).Hash -ne `$dcFile.Hash) { throw 'Package file changed' }
            }
            Set-Location -LiteralPath ([Environment]::GetFolderPath('UserProfile'))
            for (`$dcAttempt=0; `$dcAttempt -lt 5; `$dcAttempt++) {
                try { Remove-Item -LiteralPath `$dcOuter.FullName -Recurse -Force -ErrorAction Stop; break }
                catch { if (`$dcAttempt -eq 4) { throw }; Start-Sleep -Seconds 2 }
            }
        }
    } catch {
        try { Add-Content -LiteralPath (Join-Path `$env:LOCALAPPDATA 'Device Care Cleanup.log') -Value ((Get-Date).ToString('s') + ' Folder cleanup: ' + `$_.Exception.Message) } catch { }
    }
    try {
        `$dcZip = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__ZIP__'))
        if (Test-Path -LiteralPath `$dcZip -PathType Leaf) {
            `$dcItem = Get-Item -LiteralPath `$dcZip -Force
            if (`$dcItem.LastWriteTime -ge (Get-Date).AddHours(-24) -and -not (`$dcItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) { Remove-Item -LiteralPath `$dcZip -Force }
        }
    } catch { }
'@
    $post = $post.Replace('__STAGE__',$stage64).Replace('__FOLDER__',$folder64).Replace('__ZIP__',$zip64)
    $m = Replace-One $m $hook $post 'Maintenance report hook'
    $m = Replace-One $m '(?im)^[ \t]*Write-Host "Restarting computer now\." -ForegroundColor Cyan[ \t]*\r?\n[ \t]*Shutdown /r /t 0[ \t]*\r?$' @'
    [IO.File]::WriteAllText((Join-Path $env:DEVICE_CARE_STAGE 'Maintenance.complete'), 'OK')
'@ 'Maintenance restart deferral'
    [IO.File]::WriteAllText($maint,$m,[Text.UTF8Encoding]::new($true))
    $null = Assert-Syntax $maint
    Write-Host 'Both downloads and compatibility checks passed.' -ForegroundColor Green
    if ($PreflightOnly) { Write-Host 'Preflight only: no inspection, maintenance, or Downloads cleanup performed.'; Remove-Item -LiteralPath $stage -Recurse -Force; return }
    do {
        $deepAnswer = (Read-Host $deepPromptText.TrimEnd(':')).Trim().ToLowerInvariant()
        if ($deepAnswer -eq 'qq') { Write-Host 'Device Care canceled.'; Remove-Item -LiteralPath $stage -Recurse -Force; return }
        if ($deepAnswer -notin @('y','n')) { Write-Host 'Please enter y or n.' -ForegroundColor Yellow }
    } until ($deepAnswer -in @('y','n'))
    $env:DEVICE_CARE_DEEP_SCAN = $deepAnswer
    $env:DEVICE_CARE_STAGE = $stage
    & $ps -NoLogo -NoProfile -ExecutionPolicy Bypass -File $maint
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $stage 'Maintenance.complete') -PathType Leaf)) { throw 'Maintenance did not reach its successful restart point. Threat Inspection and automatic restart skipped.' }
    $started = Get-Date
    Write-Host "`nThreat Inspection" -ForegroundColor Cyan
    & $ps -NoLogo -NoProfile -ExecutionPolicy Bypass -File $threat -NoOpenReport
    if ($LASTEXITCODE -ne 0) { throw "Threat Inspection failed: $LASTEXITCODE. Automatic restart skipped." }
    $report = @(Get-ChildItem -LiteralPath $desktop -File -Filter 'Threat Inspection*.html' | Where-Object {$_.LastWriteTime -ge $started.AddSeconds(-2)} | Sort-Object LastWriteTime -Descending | Select-Object -First 1)
    if ($report.Count -ne 1 -or -not (Test-Path -LiteralPath $helper -PathType Leaf)) { throw 'Fresh Threat Inspection report or Temp helper missing. Automatic restart skipped.' }
    [IO.File]::WriteAllText((Join-Path $stage 'ThreatReportPath.txt'), $report[0].FullName)
    Write-Host "`nRestarting computer now." -ForegroundColor Cyan
    & shutdown.exe /r /t 0
    if ($LASTEXITCODE -ne 0) { throw 'Restart command failed. Restart manually to complete Maintenance.' }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Staging (for troubleshooting): $stage"
    exit 1
}
