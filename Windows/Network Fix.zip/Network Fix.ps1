﻿# Initialize transcript path
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $ScriptDirectory) { $ScriptDirectory = $env:USERPROFILE } # Fallback
$TranscriptPath = Join-Path -Path $ScriptDirectory -ChildPath "NetworkFix.txt"


function Remove-TranscriptHeaderFooter {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    try {
        $lines = @(Get-Content -LiteralPath $Path -ErrorAction Stop)
        $cleanLines = New-Object System.Collections.Generic.List[string]
        $skipBlock = $false

        foreach ($line in $lines) {
            if (-not $skipBlock -and $line -match '^\*+$') {
                # Hold the separator temporarily so we can determine whether it begins
                # a PowerShell transcript metadata block.
                $cleanLines.Add($line)
                continue
            }

            if ($cleanLines.Count -gt 0 -and
                $cleanLines[$cleanLines.Count - 1] -match '^\*+$' -and
                $line -match '^Windows PowerShell transcript (start|end)$') {

                # Remove the separator we just buffered and skip through the closing separator.
                $cleanLines.RemoveAt($cleanLines.Count - 1)
                $skipBlock = $true
                continue
            }

            if ($skipBlock) {
                if ($line -match '^\*+$') {
                    $skipBlock = $false
                }
                continue
            }

            $cleanLines.Add($line)
        }

        # Avoid accumulating blank lines where transcript metadata was removed.
        while ($cleanLines.Count -gt 0 -and [string]::IsNullOrWhiteSpace($cleanLines[0])) {
            $cleanLines.RemoveAt(0)
        }
        while ($cleanLines.Count -gt 0 -and [string]::IsNullOrWhiteSpace($cleanLines[$cleanLines.Count - 1])) {
            $cleanLines.RemoveAt($cleanLines.Count - 1)
        }

        Set-Content -LiteralPath $Path -Value $cleanLines -Encoding UTF8
    }
    catch {
        Write-Host "Failed to clean transcript header/footer: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

# Start Transcript
try {
    Start-Transcript -Path $TranscriptPath -Append
} catch {
    Write-Host "Failed to start transcript. Ensure you have write permissions." -ForegroundColor Red
    return
}

Write-Host ""

# Test Connectivity
Write-Host "Testing connectivity" -ForegroundColor Cyan
try {
    $PingResult = Test-Connection -ComputerName 8.8.8.8 -Count 1 -ErrorAction Stop
    if ($PingResult) {
        foreach ($Ping in $PingResult) {
            Write-Host "Ping to $($Ping.Address): Response Time = $($Ping.ResponseTime) ms, Status = Success"`n -ForegroundColor Green
        }
    } else {
        Write-Host "Connectivity test failed" -ForegroundColor Red
    }
} catch {
    Write-Host "Error during connectivity test: $_" -ForegroundColor Red
}

Write-Host ""

# Reset Network Settings
Write-Host "Resetting network settings" -ForegroundColor Cyan
try {
    ipconfig /release | Out-Null
    Write-Host "IP address released" -ForegroundColor Green

    ipconfig /flushdns | Out-Null
    Write-Host "DNS flushed" -ForegroundColor Green

    ipconfig /renew | Out-Null
    Write-Host "IP address renewed" -ForegroundColor Green

    netsh int ip reset | Out-Null
    Write-Host "TCP/IP stack reset" -ForegroundColor Green

    netsh winsock reset | Out-Null
    Write-Host "Winsock catalog reset" -ForegroundColor Green
	
	Write-Host "[Done] Resettting network settings complete" -ForegroundColor Green
} catch {
    Write-Host "Error resetting network settings: $_" -ForegroundColor Red
}

Write-Host ""

# Download and Run DNS Jumper
$TempPath = $Env:Temp
$DnsJumperZip = Join-Path -Path $TempPath -ChildPath "DnsJumper.zip"
$DnsJumperFolder = Join-Path -Path $TempPath -ChildPath "DnsJumper"

try {
    Invoke-WebRequest -Uri "https://customresolutionutility.b-cdn.net/DnsJumper.zip" -OutFile $DnsJumperZip -ErrorAction Stop
    Expand-Archive -Path $DnsJumperZip -DestinationPath $DnsJumperFolder -Force
    $DnsJumperExe = Join-Path -Path $DnsJumperFolder -ChildPath "DnsJumper\DnsJumper.exe"
    if (Test-Path $DnsJumperExe) {
        Write-Host "DNS Jumper" -ForegroundColor Cyan
        Write-Host "Select 'Fastest DNS', select 'Start DNS Test', and select 'Apply DNS Server'. Exit DNS Jumper to continue." -ForegroundColor Yellow
        Start-Process -FilePath $DnsJumperExe -Wait
    } else {
        throw "DNS Jumper executable not found at expected path: $DnsJumperExe"
    }
} catch {
    Write-Host "Failed to download or run DNS Jumper: $_" -ForegroundColor Red
}

Write-Host ""

# Get Current DNS
Write-Host "Retrieving current DNS server" -ForegroundColor Cyan
$DnsConfig = Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.ServerAddresses -ne $null } | Select-Object -First 1
if ($DnsConfig) {
    $PreferredDNS = $DnsConfig.ServerAddresses[0]
    $AlternateDNS = if ($DnsConfig.ServerAddresses.Count -gt 1) { $DnsConfig.ServerAddresses[1] } else { "None" }
    Write-Host "Current DNS" -ForegroundColor Cyan
    Write-Host "Preferred DNS: $PreferredDNS" -ForegroundColor Green
    Write-Host "Alternate DNS: $AlternateDNS" -ForegroundColor Green
} else {
    Write-Host "No current DNS server found" -ForegroundColor Red
}

Write-Host ""

# Delete Temp Folder Items
Write-Host "Cleaning up temporary files" -ForegroundColor Cyan
try {
    Remove-Item -Path $DnsJumperZip -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $DnsJumperFolder -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "[Done] Temporary files deleted successfully" -ForegroundColor Green
} catch {
    Write-Host "Failed to delete temporary files: $_" -ForegroundColor Red
}

Write-Host ""

# Speedtest
Write-Host "Speedtest" -ForegroundColor Cyan

function Get-SpeedtestExecutable {
    # First, use the current PATH if Speedtest is already available.
    $command = Get-Command "speedtest.exe" -ErrorAction SilentlyContinue
    if ($command -and $command.Source) {
        return $command.Source
    }

    # WinGet commonly exposes portable applications through this links folder.
    $wingetLink = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links\speedtest.exe"
    if (Test-Path -LiteralPath $wingetLink) {
        return $wingetLink
    }

    # Fallback: locate the executable inside WinGet's package directory.
    $wingetPackages = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"
    if (Test-Path -LiteralPath $wingetPackages) {
        $candidate = Get-ChildItem -Path $wingetPackages -Filter "speedtest.exe" -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -match 'Ookla\.Speedtest\.CLI' } |
            Select-Object -First 1

        if ($candidate) {
            return $candidate.FullName
        }
    }

    return $null
}

try {
    $SpeedtestExecutable = Get-SpeedtestExecutable

    if (-not $SpeedtestExecutable) {
        Write-Host "Speedtest not installed. Installing..." -ForegroundColor Yellow

        $wingetProcess = Start-Process -FilePath "winget.exe" -ArgumentList @(
            "install",
            "--id", "Ookla.Speedtest.CLI",
            "-e",
            "--source", "winget",
            "--accept-package-agreements",
            "--accept-source-agreements"
        ) -Wait -PassThru

        if ($wingetProcess.ExitCode -ne 0) {
            throw "WinGet installation failed with exit code $($wingetProcess.ExitCode)."
        }

        # Refresh PATH in this already-running PowerShell session.
        $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        $env:Path = "$machinePath;$userPath"

        $SpeedtestExecutable = Get-SpeedtestExecutable

        if (-not $SpeedtestExecutable) {
            throw "Speedtest installed, but speedtest.exe could not be located."
        }

        Write-Host "Speedtest installed successfully" -ForegroundColor Green
    }
    else {
        Write-Host "Speedtest is already installed" -ForegroundColor Green
    }

    Write-Host "Running Speedtest" -ForegroundColor Cyan
    & $SpeedtestExecutable --accept-license --accept-gdpr

    if ($LASTEXITCODE -ne 0) {
        throw "Speedtest exited with code $LASTEXITCODE."
    }

    Write-Host ""
    Write-Host "[Done] Running Speedtest complete" -ForegroundColor Green
}
catch {
    Write-Host "Failed to check, install, or run Speedtest: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Stop Transcript
try {
    Write-Host "Transcript stopped. Results saved to: $TranscriptPath" -ForegroundColor Green
    Write-Host ""
    Stop-Transcript | Out-Null
    Remove-TranscriptHeaderFooter -Path $TranscriptPath
} catch {
    Write-Host "Failed to stop transcript." -ForegroundColor Red
}


