
# Initialize transcript path
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Definition
if (-not $ScriptDirectory) { $ScriptDirectory = $env:USERPROFILE } # Fallback
$TranscriptPath = Join-Path -Path $ScriptDirectory -ChildPath "NetworkFix.txt"

# Start Transcript
try {
    Start-Transcript -Path $TranscriptPath -Append
} catch {
    Write-Host "Failed to start transcript. Ensure you have write permissions." -ForegroundColor Red
    return
}

Write-Host ""

# Test Connectivity
Write-Host "Testing connectivity" -ForegroundColor Cyan
try {
    $PingResult = Test-Connection -ComputerName 8.8.8.8 -Count 1 -ErrorAction Stop
    if ($PingResult) {
        foreach ($Ping in $PingResult) {
            Write-Host "Ping to $($Ping.Address): Response Time = $($Ping.ResponseTime) ms, Status = Success"`n -ForegroundColor Green
        }
    } else {
        Write-Host "Connectivity test failed" -ForegroundColor Red
    }
} catch {
    Write-Host "Error during connectivity test: $_" -ForegroundColor Red
}

Write-Host ""

# Reset Network Settings
Write-Host "Resetting network settings" -ForegroundColor Cyan
try {
    ipconfig /release | Out-Null
    Write-Host "IP address released" -ForegroundColor Green

    ipconfig /flushdns | Out-Null
    Write-Host "DNS flushed" -ForegroundColor Green

    ipconfig /renew | Out-Null
    Write-Host "IP address renewed" -ForegroundColor Green

    netsh int ip reset | Out-Null
    Write-Host "TCP/IP stack reset" -ForegroundColor Green

    netsh winsock reset | Out-Null
    Write-Host "Winsock catalog reset" -ForegroundColor Green
	
	Write-Host "[Done] Resettting network settings complete" -ForegroundColor Green
} catch {
    Write-Host "Error resetting network settings: $_" -ForegroundColor Red
}

Write-Host ""

# Download and Run DNS Jumper
$TempPath = $Env:Temp
$DnsJumperZip = Join-Path -Path $TempPath -ChildPath "DnsJumper.zip"
$DnsJumperFolder = Join-Path -Path $TempPath -ChildPath "DnsJumper"

try {
    Invoke-WebRequest -Uri "https://customresolutionutility.b-cdn.net/DnsJumper.zip" -OutFile $DnsJumperZip -ErrorAction Stop
    Expand-Archive -Path $DnsJumperZip -DestinationPath $DnsJumperFolder -Force
    $DnsJumperExe = Join-Path -Path $DnsJumperFolder -ChildPath "DnsJumper\DnsJumper.exe"
    if (Test-Path $DnsJumperExe) {
        Write-Host "DNS Jumper" -ForegroundColor Cyan
        Write-Host "Select 'Fastest DNS', select 'Start DNS Test', and select 'Apply DNS Server'. Exit DNS Jumper to continue." -ForegroundColor Yellow
        Start-Process -FilePath $DnsJumperExe -Wait
    } else {
        throw "DNS Jumper executable not found at expected path: $DnsJumperExe"
    }
} catch {
    Write-Host "Failed to download or run DNS Jumper: $_" -ForegroundColor Red
}

Write-Host ""

# Get Current DNS
Write-Host "Retrieving current DNS server" -ForegroundColor Cyan
$DnsConfig = Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.ServerAddresses -ne $null } | Select-Object -First 1
if ($DnsConfig) {
    $PreferredDNS = $DnsConfig.ServerAddresses[0]
    $AlternateDNS = if ($DnsConfig.ServerAddresses.Count -gt 1) { $DnsConfig.ServerAddresses[1] } else { "None" }
    Write-Host "Current DNS" -ForegroundColor Cyan
    Write-Host "Preferred DNS: $PreferredDNS" -ForegroundColor Green
    Write-Host "Alternate DNS: $AlternateDNS" -ForegroundColor Green
} else {
    Write-Host "No current DNS server found" -ForegroundColor Red
}

Write-Host ""

# Delete Temp Folder Items
Write-Host "Cleaning up temporary files" -ForegroundColor Cyan
try {
    Remove-Item -Path $DnsJumperZip -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $DnsJumperFolder -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "[Done] Temporary files deleted successfully" -ForegroundColor Green
} catch {
    Write-Host "Failed to delete temporary files: $_" -ForegroundColor Red
}

Write-Host ""

# Speedtest
Write-Host "Speedtest" -ForegroundColor Cyan
$SpeedtestAppID = "9NBLGGH4Z1JC"

try {
    # Check if Speedtest is installed via AppxPackage or executable in PATH
    $SpeedtestInstalled = Get-AppxPackage | Where-Object { $_.PackageFamilyName -like "*$SpeedtestAppID*" }
    if (-not $SpeedtestInstalled) {
        # Fallback: Check if speedtest executable is in PATH
        $SpeedtestExecutable = Get-Command "speedtest" -ErrorAction SilentlyContinue
    }

    if (-not $SpeedtestInstalled -and -not $SpeedtestExecutable) {
        Write-Host "Speedtest not installed. Installing..." -ForegroundColor Yellow
        Start-Process -FilePath "winget" -ArgumentList "install --id Speedtest.Ookla -e --accept-package-agreements --accept-source-agreements" -Wait
        Write-Host "Speedtest installed successfully" -ForegroundColor Green
    } else {
        Write-Host "Speedtest is already installed" -ForegroundColor Green
    }

    # Run Speedtest inline
    Write-Host "Running Speedtest" -ForegroundColor Cyan
    & speedtest --accept-license --accept-gdpr
	Write-Host ""
	Write-Host "[Done] Running Speedtest complete" -ForegroundColor Green
} catch {
    Write-Host "Failed to check, install, or run Speedtest: $_" -ForegroundColor Red
}

Write-Host ""

# Stop Transcript
try {
    Write-Host "Transcript stopped. Results saved to: $TranscriptPath" -ForegroundColor Green
	Write-Host ""
	Stop-Transcript
} catch {
    Write-Host "Failed to stop transcript." -ForegroundColor Red
}
