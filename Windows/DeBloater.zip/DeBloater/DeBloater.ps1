# Current Windows 10/11 optional consumer/inbox apps that are safe to target
# when the user explicitly selects Bloatware. Core utilities and dependencies
# (Store, App Installer, Calculator, Camera, Snipping Tool, Notepad, Terminal,
# Photos, Sticky Notes, Quick Assist, Web Experience, Cross Device and Gaming
# Services) are intentionally preserved.
$MicrosoftBloatware = @(
    'Clipchamp.Clipchamp',
    'Microsoft.3DBuilder',
    'Microsoft.549981C3F5F10',             # Cortana (legacy Win10)
    'Microsoft.BingFinance',
    'Microsoft.BingFoodAndDrink',
    'Microsoft.BingHealthAndFitness',
    'Microsoft.BingNews',
    'Microsoft.BingSports',
    'Microsoft.BingTranslator',
    'Microsoft.BingTravel',
    'Microsoft.BingWeather',
    'Microsoft.Copilot',
    'Microsoft.GetHelp',
    'Microsoft.Getstarted',
    'Microsoft.Messaging',
    'Microsoft.Microsoft3DViewer',
    'Microsoft.MicrosoftJournal',
    'Microsoft.MicrosoftOfficeHub',
    'Microsoft.MicrosoftSolitaireCollection',
    'Microsoft.MixedReality.Portal',
    'Microsoft.Music.Preview',
    'Microsoft.NetworkSpeedTest',
    'Microsoft.News',
    'Microsoft.Office.OneNote',
    'Microsoft.Office.Sway',
    'Microsoft.OneConnect',
    'Microsoft.OutlookForWindows',
    'Microsoft.People',
    'Microsoft.PowerAutomateDesktop',
    'Microsoft.Print3D',
    'Microsoft.SkypeApp',
    'Microsoft.Windows.DevHome',
    'Microsoft.WindowsFeedbackHub',
    'Microsoft.WindowsMaps',
    'Microsoft.WindowsPhone',
    'Microsoft.GamingApp',                  # current Xbox app
    'Microsoft.Xbox.TCUI',
    'Microsoft.XboxApp',                    # legacy Xbox Console Companion
    'Microsoft.XboxGameOverlay',
    'Microsoft.XboxGamingOverlay',          # Xbox Game Bar
    'Microsoft.XboxIdentityProvider',
    'Microsoft.XboxSpeechToTextOverlay',
    'Microsoft.YourPhone',
    'Microsoft.ZuneVideo',                  # Movies & TV; Media Player is preserved
    'MicrosoftCorporationII.MicrosoftFamily',
    'MicrosoftTeams',                       # legacy/consumer Teams
    'MSTeams',                              # current Teams package
    'MixedRealityLearning'
)

# Third-party promotional apps are removed only when they are provisioned by
# Windows/OEM. This avoids deleting a copy the user intentionally installed.
$SponsoredProvisionedPatterns = @(
    '*AdobePhotoshopExpress*',
    '*Amazon*',
    '*PrimeVideo*',
    '*BubbleWitch*',
    '*CandyCrush*',
    '*DisneyMagicKingdoms*',
    '*Duolingo*',
    '*FarmVille*',
    '*Facebook*',
    '*Flipboard*',
    '*HULU*',
    '*iHeartRadio*',
    '*Instagram*',
    '*LinkedIn*',
    '*MarchofEmpires*',
    '*Netflix*',
    '*Pandora*',
    '*Phototastic*',
    '*PicsArt*',
    '*SlingTV*',
    '*Spotify*',
    '*TikTok*',
    '*TuneInRadio*',
    '*Twitter*',
    '*Viber*',
    '*WinZip*'
)

Write-Host "Removing bloatware" -ForegroundColor Cyan

try {
    $installedPkgs = @(Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue)
    $provPkgs = @(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue)

    $targetNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($name in $MicrosoftBloatware) { [void]$targetNames.Add($name) }

    foreach ($pattern in $SponsoredProvisionedPatterns) {
        foreach ($prov in @($provPkgs | Where-Object { $_.DisplayName -like $pattern })) {
            if ($prov.DisplayName) { [void]$targetNames.Add([string]$prov.DisplayName) }
        }
    }

    $removedInstalled = 0
    $removedProvisioned = 0
    $failedRemovals = 0
    $seenInstalled = @{}
    $seenProvisioned = @{}

    foreach ($appName in $targetNames) {
        foreach ($pkg in @($installedPkgs | Where-Object { $_.Name -eq $appName })) {
            if ($seenInstalled.ContainsKey($pkg.PackageFullName)) { continue }
            $seenInstalled[$pkg.PackageFullName] = $true

            if ($pkg.NonRemovable) {
                Write-Host "[SKIPPED] Protected package: $($pkg.Name)" -ForegroundColor DarkGray
                continue
            }

            try {
                Remove-AppxPackage -Package $pkg.PackageFullName -AllUsers -ErrorAction Stop
                $removedInstalled++
            }
            catch {
                $failedRemovals++
                Write-Host "[WARNING] Could not remove $($pkg.Name): $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }

        foreach ($prov in @($provPkgs | Where-Object { $_.DisplayName -eq $appName })) {
            if ($seenProvisioned.ContainsKey($prov.PackageName)) { continue }
            $seenProvisioned[$prov.PackageName] = $true

            try {
                Remove-AppxProvisionedPackage -Online -PackageName $prov.PackageName -ErrorAction Stop | Out-Null
                $removedProvisioned++
            }
            catch {
                $failedRemovals++
                Write-Host "[WARNING] Could not deprovision $($prov.DisplayName): $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
    }

    if ($failedRemovals -gt 0) {
        Write-Host "[WARNING] Bloatware cleanup removed $removedInstalled installed package(s) and $removedProvisioned provisioned package(s); $failedRemovals removal(s) could not be completed.`n" -ForegroundColor Yellow
    }
    else {
        Write-Host "[DONE] Bloatware cleanup removed $removedInstalled installed package(s) and $removedProvisioned provisioned package(s).`n" -ForegroundColor Green
    }
}
catch {
    Write-Host "[ERROR] Bloatware cleanup failed: $($_.Exception.Message)`n" -ForegroundColor Red
}

Read-Host "Press Enter to exit"
