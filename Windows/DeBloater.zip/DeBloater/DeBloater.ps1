$AppsList = @(
'ACGMediaPlayer',
'ActiproSoftwareLLC',
'AdobeSystemsIncorporated.AdobePhotoshopExpress',
'Amazon.com.Amazon',
'AmazonVideo.PrimeVideo',
'Asphalt8Airborne',
'AutodeskSketchBook',
'C27EB4BA.DropboxOEM',
'CaesarsSlotsFreeCasino',
'Clipchamp.Clipchamp',
'COOKINGFEVER',
'CyberLinkMediaSuiteEssentials',
'Disney',
'DisneyMagicKingdoms',
'Dolby',
'DrawboardPDF',
'Duolingo-LearnLanguagesforFree',
'EclipseManager',
'Facebook',
'FarmVille2CountryEscape',
'fitbit',
'Flipboard',
'HiddenCity',
'HULULLC.HULUPLUS',
'iHeartRadio',
'Instagram',
'king.com.BubbleWitch3Saga',
'king.com.CandyCrushSaga',
'king.com.CandyCrushSodaSaga',
'Kodi',
'LinkedInforWindows',
'MarchofEmpires',
'Microsoft.3DBuilder',
'Microsoft.549981C3F5F10',
'Microsoft.BingFinance',
'Microsoft.BingFoodAndDrink',
'Microsoft.BingHealthAndFitness',
'Microsoft.BingNews',
'Microsoft.BingSearch',
'Microsoft.BingSports',
'Microsoft.BingTranslator',
'Microsoft.BingTravel',
'Microsoft.BingWeather',
'Microsoft.Copilot',
'Microsoft.GamingApp',
'Microsoft.GetHelp',
'Microsoft.Getstarted',
'Microsoft.Messaging',
'Microsoft.Microsoft3DViewer',
'Microsoft.MicrosoftJournal',
'Microsoft.MicrosoftOfficeHub',
'Microsoft.MicrosoftPowerBIForWindows',
'Microsoft.MicrosoftSolitaireCollection',
'Microsoft.MicrosoftStickyNotes',
'Microsoft.MixedReality.Portal',
'Microsoft.Music.Preview',
'Microsoft.NetworkSpeedTest',
'Microsoft.News',
'Microsoft.Office.OneNote',
'Microsoft.Office.Sway',
'Microsoft.OneConnect',
'Microsoft.OneDrive',
'Microsoft.OutlookForWindows',
'Microsoft.People',
'Microsoft.PowerAutomateDesktop',
'Microsoft.Print3D',
'Microsoft.RemoteDesktop',
'Microsoft.ScreenSketch',
'Microsoft.SkypeApp',
'Microsoft.Todos',
'Microsoft.Whiteboard',
'Microsoft.Windows.DevHome',
'Microsoft.WindowsAlarms',
'Microsoft.WindowsCalculator',
'Microsoft.WindowsCamera',
'Microsoft.windowscommunicationsapps',
'Microsoft.WindowsFeedbackHub',
'Microsoft.WindowsMaps',
'Microsoft.WindowsPhone',
'Microsoft.WindowsSoundRecorder',
'Microsoft.Xbox.TCUI',
'Microsoft.XboxApp',
'Microsoft.XboxGameOverlay',
'Microsoft.XboxGamingOverlay',
'Microsoft.XboxIdentityProvider',
'Microsoft.XboxSpeechToTextOverlay',
'Microsoft.YourPhone',
'Microsoft.ZuneMusic',
'Microsoft.ZuneVideo',
'MicrosoftCorporationII.MicrosoftFamily',
'MicrosoftCorporationII.QuickAssist',
'MicrosoftTeams',
'MicrosoftWindows.CrossDevice',
'MixedRealityLearning',
'Movies & TV',
'MSTeams',
'Netflix',
'NYTCrossword',
'OneCalendar',
'PandoraMediaInc',
'PhototasticCollage',
'PicsArt-PhotoStudio',
'Plex',
'PolarrPhotoEditorAcademicEdition',
'Royal Revolt',
'Shazam',
'Sidia.LiveWallpaper',
'SlingTV',
'Speed Test',
'Spotify',
'TikTok',
'TuneInRadio',
'Twitter',
'Viber',
'WhatsApp',
'WinZipUniversal',
'Wunderlist',
'XING'
)

# Cache provisioned packages once
$provPkgs = Get-AppxProvisionedPackage -Online

Write-Host "Removing bloatware" -ForegroundColor Cyan

foreach ($App in $AppsList) {
    # Installed (per-user) removal
    $installed = Get-AppxPackage -Name $App -AllUsers -ErrorAction SilentlyContinue
    if ($installed) {
        foreach ($pkg in $installed) {
            Write-Verbose "Removing installed: $($pkg.PackageFullName)"
            Remove-AppxPackage -Package $pkg.PackageFullName -ErrorAction SilentlyContinue 
        }
    } else {
        Write-Verbose "Not installed: $App"
    }

    # Provisioned (new-user) removal
    $prov = $provPkgs | Where-Object { $_.DisplayName -eq $App }
    if ($prov) {
        Write-Verbose "Removing provisioned: $($prov.PackageName)"
        Remove-AppxProvisionedPackage -Online -PackageName $prov.PackageName -ErrorAction SilentlyContinue 
    } else {
        Write-Verbose "No provisioned package found for: $App"
    }
}

Write-Host "[DONE] Removing bloatware completed`n" -ForegroundColor Green
Read-Host "Press Enter to exit"