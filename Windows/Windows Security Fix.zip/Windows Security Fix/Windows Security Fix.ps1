# WINDOWS SECURITY FIX

# Detect Windows version
$osVersion = (Get-CimInstance Win32_OperatingSystem).Version
$isWin11 = [version]$osVersion -ge [version]"10.0.22000"

# 1. Remove DisableAntiSpyware registry key (if exists)
try {
    Write-Host "Removing 'DisableAntiSpyware' registry key" -ForegroundColor Cyan
    cmd.exe /c REG DELETE "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /f
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[DONE] Registry key deleted successfully.`n" -ForegroundColor Green
    } else {
        Write-Host "[SKIPPED] Registry key not found. No action needed.`n" -ForegroundColor Green
    }
} catch {
    Write-Host "An unexpected error occurred during registry cleanup: $_`n" -ForegroundColor Red
}

# 2. Reset or Re-register the Windows Security app (SecHealthUI)
try {
    Write-Host "Repairing Windows Security (SecHealthUI)" -ForegroundColor Cyan
    if ($isWin11) {
        Write-Host "Detected Windows 11: Using Reset-AppxPackage" -ForegroundColor DarkCyan
        Get-AppxPackage Microsoft.SecHealthUI -AllUsers | Reset-AppxPackage
        Write-Host "[DONE] Reset with Reset-AppxPackage.`n" -ForegroundColor Green
    } else {
        Write-Host "Detected Windows 10: Verifying if Security app launches" -ForegroundColor DarkCyan
        try {
            Start-Process "windowsdefender:"
            Start-Sleep -Seconds 3

            $proc = Get-Process -Name "SecHealthUI" -ErrorAction SilentlyContinue
            if ($proc) {
                $proc | Stop-Process -Force
                Write-Host "[INFO] Closed Windows Security after confirming launch." -ForegroundColor DarkGray
            }
            Write-Host "[SKIPPED] App launches successfully. Reset not needed.`n" -ForegroundColor Green
        } catch {
            Write-Host "App failed to launch. Attempting re-registration" -ForegroundColor Yellow
            $path = Get-ChildItem "C:\Windows\SystemApps" | Where-Object { $_.Name -like "Microsoft.SecHealthUI*" }
            if ($path) {
                $manifest = Join-Path $path.FullName "AppxManifest.xml"
                if (Test-Path $manifest) {
                    Add-AppxPackage -Register $manifest -DisableDevelopmentMode -Force
                    Write-Host "[DONE] Re-registered Windows Security app.`n" -ForegroundColor Green
                } else {
                    Write-Host "Manifest file not found in $($path.FullName).`n" -ForegroundColor Red
                }
            } else {
                Write-Host "SecHealthUI folder not found in SystemApps.`n" -ForegroundColor Red
            }
        }
    }
} catch {
    Write-Host "Error repairing Windows Security UI: $_`n" -ForegroundColor Red
}

# 3. Re-enable Defender services
Write-Host "Ensuring core Defender services are set to start automatically" -ForegroundColor Cyan
Set-Service -Name WinDefend -StartupType Automatic -ErrorAction SilentlyContinue
Set-Service -Name SecurityHealthService -StartupType Automatic -ErrorAction SilentlyContinue
Set-Service -Name wscsvc -StartupType Automatic -ErrorAction SilentlyContinue
Write-Host "[DONE] Service startup types verified.`n" -ForegroundColor Green

# 4. Clear Defender group policy settings (if any)
Write-Host "Clearing Group Policy settings that may interfere with Defender" -ForegroundColor Cyan
Remove-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Antivirus" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Group Policy settings cleared (if present).`n" -ForegroundColor Green

# 5. Re-register Windows Defender WMI provider (fixes broken services)
Write-Host "Re-registering Defender WMI components (if needed)" -ForegroundColor Cyan
Get-WmiObject -Namespace "root\Microsoft\Windows\Defender" -List | Out-Null
if ($?) {
    Write-Host "[DONE] WMI Namespace exists. Re-registration not required.`n" -ForegroundColor Green
} else {
    Write-Host "Attempting to re-register WMI namespace" -ForegroundColor DarkYellow
    mofcomp.exe "%programfiles%\Windows Defender\MpProvider.mof"
    mofcomp.exe "%programfiles%\Windows Defender\MpProvider.mfl"
}

Write-Host "[COMPLETE] Windows Security Fix finished. You may need to restart your PC.`n" -ForegroundColor Green
Read-Host "Press Enter to close"
