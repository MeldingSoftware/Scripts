# Function to get the BitLocker Recovery Key and save it to a text file if found
function Get-BitLockerRecoveryKey {
    try {
        # Get the directory of the currently executing script
        $scriptDirectory = $PSScriptRoot
        if ([string]::IsNullOrEmpty($scriptDirectory)) {
            $scriptDirectory = $PWD.Path  # Use the current directory if script directory is undefined
        }

        # Define the output file path
        $outputFile = Join-Path -Path $scriptDirectory -ChildPath "BitLockerRecoveryKey.txt"

        # Initialize an array to store recovery key information
        $outputContent = @()

        # Get the BitLocker volume information
        $bitlockerVolumes = Get-BitLockerVolume
        foreach ($volume in $bitlockerVolumes) {
            if ($volume.ProtectionStatus -eq 1) {  # 1 indicates 'On'
                $outputContent += "Recovery Key for drive $($volume.MountPoint):"
                $volume.KeyProtector | Where-Object { $_.KeyProtectorType -eq 'RecoveryPassword' } |
                ForEach-Object {
                    $outputContent += "Recovery Password: $($_.RecoveryPassword)"
                }
            }
        }

        # Only create the output file if recovery keys are found
        if ($outputContent.Count -gt 0) {
            $outputContent | Out-File -FilePath $outputFile -Encoding UTF8
            Write-Host "Recovery key(s) saved to $outputFile"
        } else {
            Write-Host "No BitLocker-protected drives or recovery keys found.`n"
        }

    } catch {
        Write-Host "Failed to retrieve the BitLocker recovery key. Error: $($_.Exception.Message)"
    }
}

# Execute the function
Get-BitLockerRecoveryKey

# Wait for user input before exiting
Read-Host "Press enter to exit"