﻿# Add The Required C#, .Net, Namespace, And Classes

Add-Type -AssemblyName System.Windows.Forms

#---------------------------------------------------------------------------------------------
# Initiate A Form Object

$Form = New-Object System.Windows.Forms.Form
$Form.AutoScroll = $True 
$Form.Text = "Melder"
$Form.Size = New-Object System.Drawing.Size(1200,650)
$Form.StartPosition = "CenterScreen"

# Fonts
$TabFont = New-Object System.Drawing.Font("Arial",13,[System.Drawing.Fontstyle]::Bold)
$HeaderFont = New-Object System.Drawing.Font("Times New Roman",13,[System.Drawing.Fontstyle]::Regular)
$BodyFont = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.Fontstyle]::Regular)
$RunFont = New-Object System.Drawing.Font("Arial",17,[System.Drawing.Fontstyle]::Bold)
$ButtonFont = New-Object System.Drawing.Font("Arial",11,[System.Drawing.Fontstyle]::Bold)
$ListBoxFont = New-Object System.Drawing.Font("Lucida Console",10.5,[System.Drawing.Fontstyle]::Regular)

$TabControl = New-Object System.Windows.Forms.TabControl
$TabControl.Dock = [System.Windows.Forms.DockStyle]::Fill
$TabControl.Font = $TabFont
$Form.Controls.Add($TabControl)

#---------------------------------------------------------------------------------------------
# Functions

# DLL's for show, hide, and focus console
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);

[DllImport("user32.dll")]
public static extern bool SetForegroundWindow(IntPtr hWnd);
'

function Show-Console
{
    $consolePtr = [Console.Window]::GetConsoleWindow()

    # Hide = 0,
    # ShowNormal = 1,
    # ShowMinimized = 2,
    # ShowMaximized = 3,
    # Maximize = 3,
    # ShowNormalNoActivate = 4,
    # Show = 5,
    # Minimize = 6,
    # ShowMinNoActivate = 7,
    # ShowNoActivate = 8,
    # Restore = 9,
    # ShowDefault = 10,
    # ForceMinimized = 11

    [Console.Window]::ShowWindow($consolePtr, 3)              # Show/maximize console
    [Console.Window]::SetForegroundWindow($consolePtr) | Out-Null  # Ensure focus
}

function Hide-Console
{
    $consolePtr = [Console.Window]::GetConsoleWindow()
    #0 hide
    [Console.Window]::ShowWindow($consolePtr, 0)
}

function Focus-Console {
    $consolePtr = [Console.Window]::GetConsoleWindow()
    if ($consolePtr -ne [IntPtr]::Zero) {
        [Console.Window]::SetForegroundWindow($consolePtr) | Out-Null
    }
}

#Hide console when form is shown
$Form.Add_Shown({
	$Form.Activate()
	Hide-Console | Out-Null
})

function FindDependenciesFolder {
    param (
        [string]$rootPath
    )

    $DependenciesFolder = Get-ChildItem -Path $rootPath -Recurse -Directory -Filter "Dependencies" -ErrorAction SilentlyContinue

    if ($DependenciesFolder) {
        return $DependenciesFolder.FullName
    } 
	else {
        return $null
    }
}


function Get-OneLineError {
    param(
        [Parameter(Mandatory)] $ErrorRecord,
        [int] $MaxLength = 180
    )

    $message = if ($ErrorRecord.Exception -and $ErrorRecord.Exception.Message) {
        $ErrorRecord.Exception.Message
    } else {
        [string]$ErrorRecord
    }

    $message = ($message -replace '[\r\n]+', ' ' -replace '\s{2,}', ' ').Trim()

    if ($message.Length -gt $MaxLength) {
        $message = $message.Substring(0, $MaxLength - 3) + '...'
    }

    return $message
}

function Install-AppxDependency {
    param(
        [Parameter(Mandatory)] [string] $Name,
        [Parameter(Mandatory)] [string] $Path
    )

    if (-not (Test-Path $Path)) {
        return [PSCustomObject]@{
            Success = $false
            Name    = $Name
            Message = 'File not found'
        }
    }

    try {
        Add-AppxPackage `
            -Path $Path `
            -ForceApplicationShutdown `
            -ErrorAction Stop `
            -WarningAction SilentlyContinue `
            -InformationAction SilentlyContinue 3>$null 4>$null 6>$null | Out-Null

        return [PSCustomObject]@{
            Success = $true
            Name    = $Name
            Message = $null
        }
    }
    catch {
        $message = Get-OneLineError -ErrorRecord $_

        # A newer copy already being installed is not a failure
        if ($message -match '0x80073D06|higher version.*already installed|already installed.*higher version') {
            return [PSCustomObject]@{
                Success = $true
                Name    = $Name
                Message = $null
            }
        }

        return [PSCustomObject]@{
            Success = $false
            Name    = $Name
            Message = $message
        }
    }
}


function Ensure-WindowsAppRuntime18 {
    param(
        [Version]$MinimumVersion = [Version]'8000.616.304.0',
        [string]$InstallerUrl = 'https://aka.ms/windowsappsdk/1.8/1.8.260101001/windowsappruntimeinstall-x64.exe'
    )

    $installerPath = Join-Path $env:TEMP 'WindowsAppRuntimeInstall-x64.exe'

    try {
        # App Installer 1.30.70 requires this framework version or newer.
        $installedRuntime = Get-AppxPackage -AllUsers -PackageTypeFilter Framework -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -eq 'Microsoft.WindowsAppRuntime.1.8' -and
                [Version]$_.Version -ge $MinimumVersion -and
                "$($_.Architecture)" -in @('X64', 'Neutral')
            } |
            Sort-Object { [Version]$_.Version } -Descending |
            Select-Object -First 1

        if ($installedRuntime) {
            Write-Host "Windows App Runtime 1.8 is already installed: $($installedRuntime.Version)" -ForegroundColor Green
            return $true
        }

        Write-Host "Downloading Windows App Runtime 1.8" -ForegroundColor Cyan
        Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
        Invoke-WebRequest -Uri $InstallerUrl -OutFile $installerPath -UseBasicParsing -ErrorAction Stop
        Write-Host "[DONE] Downloaded Windows App Runtime 1.8`n" -ForegroundColor Green

        Write-Host "Installing Windows App Runtime 1.8" -ForegroundColor Cyan

        # Microsoft's documented unattended switches. Run the installer exactly once.
        $process = Start-Process `
            -FilePath $installerPath `
            -ArgumentList @('--quiet', '--force') `
            -WindowStyle Hidden `
            -Wait `
            -PassThru `
            -ErrorAction Stop

        if ($process.ExitCode -notin @(0, 1641, 3010)) {
            throw "Windows App Runtime installer exited with code $($process.ExitCode)"
        }

        Start-Sleep -Seconds 2

        $installedRuntime = Get-AppxPackage -AllUsers -PackageTypeFilter Framework -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -eq 'Microsoft.WindowsAppRuntime.1.8' -and
                [Version]$_.Version -ge $MinimumVersion -and
                "$($_.Architecture)" -in @('X64', 'Neutral')
            } |
            Sort-Object { [Version]$_.Version } -Descending |
            Select-Object -First 1

        if (-not $installedRuntime) {
            throw "Windows App Runtime 1.8 version $MinimumVersion or newer was not detected after installation"
        }

        Write-Host "[DONE] Windows App Runtime 1.8 installed: $($installedRuntime.Version)`n" -ForegroundColor Green
        return $true
    }
    catch {
        $message = Get-OneLineError -ErrorRecord $_
        Write-Host "[ERROR] Windows App Runtime 1.8 failed: $message`n" -ForegroundColor Red
        return $false
    }
    finally {
        Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
    }
}

function Close-AppInstallerConflicts {
    Write-Host "Closing possible App Installer conflicts" -ForegroundColor Cyan

    $processNames = @(
        'WinStore.App',
        'DesktopAppInstaller',
        'AppInstallerCLI',
        'WindowsPackageManagerServer',
        'winget'
    )

    foreach ($processName in $processNames) {
        Get-Process -Name $processName -ErrorAction SilentlyContinue |
            Stop-Process -Force -ErrorAction SilentlyContinue
    }

    # These services support AppX/MSIX deployment and should remain available.
    foreach ($serviceName in @('AppXSvc', 'ClipSVC', 'InstallService')) {
        $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
        if ($service -and $service.Status -ne 'Running') {
            Start-Service -Name $serviceName -ErrorAction SilentlyContinue
        }
    }

    Start-Sleep -Seconds 2
    Write-Host "[DONE] App Installer conflicts cleared`n" -ForegroundColor Green
}

function Search {

# Search for the specified app and display the results in a list box
    $searchButton.Text = "Loading"
    $searchText = $searchBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a search term", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        $searchButton.Text = "Search"
        return
    }
    try {
        $results = winget search $searchText | Select-Object -Skip 2
        if ($results) {
            $listBox.Items.Clear()
			foreach ($result in $results) {
				$listBox.Items.Add($result)
			}
        } else {
            [System.Windows.Forms.MessageBox]::Show("No results found for '$($searchText)'", "No Results", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    } catch {
        Write-Host "Error: $_"
        [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
    $searchButton.Text = "Search"

}

function Installed {

 # Search for an installed app and display the results in a list box
    $searchInstalledButton.Text = "Loading"
    $searchText = $searchBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a search term", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        $searchInstalledButton.Text = "Search Installed"
        return
    }
    try {
        $results = winget list $searchText | Select-Object -Skip 2
        if ($results) {
            $listBox.Items.Clear()
            foreach ($result in $results) {
				$listBox.Items.Add($result)
			}
        } else {
            [System.Windows.Forms.MessageBox]::Show("No results found for '$($searchText)'", "No Results", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    } catch {
        Write-Host "Error: $_"
        [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
    $searchInstalledButton.Text = "Search Installed"

}

function ListInstalled {
    # List all installed apps and return the results
    $listInstalledButton.Text = "Loading"
    $searchText = $searchBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        $searchText = ""
    }
    try {
        $results = winget list $searchText | Select-Object -Skip 2
        if ($results) {
            $listBox.Items.Clear()
            foreach ($result in $results) {
                $listBox.Items.Add($result)
            }
        } else {
            [System.Windows.Forms.MessageBox]::Show("No results found for '$($searchText)'", "No Results", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    } catch {
        Write-Host "Error: $_"
        [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
    $listInstalledButton.Text = "List Installed"
}

function Install {

# Install the selected app
    $selected = $listBox.SelectedItem
    if ($selected) {
        $installButton.Text = "Loading"
        try {
			$packageName = ($selected -split '\s+', 3)[1]
            Install-Winget -IdOrName $packageName
			 
        } catch {
            Write-Host "Error: $_"
            [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
        $installButton.Text = "Install"
    }

}

function Uninstall {
    # Uninstall the selected installed app
    $selected = $listBox.SelectedItem
    if ($selected) {
        $uninstallButton.Text = "Loading"
        try {
            # Split the selected item to extract the package ID
            $packageName = ($selected -split '\s+', 3)[1]
            winget uninstall $packageName 
        } catch {
            Write-Host "Error: $_"
            [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
        $uninstallButton.Text = "Uninstall"
    }
}

function Get-GamesDrive {
    param (
        [string[]]$EligibleDriveLetters
    )

    # If already set, reuse it
    if ($Global:GamesDrive) {
        return $Global:GamesDrive
    }

    # If only C: exists, pick it automatically without asking
    if ($EligibleDriveLetters.Count -eq 1 -and $EligibleDriveLetters -contains 'C') {
        $Global:GamesDrive = 'C'
        return $Global:GamesDrive
    }

    # Otherwise, prompt the user once
    Write-Host "Available internal hard drives:"
    $EligibleDriveLetters | ForEach-Object { Write-Host "${_}:" }

    while ($true) {
        Focus-Console  # make sure console has focus before asking
        $selectedDrive = Read-Host "Enter the drive letter where you want to install games (e.g., D)"
        $selectedDrive = $selectedDrive.ToUpper()

        if ($EligibleDriveLetters -notcontains $selectedDrive) {
            Write-Host "The drive letter '$selectedDrive' is not eligible. Please enter a valid drive letter." -ForegroundColor Red
        }
        else {
            $Global:GamesDrive = $selectedDrive
            return $Global:GamesDrive
        }
    }
}

function Install-Game {
    param (
        [string]$GameName,
        [string]$WingetId,
        [string]$SubFolder
    )

    Write-Host "Installing $GameName" -ForegroundColor Cyan

    try {
        $eligibleDriveLetters = (Get-WmiObject Win32_LogicalDisk |
            Where-Object { $_.DriveType -eq 3 }).DeviceID |
            ForEach-Object { $_.TrimEnd(':') }

        $extraArgs = @()

        if (-not ($eligibleDriveLetters.Count -eq 1 -and $eligibleDriveLetters -contains 'C')) {
            $gamesDrive = Get-GamesDrive -EligibleDriveLetters $eligibleDriveLetters

            if (-not $gamesDrive) {
                Write-Host "Installation of $GameName canceled`n" -ForegroundColor Red
                return
            }

            $installFolder = "${gamesDrive}:\$SubFolder"
            $extraArgs = @('--location', "`"$installFolder`"")
        }

        Install-Winget -IdOrName $WingetId -Source 'winget' -ExtraArgs $extraArgs
        Write-Host "[DONE] Installing $GameName completed`n" -ForegroundColor Green
    }
    catch {
        Write-Host "[ERROR] Installing $GameName failed: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

function New-WebShortcut {
    param(
        [Parameter(Mandatory)] [string] $Name,      # Shortcut name (no .lnk)
        [Parameter(Mandatory)] [string] $Url,       # Target URL
        [Parameter(Mandatory)] $Shell,              # WScript.Shell object
        [Parameter(Mandatory)] [string] $DesktopPath,
        [string] $IconPath
    )

    $lnkPath = Join-Path $DesktopPath "$Name.lnk"

    if (Test-Path $lnkPath) {
        Remove-Item $lnkPath -Force -ErrorAction SilentlyContinue
    }

    $shortcut = $Shell.CreateShortcut($lnkPath)
    $shortcut.TargetPath = $Url

    if ($IconPath -and (Test-Path $IconPath)) {
        $shortcut.IconLocation = $IconPath
    }

    $shortcut.Save()
}

function Get-WingetSourceForId {
    param(
        [Parameter(Mandatory)] [string] $IdOrName
    )

    # Community-repository package IDs contain a period.
    # Microsoft Store product IDs are alphanumeric and do not.
    if ($IdOrName -match '\.') {
        return 'winget'
    }

    return 'msstore'
}

function Repair-WingetSource {
    param(
        [Parameter(Mandatory)]
        [ValidateSet('winget', 'msstore')]
        [string] $Source
    )

    try {
        Write-Host "[WARNING] Repairing the $Source Winget source" -ForegroundColor Yellow

        $reset = Start-Process -FilePath 'winget.exe' `
            -ArgumentList @('source', 'reset', '--name', $Source, '--force') `
            -Wait -PassThru -NoNewWindow -ErrorAction Stop

        if ($reset.ExitCode -ne 0) {
            return $false
        }

        $update = Start-Process -FilePath 'winget.exe' `
            -ArgumentList @('source', 'update', '--name', $Source) `
            -Wait -PassThru -NoNewWindow -ErrorAction Stop

        return ($update.ExitCode -eq 0)
    }
    catch {
        Write-Host "[WARNING] Unable to repair the $Source Winget source: $($_.Exception.Message)" -ForegroundColor Yellow
        return $false
    }
}

function Install-Winget {
    param(
        [Parameter(Mandatory)] [string] $IdOrName,
        [string[]] $ExtraArgs = @(),
        [ValidateSet('winget', 'msstore')]
        [string] $Source
    )

    if (-not $Source) {
        $Source = Get-WingetSourceForId -IdOrName $IdOrName
    }

    # --id, --exact, and --source prevent Winget from querying every source.
    # This avoids a broken msstore source blocking normal winget packages.
    $arguments = @(
        'install',
        '--id', $IdOrName,
        '--exact',
        '--source', $Source,
        '--accept-source-agreements',
        '--accept-package-agreements',
        '--disable-interactivity'
    )

    if ($ExtraArgs) {
        $arguments += $ExtraArgs
    }

    $process = Start-Process -FilePath 'winget.exe' `
        -ArgumentList $arguments `
        -Wait -PassThru -NoNewWindow -ErrorAction Stop

    # 0x8A15005E / -1978335138 is the source certificate error shown by msstore.
    # Repair only that source and retry once.
    if ($process.ExitCode -eq -1978335138 -and $Source -eq 'msstore') {
        if (Repair-WingetSource -Source 'msstore') {
            $process = Start-Process -FilePath 'winget.exe' `
                -ArgumentList $arguments `
                -Wait -PassThru -NoNewWindow -ErrorAction Stop
        }
    }

    if ($process.ExitCode -ne 0) {
        throw "winget failed with exit code $($process.ExitCode) using source '$Source'"
    }
}

function New-DriverExplorerDesktopShortcut {
    try {
        $desktopPath = [Environment]::GetFolderPath('Desktop')
        $shortcutPath = Join-Path $desktopPath 'Driver Explorer.lnk'

        $raprPath = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\rapr.exe'

        if (-not (Test-Path $raprPath)) {
            $raprPath = Get-ChildItem -Path (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages') `
                -Filter 'Rapr.exe' -File -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.FullName -like '*lostindark.DriverStoreExplorer*' } |
                Select-Object -ExpandProperty FullName -First 1
        }

        if (-not $raprPath -or -not (Test-Path $raprPath)) {
            throw 'Rapr.exe could not be found after installation'
        }

        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $raprPath
        $shortcut.WorkingDirectory = Split-Path -Parent $raprPath
        $shortcut.IconLocation = "$raprPath,0"
        $shortcut.Description = 'Driver Store Explorer'
        $shortcut.Save()

        Write-Host "[DONE] Driver Explorer desktop shortcut created" -ForegroundColor Green
    }
    catch {
        Write-Host "[WARNING] Driver Explorer shortcut could not be created: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Invoke-WingetItem {
    param(
        [Parameter(Mandatory)] $Checkbox,
        [Parameter(Mandatory)] [string] $Label,
        [Parameter(Mandatory)] [string] $IdOrName,
        [string[]] $ExtraArgs = @()
    )

    if ($Checkbox -and $Checkbox.Checked) {
        Write-Host "Installing $Label" -ForegroundColor Cyan
        try {
            Install-Winget -IdOrName $IdOrName -ExtraArgs $ExtraArgs

            if ($IdOrName -eq 'lostindark.DriverStoreExplorer') {
                New-DriverExplorerDesktopShortcut
            }

            Write-Host "[DONE] Installing $Label completed`n" -ForegroundColor Green
        }
        catch {
            Write-Host "[ERROR] Installing $Label failed: $($_.Exception.Message)`n" -ForegroundColor Red
        }
    }
}


#---------------------------------------------------------------------------------------------
# Startup

# Hide progress bar
$ProgressPreference = 'SilentlyContinue'

$targetVersion = [Version]'1.30.70.0'
$appinstallerInstalled = Get-AppxPackage -AllUsers -Name 'Microsoft.DesktopAppInstaller' -ErrorAction SilentlyContinue |
    Sort-Object { [Version]$_.Version } -Descending |
    Select-Object -First 1

# Get the current directory where the script is executed
$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Check if App Installer is missing or outdated
if (-not $appinstallerInstalled -or ([Version]$appinstallerInstalled.Version -lt $targetVersion)) {
    Write-Host "App Installer is missing or outdated" -ForegroundColor Yellow

    # Clear Store/App Installer processes once before beginning the repair.
    Close-AppInstallerConflicts

    # Install local dependencies with one closing status line
    Write-Host "Installing required dependencies" -ForegroundColor Cyan
    $DependenciesFolder = FindDependenciesFolder -rootPath $currentDirectory
    $dependencyIssues = @()

    if ($DependenciesFolder) {
        $dependencyItems = @(
            @{
                Name = 'Microsoft VCLibs'
                Path = Join-Path -Path $DependenciesFolder -ChildPath 'Microsoft.VCLibs.140.00.UWPDesktop.x64.appx'
            },
            @{
                Name = 'Microsoft UI Xaml'
                Path = Join-Path -Path $DependenciesFolder -ChildPath 'Microsoft.UI.Xaml.2.8.appx'
            }
        )

        foreach ($dependency in $dependencyItems) {
            $result = Install-AppxDependency -Name $dependency.Name -Path $dependency.Path
            if (-not $result.Success) {
                $dependencyIssues += $result.Name
            }
        }

        if ($dependencyIssues.Count -eq 0) {
            Write-Host "[DONE] Dependencies installed`n" -ForegroundColor Green
        }
        else {
            Write-Host "[WARNING] Dependencies could not be installed: $($dependencyIssues -join ', ')`n" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host "[WARNING] Dependencies folder was not found`n" -ForegroundColor Yellow
    }

    # Install and verify the framework before attempting App Installer.
    if (Ensure-WindowsAppRuntime18) {
        $downloadUrl = 'https://github.com/microsoft/winget-cli/releases/download/v1.30.70-preview/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle'
        $bundlePath = Join-Path $env:TEMP 'Microsoft.DesktopAppInstaller.msixbundle'

        try {
            Write-Host "Downloading App Installer" -ForegroundColor Cyan
            Remove-Item $bundlePath -Force -ErrorAction SilentlyContinue
            Invoke-WebRequest -Uri $downloadUrl -OutFile $bundlePath -UseBasicParsing -ErrorAction Stop
            Write-Host "[DONE] Downloading App Installer complete`n" -ForegroundColor Green

            Write-Host "Installing App Installer" -ForegroundColor Cyan
            Add-AppxPackage -Path $bundlePath -ForceApplicationShutdown -ErrorAction Stop

            $installedAppInstaller = Get-AppxPackage -AllUsers -Name 'Microsoft.DesktopAppInstaller' -ErrorAction SilentlyContinue |
                Sort-Object { [Version]$_.Version } -Descending |
                Select-Object -First 1

            if (-not $installedAppInstaller) {
                throw 'App Installer completed but the package could not be detected afterward'
            }

            if ([Version]$installedAppInstaller.Version -lt $targetVersion) {
                throw "App Installer version $($installedAppInstaller.Version) was installed, but version $targetVersion or newer is required"
            }

            Write-Host "[DONE] Installing App Installer complete: $($installedAppInstaller.Version)`n" -ForegroundColor Green
        }
        catch {
            $message = Get-OneLineError -ErrorRecord $_
            Write-Host "[ERROR] Failed to install App Installer: $message`n" -ForegroundColor Red
        }
        finally {
            Remove-Item $bundlePath -Force -ErrorAction SilentlyContinue
        }
    }
    else {
        Write-Host "[ERROR] App Installer was skipped because Windows App Runtime 1.8 could not be installed`n" -ForegroundColor Red
    }
}

#---------------------------------------------------------------------------------------------
# Build The Form Components And Add To Form

# Tab 1 GENERAL
$Tab1 = New-Object System.Windows.Forms.TabPage
$Tab1.Text = "General"
$Tab1.Font = $TabFont
$Tab1.Autoscroll  = $True
$TabControl.Controls.Add($Tab1)

$AIChatbotLabel = New-Object System.Windows.Forms.Label
$AIChatbotLabel.Location = New-Object System.Drawing.Size(10,10)
$AIChatbotLabel.Text = "AI Chatbot"
$AIChatbotLabel.Width = 180
$AIChatbotLabel.Height = 20
$AIChatbotLabel.Font = $HeaderFont
$Tab1.Controls.Add($AIChatbotLabel)

$ChatGPTLogo = New-Object System.Windows.Forms.PictureBox
$ChatGPTLogo.Width = 18
$ChatGPTLogo.Height = 18
$ChatGPTLogo.Location = New-Object System.Drawing.Size(30,30)
$ChatGPTLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\ChatGPT.png"
$ChatGPTLogo.ImageLocation = $ChatGPTLogoFile
$ChatGPTLogo.BorderStyle = 0
$ChatGPTLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ChatGPTLogo)

$ChatGPTCheckbox = New-Object System.Windows.Forms.Checkbox 
$ChatGPTCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$ChatGPTCheckbox.Text = "       ChatGPT"
$ChatGPTCheckbox.Width = 180
$ChatGPTCheckbox.Height = 20
$ChatGPTCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ChatGPTCheckbox)

$ClaudeLogo = New-Object System.Windows.Forms.PictureBox
$ClaudeLogo.Width = 18
$ClaudeLogo.Height = 18
$ClaudeLogo.Location = New-Object System.Drawing.Size(30,50)
$ClaudeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Claude.png"
$ClaudeLogo.ImageLocation = $ClaudeLogoFile
$ClaudeLogo.BorderStyle = 0
$ClaudeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ClaudeLogo)

$ClaudeCheckbox = New-Object System.Windows.Forms.Checkbox 
$ClaudeCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$ClaudeCheckbox.Text = "       Claude"
$ClaudeCheckbox.Width = 180
$ClaudeCheckbox.Height = 20
$ClaudeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ClaudeCheckbox)

$GeminiLogo = New-Object System.Windows.Forms.PictureBox
$GeminiLogo.Width = 18
$GeminiLogo.Height = 18
$GeminiLogo.Location = New-Object System.Drawing.Size(30,70)
$GeminiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Gemini.png"
$GeminiLogo.ImageLocation = $GeminiLogoFile
$GeminiLogo.BorderStyle = 0
$GeminiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GeminiLogo)

$GeminiCheckbox = New-Object System.Windows.Forms.Checkbox 
$GeminiCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$GeminiCheckbox.Text = "       Gemini"
$GeminiCheckbox.Width = 180
$GeminiCheckbox.Height = 20
$GeminiCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GeminiCheckbox)

$GrokLogo = New-Object System.Windows.Forms.PictureBox
$GrokLogo.Width = 18
$GrokLogo.Height = 18
$GrokLogo.Location = New-Object System.Drawing.Size(30,90)
$GrokLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Grok.png"
$GrokLogo.ImageLocation = $GrokLogoFile
$GrokLogo.BorderStyle = 0
$GrokLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GrokLogo)

$GrokCheckbox = New-Object System.Windows.Forms.Checkbox 
$GrokCheckbox.Location = New-Object System.Drawing.Size(10,90) 
$GrokCheckbox.Text = "       Grok"
$GrokCheckbox.Width = 180
$GrokCheckbox.Height = 20
$GrokCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GrokCheckbox)

$PerplexityLogo = New-Object System.Windows.Forms.PictureBox
$PerplexityLogo.Width = 18
$PerplexityLogo.Height = 18
$PerplexityLogo.Location = New-Object System.Drawing.Size(30,110)
$PerplexityLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Perplexity.png"
$PerplexityLogo.ImageLocation = $PerplexityLogoFile
$PerplexityLogo.BorderStyle = 0
$PerplexityLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PerplexityLogo)

$PerplexityCheckbox = New-Object System.Windows.Forms.Checkbox 
$PerplexityCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$PerplexityCheckbox.Text = "       Perplexity"
$PerplexityCheckbox.Width = 180
$PerplexityCheckbox.Height = 20
$PerplexityCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PerplexityCheckbox)

$AudioLabel = New-Object System.Windows.Forms.Label
$AudioLabel.Location = New-Object System.Drawing.Size(10,150)
$AudioLabel.Text = "Audio"
$AudioLabel.Width = 180
$AudioLabel.Height = 20
$AudioLabel.Font = $HeaderFont
$Tab1.Controls.Add($AudioLabel)

$AudacityLogo = New-Object System.Windows.Forms.PictureBox
$AudacityLogo.Width = 18
$AudacityLogo.Height = 18
$AudacityLogo.Location = New-Object System.Drawing.Size(30,170)
$AudacityLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Audacity.png"
$AudacityLogo.ImageLocation = $AudacityLogoFile
$AudacityLogo.BorderStyle = 0
$AudacityLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AudacityLogo)

$AudacityCheckbox = New-Object System.Windows.Forms.Checkbox 
$AudacityCheckbox.Location = New-Object System.Drawing.Size(10,170) 
$AudacityCheckbox.Text = "       Audacity"
$AudacityCheckbox.Width = 180
$AudacityCheckbox.Height = 20
$AudacityCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AudacityCheckbox)

$FLStudioLogo = New-Object System.Windows.Forms.PictureBox
$FLStudioLogo.Width = 18
$FLStudioLogo.Height = 18
$FLStudioLogo.Location = New-Object System.Drawing.Size(30,190)
$FLStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\FLStudio.png"
$FLStudioLogo.ImageLocation = $FLStudioLogoFile
$FLStudioLogo.BorderStyle = 0
$FLStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($FLStudioLogo)

$FLStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$FLStudioCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$FLStudioCheckbox.Text = "       FL Studio"
$FLStudioCheckbox.Width = 180
$FLStudioCheckbox.Height = 20
$FLStudioCheckbox.Font = $BodyFont
$Tab1.Controls.Add($FLStudioCheckbox)

$BrowsersLabel = New-Object System.Windows.Forms.Label
$BrowsersLabel.Location = New-Object System.Drawing.Size(10,230)
$BrowsersLabel.Text = "Browsers"
$BrowsersLabel.Width = 180
$BrowsersLabel.Height = 20
$BrowsersLabel.Font = $HeaderFont
$Tab1.Controls.Add($BrowsersLabel)

$BraveLogo = New-Object System.Windows.Forms.PictureBox
$BraveLogo.Width = 18
$BraveLogo.Height = 18
$BraveLogo.Location = New-Object System.Drawing.Size(30,250)
$BraveLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Brave.png"
$BraveLogo.ImageLocation = $BraveLogoFile
$BraveLogo.BorderStyle = 0
$BraveLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($BraveLogo)

$BraveCheckbox = New-Object System.Windows.Forms.Checkbox 
$BraveCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$BraveCheckbox.Text = "       Brave"
$BraveCheckbox.Width = 180
$BraveCheckbox.Height = 20
$BraveCheckbox.Font = $BodyFont
$Tab1.Controls.Add($BraveCheckbox)

$ChromeLogo = New-Object System.Windows.Forms.PictureBox
$ChromeLogo.Width = 18
$ChromeLogo.Height = 18
$ChromeLogo.Location = New-Object System.Drawing.Size(30,270)
$ChromeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Chrome.png"
$ChromeLogo.ImageLocation = $ChromeLogoFile
$ChromeLogo.BorderStyle = 0
$ChromeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ChromeLogo)

$ChromeCheckbox = New-Object System.Windows.Forms.Checkbox 
$ChromeCheckbox.Location = New-Object System.Drawing.Size(10,270) 
$ChromeCheckbox.Text = "       Chrome"
$ChromeCheckbox.Width = 180
$ChromeCheckbox.Height = 20
$ChromeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ChromeCheckbox)

$DuckDuckGoLogo = New-Object System.Windows.Forms.PictureBox
$DuckDuckGoLogo.Width = 18
$DuckDuckGoLogo.Height = 18
$DuckDuckGoLogo.Location = New-Object System.Drawing.Size(30,290)
$DuckDuckGoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\DuckDuckGo.png"
$DuckDuckGoLogo.ImageLocation = $DuckDuckGoLogoFile
$DuckDuckGoLogo.BorderStyle = 0
$DuckDuckGoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DuckDuckGoLogo)

$DuckDuckGoCheckbox = New-Object System.Windows.Forms.Checkbox 
$DuckDuckGoCheckbox.Location = New-Object System.Drawing.Size(10,290) 
$DuckDuckGoCheckbox.Text = "       DuckDuckGo"
$DuckDuckGoCheckbox.Width = 180
$DuckDuckGoCheckbox.Height = 20
$DuckDuckGoCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DuckDuckGoCheckbox)

$FirefoxLogo = New-Object System.Windows.Forms.PictureBox
$FirefoxLogo.Width = 18
$FirefoxLogo.Height = 18
$FirefoxLogo.Location = New-Object System.Drawing.Size(30,310)
$FirefoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Firefox.png"
$FirefoxLogo.ImageLocation = $FirefoxLogoFile
$FirefoxLogo.BorderStyle = 0
$FirefoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($FirefoxLogo)

$FirefoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$FirefoxCheckbox.Location = New-Object System.Drawing.Size(10,310) 
$FirefoxCheckbox.Text = "       Firefox"
$FirefoxCheckbox.Width = 180
$FirefoxCheckbox.Height = 20
$FirefoxCheckbox.Font = $BodyFont
$Tab1.Controls.Add($FirefoxCheckbox)

$OperaLogo = New-Object System.Windows.Forms.PictureBox
$OperaLogo.Width = 18
$OperaLogo.Height = 18
$OperaLogo.Location = New-Object System.Drawing.Size(30,330)
$OperaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Opera.png"
$OperaLogo.ImageLocation = $OperaLogoFile
$OperaLogo.BorderStyle = 0
$OperaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OperaLogo)

$OperaCheckbox = New-Object System.Windows.Forms.Checkbox 
$OperaCheckbox.Location = New-Object System.Drawing.Size(10,330) 
$OperaCheckbox.Text = "       Opera"
$OperaCheckbox.Width = 180
$OperaCheckbox.Height = 20
$OperaCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OperaCheckbox)

$OperaGXLogo = New-Object System.Windows.Forms.PictureBox
$OperaGXLogo.Width = 18
$OperaGXLogo.Height = 18
$OperaGXLogo.Location = New-Object System.Drawing.Size(30,350)
$OperaGXLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\OperaGX.png"
$OperaGXLogo.ImageLocation = $OperaGXLogoFile
$OperaGXLogo.BorderStyle = 0
$OperaGXLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OperaGXLogo)

$OperaGXCheckbox = New-Object System.Windows.Forms.Checkbox 
$OperaGXCheckbox.Location = New-Object System.Drawing.Size(10,350) 
$OperaGXCheckbox.Text = "       Opera GX"
$OperaGXCheckbox.Width = 180
$OperaGXCheckbox.Height = 20
$OperaGXCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OperaGXCheckbox)

$TorLogo = New-Object System.Windows.Forms.PictureBox
$TorLogo.Width = 18
$TorLogo.Height = 18
$TorLogo.Location = New-Object System.Drawing.Size(30,370)
$TorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Tor.png"
$TorLogo.ImageLocation = $TorLogoFile
$TorLogo.BorderStyle = 0
$TorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TorLogo)

$TorCheckbox = New-Object System.Windows.Forms.Checkbox 
$TorCheckbox.Location = New-Object System.Drawing.Size(10,370) 
$TorCheckbox.Text = "       Tor"
$TorCheckbox.Width = 180
$TorCheckbox.Height = 20
$TorCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TorCheckbox)

$CompressionLabel = New-Object System.Windows.Forms.Label
$CompressionLabel.Location = New-Object System.Drawing.Size(200,10)
$CompressionLabel.Text = "Compression"
$CompressionLabel.Width = 180
$CompressionLabel.Height = 20
$CompressionLabel.Font = $HeaderFont
$Tab1.Controls.Add($CompressionLabel)

$7ZipLogo = New-Object System.Windows.Forms.PictureBox
$7ZipLogo.Width = 18
$7ZipLogo.Height = 18
$7ZipLogo.Location = New-Object System.Drawing.Size(220,30)
$7ZipLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\7Zip.png"
$7ZipLogo.ImageLocation = $7ZipLogoFile
$7ZipLogo.BorderStyle = 0
$7ZipLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($7ZipLogo)

$7ZipCheckbox = New-Object System.Windows.Forms.Checkbox 
$7ZipCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$7ZipCheckbox.Text = "       7-Zip"
$7ZipCheckbox.Width = 180
$7ZipCheckbox.Height = 20
$7ZipCheckbox.Font = $BodyFont
$Tab1.Controls.Add($7ZipCheckbox)

$WinRARLogo = New-Object System.Windows.Forms.PictureBox
$WinRARLogo.Width = 18
$WinRARLogo.Height = 18
$WinRARLogo.Location = New-Object System.Drawing.Size(220,50)
$WinRARLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\WinRAR.png"
$WinRARLogo.ImageLocation = $WinRARLogoFile
$WinRARLogo.BorderStyle = 0
$WinRARLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($WinRARLogo)

$WinRARCheckbox = New-Object System.Windows.Forms.Checkbox 
$WinRARCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$WinRARCheckbox.Text = "       WinRAR"
$WinRARCheckbox.Width = 180
$WinRARCheckbox.Height = 20
$WinRARCheckbox.Font = $BodyFont
$Tab1.Controls.Add($WinRARCheckbox)

$DocumentsLabel = New-Object System.Windows.Forms.Label
$DocumentsLabel.Location = New-Object System.Drawing.Size(200,90)
$DocumentsLabel.Text = "Documents"
$DocumentsLabel.Width = 180
$DocumentsLabel.Height = 20
$DocumentsLabel.Font = $HeaderFont
$Tab1.Controls.Add($DocumentsLabel)

$AcrobatReaderLogo = New-Object System.Windows.Forms.PictureBox
$AcrobatReaderLogo.Width = 18
$AcrobatReaderLogo.Height = 18
$AcrobatReaderLogo.Location = New-Object System.Drawing.Size(220,110)
$AcrobatReaderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\AcrobatReader.png"
$AcrobatReaderLogo.ImageLocation = $AcrobatReaderLogoFile
$AcrobatReaderLogo.BorderStyle = 0
$AcrobatReaderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AcrobatReaderLogo)

$AcrobatReaderCheckbox = New-Object System.Windows.Forms.Checkbox 
$AcrobatReaderCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$AcrobatReaderCheckbox.Text = "       Acrobat Reader"
$AcrobatReaderCheckbox.Width = 180
$AcrobatReaderCheckbox.Height = 20
$AcrobatReaderCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AcrobatReaderCheckbox)

$EvernoteLogo = New-Object System.Windows.Forms.PictureBox
$EvernoteLogo.Width = 18
$EvernoteLogo.Height = 18
$EvernoteLogo.Location = New-Object System.Drawing.Size(220,130)
$EvernoteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Evernote.png"
$EvernoteLogo.ImageLocation = $EvernoteLogoFile
$EvernoteLogo.BorderStyle = 0
$EvernoteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($EvernoteLogo)

$EvernoteCheckbox = New-Object System.Windows.Forms.Checkbox 
$EvernoteCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$EvernoteCheckbox.Text = "       Evernote"
$EvernoteCheckbox.Width = 180
$EvernoteCheckbox.Height = 20
$EvernoteCheckbox.Font = $BodyFont
$Tab1.Controls.Add($EvernoteCheckbox)

$GrammarlyAppLogo = New-Object System.Windows.Forms.PictureBox
$GrammarlyAppLogo.Width = 18
$GrammarlyAppLogo.Height = 18
$GrammarlyAppLogo.Location = New-Object System.Drawing.Size(220,150)
$GrammarlyAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Grammarly.png"
$GrammarlyAppLogo.ImageLocation = $GrammarlyAppLogoFile
$GrammarlyAppLogo.BorderStyle = 0
$GrammarlyAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GrammarlyAppLogo)

$GrammarlyAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$GrammarlyAppCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$GrammarlyAppCheckbox.Text = "       Grammarly"
$GrammarlyAppCheckbox.Width = 180
$GrammarlyAppCheckbox.Height = 20
$GrammarlyAppCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GrammarlyAppCheckbox)

$LibreOfficeLogo = New-Object System.Windows.Forms.PictureBox
$LibreOfficeLogo.Width = 18
$LibreOfficeLogo.Height = 18
$LibreOfficeLogo.Location = New-Object System.Drawing.Size(220,170)
$LibreOfficeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\LibreOffice.png"
$LibreOfficeLogo.ImageLocation = $LibreOfficeLogoFile
$LibreOfficeLogo.BorderStyle = 0
$LibreOfficeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($LibreOfficeLogo)

$LibreOfficeCheckbox = New-Object System.Windows.Forms.Checkbox 
$LibreOfficeCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$LibreOfficeCheckbox.Text = "       Libre Office"
$LibreOfficeCheckbox.Width = 180
$LibreOfficeCheckbox.Height = 20
$LibreOfficeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($LibreOfficeCheckbox)

$ObsidianLogo = New-Object System.Windows.Forms.PictureBox
$ObsidianLogo.Width = 18
$ObsidianLogo.Height = 18
$ObsidianLogo.Location = New-Object System.Drawing.Size(220,190)
$ObsidianLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Obsidian.png"
$ObsidianLogo.ImageLocation = $ObsidianLogoFile
$ObsidianLogo.BorderStyle = 0
$ObsidianLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ObsidianLogo)

$ObsidianCheckbox = New-Object System.Windows.Forms.Checkbox 
$ObsidianCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$ObsidianCheckbox.Text = "       Obsidian"
$ObsidianCheckbox.Width = 180
$ObsidianCheckbox.Height = 20
$ObsidianCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ObsidianCheckbox)

$Office365Logo = New-Object System.Windows.Forms.PictureBox
$Office365Logo.Width = 18
$Office365Logo.Height = 18
$Office365Logo.Location = New-Object System.Drawing.Size(220,210)
$Office365LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Office365.png"
$Office365Logo.ImageLocation = $Office365LogoFile
$Office365Logo.BorderStyle = 0
$Office365Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($Office365Logo)

$Office365Checkbox = New-Object System.Windows.Forms.Checkbox 
$Office365Checkbox.Location = New-Object System.Drawing.Size(200,210) 
$Office365Checkbox.Text = "       Office365"
$Office365Checkbox.Width = 180
$Office365Checkbox.Height = 20
$Office365Checkbox.Font = $BodyFont
$Tab1.Controls.Add($Office365Checkbox)

$OpenOfficeLogo = New-Object System.Windows.Forms.PictureBox
$OpenOfficeLogo.Width = 18
$OpenOfficeLogo.Height = 18
$OpenOfficeLogo.Location = New-Object System.Drawing.Size(220,230)
$OpenOfficeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\OpenOffice.png"
$OpenOfficeLogo.ImageLocation = $OpenOfficeLogoFile
$OpenOfficeLogo.BorderStyle = 0
$OpenOfficeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OpenOfficeLogo)

$OpenOfficeCheckbox = New-Object System.Windows.Forms.Checkbox 
$OpenOfficeCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$OpenOfficeCheckbox.Text = "       Open Office"
$OpenOfficeCheckbox.Width = 180
$OpenOfficeCheckbox.Height = 20
$OpenOfficeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OpenOfficeCheckbox)

$EducationalLabel = New-Object System.Windows.Forms.Label
$EducationalLabel.Location = New-Object System.Drawing.Size(200,270)
$EducationalLabel.Text = "Educational"
$EducationalLabel.Width = 180
$EducationalLabel.Height = 20
$EducationalLabel.Font = $HeaderFont
$Tab1.Controls.Add($EducationalLabel)

$AnkiLogo = New-Object System.Windows.Forms.PictureBox
$AnkiLogo.Width = 18
$AnkiLogo.Height = 18
$AnkiLogo.Location = New-Object System.Drawing.Size(220,290)
$AnkiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Anki.png"
$AnkiLogo.ImageLocation = $AnkiLogoFile
$AnkiLogo.BorderStyle = 0
$AnkiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AnkiLogo)

$AnkiCheckbox = New-Object System.Windows.Forms.Checkbox 
$AnkiCheckbox.Location = New-Object System.Drawing.Size(200,290) 
$AnkiCheckbox.Text = "       Anki"
$AnkiCheckbox.Width = 180
$AnkiCheckbox.Height = 20
$AnkiCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AnkiCheckbox)

$DuolingoLogo = New-Object System.Windows.Forms.PictureBox
$DuolingoLogo.Width = 18
$DuolingoLogo.Height = 18
$DuolingoLogo.Location = New-Object System.Drawing.Size(220,310)
$DuolingoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Duolingo.png"
$DuolingoLogo.ImageLocation = $DuolingoLogoFile
$DuolingoLogo.BorderStyle = 0
$DuolingoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DuolingoLogo)

$DuolingoCheckbox = New-Object System.Windows.Forms.Checkbox 
$DuolingoCheckbox.Location = New-Object System.Drawing.Size(200,310) 
$DuolingoCheckbox.Text = "       Duolingo"
$DuolingoCheckbox.Width = 180
$DuolingoCheckbox.Height = 20
$DuolingoCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DuolingoCheckbox)

$MendeleyLogo = New-Object System.Windows.Forms.PictureBox
$MendeleyLogo.Width = 18
$MendeleyLogo.Height = 18
$MendeleyLogo.Location = New-Object System.Drawing.Size(220,330)
$MendeleyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Mendeley.png"
$MendeleyLogo.ImageLocation = $MendeleyLogoFile
$MendeleyLogo.BorderStyle = 0
$MendeleyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($MendeleyLogo)

$MendeleyCheckbox = New-Object System.Windows.Forms.Checkbox 
$MendeleyCheckbox.Location = New-Object System.Drawing.Size(200,330) 
$MendeleyCheckbox.Text = "       Mendeley"
$MendeleyCheckbox.Width = 180
$MendeleyCheckbox.Height = 20
$MendeleyCheckbox.Font = $BodyFont
$Tab1.Controls.Add($MendeleyCheckbox)

$FinanceLabel = New-Object System.Windows.Forms.Label
$FinanceLabel.Location = New-Object System.Drawing.Size(390,10)
$FinanceLabel.Text = "Finance"
$FinanceLabel.Width = 180
$FinanceLabel.Height = 20
$FinanceLabel.Font = $HeaderFont
$Tab1.Controls.Add($FinanceLabel)

$ExodusLogo = New-Object System.Windows.Forms.PictureBox
$ExodusLogo.Width = 18
$ExodusLogo.Height = 18
$ExodusLogo.Location = New-Object System.Drawing.Size(410,30)
$ExodusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Exodus.png"
$ExodusLogo.ImageLocation = $ExodusLogoFile
$ExodusLogo.BorderStyle = 0
$ExodusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ExodusLogo)

$ExodusCheckbox = New-Object System.Windows.Forms.Checkbox 
$ExodusCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$ExodusCheckbox.Text = "       Exodus"
$ExodusCheckbox.Width = 180
$ExodusCheckbox.Height = 20
$ExodusCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ExodusCheckbox)

$QuickenLogo = New-Object System.Windows.Forms.PictureBox
$QuickenLogo.Width = 18
$QuickenLogo.Height = 18
$QuickenLogo.Location = New-Object System.Drawing.Size(410,50)
$QuickenLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Quicken.png"
$QuickenLogo.ImageLocation = $QuickenLogoFile
$QuickenLogo.BorderStyle = 0
$QuickenLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($QuickenLogo)

$QuickenCheckbox = New-Object System.Windows.Forms.Checkbox 
$QuickenCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$QuickenCheckbox.Text = "       Quicken"
$QuickenCheckbox.Width = 180
$QuickenCheckbox.Height = 20
$QuickenCheckbox.Font = $BodyFont
$Tab1.Controls.Add($QuickenCheckbox)

$ImagingLabel = New-Object System.Windows.Forms.Label
$ImagingLabel.Location = New-Object System.Drawing.Size(390,90)
$ImagingLabel.Text = "Imaging"
$ImagingLabel.Width = 180
$ImagingLabel.Height = 20
$ImagingLabel.Font = $HeaderFont
$Tab1.Controls.Add($ImagingLabel)

$BlenderLogo = New-Object System.Windows.Forms.PictureBox
$BlenderLogo.Width = 18
$BlenderLogo.Height = 18
$BlenderLogo.Location = New-Object System.Drawing.Size(410,110)
$BlenderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Blender.png"
$BlenderLogo.ImageLocation = $BlenderLogoFile
$BlenderLogo.BorderStyle = 0
$BlenderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($BlenderLogo)

$BlenderCheckbox = New-Object System.Windows.Forms.Checkbox
$BlenderCheckbox.Location = New-Object System.Drawing.Size(390,110)
$BlenderCheckbox.Text = "       Blender"
$BlenderCheckbox.Width = 180
$BlenderCheckbox.Height = 20
$BlenderCheckbox.Font = $BodyFont
$Tab1.Controls.Add($BlenderCheckbox)

$GimpLogo = New-Object System.Windows.Forms.PictureBox
$GimpLogo.Width = 18
$GimpLogo.Height = 18
$GimpLogo.Location = New-Object System.Drawing.Size(410,130)
$GimpLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Gimp.png"
$GimpLogo.ImageLocation = $GimpLogoFile
$GimpLogo.BorderStyle = 0
$GimpLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GimpLogo)

$GimpCheckbox = New-Object System.Windows.Forms.Checkbox
$GimpCheckbox.Location = New-Object System.Drawing.Size(390,130)
$GimpCheckbox.Text = "       Gimp"
$GimpCheckbox.Width = 180
$GimpCheckbox.Height = 20
$GimpCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GimpCheckbox)

$GreenshotLogo = New-Object System.Windows.Forms.PictureBox
$GreenshotLogo.Width = 18
$GreenshotLogo.Height = 18
$GreenshotLogo.Location = New-Object System.Drawing.Size(410,150)
$GreenshotLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Greenshot.png"
$GreenshotLogo.ImageLocation = $GreenshotLogoFile
$GreenshotLogo.BorderStyle = 0
$GreenshotLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GreenshotLogo)

$GreenshotCheckbox = New-Object System.Windows.Forms.Checkbox
$GreenshotCheckbox.Location = New-Object System.Drawing.Size(390,150)
$GreenshotCheckbox.Text = "       Greenshot"
$GreenshotCheckbox.Width = 180
$GreenshotCheckbox.Height = 20
$GreenshotCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GreenshotCheckbox)

$Paint3DLogo = New-Object System.Windows.Forms.PictureBox
$Paint3DLogo.Width = 18
$Paint3DLogo.Height = 18
$Paint3DLogo.Location = New-Object System.Drawing.Size(410,170)
$Paint3DLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Paint3D.png"
$Paint3DLogo.ImageLocation = $Paint3DLogoFile
$Paint3DLogo.BorderStyle = 0
$Paint3DLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($Paint3DLogo)

$Paint3DCheckbox = New-Object System.Windows.Forms.Checkbox
$Paint3DCheckbox.Location = New-Object System.Drawing.Size(390,170)
$Paint3DCheckbox.Text = "       Paint3D"
$Paint3DCheckbox.Width = 180
$Paint3DCheckbox.Height = 20
$Paint3DCheckbox.Font = $BodyFont
$Tab1.Controls.Add($Paint3DCheckbox)

$PaintNETLogo = New-Object System.Windows.Forms.PictureBox
$PaintNETLogo.Width = 18
$PaintNETLogo.Height = 18
$PaintNETLogo.Location = New-Object System.Drawing.Size(410,190)
$PaintNETLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Paint.net.png"
$PaintNETLogo.ImageLocation = $PaintNETLogoFile
$PaintNETLogo.BorderStyle = 0
$PaintNETLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PaintNETLogo)

$PaintNETCheckbox = New-Object System.Windows.Forms.Checkbox 
$PaintNETCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$PaintNETCheckbox.Text = "       Paint.NET"
$PaintNETCheckbox.Width = 180
$PaintNETCheckbox.Height = 20
$PaintNETCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PaintNETCheckbox)

$ShareXLogo = New-Object System.Windows.Forms.PictureBox
$ShareXLogo.Width = 18
$ShareXLogo.Height = 18
$ShareXLogo.Location = New-Object System.Drawing.Size(410,210)
$ShareXLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\ShareX.png"
$ShareXLogo.ImageLocation = $ShareXLogoFile
$ShareXLogo.BorderStyle = 0
$ShareXLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ShareXLogo)

$ShareXCheckbox = New-Object System.Windows.Forms.Checkbox
$ShareXCheckbox.Location = New-Object System.Drawing.Size(390,210)
$ShareXCheckbox.Text = "       ShareX"
$ShareXCheckbox.Width = 180
$ShareXCheckbox.Height = 20
$ShareXCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ShareXCheckbox)

$MediaLabel = New-Object System.Windows.Forms.Label
$MediaLabel.Location = New-Object System.Drawing.Size(580,10)
$MediaLabel.Text = "Media"
$MediaLabel.Width = 180
$MediaLabel.Height = 20
$MediaLabel.Font = $HeaderFont
$Tab1.Controls.Add($MediaLabel)

$AmazonMusicLogo = New-Object System.Windows.Forms.PictureBox
$AmazonMusicLogo.Width = 18
$AmazonMusicLogo.Height = 18
$AmazonMusicLogo.Location = New-Object System.Drawing.Size(600,30)
$AmazonMusicLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Amazon.png"
$AmazonMusicLogo.ImageLocation = $AmazonMusicLogoFile
$AmazonMusicLogo.BorderStyle = 0
$AmazonMusicLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AmazonMusicLogo)

$AmazonMusicCheckbox = New-Object System.Windows.Forms.Checkbox 
$AmazonMusicCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$AmazonMusicCheckbox.Text = "       Amazon Music"
$AmazonMusicCheckbox.Width = 180
$AmazonMusicCheckbox.Height = 20
$AmazonMusicCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AmazonMusicCheckbox)

$iTunesLogo = New-Object System.Windows.Forms.PictureBox
$iTunesLogo.Width = 18
$iTunesLogo.Height = 18
$iTunesLogo.Location = New-Object System.Drawing.Size(600,50)
$iTunesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\iTunes.png"
$iTunesLogo.ImageLocation = $iTunesLogoFile
$iTunesLogo.BorderStyle = 0
$iTunesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($iTunesLogo)

$iTunesCheckbox = New-Object System.Windows.Forms.Checkbox 
$iTunesCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$iTunesCheckbox.Text = "       iTunes"
$iTunesCheckbox.Width = 180
$iTunesCheckbox.Height = 20
$iTunesCheckbox.Font = $BodyFont
$Tab1.Controls.Add($iTunesCheckbox)

$KodiLogo = New-Object System.Windows.Forms.PictureBox
$KodiLogo.Width = 18
$KodiLogo.Height = 18
$KodiLogo.Location = New-Object System.Drawing.Size(600,70)
$KodiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Kodi.png"
$KodiLogo.ImageLocation = $KodiLogoFile
$KodiLogo.BorderStyle = 0
$KodiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($KodiLogo)

$KodiCheckbox = New-Object System.Windows.Forms.Checkbox 
$KodiCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$KodiCheckbox.Text = "       Kodi"
$KodiCheckbox.Width = 180
$KodiCheckbox.Height = 20
$KodiCheckbox.Font = $BodyFont
$Tab1.Controls.Add($KodiCheckbox)

$NetflixLogo = New-Object System.Windows.Forms.PictureBox
$NetflixLogo.Width = 18
$NetflixLogo.Height = 18
$NetflixLogo.Location = New-Object System.Drawing.Size(600,90)
$NetflixLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Netflix.png"
$NetflixLogo.ImageLocation = $NetflixLogoFile
$NetflixLogo.BorderStyle = 0
$NetflixLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($NetflixLogo)

$NetflixCheckbox = New-Object System.Windows.Forms.Checkbox 
$NetflixCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$NetflixCheckbox.Text = "       Netflix"
$NetflixCheckbox.Width = 180
$NetflixCheckbox.Height = 20
$NetflixCheckbox.Font = $BodyFont
$Tab1.Controls.Add($NetflixCheckbox)

$PlexLogo = New-Object System.Windows.Forms.PictureBox
$PlexLogo.Width = 18
$PlexLogo.Height = 18
$PlexLogo.Location = New-Object System.Drawing.Size(600,110)
$PlexLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Plex.png"
$PlexLogo.ImageLocation = $PlexLogoFile
$PlexLogo.BorderStyle = 0
$PlexLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PlexLogo)

$PlexCheckbox = New-Object System.Windows.Forms.Checkbox 
$PlexCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$PlexCheckbox.Text = "       Plex"
$PlexCheckbox.Width = 180
$PlexCheckbox.Height = 20
$PlexCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PlexCheckbox)

$SpotifyLogo = New-Object System.Windows.Forms.PictureBox
$SpotifyLogo.Width = 18
$SpotifyLogo.Height = 18
$SpotifyLogo.Location = New-Object System.Drawing.Size(600,130)
$SpotifyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Spotify.png"
$SpotifyLogo.ImageLocation = $SpotifyLogoFile
$SpotifyLogo.BorderStyle = 0
$SpotifyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SpotifyLogo)

$SpotifyCheckbox = New-Object System.Windows.Forms.Checkbox 
$SpotifyCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$SpotifyCheckbox.Text = "       Spotify"
$SpotifyCheckbox.Width = 180
$SpotifyCheckbox.Height = 20
$SpotifyCheckbox.Font = $BodyFont
$Tab1.Controls.Add($SpotifyCheckbox)

$VLCLogo = New-Object System.Windows.Forms.PictureBox
$VLCLogo.Width = 18
$VLCLogo.Height = 18
$VLCLogo.Location = New-Object System.Drawing.Size(600,150)
$VLCLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\VLC.png"
$VLCLogo.ImageLocation = $VLCLogoFile
$VLCLogo.BorderStyle = 0
$VLCLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($VLCLogo)

$VLCCheckbox = New-Object System.Windows.Forms.Checkbox 
$VLCCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$VLCCheckbox.Text = "       VLC Player"
$VLCCheckbox.Width = 180
$VLCCheckbox.Height = 20
$VLCCheckbox.Font = $BodyFont
$Tab1.Controls.Add($VLCCheckbox)

$P2PLabel = New-Object System.Windows.Forms.Label
$P2PLabel.Location = New-Object System.Drawing.Size(580,190)
$P2PLabel.Text = "P2P"
$P2PLabel.Width = 180
$P2PLabel.Height = 20
$P2PLabel.Font = $HeaderFont
$Tab1.Controls.Add($P2PLabel)

$BitTorrentLogo = New-Object System.Windows.Forms.PictureBox
$BitTorrentLogo.Width = 18
$BitTorrentLogo.Height = 18
$BitTorrentLogo.Location = New-Object System.Drawing.Size(600,210)
$BitTorrentLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\BitTorrent.png"
$BitTorrentLogo.ImageLocation = $BitTorrentLogoFile
$BitTorrentLogo.BorderStyle = 0
$BitTorrentLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($BitTorrentLogo)

$BitTorrentCheckbox = New-Object System.Windows.Forms.Checkbox 
$BitTorrentCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$BitTorrentCheckbox.Text = "       BitTorrent"
$BitTorrentCheckbox.Width = 180
$BitTorrentCheckbox.Height = 20
$BitTorrentCheckbox.Font = $BodyFont
$Tab1.Controls.Add($BitTorrentCheckbox)

$qBittorrentLogo = New-Object System.Windows.Forms.PictureBox
$qBittorrentLogo.Width = 18
$qBittorrentLogo.Height = 18
$qBittorrentLogo.Location = New-Object System.Drawing.Size(600,230)
$qBittorrentLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\qBittorrent.png"
$qBittorrentLogo.ImageLocation = $qBittorrentLogoFile
$qBittorrentLogo.BorderStyle = 0
$qBittorrentLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($qBittorrentLogo)

$qBittorrentCheckbox = New-Object System.Windows.Forms.Checkbox 
$qBittorrentCheckbox.Location = New-Object System.Drawing.Size(580,230) 
$qBittorrentCheckbox.Text = "       qBittorrent"
$qBittorrentCheckbox.Width = 180
$qBittorrentCheckbox.Height = 20
$qBittorrentCheckbox.Font = $BodyFont
$Tab1.Controls.Add($qBittorrentCheckbox)

$uTorrentLogo = New-Object System.Windows.Forms.PictureBox
$uTorrentLogo.Width = 18
$uTorrentLogo.Height = 18
$uTorrentLogo.Location = New-Object System.Drawing.Size(600,250)
$uTorrentLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\uTorrent.png"
$uTorrentLogo.ImageLocation = $uTorrentLogoFile
$uTorrentLogo.BorderStyle = 0
$uTorrentLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($uTorrentLogo)

$uTorrentCheckbox = New-Object System.Windows.Forms.Checkbox 
$uTorrentCheckbox.Location = New-Object System.Drawing.Size(580,250) 
$uTorrentCheckbox.Text = "       uTorrent"
$uTorrentCheckbox.Width = 180
$uTorrentCheckbox.Height = 20
$uTorrentCheckbox.Font = $BodyFont
$Tab1.Controls.Add($uTorrentCheckbox)

$SocialLabel = New-Object System.Windows.Forms.Label
$SocialLabel.Location = New-Object System.Drawing.Size(770,10)
$SocialLabel.Text = "Social"
$SocialLabel.Width = 180
$SocialLabel.Height = 20
$SocialLabel.Font = $HeaderFont
$Tab1.Controls.Add($SocialLabel)

$DiscordLogo = New-Object System.Windows.Forms.PictureBox
$DiscordLogo.Width = 18
$DiscordLogo.Height = 18
$DiscordLogo.Location = New-Object System.Drawing.Size(790,30)
$DiscordLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Discord.png"
$DiscordLogo.ImageLocation = $DiscordLogoFile
$DiscordLogo.BorderStyle = 0
$DiscordLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DiscordLogo)

$DiscordCheckbox = New-Object System.Windows.Forms.Checkbox 
$DiscordCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$DiscordCheckbox.Text = "       Discord"
$DiscordCheckbox.Width = 180
$DiscordCheckbox.Height = 20
$DiscordCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DiscordCheckbox)

$GSSupportLogo = New-Object System.Windows.Forms.PictureBox
$GSSupportLogo.Width = 18
$GSSupportLogo.Height = 18
$GSSupportLogo.Location = New-Object System.Drawing.Size(790,50)
$GSSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\GSSupport.png"
$GSSupportLogo.ImageLocation = $GSSupportLogoFile
$GSSupportLogo.BorderStyle = 0
$GSSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GSSupportLogo)

$GSSupportCheckbox = New-Object System.Windows.Forms.Checkbox 
$GSSupportCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$GSSupportCheckbox.Text = "       GS Support"
$GSSupportCheckbox.Width = 180
$GSSupportCheckbox.Height = 20
$GSSupportCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GSSupportCheckbox)

$SlackLogo = New-Object System.Windows.Forms.PictureBox
$SlackLogo.Width = 18
$SlackLogo.Height = 18
$SlackLogo.Location = New-Object System.Drawing.Size(790,70)
$SlackLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Slack.png"
$SlackLogo.ImageLocation = $SlackLogoFile
$SlackLogo.BorderStyle = 0
$SlackLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SlackLogo)

$SlackCheckbox = New-Object System.Windows.Forms.Checkbox 
$SlackCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$SlackCheckbox.Text = "       Slack"
$SlackCheckbox.Width = 180
$SlackCheckbox.Height = 20
$SlackCheckbox.Font = $BodyFont
$Tab1.Controls.Add($SlackCheckbox)

$TeamsLogo = New-Object System.Windows.Forms.PictureBox
$TeamsLogo.Width = 18
$TeamsLogo.Height = 18
$TeamsLogo.Location = New-Object System.Drawing.Size(790,90)
$TeamsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Teams.png"
$TeamsLogo.ImageLocation = $TeamsLogoFile
$TeamsLogo.BorderStyle = 0
$TeamsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TeamsLogo)

$TeamsCheckbox = New-Object System.Windows.Forms.Checkbox 
$TeamsCheckbox.Location = New-Object System.Drawing.Size(770,90) 
$TeamsCheckbox.Text = "       Teams"
$TeamsCheckbox.Width = 180
$TeamsCheckbox.Height = 20
$TeamsCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TeamsCheckbox)

$TeamviewerLogo = New-Object System.Windows.Forms.PictureBox
$TeamviewerLogo.Width = 18
$TeamviewerLogo.Height = 18
$TeamviewerLogo.Location = New-Object System.Drawing.Size(790,110)
$TeamviewerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Teamviewer.png"
$TeamviewerLogo.ImageLocation = $TeamviewerLogoFile
$TeamviewerLogo.BorderStyle = 0
$TeamviewerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TeamviewerLogo)

$TeamViewerCheckbox = New-Object System.Windows.Forms.Checkbox 
$TeamViewerCheckbox.Location = New-Object System.Drawing.Size(770,110) 
$TeamViewerCheckbox.Text = "       TeamViewer"
$TeamViewerCheckbox.Width = 180
$TeamViewerCheckbox.Height = 20
$TeamViewerCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TeamViewerCheckbox)

$TelegramLogo = New-Object System.Windows.Forms.PictureBox
$TelegramLogo.Width = 18
$TelegramLogo.Height = 18
$TelegramLogo.Location = New-Object System.Drawing.Size(790,130)
$TelegramLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Telegram.png"
$TelegramLogo.ImageLocation = $TelegramLogoFile
$TelegramLogo.BorderStyle = 0
$TelegramLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TelegramLogo)

$TelegramCheckbox = New-Object System.Windows.Forms.Checkbox 
$TelegramCheckbox.Location = New-Object System.Drawing.Size(770,130) 
$TelegramCheckbox.Text = "       Telegram"
$TelegramCheckbox.Width = 180
$TelegramCheckbox.Height = 20
$TelegramCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TelegramCheckbox)

$ThunderbirdLogo = New-Object System.Windows.Forms.PictureBox
$ThunderbirdLogo.Width = 18
$ThunderbirdLogo.Height = 18
$ThunderbirdLogo.Location = New-Object System.Drawing.Size(790,150)
$ThunderbirdLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Thunderbird.png"
$ThunderbirdLogo.ImageLocation = $ThunderbirdLogoFile
$ThunderbirdLogo.BorderStyle = 0
$ThunderbirdLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ThunderbirdLogo)

$ThunderbirdCheckbox = New-Object System.Windows.Forms.Checkbox 
$ThunderbirdCheckbox.Location = New-Object System.Drawing.Size(770,150) 
$ThunderbirdCheckbox.Text = "       Thunderbird"
$ThunderbirdCheckbox.Width = 180
$ThunderbirdCheckbox.Height = 20
$ThunderbirdCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ThunderbirdCheckbox)

$WhatsAppLogo = New-Object System.Windows.Forms.PictureBox
$WhatsAppLogo.Width = 18
$WhatsAppLogo.Height = 18
$WhatsAppLogo.Location = New-Object System.Drawing.Size(790,170)
$WhatsAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\WhatsApp.png"
$WhatsAppLogo.ImageLocation = $WhatsAppLogoFile
$WhatsAppLogo.BorderStyle = 0
$WhatsAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($WhatsAppLogo)

$WhatsAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$WhatsAppCheckbox.Location = New-Object System.Drawing.Size(770,170) 
$WhatsAppCheckbox.Text = "       WhatsApp"
$WhatsAppCheckbox.Width = 180
$WhatsAppCheckbox.Height = 20
$WhatsAppCheckbox.Font = $BodyFont
$Tab1.Controls.Add($WhatsAppCheckbox)

$ZoomLogo = New-Object System.Windows.Forms.PictureBox
$ZoomLogo.Width = 18
$ZoomLogo.Height = 18
$ZoomLogo.Location = New-Object System.Drawing.Size(790,190)
$ZoomLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Zoom.png"
$ZoomLogo.ImageLocation = $ZoomLogoFile
$ZoomLogo.BorderStyle = 0
$ZoomLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ZoomLogo)

$ZoomCheckbox = New-Object System.Windows.Forms.Checkbox 
$ZoomCheckbox.Location = New-Object System.Drawing.Size(770,190) 
$ZoomCheckbox.Text = "       Zoom"
$ZoomCheckbox.Width = 180
$ZoomCheckbox.Height = 20
$ZoomCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ZoomCheckbox)

$TravelLabel = New-Object System.Windows.Forms.Label
$TravelLabel.Location = New-Object System.Drawing.Size(960,10)
$TravelLabel.Text = "Travel"
$TravelLabel.Width = 180
$TravelLabel.Height = 20
$TravelLabel.Font = $HeaderFont
$Tab1.Controls.Add($TravelLabel)

$GarminLogo = New-Object System.Windows.Forms.PictureBox
$GarminLogo.Width = 18
$GarminLogo.Height = 18
$GarminLogo.Location = New-Object System.Drawing.Size(980,30)
$GarminLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Garmin.png"
$GarminLogo.ImageLocation = $GarminLogoFile
$GarminLogo.BorderStyle = 0
$GarminLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GarminLogo)

$GarminCheckbox = New-Object System.Windows.Forms.Checkbox 
$GarminCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$GarminCheckbox.Text = "       Garmin Express"
$GarminCheckbox.Width = 180
$GarminCheckbox.Height = 20
$GarminCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GarminCheckbox)

$GoogleEarthProLogo = New-Object System.Windows.Forms.PictureBox
$GoogleEarthProLogo.Width = 18
$GoogleEarthProLogo.Height = 18
$GoogleEarthProLogo.Location = New-Object System.Drawing.Size(980,50)
$GoogleEarthProLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\GoogleEarthPro.png"
$GoogleEarthProLogo.ImageLocation = $GoogleEarthProLogoFile
$GoogleEarthProLogo.BorderStyle = 0
$GoogleEarthProLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GoogleEarthProLogo)

$GoogleEarthProCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoogleEarthProCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$GoogleEarthProCheckbox.Text = "       Google Earth Pro"
$GoogleEarthProCheckbox.Width = 180
$GoogleEarthProCheckbox.Height = 20
$GoogleEarthProCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GoogleEarthProCheckbox)

$UtilitiesLabel = New-Object System.Windows.Forms.Label
$UtilitiesLabel.Location = New-Object System.Drawing.Size(960,90)
$UtilitiesLabel.Text = "Utilities"
$UtilitiesLabel.Width = 180
$UtilitiesLabel.Height = 20
$UtilitiesLabel.Font = $HeaderFont
$Tab1.Controls.Add($UtilitiesLabel)

$FluxLogo = New-Object System.Windows.Forms.PictureBox
$FluxLogo.Width = 18
$FluxLogo.Height = 18
$FluxLogo.Location = New-Object System.Drawing.Size(980,110)
$FluxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Flux.png"
$FluxLogo.ImageLocation = $FluxLogoFile
$FluxLogo.BorderStyle = 0
$FluxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($FluxLogo)

$FluxCheckbox = New-Object System.Windows.Forms.Checkbox 
$FluxCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$FluxCheckbox.Text = "       F.lux"
$FluxCheckbox.Width = 180
$FluxCheckbox.Height = 20
$FluxCheckbox.Font = $BodyFont
$Tab1.Controls.Add($FluxCheckbox)

$PowerToysLogo = New-Object System.Windows.Forms.PictureBox
$PowerToysLogo.Width = 18
$PowerToysLogo.Height = 18
$PowerToysLogo.Location = New-Object System.Drawing.Size(980,130)
$PowerToysLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\PowerToys.png"
$PowerToysLogo.ImageLocation = $PowerToysLogoFile
$PowerToysLogo.BorderStyle = 0
$PowerToysLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PowerToysLogo)

$PowerToysCheckbox = New-Object System.Windows.Forms.Checkbox 
$PowerToysCheckbox.Location = New-Object System.Drawing.Size(960,130) 
$PowerToysCheckbox.Text = "       PowerToys"
$PowerToysCheckbox.Width = 180
$PowerToysCheckbox.Height = 20
$PowerToysCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PowerToysCheckbox)

$RufusLogo = New-Object System.Windows.Forms.PictureBox
$RufusLogo.Width = 18
$RufusLogo.Height = 18
$RufusLogo.Location = New-Object System.Drawing.Size(980,150)
$RufusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Rufus.png"
$RufusLogo.ImageLocation = $RufusLogoFile
$RufusLogo.BorderStyle = 0
$RufusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($RufusLogo)

$RufusCheckbox = New-Object System.Windows.Forms.Checkbox 
$RufusCheckbox.Location = New-Object System.Drawing.Size(960,150) 
$RufusCheckbox.Text = "       Rufus"
$RufusCheckbox.Width = 180
$RufusCheckbox.Height = 20
$RufusCheckbox.Font = $BodyFont
$RufusCheckbox.AutoSize = $True
$Tab1.Controls.Add($RufusCheckbox)

$SuperF4Logo = New-Object System.Windows.Forms.PictureBox
$SuperF4Logo.Width = 18
$SuperF4Logo.Height = 18
$SuperF4Logo.Location = New-Object System.Drawing.Size(980,170)
$SuperF4LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\SuperF4.png"
$SuperF4Logo.ImageLocation = $SuperF4LogoFile
$SuperF4Logo.BorderStyle = 0
$SuperF4Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SuperF4Logo)

$SuperF4Checkbox = New-Object System.Windows.Forms.Checkbox 
$SuperF4Checkbox.Location = New-Object System.Drawing.Size(960,170) 
$SuperF4Checkbox.Text = "       SuperF4"
$SuperF4Checkbox.Width = 180
$SuperF4Checkbox.Height = 20
$SuperF4Checkbox.Font = $BodyFont
$SuperF4Checkbox.AutoSize = $True
$Tab1.Controls.Add($SuperF4Checkbox)

$VideoLabel = New-Object System.Windows.Forms.Label
$VideoLabel.Location = New-Object System.Drawing.Size(960,210)
$VideoLabel.Text = "Video"
$VideoLabel.Width = 180
$VideoLabel.Height = 20
$VideoLabel.Font = $HeaderFont
$Tab1.Controls.Add($VideoLabel)

$CapCutLogo = New-Object System.Windows.Forms.PictureBox
$CapCutLogo.Width = 18
$CapCutLogo.Height = 18
$CapCutLogo.Location = New-Object System.Drawing.Size(980,230)
$CapCutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\CapCut.png"
$CapCutLogo.ImageLocation = $CapCutLogoFile
$CapCutLogo.BorderStyle = 0
$CapCutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($CapCutLogo)

$CapCutCheckbox = New-Object System.Windows.Forms.Checkbox 
$CapCutCheckbox.Location = New-Object System.Drawing.Size(960,230) 
$CapCutCheckbox.Text = "       CapCut"
$CapCutCheckbox.Width = 180
$CapCutCheckbox.Height = 20
$CapCutCheckbox.Font = $BodyFont
$Tab1.Controls.Add($CapCutCheckbox)

$HandbrakeLogo = New-Object System.Windows.Forms.PictureBox
$HandbrakeLogo.Width = 18
$HandbrakeLogo.Height = 18
$HandbrakeLogo.Location = New-Object System.Drawing.Size(980,250)
$HandbrakeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Handbrake.png"
$HandbrakeLogo.ImageLocation = $HandbrakeLogoFile
$HandbrakeLogo.BorderStyle = 0
$HandbrakeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($HandbrakeLogo)

$HandbrakeCheckbox = New-Object System.Windows.Forms.Checkbox 
$HandbrakeCheckbox.Location = New-Object System.Drawing.Size(960,250) 
$HandbrakeCheckbox.Text = "       Handbrake"
$HandbrakeCheckbox.Width = 180
$HandbrakeCheckbox.Height = 20
$HandbrakeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($HandbrakeCheckbox)

$LightworksLogo = New-Object System.Windows.Forms.PictureBox
$LightworksLogo.Width = 18
$LightworksLogo.Height = 18
$LightworksLogo.Location = New-Object System.Drawing.Size(980,270)
$LightworksLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Lightworks.png"
$LightworksLogo.ImageLocation = $LightworksLogoFile
$LightworksLogo.BorderStyle = 0
$LightworksLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($LightworksLogo)

$LightworksCheckbox = New-Object System.Windows.Forms.Checkbox 
$LightworksCheckbox.Location = New-Object System.Drawing.Size(960,270) 
$LightworksCheckbox.Text = "       Lightworks"
$LightworksCheckbox.Width = 180
$LightworksCheckbox.Height = 20
$LightworksCheckbox.Font = $BodyFont
$Tab1.Controls.Add($LightworksCheckbox)

# Tab 2 GAMING
$Tab2 = New-Object System.Windows.Forms.TabPage
$Tab2.Text = "Gaming"
$Tab2.Font = $TabFont
$Tab2.Autoscroll  = $True
$TabControl.Controls.Add($Tab2)

$EmulationLabel = New-Object System.Windows.Forms.Label
$EmulationLabel.Location = New-Object System.Drawing.Size(10,10)
$EmulationLabel.Text = "Emulation 1"
$EmulationLabel.Width = 180
$EmulationLabel.Height = 20
$EmulationLabel.Font = $HeaderFont
$Tab2.Controls.Add($EmulationLabel)

$AzaharLogo = New-Object System.Windows.Forms.PictureBox
$AzaharLogo.Width = 18
$AzaharLogo.Height = 18
$AzaharLogo.Location = New-Object System.Drawing.Size(30,30)
$AzaharLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Azahar.png"
$AzaharLogo.ImageLocation = $AzaharLogoFile
$AzaharLogo.BorderStyle = 0
$AzaharLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($AzaharLogo)

$AzaharCheckbox = New-Object System.Windows.Forms.Checkbox 
$AzaharCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$AzaharCheckbox.Text = "       Azahar"
$AzaharCheckbox.Width = 180
$AzaharCheckbox.Height = 20
$AzaharCheckbox.Font = $BodyFont
$Tab2.Controls.Add($AzaharCheckbox)

$BlueStacksLogo = New-Object System.Windows.Forms.PictureBox
$BlueStacksLogo.Width = 18
$BlueStacksLogo.Height = 18
$BlueStacksLogo.Location = New-Object System.Drawing.Size(30,50)
$BlueStacksLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\BlueStacks.png"
$BlueStacksLogo.ImageLocation = $BlueStacksLogoFile
$BlueStacksLogo.BorderStyle = 0
$BlueStacksLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BlueStacksLogo)

$BlueStacksCheckbox = New-Object System.Windows.Forms.Checkbox 
$BlueStacksCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$BlueStacksCheckbox.Text = "       BlueStacks"
$BlueStacksCheckbox.Width = 180
$BlueStacksCheckbox.Height = 20
$BlueStacksCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BlueStacksCheckbox)

$CemuLogo = New-Object System.Windows.Forms.PictureBox
$CemuLogo.Width = 18
$CemuLogo.Height = 18
$CemuLogo.Location = New-Object System.Drawing.Size(30,70)
$CemuLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Cemu.png"
$CemuLogo.ImageLocation = $CemuLogoFile
$CemuLogo.BorderStyle = 0
$CemuLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CemuLogo)

$CemuCheckbox = New-Object System.Windows.Forms.Checkbox 
$CemuCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$CemuCheckbox.Text = "       Cemu"
$CemuCheckbox.Width = 180
$CemuCheckbox.Height = 20
$CemuCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CemuCheckbox)

$DeSmuMELogo = New-Object System.Windows.Forms.PictureBox
$DeSmuMELogo.Width = 18
$DeSmuMELogo.Height = 18
$DeSmuMELogo.Location = New-Object System.Drawing.Size(30,90)
$DeSmuMELogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DeSmuME.png"
$DeSmuMELogo.ImageLocation = $DeSmuMELogoFile
$DeSmuMELogo.BorderStyle = 0
$DeSmuMELogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DeSmuMELogo)

$DeSmuMECheckbox = New-Object System.Windows.Forms.Checkbox 
$DeSmuMECheckbox.Location = New-Object System.Drawing.Size(10,90) 
$DeSmuMECheckbox.Text = "       DeSmuME"
$DeSmuMECheckbox.Width = 180
$DeSmuMECheckbox.Height = 20
$DeSmuMECheckbox.Font = $BodyFont
$Tab2.Controls.Add($DeSmuMECheckbox)

$DolphinLogo = New-Object System.Windows.Forms.PictureBox
$DolphinLogo.Width = 18
$DolphinLogo.Height = 18
$DolphinLogo.Location = New-Object System.Drawing.Size(30,110)
$DolphinLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Dolphin.png"
$DolphinLogo.ImageLocation = $DolphinLogoFile
$DolphinLogo.BorderStyle = 0
$DolphinLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DolphinLogo)

$DolphinCheckbox = New-Object System.Windows.Forms.Checkbox 
$DolphinCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$DolphinCheckbox.Text = "       Dolphin"
$DolphinCheckbox.Width = 180
$DolphinCheckbox.Height = 20
$DolphinCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DolphinCheckbox)

$DOSBoxLogo = New-Object System.Windows.Forms.PictureBox
$DOSBoxLogo.Width = 18
$DOSBoxLogo.Height = 18
$DOSBoxLogo.Location = New-Object System.Drawing.Size(30,130)
$DOSBoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DOSBox.png"
$DOSBoxLogo.ImageLocation = $DOSBoxLogoFile
$DOSBoxLogo.BorderStyle = 0
$DOSBoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DOSBoxLogo)

$DOSBoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$DOSBoxCheckbox.Location = New-Object System.Drawing.Size(10,130) 
$DOSBoxCheckbox.Text = "       DOSBox"
$DOSBoxCheckbox.Width = 180
$DOSBoxCheckbox.Height = 20
$DOSBoxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DOSBoxCheckbox)

$EdenLogo = New-Object System.Windows.Forms.PictureBox
$EdenLogo.Width = 18
$EdenLogo.Height = 18
$EdenLogo.Location = New-Object System.Drawing.Size(30,150)
$EdenLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Eden.png"
$EdenLogo.ImageLocation = $EdenLogoFile
$EdenLogo.BorderStyle = 0
$EdenLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EdenLogo)

$EdenCheckbox = New-Object System.Windows.Forms.Checkbox 
$EdenCheckbox.Location = New-Object System.Drawing.Size(10,150) 
$EdenCheckbox.Text = "       Eden"
$EdenCheckbox.Width = 180
$EdenCheckbox.Height = 20
$EdenCheckbox.Font = $BodyFont
$Tab2.Controls.Add($EdenCheckbox)

$ePSXeLogo = New-Object System.Windows.Forms.PictureBox
$ePSXeLogo.Width = 18
$ePSXeLogo.Height = 18
$ePSXeLogo.Location = New-Object System.Drawing.Size(30,170)
$ePSXeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\ePSXe.png"
$ePSXeLogo.ImageLocation = $ePSXeLogoFile
$ePSXeLogo.BorderStyle = 0
$ePSXeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($ePSXeLogo)

$ePSXeCheckbox = New-Object System.Windows.Forms.Checkbox 
$ePSXeCheckbox.Location = New-Object System.Drawing.Size(10,170) 
$ePSXeCheckbox.Text = "       ePSXe"
$ePSXeCheckbox.Width = 180
$ePSXeCheckbox.Height = 20
$ePSXeCheckbox.Font = $BodyFont
$Tab2.Controls.Add($ePSXeCheckbox)

$HiganLogo = New-Object System.Windows.Forms.PictureBox
$HiganLogo.Width = 18
$HiganLogo.Height = 18
$HiganLogo.Location = New-Object System.Drawing.Size(30,190)
$HiganLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Higan.png"
$HiganLogo.ImageLocation = $HiganLogoFile
$HiganLogo.BorderStyle = 0
$HiganLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($HiganLogo)

$HiganCheckbox = New-Object System.Windows.Forms.Checkbox 
$HiganCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$HiganCheckbox.Text = "       Higan"
$HiganCheckbox.Width = 180
$HiganCheckbox.Height = 20
$HiganCheckbox.Font = $BodyFont
$Tab2.Controls.Add($HiganCheckbox)

$KegaFusionLogo = New-Object System.Windows.Forms.PictureBox
$KegaFusionLogo.Width = 18
$KegaFusionLogo.Height = 18
$KegaFusionLogo.Location = New-Object System.Drawing.Size(30,210)
$KegaFusionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\KegaFusion.png"
$KegaFusionLogo.ImageLocation = $KegaFusionLogoFile
$KegaFusionLogo.BorderStyle = 0
$KegaFusionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($KegaFusionLogo)

$KegaFusionCheckbox = New-Object System.Windows.Forms.Checkbox 
$KegaFusionCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$KegaFusionCheckbox.Text = "       Kega Fusion"
$KegaFusionCheckbox.Width = 180
$KegaFusionCheckbox.Height = 20
$KegaFusionCheckbox.Font = $BodyFont
$Tab2.Controls.Add($KegaFusionCheckbox)

$MAMELogo = New-Object System.Windows.Forms.PictureBox
$MAMELogo.Width = 18
$MAMELogo.Height = 18
$MAMELogo.Location = New-Object System.Drawing.Size(30,230)
$MAMELogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MAME.png"
$MAMELogo.ImageLocation = $MAMELogoFile
$MAMELogo.BorderStyle = 0
$MAMELogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MAMELogo)

$MAMECheckbox = New-Object System.Windows.Forms.Checkbox 
$MAMECheckbox.Location = New-Object System.Drawing.Size(10,230) 
$MAMECheckbox.Text = "       MAME"
$MAMECheckbox.Width = 180
$MAMECheckbox.Height = 20
$MAMECheckbox.Font = $BodyFont
$Tab2.Controls.Add($MAMECheckbox)

$NestopiaLogo = New-Object System.Windows.Forms.PictureBox
$NestopiaLogo.Width = 18
$NestopiaLogo.Height = 18
$NestopiaLogo.Location = New-Object System.Drawing.Size(30,250)
$NestopiaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Nestopia.png"
$NestopiaLogo.ImageLocation = $NestopiaLogoFile
$NestopiaLogo.BorderStyle = 0
$NestopiaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($NestopiaLogo)

$NestopiaCheckbox = New-Object System.Windows.Forms.Checkbox 
$NestopiaCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$NestopiaCheckbox.Text = "       Nestopia"
$NestopiaCheckbox.Width = 180
$NestopiaCheckbox.Height = 20
$NestopiaCheckbox.Font = $BodyFont
$Tab2.Controls.Add($NestopiaCheckbox)

$NoxPlayerLogo = New-Object System.Windows.Forms.PictureBox
$NoxPlayerLogo.Width = 18
$NoxPlayerLogo.Height = 18
$NoxPlayerLogo.Location = New-Object System.Drawing.Size(30,270)
$NoxPlayerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\NoxPlayer.png"
$NoxPlayerLogo.ImageLocation = $NoxPlayerLogoFile
$NoxPlayerLogo.BorderStyle = 0
$NoxPlayerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($NoxPlayerLogo)

$NoxPlayerCheckbox = New-Object System.Windows.Forms.Checkbox 
$NoxPlayerCheckbox.Location = New-Object System.Drawing.Size(10,270) 
$NoxPlayerCheckbox.Text = "       NoxPlayer"
$NoxPlayerCheckbox.Width = 180
$NoxPlayerCheckbox.Height = 20
$NoxPlayerCheckbox.Font = $BodyFont
$Tab2.Controls.Add($NoxPlayerCheckbox)

$Emulation2Label = New-Object System.Windows.Forms.Label
$Emulation2Label.Location = New-Object System.Drawing.Size(200,10)
$Emulation2Label.Text = "Emulation 2"
$Emulation2Label.Width = 180
$Emulation2Label.Height = 20
$Emulation2Label.Font = $HeaderFont
$Tab2.Controls.Add($Emulation2Label)

$PCSX2Logo = New-Object System.Windows.Forms.PictureBox
$PCSX2Logo.Width = 18
$PCSX2Logo.Height = 18
$PCSX2Logo.Location = New-Object System.Drawing.Size(220,30)
$PCSX2LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\PCSX2.png"
$PCSX2Logo.ImageLocation = $PCSX2LogoFile
$PCSX2Logo.BorderStyle = 0
$PCSX2Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($PCSX2Logo)

$PCSX2Checkbox = New-Object System.Windows.Forms.Checkbox 
$PCSX2Checkbox.Location = New-Object System.Drawing.Size(200,30) 
$PCSX2Checkbox.Text = "       PCSX2"
$PCSX2Checkbox.Width = 180
$PCSX2Checkbox.Height = 20
$PCSX2Checkbox.Font = $BodyFont
$Tab2.Controls.Add($PCSX2Checkbox)

$PPSSPPLogo = New-Object System.Windows.Forms.PictureBox
$PPSSPPLogo.Width = 18
$PPSSPPLogo.Height = 18
$PPSSPPLogo.Location = New-Object System.Drawing.Size(220,50)
$PPSSPPLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\PPSSPP.png"
$PPSSPPLogo.ImageLocation = $PPSSPPLogoFile
$PPSSPPLogo.BorderStyle = 0
$PPSSPPLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($PPSSPPLogo)

$PPSSPPCheckbox = New-Object System.Windows.Forms.Checkbox 
$PPSSPPCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$PPSSPPCheckbox.Text = "       PPSSPP"
$PPSSPPCheckbox.Width = 180
$PPSSPPCheckbox.Height = 20
$PPSSPPCheckbox.Font = $BodyFont
$Tab2.Controls.Add($PPSSPPCheckbox)

$Project64Logo = New-Object System.Windows.Forms.PictureBox
$Project64Logo.Width = 18
$Project64Logo.Height = 18
$Project64Logo.Location = New-Object System.Drawing.Size(220,70)
$Project64LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Project64.png"
$Project64Logo.ImageLocation = $Project64LogoFile
$Project64Logo.BorderStyle = 0
$Project64Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($Project64Logo)

$Project64Checkbox = New-Object System.Windows.Forms.Checkbox 
$Project64Checkbox.Location = New-Object System.Drawing.Size(200,70) 
$Project64Checkbox.Text = "       Project64"
$Project64Checkbox.Width = 180
$Project64Checkbox.Height = 20
$Project64Checkbox.Font = $BodyFont
$Tab2.Controls.Add($Project64Checkbox)

$RedreamLogo = New-Object System.Windows.Forms.PictureBox
$RedreamLogo.Width = 18
$RedreamLogo.Height = 18
$RedreamLogo.Location = New-Object System.Drawing.Size(220,90)
$RedreamLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Redream.png"
$RedreamLogo.ImageLocation = $RedreamLogoFile
$RedreamLogo.BorderStyle = 0
$RedreamLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RedreamLogo)

$RedreamCheckbox = New-Object System.Windows.Forms.Checkbox 
$RedreamCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$RedreamCheckbox.Text = "       Redream"
$RedreamCheckbox.Width = 180
$RedreamCheckbox.Height = 20
$RedreamCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RedreamCheckbox)

$RetroArchLogo = New-Object System.Windows.Forms.PictureBox
$RetroArchLogo.Width = 18
$RetroArchLogo.Height = 18
$RetroArchLogo.Location = New-Object System.Drawing.Size(220,110)
$RetroArchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RetroArch.png"
$RetroArchLogo.ImageLocation = $RetroArchLogoFile
$RetroArchLogo.BorderStyle = 0
$RetroArchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RetroArchLogo)

$RetroArchEmulationCheckbox = New-Object System.Windows.Forms.Checkbox 
$RetroArchEmulationCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$RetroArchEmulationCheckbox.Text = "       RetroArch"
$RetroArchEmulationCheckbox.Width = 180
$RetroArchEmulationCheckbox.Height = 20
$RetroArchEmulationCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RetroArchEmulationCheckbox)

$RPCS3Logo = New-Object System.Windows.Forms.PictureBox
$RPCS3Logo.Width = 18
$RPCS3Logo.Height = 18
$RPCS3Logo.Location = New-Object System.Drawing.Size(220,130)
$RPCS3LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RPCS3.png"
$RPCS3Logo.ImageLocation = $RPCS3LogoFile
$RPCS3Logo.BorderStyle = 0
$RPCS3Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RPCS3Logo)

$RPCS3Checkbox = New-Object System.Windows.Forms.Checkbox 
$RPCS3Checkbox.Location = New-Object System.Drawing.Size(200,130) 
$RPCS3Checkbox.Text = "       RPCS3"
$RPCS3Checkbox.Width = 180
$RPCS3Checkbox.Height = 20
$RPCS3Checkbox.Font = $BodyFont
$Tab2.Controls.Add($RPCS3Checkbox)

$VirtualBoxLogo = New-Object System.Windows.Forms.PictureBox
$VirtualBoxLogo.Width = 18
$VirtualBoxLogo.Height = 18
$VirtualBoxLogo.Location = New-Object System.Drawing.Size(220,150)
$VirtualBoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\VirtualBox.png"
$VirtualBoxLogo.ImageLocation = $VirtualBoxLogoFile
$VirtualBoxLogo.BorderStyle = 0
$VirtualBoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($VirtualBoxLogo)

$VirtualBoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$VirtualBoxCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$VirtualBoxCheckbox.Text = "       VirtualBox"
$VirtualBoxCheckbox.Width = 180
$VirtualBoxCheckbox.Height = 20
$VirtualBoxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($VirtualBoxCheckbox)

$VisualBoyAdvanceLogo = New-Object System.Windows.Forms.PictureBox
$VisualBoyAdvanceLogo.Width = 18
$VisualBoyAdvanceLogo.Height = 18
$VisualBoyAdvanceLogo.Location = New-Object System.Drawing.Size(220,170)
$VisualBoyAdvanceLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\VisualBoyAdvance.png"
$VisualBoyAdvanceLogo.ImageLocation = $VisualBoyAdvanceLogoFile
$VisualBoyAdvanceLogo.BorderStyle = 0
$VisualBoyAdvanceLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($VisualBoyAdvanceLogo)

$VisualBoyAdvanceCheckbox = New-Object System.Windows.Forms.Checkbox 
$VisualBoyAdvanceCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$VisualBoyAdvanceCheckbox.Text = "       VisualBoyAdvance"
$VisualBoyAdvanceCheckbox.Width = 180
$VisualBoyAdvanceCheckbox.Height = 20
$VisualBoyAdvanceCheckbox.Font = $BodyFont
$Tab2.Controls.Add($VisualBoyAdvanceCheckbox)

$XemuLogo = New-Object System.Windows.Forms.PictureBox
$XemuLogo.Width = 18
$XemuLogo.Height = 18
$XemuLogo.Location = New-Object System.Drawing.Size(220,190)
$XemuLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Xemu.png"
$XemuLogo.ImageLocation = $XemuLogoFile
$XemuLogo.BorderStyle = 0
$XemuLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($XemuLogo)

$XemuCheckbox = New-Object System.Windows.Forms.Checkbox 
$XemuCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$XemuCheckbox.Text = "       Xemu"
$XemuCheckbox.Width = 180
$XemuCheckbox.Height = 20
$XemuCheckbox.Font = $BodyFont
$Tab2.Controls.Add($XemuCheckbox)

$XeniaLogo = New-Object System.Windows.Forms.PictureBox
$XeniaLogo.Width = 18
$XeniaLogo.Height = 18
$XeniaLogo.Location = New-Object System.Drawing.Size(220,210)
$XeniaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Xenia.png"
$XeniaLogo.ImageLocation = $XeniaLogoFile
$XeniaLogo.BorderStyle = 0
$XeniaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($XeniaLogo)

$XeniaCheckbox = New-Object System.Windows.Forms.Checkbox 
$XeniaCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$XeniaCheckbox.Text = "       Xenia"
$XeniaCheckbox.Width = 180
$XeniaCheckbox.Height = 20
$XeniaCheckbox.Font = $BodyFont
$Tab2.Controls.Add($XeniaCheckbox)

$YabauseLogo = New-Object System.Windows.Forms.PictureBox
$YabauseLogo.Width = 18
$YabauseLogo.Height = 18
$YabauseLogo.Location = New-Object System.Drawing.Size(220,230)
$YabauseLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Yabause.png"
$YabauseLogo.ImageLocation = $YabauseLogoFile
$YabauseLogo.BorderStyle = 0
$YabauseLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($YabauseLogo)

$YabauseCheckbox = New-Object System.Windows.Forms.Checkbox 
$YabauseCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$YabauseCheckbox.Text = "       Yabause"
$YabauseCheckbox.Width = 180
$YabauseCheckbox.Height = 20
$YabauseCheckbox.Font = $BodyFont
$Tab2.Controls.Add($YabauseCheckbox)

$FrontendLabel = New-Object System.Windows.Forms.Label
$FrontendLabel.Location = New-Object System.Drawing.Size(390,10)
$FrontendLabel.Text = "Frontend"
$FrontendLabel.Width = 180
$FrontendLabel.Height = 20
$FrontendLabel.Font = $HeaderFont
$Tab2.Controls.Add($FrontendLabel)

$EmulationStationLogo = New-Object System.Windows.Forms.PictureBox
$EmulationStationLogo.Width = 18
$EmulationStationLogo.Height = 18
$EmulationStationLogo.Location = New-Object System.Drawing.Size(410,30)
$EmulationStationLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\EmulationStation.png"
$EmulationStationLogo.ImageLocation = $EmulationStationLogoFile
$EmulationStationLogo.BorderStyle = 0
$EmulationStationLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EmulationStationLogo)

$EmulationStationCheckbox = New-Object System.Windows.Forms.Checkbox 
$EmulationStationCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$EmulationStationCheckbox.Text = "       Emulation Station"
$EmulationStationCheckbox.Width = 180
$EmulationStationCheckbox.Height = 20
$EmulationStationCheckbox.Font = $BodyFont
$Tab2.Controls.Add($EmulationStationCheckbox)

$LaunchBoxLogo = New-Object System.Windows.Forms.PictureBox
$LaunchBoxLogo.Width = 18
$LaunchBoxLogo.Height = 18
$LaunchBoxLogo.Location = New-Object System.Drawing.Size(410,50)
$LaunchBoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\LaunchBox.png"
$LaunchBoxLogo.ImageLocation = $LaunchBoxLogoFile
$LaunchBoxLogo.BorderStyle = 0
$LaunchBoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($LaunchBoxLogo)

$LaunchBoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$LaunchBoxCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$LaunchBoxCheckbox.Text = "       LaunchBox"
$LaunchBoxCheckbox.Width = 180
$LaunchBoxCheckbox.Height = 20
$LaunchBoxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($LaunchBoxCheckbox)

$PlayniteLogo = New-Object System.Windows.Forms.PictureBox
$PlayniteLogo.Width = 18
$PlayniteLogo.Height = 18
$PlayniteLogo.Location = New-Object System.Drawing.Size(410,70)
$PlayniteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Playnite.png"
$PlayniteLogo.ImageLocation = $PlayniteLogoFile
$PlayniteLogo.BorderStyle = 0
$PlayniteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($PlayniteLogo)

$PlayniteCheckbox = New-Object System.Windows.Forms.Checkbox 
$PlayniteCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$PlayniteCheckbox.Text = "       Playnite"
$PlayniteCheckbox.Width = 180
$PlayniteCheckbox.Height = 20
$PlayniteCheckbox.Font = $BodyFont
$Tab2.Controls.Add($PlayniteCheckbox)

$RetroArchLogo = New-Object System.Windows.Forms.PictureBox
$RetroArchLogo.Width = 18
$RetroArchLogo.Height = 18
$RetroArchLogo.Location = New-Object System.Drawing.Size(410,90)
$RetroArchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RetroArch.png"
$RetroArchLogo.ImageLocation = $RetroArchLogoFile
$RetroArchLogo.BorderStyle = 0
$RetroArchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RetroArchLogo)

$RetroArchCheckbox = New-Object System.Windows.Forms.Checkbox 
$RetroArchCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$RetroArchCheckbox.Text = "       RetroArch"
$RetroArchCheckbox.Width = 180
$RetroArchCheckbox.Height = 20
$RetroArchCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RetroArchCheckbox)

$GameBoosterLabel = New-Object System.Windows.Forms.Label
$GameBoosterLabel.Location = New-Object System.Drawing.Size(390,130)
$GameBoosterLabel.Text = "Game Booster"
$GameBoosterLabel.Width = 180
$GameBoosterLabel.Height = 20
$GameBoosterLabel.Font = $HeaderFont
$Tab2.Controls.Add($GameBoosterLabel)

$RazerCortexLogo = New-Object System.Windows.Forms.PictureBox
$RazerCortexLogo.Width = 18
$RazerCortexLogo.Height = 18
$RazerCortexLogo.Location = New-Object System.Drawing.Size(410,150)
$RazerCortexLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RazerCortex.png"
$RazerCortexLogo.ImageLocation = $RazerCortexLogoFile
$RazerCortexLogo.BorderStyle = 0
$RazerCortexLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RazerCortexLogo)

$RazerCortexCheckbox = New-Object System.Windows.Forms.Checkbox 
$RazerCortexCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$RazerCortexCheckbox.Text = "       RazerCortex"
$RazerCortexCheckbox.Width = 180
$RazerCortexCheckbox.Height = 20
$RazerCortexCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RazerCortexCheckbox)

$WiseGameBoosterLogo = New-Object System.Windows.Forms.PictureBox
$WiseGameBoosterLogo.Width = 18
$WiseGameBoosterLogo.Height = 18
$WiseGameBoosterLogo.Location = New-Object System.Drawing.Size(410,170)
$WiseGameBoosterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\WiseGameBooster.png"
$WiseGameBoosterLogo.ImageLocation = $WiseGameBoosterLogoFile
$WiseGameBoosterLogo.BorderStyle = 0
$WiseGameBoosterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($WiseGameBoosterLogo)

$WiseGameBoosterCheckbox = New-Object System.Windows.Forms.Checkbox 
$WiseGameBoosterCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$WiseGameBoosterCheckbox.Text = "       WiseGameBooster"
$WiseGameBoosterCheckbox.Width = 180
$WiseGameBoosterCheckbox.Height = 20
$WiseGameBoosterCheckbox.Font = $BodyFont
$Tab2.Controls.Add($WiseGameBoosterCheckbox)

$GamesLabel = New-Object System.Windows.Forms.Label
$GamesLabel.Location = New-Object System.Drawing.Size(390,210)
$GamesLabel.Text = "Games"
$GamesLabel.Width = 180
$GamesLabel.Height = 20
$GamesLabel.Font = $HeaderFont
$Tab2.Controls.Add($GamesLabel)

$LoLLogo = New-Object System.Windows.Forms.PictureBox
$LoLLogo.Width = 18
$LoLLogo.Height = 18
$LoLLogo.Location = New-Object System.Drawing.Size(410,230)
$LoLLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\LoL.png"
$LoLLogo.ImageLocation = $LoLLogoFile
$LoLLogo.BorderStyle = 0
$LoLLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($LoLLogo)

$LoLCheckbox = New-Object System.Windows.Forms.Checkbox 
$LoLCheckbox.Location = New-Object System.Drawing.Size(390,230) 
$LoLCheckbox.Text = "       LoL"
$LoLCheckbox.Width = 180
$LoLCheckbox.Height = 20
$LoLCheckbox.Font = $BodyFont
$Tab2.Controls.Add($LoLCheckbox)

$MTGArenaLogo = New-Object System.Windows.Forms.PictureBox
$MTGArenaLogo.Width = 18
$MTGArenaLogo.Height = 18
$MTGArenaLogo.Location = New-Object System.Drawing.Size(410,250)
$MTGArenaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MTGArena.png"
$MTGArenaLogo.ImageLocation = $MTGArenaLogoFile
$MTGArenaLogo.BorderStyle = 0
$MTGArenaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MTGArenaLogo)

$MTGArenaCheckbox = New-Object System.Windows.Forms.Checkbox 
$MTGArenaCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$MTGArenaCheckbox.Text = "       MTG Arena"
$MTGArenaCheckbox.Width = 180
$MTGArenaCheckbox.Height = 20
$MTGArenaCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MTGArenaCheckbox)

$MTGOLogo = New-Object System.Windows.Forms.PictureBox
$MTGOLogo.Width = 18
$MTGOLogo.Height = 18
$MTGOLogo.Location = New-Object System.Drawing.Size(410,270)
$MTGOLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MTGO.png"
$MTGOLogo.ImageLocation = $MTGOLogoFile
$MTGOLogo.BorderStyle = 0
$MTGOLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MTGOLogo)

$MTGOCheckbox = New-Object System.Windows.Forms.Checkbox 
$MTGOCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$MTGOCheckbox.Text = "       MTGO"
$MTGOCheckbox.Width = 180
$MTGOCheckbox.Height = 20
$MTGOCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MTGOCheckbox)

$OSULogo = New-Object System.Windows.Forms.PictureBox
$OSULogo.Width = 18
$OSULogo.Height = 18
$OSULogo.Location = New-Object System.Drawing.Size(410,290)
$OSULogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\OSU.png"
$OSULogo.ImageLocation = $OSULogoFile
$OSULogo.BorderStyle = 0
$OSULogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($OSULogo)

$OSUCheckbox = New-Object System.Windows.Forms.Checkbox 
$OSUCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$OSUCheckbox.Text = "       Osu!"
$OSUCheckbox.Width = 180
$OSUCheckbox.Height = 20
$OSUCheckbox.Font = $BodyFont
$Tab2.Controls.Add($OSUCheckbox)

$RobloxLogo = New-Object System.Windows.Forms.PictureBox
$RobloxLogo.Width = 18
$RobloxLogo.Height = 18
$RobloxLogo.Location = New-Object System.Drawing.Size(410,310)
$RobloxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Roblox.png"
$RobloxLogo.ImageLocation = $RobloxLogoFile
$RobloxLogo.BorderStyle = 0
$RobloxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RobloxLogo)

$RobloxCheckbox = New-Object System.Windows.Forms.Checkbox 
$RobloxCheckbox.Location = New-Object System.Drawing.Size(390,310) 
$RobloxCheckbox.Text = "       Roblox"
$RobloxCheckbox.Width = 180
$RobloxCheckbox.Height = 20
$RobloxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RobloxCheckbox)

$ValorantLogo = New-Object System.Windows.Forms.PictureBox
$ValorantLogo.Width = 18
$ValorantLogo.Height = 18
$ValorantLogo.Location = New-Object System.Drawing.Size(410,330)
$ValorantLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Valorant.png"
$ValorantLogo.ImageLocation = $ValorantLogoFile
$ValorantLogo.BorderStyle = 0
$ValorantLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($ValorantLogo)

$ValorantCheckbox = New-Object System.Windows.Forms.Checkbox 
$ValorantCheckbox.Location = New-Object System.Drawing.Size(390,330) 
$ValorantCheckbox.Text = "       Valorant"
$ValorantCheckbox.Width = 180
$ValorantCheckbox.Height = 20
$ValorantCheckbox.Font = $BodyFont
$Tab2.Controls.Add($ValorantCheckbox)

$LauncherLabel = New-Object System.Windows.Forms.Label
$LauncherLabel.Location = New-Object System.Drawing.Size(580,10)
$LauncherLabel.Text = "Launcher"
$LauncherLabel.Width = 180
$LauncherLabel.Height = 20
$LauncherLabel.Font = $HeaderFont
$Tab2.Controls.Add($LauncherLabel)

$BattleLogo = New-Object System.Windows.Forms.PictureBox
$BattleLogo.Width = 18
$BattleLogo.Height = 18
$BattleLogo.Location = New-Object System.Drawing.Size(600,30)
$BattleLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Battle.png"
$BattleLogo.ImageLocation = $BattleLogoFile
$BattleLogo.BorderStyle = 0
$BattleLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BattleLogo)

$BattleCheckbox = New-Object System.Windows.Forms.Checkbox 
$BattleCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$BattleCheckbox.Text = "       Battle.net"
$BattleCheckbox.Width = 180
$BattleCheckbox.Height = 20
$BattleCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BattleCheckbox)

$EALogo = New-Object System.Windows.Forms.PictureBox
$EALogo.Width = 18
$EALogo.Height = 18
$EALogo.Location = New-Object System.Drawing.Size(600,50)
$EALogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\EA.png"
$EALogo.ImageLocation = $EALogoFile
$EALogo.BorderStyle = 0
$EALogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EALogo)

$EACheckbox = New-Object System.Windows.Forms.Checkbox 
$EACheckbox.Location = New-Object System.Drawing.Size(580,50) 
$EACheckbox.Text = "       EA Desktop"
$EACheckbox.Width = 180
$EACheckbox.Height = 20
$EACheckbox.Font = $BodyFont
$Tab2.Controls.Add($EACheckbox)

$EpicGamesLogo = New-Object System.Windows.Forms.PictureBox
$EpicGamesLogo.Width = 18
$EpicGamesLogo.Height = 18
$EpicGamesLogo.Location = New-Object System.Drawing.Size(600,70)
$EpicGamesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\EpicGames.png"
$EpicGamesLogo.ImageLocation = $EpicGamesLogoFile
$EpicGamesLogo.BorderStyle = 0
$EpicGamesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EpicGamesLogo)

$EpicGamesCheckbox = New-Object System.Windows.Forms.Checkbox 
$EpicGamesCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$EpicGamesCheckbox.Text = "       Epic Games"
$EpicGamesCheckbox.Width = 180
$EpicGamesCheckbox.Height = 20
$EpicGamesCheckbox.Font = $BodyFont
$Tab2.Controls.Add($EpicGamesCheckbox)

$MinecraftLogo = New-Object System.Windows.Forms.PictureBox
$MinecraftLogo.Width = 18
$MinecraftLogo.Height = 18
$MinecraftLogo.Location = New-Object System.Drawing.Size(600,90)
$MinecraftLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Minecraft.png"
$MinecraftLogo.ImageLocation = $MinecraftLogoFile
$MinecraftLogo.BorderStyle = 0
$MinecraftLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MinecraftLogo)

$MinecraftCheckbox = New-Object System.Windows.Forms.Checkbox 
$MinecraftCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$MinecraftCheckbox.Text = "       Minecraft"
$MinecraftCheckbox.Width = 180
$MinecraftCheckbox.Height = 20
$MinecraftCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MinecraftCheckbox)

$RockstarLogo = New-Object System.Windows.Forms.PictureBox
$RockstarLogo.Width = 18
$RockstarLogo.Height = 18
$RockstarLogo.Location = New-Object System.Drawing.Size(600,110)
$RockstarLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Rockstar.png"
$RockstarLogo.ImageLocation = $RockstarLogoFile
$RockstarLogo.BorderStyle = 0
$RockstarLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RockstarLogo)

$RockstarCheckbox = New-Object System.Windows.Forms.Checkbox 
$RockstarCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$RockstarCheckbox.Text = "       Rockstar"
$RockstarCheckbox.Width = 180
$RockstarCheckbox.Height = 20
$RockstarCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RockstarCheckbox)

$SteamLogo = New-Object System.Windows.Forms.PictureBox
$SteamLogo.Width = 18
$SteamLogo.Height = 18
$SteamLogo.Location = New-Object System.Drawing.Size(600,130)
$SteamLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Steam.png"
$SteamLogo.ImageLocation = $SteamLogoFile
$SteamLogo.BorderStyle = 0
$SteamLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($SteamLogo)

$SteamCheckbox = New-Object System.Windows.Forms.Checkbox 
$SteamCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$SteamCheckbox.Text = "       Steam"
$SteamCheckbox.Width = 180
$SteamCheckbox.Height = 20
$SteamCheckbox.Font = $BodyFont
$Tab2.Controls.Add($SteamCheckbox)

$UbisoftConnectLogo = New-Object System.Windows.Forms.PictureBox
$UbisoftConnectLogo.Width = 18
$UbisoftConnectLogo.Height = 18
$UbisoftConnectLogo.Location = New-Object System.Drawing.Size(600,150)
$UbisoftConnectLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\UbisoftConnect.png"
$UbisoftConnectLogo.ImageLocation = $UbisoftConnectLogoFile
$UbisoftConnectLogo.BorderStyle = 0
$UbisoftConnectLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($UbisoftConnectLogo)

$UbisoftConnectCheckbox = New-Object System.Windows.Forms.Checkbox 
$UbisoftConnectCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$UbisoftConnectCheckbox.Text = "       Ubisoft Connect"
$UbisoftConnectCheckbox.Width = 180
$UbisoftConnectCheckbox.Height = 20
$UbisoftConnectCheckbox.Font = $BodyFont
$Tab2.Controls.Add($UbisoftConnectCheckbox)

$ModsLabel = New-Object System.Windows.Forms.Label
$ModsLabel.Location = New-Object System.Drawing.Size(770,10)
$ModsLabel.Text = "Mods"
$ModsLabel.Width = 180
$ModsLabel.Height = 20
$ModsLabel.Font = $HeaderFont
$Tab2.Controls.Add($ModsLabel)

$BakkesModLogo = New-Object System.Windows.Forms.PictureBox
$BakkesModLogo.Width = 18
$BakkesModLogo.Height = 18
$BakkesModLogo.Location = New-Object System.Drawing.Size(790,30)
$BakkesModLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\BakkesMod.png"
$BakkesModLogo.ImageLocation = $BakkesModLogoFile
$BakkesModLogo.BorderStyle = 0
$BakkesModLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BakkesModLogo)

$BakkesModCheckbox = New-Object System.Windows.Forms.Checkbox 
$BakkesModCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$BakkesModCheckbox.Text = "       BakkesMod"
$BakkesModCheckbox.Width = 180
$BakkesModCheckbox.Height = 20
$BakkesModCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BakkesModCheckbox)

$BrutalDoomLogo = New-Object System.Windows.Forms.PictureBox
$BrutalDoomLogo.Width = 18
$BrutalDoomLogo.Height = 18
$BrutalDoomLogo.Location = New-Object System.Drawing.Size(790,50)
$BrutalDoomLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\BrutalDoom.png"
$BrutalDoomLogo.ImageLocation = $BrutalDoomLogoFile
$BrutalDoomLogo.BorderStyle = 0
$BrutalDoomLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BrutalDoomLogo)

$BrutalDoomCheckbox = New-Object System.Windows.Forms.Checkbox 
$BrutalDoomCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$BrutalDoomCheckbox.Text = "       Brutal Doom"
$BrutalDoomCheckbox.Width = 180
$BrutalDoomCheckbox.Height = 20
$BrutalDoomCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BrutalDoomCheckbox)

$CheatEngineLogo = New-Object System.Windows.Forms.PictureBox
$CheatEngineLogo.Width = 18
$CheatEngineLogo.Height = 18
$CheatEngineLogo.Location = New-Object System.Drawing.Size(790,70)
$CheatEngineLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\CheatEngine.png"
$CheatEngineLogo.ImageLocation = $CheatEngineLogoFile
$CheatEngineLogo.BorderStyle = 0
$CheatEngineLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CheatEngineLogo)

$CheatEngineCheckbox = New-Object System.Windows.Forms.Checkbox 
$CheatEngineCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$CheatEngineCheckbox.Text = "       Cheat Engine"
$CheatEngineCheckbox.Width = 180
$CheatEngineCheckbox.Height = 20
$CheatEngineCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CheatEngineCheckbox)

$CurseForgeLogo = New-Object System.Windows.Forms.PictureBox
$CurseForgeLogo.Width = 18
$CurseForgeLogo.Height = 18
$CurseForgeLogo.Location = New-Object System.Drawing.Size(790,90)
$CurseForgeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\CurseForge.png"
$CurseForgeLogo.ImageLocation = $CurseForgeLogoFile
$CurseForgeLogo.BorderStyle = 0
$CurseForgeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CurseForgeLogo)

$CurseForgeCheckbox = New-Object System.Windows.Forms.Checkbox 
$CurseForgeCheckbox.Location = New-Object System.Drawing.Size(770,90) 
$CurseForgeCheckbox.Text = "       CurseForge"
$CurseForgeCheckbox.Width = 180
$CurseForgeCheckbox.Height = 20
$CurseForgeCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CurseForgeCheckbox)

$DoomInfiniteLogo = New-Object System.Windows.Forms.PictureBox
$DoomInfiniteLogo.Width = 18
$DoomInfiniteLogo.Height = 18
$DoomInfiniteLogo.Location = New-Object System.Drawing.Size(790,110)
$DoomInfiniteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DoomInfinite.png"
$DoomInfiniteLogo.ImageLocation = $DoomInfiniteLogoFile
$DoomInfiniteLogo.BorderStyle = 0
$DoomInfiniteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DoomInfiniteLogo)

$DoomInfiniteCheckbox = New-Object System.Windows.Forms.Checkbox 
$DoomInfiniteCheckbox.Location = New-Object System.Drawing.Size(770,110) 
$DoomInfiniteCheckbox.Text = "       Doom Infinite"
$DoomInfiniteCheckbox.Width = 180
$DoomInfiniteCheckbox.Height = 20
$DoomInfiniteCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DoomInfiniteCheckbox)

$FiveMLogo = New-Object System.Windows.Forms.PictureBox
$FiveMLogo.Width = 18
$FiveMLogo.Height = 18
$FiveMLogo.Location = New-Object System.Drawing.Size(790,130)
$FiveMLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\FiveM.png"
$FiveMLogo.ImageLocation = $FiveMLogoFile
$FiveMLogo.BorderStyle = 0
$FiveMLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($FiveMLogo)

$FiveMCheckbox = New-Object System.Windows.Forms.Checkbox 
$FiveMCheckbox.Location = New-Object System.Drawing.Size(770,130) 
$FiveMCheckbox.Text = "       FiveM"
$FiveMCheckbox.Width = 180
$FiveMCheckbox.Height = 20
$FiveMCheckbox.Font = $BodyFont
$Tab2.Controls.Add($FiveMCheckbox)

$TModLoaderLogo = New-Object System.Windows.Forms.PictureBox
$TModLoaderLogo.Width = 18
$TModLoaderLogo.Height = 18
$TModLoaderLogo.Location = New-Object System.Drawing.Size(790,150)
$TModLoaderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\TModLoader.png"
$TModLoaderLogo.ImageLocation = $TModLoaderLogoFile
$TModLoaderLogo.BorderStyle = 0
$TModLoaderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($TModLoaderLogo)

$TModLoaderCheckbox = New-Object System.Windows.Forms.Checkbox 
$TModLoaderCheckbox.Location = New-Object System.Drawing.Size(770,150) 
$TModLoaderCheckbox.Text = "       TModLoader"
$TModLoaderCheckbox.Width = 180
$TModLoaderCheckbox.Height = 20
$TModLoaderCheckbox.Font = $BodyFont
$Tab2.Controls.Add($TModLoaderCheckbox)

$RandomizersLogo = New-Object System.Windows.Forms.PictureBox
$RandomizersLogo.Width = 18
$RandomizersLogo.Height = 18
$RandomizersLogo.Location = New-Object System.Drawing.Size(790,170)
$RandomizersLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Randomizers.png"
$RandomizersLogo.ImageLocation = $RandomizersLogoFile
$RandomizersLogo.BorderStyle = 0
$RandomizersLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RandomizersLogo)

$RandomizersCheckbox = New-Object System.Windows.Forms.Checkbox 
$RandomizersCheckbox.Location = New-Object System.Drawing.Size(770,170) 
$RandomizersCheckbox.Text = "       Randomizers"
$RandomizersCheckbox.Width = 180
$RandomizersCheckbox.Height = 20
$RandomizersCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RandomizersCheckbox)

$VortexLogo = New-Object System.Windows.Forms.PictureBox
$VortexLogo.Width = 18
$VortexLogo.Height = 18
$VortexLogo.Location = New-Object System.Drawing.Size(790,190)
$VortexLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Vortex.png"
$VortexLogo.ImageLocation = $VortexLogoFile
$VortexLogo.BorderStyle = 0
$VortexLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($VortexLogo)

$VortexCheckbox = New-Object System.Windows.Forms.Checkbox 
$VortexCheckbox.Location = New-Object System.Drawing.Size(770,190) 
$VortexCheckbox.Text = "       Vortex"
$VortexCheckbox.Width = 180
$VortexCheckbox.Height = 20
$VortexCheckbox.Font = $BodyFont
$Tab2.Controls.Add($VortexCheckbox)

$WeModLogo = New-Object System.Windows.Forms.PictureBox
$WeModLogo.Width = 18
$WeModLogo.Height = 18
$WeModLogo.Location = New-Object System.Drawing.Size(790,210)
$WeModLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\WeMod.png"
$WeModLogo.ImageLocation = $WeModLogoFile
$WeModLogo.BorderStyle = 0
$WeModLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($WeModLogo)

$WeModCheckbox = New-Object System.Windows.Forms.Checkbox 
$WeModCheckbox.Location = New-Object System.Drawing.Size(770,210) 
$WeModCheckbox.Text = "       WeMod"
$WeModCheckbox.Width = 180
$WeModCheckbox.Height = 20
$WeModCheckbox.Font = $BodyFont
$Tab2.Controls.Add($WeModCheckbox)

$SpeedrunLabel = New-Object System.Windows.Forms.Label
$SpeedrunLabel.Location = New-Object System.Drawing.Size(770,250)
$SpeedrunLabel.Text = "Speedrun"
$SpeedrunLabel.Width = 180
$SpeedrunLabel.Height = 20
$SpeedrunLabel.Font = $HeaderFont
$Tab2.Controls.Add($SpeedrunLabel)

$LiveSplitLogo = New-Object System.Windows.Forms.PictureBox
$LiveSplitLogo.Width = 18
$LiveSplitLogo.Height = 18
$LiveSplitLogo.Location = New-Object System.Drawing.Size(790,270)
$LiveSplitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\LiveSplit.png"
$LiveSplitLogo.ImageLocation = $LiveSplitLogoFile
$LiveSplitLogo.BorderStyle = 0
$LiveSplitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($LiveSplitLogo)

$LiveSplitCheckbox = New-Object System.Windows.Forms.Checkbox 
$LiveSplitCheckbox.Location = New-Object System.Drawing.Size(770,270) 
$LiveSplitCheckbox.Text = "       LiveSplit"
$LiveSplitCheckbox.Width = 180
$LiveSplitCheckbox.Height = 20
$LiveSplitCheckbox.Font = $BodyFont
$Tab2.Controls.Add($LiveSplitCheckbox)

$StreamingLabel = New-Object System.Windows.Forms.Label
$StreamingLabel.Location = New-Object System.Drawing.Size(960,10)
$StreamingLabel.Text = "Streaming"
$StreamingLabel.Width = 180
$StreamingLabel.Height = 20
$StreamingLabel.Font = $HeaderFont
$Tab2.Controls.Add($StreamingLabel)

$ElgatoStreamDeckLogo = New-Object System.Windows.Forms.PictureBox
$ElgatoStreamDeckLogo.Width = 18
$ElgatoStreamDeckLogo.Height = 18
$ElgatoStreamDeckLogo.Location = New-Object System.Drawing.Size(980,30)
$ElgatoStreamDeckLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\ElgatoStreamDeck.png"
$ElgatoStreamDeckLogo.ImageLocation = $ElgatoStreamDeckLogoFile
$ElgatoStreamDeckLogo.BorderStyle = 0
$ElgatoStreamDeckLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($ElgatoStreamDeckLogo)

$ElgatoStreamDeckCheckbox = New-Object System.Windows.Forms.Checkbox 
$ElgatoStreamDeckCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$ElgatoStreamDeckCheckbox.Text = "       Elgato Stream Deck"
$ElgatoStreamDeckCheckbox.Width = 180
$ElgatoStreamDeckCheckbox.Height = 20
$ElgatoStreamDeckCheckbox.Font = $BodyFont
$Tab2.Controls.Add($ElgatoStreamDeckCheckbox)

$GroundControlLogo = New-Object System.Windows.Forms.PictureBox
$GroundControlLogo.Width = 18
$GroundControlLogo.Height = 18
$GroundControlLogo.Location = New-Object System.Drawing.Size(980,50)
$GroundControlLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\GroundControl.png"
$GroundControlLogo.ImageLocation = $GroundControlLogoFile
$GroundControlLogo.BorderStyle = 0
$GroundControlLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($GroundControlLogo)

$GroundControlCheckbox = New-Object System.Windows.Forms.Checkbox 
$GroundControlCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$GroundControlCheckbox.Text = "       Ground Control"
$GroundControlCheckbox.Width = 180
$GroundControlCheckbox.Height = 20
$GroundControlCheckbox.Font = $BodyFont
$Tab2.Controls.Add($GroundControlCheckbox)

$MeldStudioLogo = New-Object System.Windows.Forms.PictureBox
$MeldStudioLogo.Width = 18
$MeldStudioLogo.Height = 18
$MeldStudioLogo.Location = New-Object System.Drawing.Size(980,70)
$MeldStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MeldStudio.png"
$MeldStudioLogo.ImageLocation = $MeldStudioLogoFile
$MeldStudioLogo.BorderStyle = 0
$MeldStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MeldStudioLogo)

$MeldStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$MeldStudioCheckbox.Location = New-Object System.Drawing.Size(960,70) 
$MeldStudioCheckbox.Text = "       Meld Studio"
$MeldStudioCheckbox.Width = 180
$MeldStudioCheckbox.Height = 20
$MeldStudioCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MeldStudioCheckbox)

$OBSStudioLogo = New-Object System.Windows.Forms.PictureBox
$OBSStudioLogo.Width = 18
$OBSStudioLogo.Height = 18
$OBSStudioLogo.Location = New-Object System.Drawing.Size(980,90)
$OBSStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\OBS.png"
$OBSStudioLogo.ImageLocation = $OBSStudioLogoFile
$OBSStudioLogo.BorderStyle = 0
$OBSStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($OBSStudioLogo)

$OBSStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$OBSStudioCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$OBSStudioCheckbox.Text = "       OBS Studio"
$OBSStudioCheckbox.Width = 180
$OBSStudioCheckbox.Height = 20
$OBSStudioCheckbox.Font = $BodyFont
$Tab2.Controls.Add($OBSStudioCheckbox)

$StreamlabsLogo = New-Object System.Windows.Forms.PictureBox
$StreamlabsLogo.Width = 18
$StreamlabsLogo.Height = 18
$StreamlabsLogo.Location = New-Object System.Drawing.Size(980,110)
$StreamlabsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Streamlabs.png"
$StreamlabsLogo.ImageLocation = $StreamlabsLogoFile
$StreamlabsLogo.BorderStyle = 0
$StreamlabsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($StreamlabsLogo)

$StreamlabsCheckbox = New-Object System.Windows.Forms.Checkbox 
$StreamlabsCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$StreamlabsCheckbox.Text = "       Streamlabs"
$StreamlabsCheckbox.Width = 180
$StreamlabsCheckbox.Height = 20
$StreamlabsCheckbox.Font = $BodyFont
$Tab2.Controls.Add($StreamlabsCheckbox)

$ToolsLabel = New-Object System.Windows.Forms.Label
$ToolsLabel.Location = New-Object System.Drawing.Size(960,150)
$ToolsLabel.Text = "Tools"
$ToolsLabel.Width = 180
$ToolsLabel.Height = 20
$ToolsLabel.Font = $HeaderFont
$Tab2.Controls.Add($ToolsLabel)

$AntiMicroXLogo = New-Object System.Windows.Forms.PictureBox
$AntiMicroXLogo.Width = 18
$AntiMicroXLogo.Height = 18
$AntiMicroXLogo.Location = New-Object System.Drawing.Size(980,170)
$AntiMicroXLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\AntiMicroX.png"
$AntiMicroXLogo.ImageLocation = $AntiMicroXLogoFile
$AntiMicroXLogo.BorderStyle = 0
$AntiMicroXLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($AntiMicroXLogo)

$AntiMicroXCheckbox = New-Object System.Windows.Forms.Checkbox 
$AntiMicroXCheckbox.Location = New-Object System.Drawing.Size(960,170) 
$AntiMicroXCheckbox.Text = "       AntiMicroX"
$AntiMicroXCheckbox.Width = 180
$AntiMicroXCheckbox.Height = 20
$AntiMicroXCheckbox.Font = $BodyFont
$Tab2.Controls.Add($AntiMicroXCheckbox)

$DS4WindowsLogo = New-Object System.Windows.Forms.PictureBox
$DS4WindowsLogo.Width = 18
$DS4WindowsLogo.Height = 18
$DS4WindowsLogo.Location = New-Object System.Drawing.Size(980,190)
$DS4WindowsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DS4Windows.png"
$DS4WindowsLogo.ImageLocation = $DS4WindowsLogoFile
$DS4WindowsLogo.BorderStyle = 0
$DS4WindowsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DS4WindowsLogo)

$DS4WindowsCheckbox = New-Object System.Windows.Forms.Checkbox 
$DS4WindowsCheckbox.Location = New-Object System.Drawing.Size(960,190) 
$DS4WindowsCheckbox.Text = "       DS4Windows"
$DS4WindowsCheckbox.Width = 180
$DS4WindowsCheckbox.Height = 20
$DS4WindowsCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DS4WindowsCheckbox)

$SpecialKLogo = New-Object System.Windows.Forms.PictureBox
$SpecialKLogo.Width = 18
$SpecialKLogo.Height = 18
$SpecialKLogo.Location = New-Object System.Drawing.Size(980,210)
$SpecialKLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\SpecialK.png"
$SpecialKLogo.ImageLocation = $SpecialKLogoFile
$SpecialKLogo.BorderStyle = 0
$SpecialKLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($SpecialKLogo)

$SpecialKCheckbox = New-Object System.Windows.Forms.Checkbox 
$SpecialKCheckbox.Location = New-Object System.Drawing.Size(960,210) 
$SpecialKCheckbox.Text = "       Special K"
$SpecialKCheckbox.Width = 180
$SpecialKCheckbox.Height = 20
$SpecialKCheckbox.Font = $BodyFont
$Tab2.Controls.Add($SpecialKCheckbox)

$VirtualLANLabel = New-Object System.Windows.Forms.Label
$VirtualLANLabel.Location = New-Object System.Drawing.Size(960,250)
$VirtualLANLabel.Text = "Virtual LAN"
$VirtualLANLabel.Width = 180
$VirtualLANLabel.Height = 20
$VirtualLANLabel.Font = $HeaderFont
$Tab2.Controls.Add($VirtualLANLabel)

$HamachiLogo = New-Object System.Windows.Forms.PictureBox
$HamachiLogo.Width = 18
$HamachiLogo.Height = 18
$HamachiLogo.Location = New-Object System.Drawing.Size(980,270)
$HamachiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Hamachi.png"
$HamachiLogo.ImageLocation = $HamachiLogoFile
$HamachiLogo.BorderStyle = 0
$HamachiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($HamachiLogo)

$HamachiCheckbox = New-Object System.Windows.Forms.Checkbox 
$HamachiCheckbox.Location = New-Object System.Drawing.Size(960,270) 
$HamachiCheckbox.Text = "       Hamachi"
$HamachiCheckbox.Width = 180
$HamachiCheckbox.Height = 20
$HamachiCheckbox.Font = $BodyFont
$Tab2.Controls.Add($HamachiCheckbox)

# Tab 3 DEVELOPING
$Tab3 = New-Object System.Windows.Forms.TabPage
$Tab3.Text = "Developing"
$Tab3.Font = $TabFont
$Tab3.Autoscroll  = $True
$TabControl.Controls.Add($Tab3)

$DatabaseLabel = New-Object System.Windows.Forms.Label
$DatabaseLabel.Location = New-Object System.Drawing.Size(10,10)
$DatabaseLabel.Text = "Database"
$DatabaseLabel.Width = 180
$DatabaseLabel.Height = 20
$DatabaseLabel.Font = $HeaderFont
$Tab3.Controls.Add($DatabaseLabel)

$MongoDBLogo = New-Object System.Windows.Forms.PictureBox
$MongoDBLogo.Width = 18
$MongoDBLogo.Height = 18
$MongoDBLogo.Location = New-Object System.Drawing.Size(30,30)
$MongoDBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\MongoDB.png"
$MongoDBLogo.ImageLocation = $MongoDBLogoFile
$MongoDBLogo.BorderStyle = 0
$MongoDBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($MongoDBLogo)

$MongoDBCheckbox = New-Object System.Windows.Forms.Checkbox 
$MongoDBCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$MongoDBCheckbox.Text = "       MongoDB"
$MongoDBCheckbox.Width = 180
$MongoDBCheckbox.Height = 20
$MongoDBCheckbox.Font = $BodyFont
$Tab3.Controls.Add($MongoDBCheckbox)

$MySQLLogo = New-Object System.Windows.Forms.PictureBox
$MySQLLogo.Width = 18
$MySQLLogo.Height = 18
$MySQLLogo.Location = New-Object System.Drawing.Size(30,50)
$MySQLLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\MySQL.png"
$MySQLLogo.ImageLocation = $MySQLLogoFile
$MySQLLogo.BorderStyle = 0
$MySQLLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($MySQLLogo)

$MySQLCheckbox = New-Object System.Windows.Forms.Checkbox 
$MySQLCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$MySQLCheckbox.Text = "       MySQL"
$MySQLCheckbox.Width = 180
$MySQLCheckbox.Height = 20
$MySQLCheckbox.Font = $BodyFont
$Tab3.Controls.Add($MySQLCheckbox)

$PostgreSQLLogo = New-Object System.Windows.Forms.PictureBox
$PostgreSQLLogo.Width = 18
$PostgreSQLLogo.Height = 18
$PostgreSQLLogo.Location = New-Object System.Drawing.Size(30,70)
$PostgreSQLLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PostgreSQL.png"
$PostgreSQLLogo.ImageLocation = $PostgreSQLLogoFile
$PostgreSQLLogo.BorderStyle = 0
$PostgreSQLLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PostgreSQLLogo)

$PostgreSQLCheckbox = New-Object System.Windows.Forms.Checkbox 
$PostgreSQLCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$PostgreSQLCheckbox.Text = "       PostgreSQL"
$PostgreSQLCheckbox.Width = 180
$PostgreSQLCheckbox.Height = 20
$PostgreSQLCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PostgreSQLCheckbox)

$RedisLogo = New-Object System.Windows.Forms.PictureBox
$RedisLogo.Width = 18
$RedisLogo.Height = 18
$RedisLogo.Location = New-Object System.Drawing.Size(30,90)
$RedisLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Redis.png"
$RedisLogo.ImageLocation = $RedisLogoFile
$RedisLogo.BorderStyle = 0
$RedisLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RedisLogo)

$RedisCheckbox = New-Object System.Windows.Forms.Checkbox 
$RedisCheckbox.Location = New-Object System.Drawing.Size(10,90) 
$RedisCheckbox.Text = "       Redis Insite"
$RedisCheckbox.Width = 180
$RedisCheckbox.Height = 20
$RedisCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RedisCheckbox)

$SQLiteLogo = New-Object System.Windows.Forms.PictureBox
$SQLiteLogo.Width = 18
$SQLiteLogo.Height = 18
$SQLiteLogo.Location = New-Object System.Drawing.Size(30,110)
$SQLiteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\SQLite.png"
$SQLiteLogo.ImageLocation = $SQLiteLogoFile
$SQLiteLogo.BorderStyle = 0
$SQLiteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SQLiteLogo)

$SQLiteCheckbox = New-Object System.Windows.Forms.Checkbox 
$SQLiteCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$SQLiteCheckbox.Text = "       SQLite"
$SQLiteCheckbox.Width = 180
$SQLiteCheckbox.Height = 20
$SQLiteCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SQLiteCheckbox)

$GameEnginesLabel = New-Object System.Windows.Forms.Label
$GameEnginesLabel.Location = New-Object System.Drawing.Size(10,150)
$GameEnginesLabel.Text = "Game Engines"
$GameEnginesLabel.Width = 180
$GameEnginesLabel.Height = 20
$GameEnginesLabel.Font = $HeaderFont
$Tab3.Controls.Add($GameEnginesLabel)

$Construct3Logo = New-Object System.Windows.Forms.PictureBox
$Construct3Logo.Width = 18
$Construct3Logo.Height = 18
$Construct3Logo.Location = New-Object System.Drawing.Size(30,170)
$Construct3LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Construct3.png"
$Construct3Logo.ImageLocation = $Construct3LogoFile
$Construct3Logo.BorderStyle = 0
$Construct3Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($Construct3Logo)

$Construct3Checkbox = New-Object System.Windows.Forms.Checkbox 
$Construct3Checkbox.Location = New-Object System.Drawing.Size(10,170) 
$Construct3Checkbox.Text = "       Construct 3"
$Construct3Checkbox.Width = 180
$Construct3Checkbox.Height = 20
$Construct3Checkbox.Font = $BodyFont
$Tab3.Controls.Add($Construct3Checkbox)

$CryEngineLogo = New-Object System.Windows.Forms.PictureBox
$CryEngineLogo.Width = 18
$CryEngineLogo.Height = 18
$CryEngineLogo.Location = New-Object System.Drawing.Size(30,190)
$CryEngineLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\CryEngine.png"
$CryEngineLogo.ImageLocation = $CryEngineLogoFile
$CryEngineLogo.BorderStyle = 0
$CryEngineLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CryEngineLogo)

$CryEngineCheckbox = New-Object System.Windows.Forms.Checkbox 
$CryEngineCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$CryEngineCheckbox.Text = "       CryEngine"
$CryEngineCheckbox.Width = 180
$CryEngineCheckbox.Height = 20
$CryEngineCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CryEngineCheckbox)

$GameMakerLogo = New-Object System.Windows.Forms.PictureBox
$GameMakerLogo.Width = 18
$GameMakerLogo.Height = 18
$GameMakerLogo.Location = New-Object System.Drawing.Size(30,210)
$GameMakerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GameMaker.png"
$GameMakerLogo.ImageLocation = $GameMakerLogoFile
$GameMakerLogo.BorderStyle = 0
$GameMakerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GameMakerLogo)

$GameMakerCheckbox = New-Object System.Windows.Forms.Checkbox 
$GameMakerCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$GameMakerCheckbox.Text = "       GameMaker"
$GameMakerCheckbox.Width = 180
$GameMakerCheckbox.Height = 20
$GameMakerCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GameMakerCheckbox)

$GodotLogo = New-Object System.Windows.Forms.PictureBox
$GodotLogo.Width = 18
$GodotLogo.Height = 18
$GodotLogo.Location = New-Object System.Drawing.Size(30,230)
$GodotLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Godot.png"
$GodotLogo.ImageLocation = $GodotLogoFile
$GodotLogo.BorderStyle = 0
$GodotLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GodotLogo)

$GodotCheckbox = New-Object System.Windows.Forms.Checkbox 
$GodotCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$GodotCheckbox.Text = "       Godot"
$GodotCheckbox.Width = 180
$GodotCheckbox.Height = 20
$GodotCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GodotCheckbox)

$UnityLogo = New-Object System.Windows.Forms.PictureBox
$UnityLogo.Width = 18
$UnityLogo.Height = 18
$UnityLogo.Location = New-Object System.Drawing.Size(30,250)
$UnityLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Unity.png"
$UnityLogo.ImageLocation = $UnityLogoFile
$UnityLogo.BorderStyle = 0
$UnityLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($UnityLogo)

$UnityCheckbox = New-Object System.Windows.Forms.Checkbox 
$UnityCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$UnityCheckbox.Text = "       Unity"
$UnityCheckbox.Width = 180
$UnityCheckbox.Height = 20
$UnityCheckbox.Font = $BodyFont
$Tab3.Controls.Add($UnityCheckbox)

$IDELabel = New-Object System.Windows.Forms.Label
$IDELabel.Location = New-Object System.Drawing.Size(200,10)
$IDELabel.Text = "IDE"
$IDELabel.Width = 180
$IDELabel.Height = 20
$IDELabel.Font = $HeaderFont
$Tab3.Controls.Add($IDELabel)

$AndroidStudioLogo = New-Object System.Windows.Forms.PictureBox
$AndroidStudioLogo.Width = 18
$AndroidStudioLogo.Height = 18
$AndroidStudioLogo.Location = New-Object System.Drawing.Size(220,30)
$AndroidStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\AndroidStudio.png"
$AndroidStudioLogo.ImageLocation = $AndroidStudioLogoFile
$AndroidStudioLogo.BorderStyle = 0
$AndroidStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($AndroidStudioLogo)

$AndroidStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$AndroidStudioCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$AndroidStudioCheckbox.Text = "       Android Studio"
$AndroidStudioCheckbox.Width = 180
$AndroidStudioCheckbox.Height = 20
$AndroidStudioCheckbox.Font = $BodyFont
$Tab3.Controls.Add($AndroidStudioCheckbox)

$CLionLogo = New-Object System.Windows.Forms.PictureBox
$CLionLogo.Width = 18
$CLionLogo.Height = 18
$CLionLogo.Location = New-Object System.Drawing.Size(220,50)
$CLionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\CLion.png"
$CLionLogo.ImageLocation = $CLionLogoFile
$CLionLogo.BorderStyle = 0
$CLionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CLionLogo)

$CLionCheckbox = New-Object System.Windows.Forms.Checkbox 
$CLionCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$CLionCheckbox.Text = "       CLion"
$CLionCheckbox.Width = 180
$CLionCheckbox.Height = 20
$CLionCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CLionCheckbox)

$DataGripLogo = New-Object System.Windows.Forms.PictureBox
$DataGripLogo.Width = 18
$DataGripLogo.Height = 18
$DataGripLogo.Location = New-Object System.Drawing.Size(220,70)
$DataGripLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\DataGrip.png"
$DataGripLogo.ImageLocation = $DataGripLogoFile
$DataGripLogo.BorderStyle = 0
$DataGripLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($DataGripLogo)

$DataGripCheckbox = New-Object System.Windows.Forms.Checkbox 
$DataGripCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$DataGripCheckbox.Text = "       DataGrip"
$DataGripCheckbox.Width = 180
$DataGripCheckbox.Height = 20
$DataGripCheckbox.Font = $BodyFont
$Tab3.Controls.Add($DataGripCheckbox)

$DataSpellLogo = New-Object System.Windows.Forms.PictureBox
$DataSpellLogo.Width = 18
$DataSpellLogo.Height = 18
$DataSpellLogo.Location = New-Object System.Drawing.Size(220,90)
$DataSpellLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\DataSpell.png"
$DataSpellLogo.ImageLocation = $DataSpellLogoFile
$DataSpellLogo.BorderStyle = 0
$DataSpellLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($DataSpellLogo)

$DataSpellCheckbox = New-Object System.Windows.Forms.Checkbox 
$DataSpellCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$DataSpellCheckbox.Text = "       DataSpell"
$DataSpellCheckbox.Width = 180
$DataSpellCheckbox.Height = 20
$DataSpellCheckbox.Font = $BodyFont
$Tab3.Controls.Add($DataSpellCheckbox)

$EclipseLogo = New-Object System.Windows.Forms.PictureBox
$EclipseLogo.Width = 18
$EclipseLogo.Height = 18
$EclipseLogo.Location = New-Object System.Drawing.Size(220,110)
$EclipseLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Eclipse.png"
$EclipseLogo.ImageLocation = $EclipseLogoFile
$EclipseLogo.BorderStyle = 0
$EclipseLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($EclipseLogo)

$EclipseCheckbox = New-Object System.Windows.Forms.Checkbox 
$EclipseCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$EclipseCheckbox.Text = "       Eclipse"
$EclipseCheckbox.Width = 180
$EclipseCheckbox.Height = 20
$EclipseCheckbox.Font = $BodyFont
$Tab3.Controls.Add($EclipseCheckbox)

$GoLandLogo = New-Object System.Windows.Forms.PictureBox
$GoLandLogo.Width = 18
$GoLandLogo.Height = 18
$GoLandLogo.Location = New-Object System.Drawing.Size(220,130)
$GoLandLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GoLand.png"
$GoLandLogo.ImageLocation = $GoLandLogoFile
$GoLandLogo.BorderStyle = 0
$GoLandLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GoLandLogo)

$GoLandCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoLandCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$GoLandCheckbox.Text = "       GoLand"
$GoLandCheckbox.Width = 180
$GoLandCheckbox.Height = 20
$GoLandCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GoLandCheckbox)

$IntelliJLogo = New-Object System.Windows.Forms.PictureBox
$IntelliJLogo.Width = 18
$IntelliJLogo.Height = 18
$IntelliJLogo.Location = New-Object System.Drawing.Size(220,150)
$IntelliJLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\IntelliJ.png"
$IntelliJLogo.ImageLocation = $IntelliJLogoFile
$IntelliJLogo.BorderStyle = 0
$IntelliJLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($IntelliJLogo)

$IntelliJCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelliJCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$IntelliJCheckbox.Text = "       IntelliJ"
$IntelliJCheckbox.Width = 180
$IntelliJCheckbox.Height = 20
$IntelliJCheckbox.Font = $BodyFont
$Tab3.Controls.Add($IntelliJCheckbox)

$JetBrainsToolboxLogo = New-Object System.Windows.Forms.PictureBox
$JetBrainsToolboxLogo.Width = 18
$JetBrainsToolboxLogo.Height = 18
$JetBrainsToolboxLogo.Location = New-Object System.Drawing.Size(220,170)
$JetBrainsToolboxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\JetBrainsToolbox.png"
$JetBrainsToolboxLogo.ImageLocation = $JetBrainsToolboxLogoFile
$JetBrainsToolboxLogo.BorderStyle = 0
$JetBrainsToolboxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JetBrainsToolboxLogo)

$JetBrainsToolboxCheckbox = New-Object System.Windows.Forms.Checkbox 
$JetBrainsToolboxCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$JetBrainsToolboxCheckbox.Text = "       JetBrains Toolbox"
$JetBrainsToolboxCheckbox.Width = 180
$JetBrainsToolboxCheckbox.Height = 20
$JetBrainsToolboxCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JetBrainsToolboxCheckbox)

$NotepadLogo = New-Object System.Windows.Forms.PictureBox
$NotepadLogo.Width = 18
$NotepadLogo.Height = 18
$NotepadLogo.Location = New-Object System.Drawing.Size(220,190)
$NotepadLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Notepad.png"
$NotepadLogo.ImageLocation = $NotepadLogoFile
$NotepadLogo.BorderStyle = 0
$NotepadLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($NotepadLogo)

$NotepadCheckbox = New-Object System.Windows.Forms.Checkbox 
$NotepadCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$NotepadCheckbox.Text = "       Notepad++"
$NotepadCheckbox.Width = 180
$NotepadCheckbox.Height = 20
$NotepadCheckbox.Font = $BodyFont
$Tab3.Controls.Add($NotepadCheckbox)

$PhpStormLogo = New-Object System.Windows.Forms.PictureBox
$PhpStormLogo.Width = 18
$PhpStormLogo.Height = 18
$PhpStormLogo.Location = New-Object System.Drawing.Size(220,210)
$PhpStormLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PhpStorm.png"
$PhpStormLogo.ImageLocation = $PhpStormLogoFile
$PhpStormLogo.BorderStyle = 0
$PhpStormLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PhpStormLogo)

$PhpStormCheckbox = New-Object System.Windows.Forms.Checkbox 
$PhpStormCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$PhpStormCheckbox.Text = "       PhpStorm"
$PhpStormCheckbox.Width = 180
$PhpStormCheckbox.Height = 20
$PhpStormCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PhpStormCheckbox)

$PyCharmLogo = New-Object System.Windows.Forms.PictureBox
$PyCharmLogo.Width = 18
$PyCharmLogo.Height = 18
$PyCharmLogo.Location = New-Object System.Drawing.Size(220,230)
$PyCharmLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PyCharm.png"
$PyCharmLogo.ImageLocation = $PyCharmLogoFile
$PyCharmLogo.BorderStyle = 0
$PyCharmLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PyCharmLogo)

$PyCharmCheckbox = New-Object System.Windows.Forms.Checkbox 
$PyCharmCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$PyCharmCheckbox.Text = "       PyCharm"
$PyCharmCheckbox.Width = 180
$PyCharmCheckbox.Height = 20
$PyCharmCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PyCharmCheckbox)

$RiderLogo = New-Object System.Windows.Forms.PictureBox
$RiderLogo.Width = 18
$RiderLogo.Height = 18
$RiderLogo.Location = New-Object System.Drawing.Size(220,250)
$RiderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Rider.png"
$RiderLogo.ImageLocation = $PyCharmLogoFile
$RiderLogo.BorderStyle = 0
$RiderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RiderLogo)

$RiderCheckbox = New-Object System.Windows.Forms.Checkbox 
$RiderCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$RiderCheckbox.Text = "       Rider"
$RiderCheckbox.Width = 180
$RiderCheckbox.Height = 20
$RiderCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RiderCheckbox)

$RubyMineLogo = New-Object System.Windows.Forms.PictureBox
$RubyMineLogo.Width = 18
$RubyMineLogo.Height = 18
$RubyMineLogo.Location = New-Object System.Drawing.Size(220,270)
$RubyMineLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\RubyMine.png"
$RubyMineLogo.ImageLocation = $RubyMineLogoFile
$RubyMineLogo.BorderStyle = 0
$RubyMineLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RubyMineLogo)

$RubyMineCheckbox = New-Object System.Windows.Forms.Checkbox 
$RubyMineCheckbox.Location = New-Object System.Drawing.Size(200,270) 
$RubyMineCheckbox.Text = "       RubyMine"
$RubyMineCheckbox.Width = 180
$RubyMineCheckbox.Height = 20
$RubyMineCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RubyMineCheckbox)

$SublimeTextLogo = New-Object System.Windows.Forms.PictureBox
$SublimeTextLogo.Width = 18
$SublimeTextLogo.Height = 18
$SublimeTextLogo.Location = New-Object System.Drawing.Size(220,290)
$SublimeTextLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\SublimeText.png"
$SublimeTextLogo.ImageLocation = $SublimeTextLogoFile
$SublimeTextLogo.BorderStyle = 0
$SublimeTextLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SublimeTextLogo)

$SublimeTextCheckbox = New-Object System.Windows.Forms.Checkbox 
$SublimeTextCheckbox.Location = New-Object System.Drawing.Size(200,290) 
$SublimeTextCheckbox.Text = "       Sublime Text"
$SublimeTextCheckbox.Width = 180
$SublimeTextCheckbox.Height = 20
$SublimeTextCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SublimeTextCheckbox)

$VisualStudioLogo = New-Object System.Windows.Forms.PictureBox
$VisualStudioLogo.Width = 18
$VisualStudioLogo.Height = 18
$VisualStudioLogo.Location = New-Object System.Drawing.Size(220,310)
$VisualStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\VisualStudio.png"
$VisualStudioLogo.ImageLocation = $VisualStudioLogoFile
$VisualStudioLogo.BorderStyle = 0
$VisualStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($VisualStudioLogo)

$VisualStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$VisualStudioCheckbox.Location = New-Object System.Drawing.Size(200,310) 
$VisualStudioCheckbox.Text = "       Visual Studio"
$VisualStudioCheckbox.Width = 180
$VisualStudioCheckbox.Height = 20
$VisualStudioCheckbox.Font = $BodyFont
$Tab3.Controls.Add($VisualStudioCheckbox)

$WebStormLogo = New-Object System.Windows.Forms.PictureBox
$WebStormLogo.Width = 18
$WebStormLogo.Height = 18
$WebStormLogo.Location = New-Object System.Drawing.Size(220,330)
$WebStormLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\WebStorm.png"
$WebStormLogo.ImageLocation = $WebStormLogoFile
$WebStormLogo.BorderStyle = 0
$WebStormLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($WebStormLogo)

$WebStormCheckbox = New-Object System.Windows.Forms.Checkbox 
$WebStormCheckbox.Location = New-Object System.Drawing.Size(200,330) 
$WebStormCheckbox.Text = "       WebStorm"
$WebStormCheckbox.Width = 180
$WebStormCheckbox.Height = 20
$WebStormCheckbox.Font = $BodyFont
$Tab3.Controls.Add($WebStormCheckbox)

$LanguageLabel = New-Object System.Windows.Forms.Label
$LanguageLabel.Location = New-Object System.Drawing.Size(390,10)
$LanguageLabel.Text = "Language"
$LanguageLabel.Width = 180
$LanguageLabel.Height = 20
$LanguageLabel.Font = $HeaderFont
$Tab3.Controls.Add($LanguageLabel)

$GoLogo = New-Object System.Windows.Forms.PictureBox
$GoLogo.Width = 18
$GoLogo.Height = 18
$GoLogo.Location = New-Object System.Drawing.Size(410,30)
$GoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Go.png"
$GoLogo.ImageLocation = $GoLogoFile
$GoLogo.BorderStyle = 0
$GoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GoLogo)

$GoCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$GoCheckbox.Text = "       Go"
$GoCheckbox.Width = 180
$GoCheckbox.Height = 20
$GoCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GoCheckbox)

$JavaJDKLogo = New-Object System.Windows.Forms.PictureBox
$JavaJDKLogo.Width = 18
$JavaJDKLogo.Height = 18
$JavaJDKLogo.Location = New-Object System.Drawing.Size(410,50)
$JavaJDKLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Java.png"
$JavaJDKLogo.ImageLocation = $JavaJDKLogoFile
$JavaJDKLogo.BorderStyle = 0
$JavaJDKLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JavaJDKLogo)

$JavaJDKCheckbox = New-Object System.Windows.Forms.Checkbox 
$JavaJDKCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$JavaJDKCheckbox.Text = "       Java JDK"
$JavaJDKCheckbox.Width = 180
$JavaJDKCheckbox.Height = 20
$JavaJDKCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JavaJDKCheckbox)

$Python3Logo = New-Object System.Windows.Forms.PictureBox
$Python3Logo.Width = 18
$Python3Logo.Height = 18
$Python3Logo.Location = New-Object System.Drawing.Size(410,70)
$Python3LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Python3.png"
$Python3Logo.ImageLocation = $Python3LogoFile
$Python3Logo.BorderStyle = 0
$Python3Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($Python3Logo)

$Python3Checkbox = New-Object System.Windows.Forms.Checkbox 
$Python3Checkbox.Location = New-Object System.Drawing.Size(390,70) 
$Python3Checkbox.Text = "       Python3"
$Python3Checkbox.Width = 180
$Python3Checkbox.Height = 20
$Python3Checkbox.Font = $BodyFont
$Tab3.Controls.Add($Python3Checkbox)

$RLogo = New-Object System.Windows.Forms.PictureBox
$RLogo.Width = 18
$RLogo.Height = 18
$RLogo.Location = New-Object System.Drawing.Size(410,90)
$RLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\R.png"
$RLogo.ImageLocation = $RLogoFile
$RLogo.BorderStyle = 0
$RLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RLogo)

$RCheckbox = New-Object System.Windows.Forms.Checkbox 
$RCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$RCheckbox.Text = "       R"
$RCheckbox.Width = 180
$RCheckbox.Height = 20
$RCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RCheckbox)

$RubyLogo = New-Object System.Windows.Forms.PictureBox
$RubyLogo.Width = 18
$RubyLogo.Height = 18
$RubyLogo.Location = New-Object System.Drawing.Size(410,110)
$RubyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Ruby.png"
$RubyLogo.ImageLocation = $RubyLogoFile
$RubyLogo.BorderStyle = 0
$RubyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RubyLogo)

$RubyCheckbox = New-Object System.Windows.Forms.Checkbox 
$RubyCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$RubyCheckbox.Text = "       Ruby"
$RubyCheckbox.Width = 180
$RubyCheckbox.Height = 20
$RubyCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RubyCheckbox)

$RustupLogo = New-Object System.Windows.Forms.PictureBox
$RustupLogo.Width = 18
$RustupLogo.Height = 18
$RustupLogo.Location = New-Object System.Drawing.Size(410,130)
$RustupLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Rustup.png"
$RustupLogo.ImageLocation = $RustupLogoFile
$RustupLogo.BorderStyle = 0
$RustupLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RustupLogo)

$RustupCheckbox = New-Object System.Windows.Forms.Checkbox 
$RustupCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$RustupCheckbox.Text = "       Rustup"
$RustupCheckbox.Width = 180
$RustupCheckbox.Height = 20
$RustupCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RustupCheckbox)

$StrawberryPerlLogo = New-Object System.Windows.Forms.PictureBox
$StrawberryPerlLogo.Width = 18
$StrawberryPerlLogo.Height = 18
$StrawberryPerlLogo.Location = New-Object System.Drawing.Size(410,150)
$StrawberryPerlLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\StrawberryPerl.png"
$StrawberryPerlLogo.ImageLocation = $StrawberryPerlLogoFile
$StrawberryPerlLogo.BorderStyle = 0
$StrawberryPerlLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($StrawberryPerlLogo)

$StrawberryPerlCheckbox = New-Object System.Windows.Forms.Checkbox 
$StrawberryPerlCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$StrawberryPerlCheckbox.Text = "       Strawberry Perl"
$StrawberryPerlCheckbox.Width = 180
$StrawberryPerlCheckbox.Height = 20
$StrawberryPerlCheckbox.Font = $BodyFont
$Tab3.Controls.Add($StrawberryPerlCheckbox)

$SwiftLogo = New-Object System.Windows.Forms.PictureBox
$SwiftLogo.Width = 18
$SwiftLogo.Height = 18
$SwiftLogo.Location = New-Object System.Drawing.Size(410,170)
$SwiftLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Swift.png"
$SwiftLogo.ImageLocation = $SwiftLogoFile
$SwiftLogo.BorderStyle = 0
$SwiftLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SwiftLogo)

$SwiftCheckbox = New-Object System.Windows.Forms.Checkbox 
$SwiftCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$SwiftCheckbox.Text = "       Swift"
$SwiftCheckbox.Width = 180
$SwiftCheckbox.Height = 20
$SwiftCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SwiftCheckbox)

$PlanningLabel = New-Object System.Windows.Forms.Label
$PlanningLabel.Location = New-Object System.Drawing.Size(390,110)
$PlanningLabel.Text = "Planning"
$PlanningLabel.Width = 180
$PlanningLabel.Height = 20
$PlanningLabel.Font = $HeaderFont
$Tab3.Controls.Add($PlanningLabel)

$ClickUpLogo = New-Object System.Windows.Forms.PictureBox
$ClickUpLogo.Width = 18
$ClickUpLogo.Height = 18
$ClickUpLogo.Location = New-Object System.Drawing.Size(410,130)
$ClickUpLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\ClickUp.png"
$ClickUpLogo.ImageLocation = $ClickUpLogoFile
$ClickUpLogo.BorderStyle = 0
$ClickUpLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($ClickUpLogo)

$ClickUpCheckbox = New-Object System.Windows.Forms.Checkbox 
$ClickUpCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$ClickUpCheckbox.Text = "       ClickUp"
$ClickUpCheckbox.Width = 180
$ClickUpCheckbox.Height = 20
$ClickUpCheckbox.Font = $BodyFont
$Tab3.Controls.Add($ClickUpCheckbox)

$CodecksLogo = New-Object System.Windows.Forms.PictureBox
$CodecksLogo.Width = 18
$CodecksLogo.Height = 18
$CodecksLogo.Location = New-Object System.Drawing.Size(410,150)
$CodecksLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Codecks.png"
$CodecksLogo.ImageLocation = $CodecksLogoFile
$CodecksLogo.BorderStyle = 0
$CodecksLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CodecksLogo)

$CodecksCheckbox = New-Object System.Windows.Forms.Checkbox 
$CodecksCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$CodecksCheckbox.Text = "       Codecks"
$CodecksCheckbox.Width = 180
$CodecksCheckbox.Height = 20
$CodecksCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CodecksCheckbox)

$HacknPlanLogo = New-Object System.Windows.Forms.PictureBox
$HacknPlanLogo.Width = 18
$HacknPlanLogo.Height = 18
$HacknPlanLogo.Location = New-Object System.Drawing.Size(410,170)
$HacknPlanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\HacknPlan.png"
$HacknPlanLogo.ImageLocation = $HacknPlanLogoFile
$HacknPlanLogo.BorderStyle = 0
$HacknPlanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($HacknPlanLogo)

$HacknPlanCheckbox = New-Object System.Windows.Forms.Checkbox 
$HacknPlanCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$HacknPlanCheckbox.Text = "       HacknPlan"
$HacknPlanCheckbox.Width = 180
$HacknPlanCheckbox.Height = 20
$HacknPlanCheckbox.Font = $BodyFont
$Tab3.Controls.Add($HacknPlanCheckbox)

$RuntimesLabel = New-Object System.Windows.Forms.Label
$RuntimesLabel.Location = New-Object System.Drawing.Size(580,10)
$RuntimesLabel.Text = "Runtimes"
$RuntimesLabel.Width = 180
$RuntimesLabel.Height = 20
$RuntimesLabel.Font = $HeaderFont
$Tab3.Controls.Add($RuntimesLabel)

$NetLogo = New-Object System.Windows.Forms.PictureBox
$NetLogo.Width = 18
$NetLogo.Height = 18
$NetLogo.Location = New-Object System.Drawing.Size(600,30)
$NetLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Net.png"
$NetLogo.ImageLocation = $NetLogoFile
$NetLogo.BorderStyle = 0
$NetLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($NetLogo)

$NetCheckbox = New-Object System.Windows.Forms.Checkbox 
$NetCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$NetCheckbox.Text = "       .NET 4.8"
$NetCheckbox.Width = 180
$NetCheckbox.Height = 20
$NetCheckbox.Font = $BodyFont
$Tab3.Controls.Add($NetCheckbox)

$JavaLogo = New-Object System.Windows.Forms.PictureBox
$JavaLogo.Width = 18
$JavaLogo.Height = 18
$JavaLogo.Location = New-Object System.Drawing.Size(600,50)
$JavaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Java.png"
$JavaLogo.ImageLocation = $JavaLogoFile
$JavaLogo.BorderStyle = 0
$JavaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JavaLogo)

$JavaCheckbox = New-Object System.Windows.Forms.Checkbox 
$JavaCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$JavaCheckbox.Text = "       Java"
$JavaCheckbox.Width = 180
$JavaCheckbox.Height = 20
$JavaCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JavaCheckbox)

$NodejsLogo = New-Object System.Windows.Forms.PictureBox
$NodejsLogo.Width = 18
$NodejsLogo.Height = 18
$NodejsLogo.Location = New-Object System.Drawing.Size(600,70)
$NodejsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Nodejs.png"
$NodejsLogo.ImageLocation = $NodejsLogoFile
$NodejsLogo.BorderStyle = 0
$NodejsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($NodejsLogo)

$NodejsCheckbox = New-Object System.Windows.Forms.Checkbox 
$NodejsCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$NodejsCheckbox.Text = "       Node.js"
$NodejsCheckbox.Width = 180
$NodejsCheckbox.Height = 20
$NodejsCheckbox.Font = $BodyFont
$Tab3.Controls.Add($NodejsCheckbox)

$VisualLogo = New-Object System.Windows.Forms.PictureBox
$VisualLogo.Width = 18
$VisualLogo.Height = 18
$VisualLogo.Location = New-Object System.Drawing.Size(600,90)
$VisualLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Visual.png"
$VisualLogo.ImageLocation = $VisualLogoFile
$VisualLogo.BorderStyle = 0
$VisualLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($VisualLogo)

$VisualCheckbox = New-Object System.Windows.Forms.Checkbox 
$VisualCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$VisualCheckbox.Text = "       Visual C++"
$VisualCheckbox.Width = 180
$VisualCheckbox.Height = 20
$VisualCheckbox.Font = $BodyFont
$Tab3.Controls.Add($VisualCheckbox)

$TerminalLabel = New-Object System.Windows.Forms.Label
$TerminalLabel.Location = New-Object System.Drawing.Size(580,130)
$TerminalLabel.Text = "Terminal"
$TerminalLabel.Width = 180
$TerminalLabel.Height = 20
$TerminalLabel.Font = $HeaderFont
$Tab3.Controls.Add($TerminalLabel)

$CmderLogo = New-Object System.Windows.Forms.PictureBox
$CmderLogo.Width = 18
$CmderLogo.Height = 18
$CmderLogo.Location = New-Object System.Drawing.Size(600,150)
$CmderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Cmder.png"
$CmderLogo.ImageLocation = $CmderLogoFile
$CmderLogo.BorderStyle = 0
$CmderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CmderLogo)

$CmderCheckbox = New-Object System.Windows.Forms.Checkbox 
$CmderCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$CmderCheckbox.Text = "       Cmder"
$CmderCheckbox.Width = 180
$CmderCheckbox.Height = 20
$CmderCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CmderCheckbox)

$HyperLogo = New-Object System.Windows.Forms.PictureBox
$HyperLogo.Width = 18
$HyperLogo.Height = 18
$HyperLogo.Location = New-Object System.Drawing.Size(600,170)
$HyperLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Hyper.png"
$HyperLogo.ImageLocation = $HyperLogoFile
$HyperLogo.BorderStyle = 0
$HyperLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($HyperLogo)

$HyperCheckbox = New-Object System.Windows.Forms.Checkbox 
$HyperCheckbox.Location = New-Object System.Drawing.Size(580,170) 
$HyperCheckbox.Text = "       Hyper"
$HyperCheckbox.Width = 180
$HyperCheckbox.Height = 20
$HyperCheckbox.Font = $BodyFont
$Tab3.Controls.Add($HyperCheckbox)

$PuTTYLogo = New-Object System.Windows.Forms.PictureBox
$PuTTYLogo.Width = 18
$PuTTYLogo.Height = 18
$PuTTYLogo.Location = New-Object System.Drawing.Size(600,190)
$PuTTYLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PuTTY.png"
$PuTTYLogo.ImageLocation = $PuTTYLogoFile
$PuTTYLogo.BorderStyle = 0
$PuTTYLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PuTTYLogo)

$PuTTYCheckbox = New-Object System.Windows.Forms.Checkbox 
$PuTTYCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$PuTTYCheckbox.Text = "       PuTTY"
$PuTTYCheckbox.Width = 180
$PuTTYCheckbox.Height = 20
$PuTTYCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PuTTYCheckbox)

$TestingLabel = New-Object System.Windows.Forms.Label
$TestingLabel.Location = New-Object System.Drawing.Size(770,10)
$TestingLabel.Text = "Testing"
$TestingLabel.Width = 180
$TestingLabel.Height = 20
$TestingLabel.Font = $HeaderFont
$Tab3.Controls.Add($TestingLabel)

$BurpSuiteLogo = New-Object System.Windows.Forms.PictureBox
$BurpSuiteLogo.Width = 18
$BurpSuiteLogo.Height = 18
$BurpSuiteLogo.Location = New-Object System.Drawing.Size(790,30)
$BurpSuiteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\BurpSuite.png"
$BurpSuiteLogo.ImageLocation = $BurpSuiteLogoFile
$BurpSuiteLogo.BorderStyle = 0
$BurpSuiteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($BurpSuiteLogo)

$BurpSuiteCheckbox = New-Object System.Windows.Forms.Checkbox 
$BurpSuiteCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$BurpSuiteCheckbox.Text = "       BurpSuite"
$BurpSuiteCheckbox.Width = 180
$BurpSuiteCheckbox.Height = 20
$BurpSuiteCheckbox.Font = $BodyFont
$Tab3.Controls.Add($BurpSuiteCheckbox)

$JMeterLogo = New-Object System.Windows.Forms.PictureBox
$JMeterLogo.Width = 18
$JMeterLogo.Height = 18
$JMeterLogo.Location = New-Object System.Drawing.Size(790,50)
$JMeterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\JMeter.png"
$JMeterLogo.ImageLocation = $JMeterLogoFile
$JMeterLogo.BorderStyle = 0
$JMeterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JMeterLogo)

$JMeterCheckbox = New-Object System.Windows.Forms.Checkbox 
$JMeterCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$JMeterCheckbox.Text = "       JMeter"
$JMeterCheckbox.Width = 180
$JMeterCheckbox.Height = 20
$JMeterCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JMeterCheckbox)

$PostmanLogo = New-Object System.Windows.Forms.PictureBox
$PostmanLogo.Width = 18
$PostmanLogo.Height = 18
$PostmanLogo.Location = New-Object System.Drawing.Size(790,70)
$PostmanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Postman.png"
$PostmanLogo.ImageLocation = $PostmanLogoFile
$PostmanLogo.BorderStyle = 0
$PostmanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PostmanLogo)

$PostmanCheckbox = New-Object System.Windows.Forms.Checkbox 
$PostmanCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$PostmanCheckbox.Text = "       Postman"
$PostmanCheckbox.Width = 180
$PostmanCheckbox.Height = 20
$PostmanCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PostmanCheckbox)

$SoapUILogo = New-Object System.Windows.Forms.PictureBox
$SoapUILogo.Width = 18
$SoapUILogo.Height = 18
$SoapUILogo.Location = New-Object System.Drawing.Size(790,90)
$SoapUILogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\SoapUI.png"
$SoapUILogo.ImageLocation = $SoapUILogoFile
$SoapUILogo.BorderStyle = 0
$SoapUILogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SoapUILogo)

$SoapUICheckbox = New-Object System.Windows.Forms.Checkbox 
$SoapUICheckbox.Location = New-Object System.Drawing.Size(770,90) 
$SoapUICheckbox.Text = "       SoapUI"
$SoapUICheckbox.Width = 180
$SoapUICheckbox.Height = 20
$SoapUICheckbox.Font = $BodyFont
$Tab3.Controls.Add($SoapUICheckbox)

$ZAPLogo = New-Object System.Windows.Forms.PictureBox
$ZAPLogo.Width = 18
$ZAPLogo.Height = 18
$ZAPLogo.Location = New-Object System.Drawing.Size(790,110)
$ZAPLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\ZAP.png"
$ZAPLogo.ImageLocation = $ZAPLogoFile
$ZAPLogo.BorderStyle = 0
$ZAPLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($ZAPLogo)

$ZAPCheckbox = New-Object System.Windows.Forms.Checkbox 
$ZAPCheckbox.Location = New-Object System.Drawing.Size(770,110) 
$ZAPCheckbox.Text = "       ZAP"
$ZAPCheckbox.Width = 180
$ZAPCheckbox.Height = 20
$ZAPCheckbox.Font = $BodyFont
$Tab3.Controls.Add($ZAPCheckbox)

$VCSLabel = New-Object System.Windows.Forms.Label
$VCSLabel.Location = New-Object System.Drawing.Size(960,10)
$VCSLabel.Text = "VCS"
$VCSLabel.Width = 180
$VCSLabel.Height = 20
$VCSLabel.Font = $HeaderFont
$Tab3.Controls.Add($VCSLabel)

$GitLogo = New-Object System.Windows.Forms.PictureBox
$GitLogo.Width = 18
$GitLogo.Height = 18
$GitLogo.Location = New-Object System.Drawing.Size(980,30)
$GitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Git.png"
$GitLogo.ImageLocation = $GitLogoFile
$GitLogo.BorderStyle = 0
$GitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GitLogo)

$GitCheckbox = New-Object System.Windows.Forms.Checkbox 
$GitCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$GitCheckbox.Text = "       Git"
$GitCheckbox.Width = 180
$GitCheckbox.Height = 20
$GitCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GitCheckbox)

$GitLFSLogo = New-Object System.Windows.Forms.PictureBox
$GitLFSLogo.Width = 18
$GitLFSLogo.Height = 18
$GitLFSLogo.Location = New-Object System.Drawing.Size(980,50)
$GitLFSLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GitLFS.png"
$GitLFSLogo.ImageLocation = $GitLFSLogoFile
$GitLFSLogo.BorderStyle = 0
$GitLFSLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GitLFSLogo)

$GitLFSCheckbox = New-Object System.Windows.Forms.Checkbox 
$GitLFSCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$GitLFSCheckbox.Text = "       Git LFS"
$GitLFSCheckbox.Width = 180
$GitLFSCheckbox.Height = 20
$GitLFSCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GitLFSCheckbox)

$GitHubDesktopLogo = New-Object System.Windows.Forms.PictureBox
$GitHubDesktopLogo.Width = 18
$GitHubDesktopLogo.Height = 18
$GitHubDesktopLogo.Location = New-Object System.Drawing.Size(980,70)
$GitHubDesktopLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GitHubDesktop.png"
$GitHubDesktopLogo.ImageLocation = $GitHubDesktopLogoFile
$GitHubDesktopLogo.BorderStyle = 0
$GitHubDesktopLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GitHubDesktopLogo)

$GitHubDesktopCheckbox = New-Object System.Windows.Forms.Checkbox 
$GitHubDesktopCheckbox.Location = New-Object System.Drawing.Size(960,70) 
$GitHubDesktopCheckbox.Text = "       GitHub Desktop"
$GitHubDesktopCheckbox.Width = 180
$GitHubDesktopCheckbox.Height = 20
$GitHubDesktopCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GitHubDesktopCheckbox)

$SourcetreeLogo = New-Object System.Windows.Forms.PictureBox
$SourcetreeLogo.Width = 18
$SourcetreeLogo.Height = 18
$SourcetreeLogo.Location = New-Object System.Drawing.Size(980,90)
$SourcetreeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Sourcetree.png"
$SourcetreeLogo.ImageLocation = $SourcetreeLogoFile
$SourcetreeLogo.BorderStyle = 0
$SourcetreeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SourcetreeLogo)

$SourcetreeCheckbox = New-Object System.Windows.Forms.Checkbox 
$SourcetreeCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$SourcetreeCheckbox.Text = "       Sourcetree"
$SourcetreeCheckbox.Width = 180
$SourcetreeCheckbox.Height = 20
$SourcetreeCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SourcetreeCheckbox)

$TortoiseGitLogo = New-Object System.Windows.Forms.PictureBox
$TortoiseGitLogo.Width = 18
$TortoiseGitLogo.Height = 18
$TortoiseGitLogo.Location = New-Object System.Drawing.Size(980,110)
$TortoiseGitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\TortoiseGit.png"
$TortoiseGitLogo.ImageLocation = $TortoiseGitLogoFile
$TortoiseGitLogo.BorderStyle = 0
$TortoiseGitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($TortoiseGitLogo)

$TortoiseGitCheckbox = New-Object System.Windows.Forms.Checkbox 
$TortoiseGitCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$TortoiseGitCheckbox.Text = "       TortoiseGit"
$TortoiseGitCheckbox.Width = 180
$TortoiseGitCheckbox.Height = 20
$TortoiseGitCheckbox.Font = $BodyFont
$Tab3.Controls.Add($TortoiseGitCheckbox)

# Tab 4 DIAGNOSTIC
$Tab4 = New-Object System.Windows.Forms.TabPage
$Tab4.Text = "Diagnostic"
$Tab4.Font = $TabFont
$Tab4.Autoscroll  = $True
$TabControl.Controls.Add($Tab4)

$Audio2Label = New-Object System.Windows.Forms.Label
$Audio2Label.Location = New-Object System.Drawing.Size(10,10)
$Audio2Label.Text = "Audio"
$Audio2Label.Width = 180
$Audio2Label.Height = 20
$Audio2Label.Font = $HeaderFont
$Tab4.Controls.Add($Audio2Label)

$DPCLatCheckerLogo = New-Object System.Windows.Forms.PictureBox
$DPCLatCheckerLogo.Width = 18
$DPCLatCheckerLogo.Height = 18
$DPCLatCheckerLogo.Location = New-Object System.Drawing.Size(30,30)
$DPCLatCheckerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\DPCLatChecker.png"
$DPCLatCheckerLogo.ImageLocation = $DPCLatCheckerLogoFile
$DPCLatCheckerLogo.BorderStyle = 0
$DPCLatCheckerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($DPCLatCheckerLogo)

$DPCLatCheckerCheckbox = New-Object System.Windows.Forms.Checkbox
$DPCLatCheckerCheckbox.Location = New-Object System.Drawing.Size(10,30)
$DPCLatCheckerCheckbox.Text = "       DPC Lat Checker"
$DPCLatCheckerCheckbox.Width = 180
$DPCLatCheckerCheckbox.Height = 20
$DPCLatCheckerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($DPCLatCheckerCheckbox)

$EqualizerAPOLogo = New-Object System.Windows.Forms.PictureBox
$EqualizerAPOLogo.Width = 18
$EqualizerAPOLogo.Height = 18
$EqualizerAPOLogo.Location = New-Object System.Drawing.Size(30,50)
$EqualizerAPOLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\EqualizerAPO.png"
$EqualizerAPOLogo.ImageLocation = $EqualizerAPOLogoFile
$EqualizerAPOLogo.BorderStyle = 0
$EqualizerAPOLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($EqualizerAPOLogo)

$EqualizerAPOCheckbox = New-Object System.Windows.Forms.Checkbox
$EqualizerAPOCheckbox.Location = New-Object System.Drawing.Size(10,50)
$EqualizerAPOCheckbox.Text = "       Equalizer APO"
$EqualizerAPOCheckbox.Width = 180
$EqualizerAPOCheckbox.Height = 20
$EqualizerAPOCheckbox.Font = $BodyFont
$Tab4.Controls.Add($EqualizerAPOCheckbox)

$LatencyMonLogo = New-Object System.Windows.Forms.PictureBox
$LatencyMonLogo.Width = 18
$LatencyMonLogo.Height = 18
$LatencyMonLogo.Location = New-Object System.Drawing.Size(30,70)
$LatencyMonLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\LatencyMon.png"
$LatencyMonLogo.ImageLocation = $LatencyMonLogoFile
$LatencyMonLogo.BorderStyle = 0
$LatencyMonLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($LatencyMonLogo)

$LatencyMonCheckbox = New-Object System.Windows.Forms.Checkbox
$LatencyMonCheckbox.Location = New-Object System.Drawing.Size(10,70)
$LatencyMonCheckbox.Text = "       Latency Mon"
$LatencyMonCheckbox.Width = 180
$LatencyMonCheckbox.Height = 20
$LatencyMonCheckbox.Font = $BodyFont
$Tab4.Controls.Add($LatencyMonCheckbox)

$BatteryLabel = New-Object System.Windows.Forms.Label
$BatteryLabel.Location = New-Object System.Drawing.Size(10,110)
$BatteryLabel.Text = "Battery"
$BatteryLabel.Width = 180
$BatteryLabel.Height = 20
$BatteryLabel.Font = $HeaderFont
$Tab4.Controls.Add($BatteryLabel)

$BatteryInfoViewLogo = New-Object System.Windows.Forms.PictureBox
$BatteryInfoViewLogo.Width = 18
$BatteryInfoViewLogo.Height = 18
$BatteryInfoViewLogo.Location = New-Object System.Drawing.Size(30,130)
$BatteryInfoViewLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BatteryInfoView.png"
$BatteryInfoViewLogo.ImageLocation = $BatteryInfoViewLogoFile
$BatteryInfoViewLogo.BorderStyle = 0
$BatteryInfoViewLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BatteryInfoViewLogo)

$BatteryInfoViewCheckbox = New-Object System.Windows.Forms.Checkbox
$BatteryInfoViewCheckbox.Location = New-Object System.Drawing.Size(10,130)
$BatteryInfoViewCheckbox.Text = "       BatteryInfoView"
$BatteryInfoViewCheckbox.Width = 180
$BatteryInfoViewCheckbox.Height = 20
$BatteryInfoViewCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BatteryInfoViewCheckbox)

$BatteryMonLogo = New-Object System.Windows.Forms.PictureBox
$BatteryMonLogo.Width = 18
$BatteryMonLogo.Height = 18
$BatteryMonLogo.Location = New-Object System.Drawing.Size(30,150)
$BatteryMonLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BatteryMon.png"
$BatteryMonLogo.ImageLocation = $BatteryMonLogoFile
$BatteryMonLogo.BorderStyle = 0
$BatteryMonLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BatteryMonLogo)

$BatteryMonCheckbox = New-Object System.Windows.Forms.Checkbox
$BatteryMonCheckbox.Location = New-Object System.Drawing.Size(10,150)
$BatteryMonCheckbox.Text = "       BatteryMon"
$BatteryMonCheckbox.Width = 180
$BatteryMonCheckbox.Height = 20
$BatteryMonCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BatteryMonCheckbox)

$BenchmarkLabel = New-Object System.Windows.Forms.Label
$BenchmarkLabel.Location = New-Object System.Drawing.Size(10,190)
$BenchmarkLabel.Text = "Benchmark"
$BenchmarkLabel.Width = 180
$BenchmarkLabel.Height = 20
$BenchmarkLabel.Font = $HeaderFont
$Tab4.Controls.Add($BenchmarkLabel)

$3DMarkLogo = New-Object System.Windows.Forms.PictureBox
$3DMarkLogo.Width = 18
$3DMarkLogo.Height = 18
$3DMarkLogo.Location = New-Object System.Drawing.Size(30,210)
$3DMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\3DMark.png"
$3DMarkLogo.ImageLocation = $3DMarkLogoFile
$3DMarkLogo.BorderStyle = 0
$3DMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($3DMarkLogo)

$3DMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$3DMarkCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$3DMarkCheckbox.Text = "       3DMark"
$3DMarkCheckbox.Width = 180
$3DMarkCheckbox.Height = 20
$3DMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($3DMarkCheckbox)

$BlenderBenchmarkLogo = New-Object System.Windows.Forms.PictureBox
$BlenderBenchmarkLogo.Width = 18
$BlenderBenchmarkLogo.Height = 18
$BlenderBenchmarkLogo.Location = New-Object System.Drawing.Size(30,230)
$BlenderBenchmarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BlenderBenchmark.png"
$BlenderBenchmarkLogo.ImageLocation = $BlenderBenchmarkLogoFile
$BlenderBenchmarkLogo.BorderStyle = 0
$BlenderBenchmarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BlenderBenchmarkLogo)

$BlenderBenchmarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$BlenderBenchmarkCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$BlenderBenchmarkCheckbox.Text = "       Blender Benchmark"
$BlenderBenchmarkCheckbox.Width = 180
$BlenderBenchmarkCheckbox.Height = 20
$BlenderBenchmarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BlenderBenchmarkCheckbox)

$CinebenchLogo = New-Object System.Windows.Forms.PictureBox
$CinebenchLogo.Width = 18
$CinebenchLogo.Height = 18
$CinebenchLogo.Location = New-Object System.Drawing.Size(30,250)
$CinebenchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Cinebench.png"
$CinebenchLogo.ImageLocation = $CinebenchLogoFile
$CinebenchLogo.BorderStyle = 0
$CinebenchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CinebenchLogo)

$CinebenchCheckbox = New-Object System.Windows.Forms.Checkbox 
$CinebenchCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$CinebenchCheckbox.Text = "       Cinebench"
$CinebenchCheckbox.Width = 180
$CinebenchCheckbox.Height = 20
$CinebenchCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CinebenchCheckbox)

$CrystalDiskMarkLogo = New-Object System.Windows.Forms.PictureBox
$CrystalDiskMarkLogo.Width = 18
$CrystalDiskMarkLogo.Height = 18
$CrystalDiskMarkLogo.Location = New-Object System.Drawing.Size(30,270)
$CrystalDiskMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CrystalDiskMark.png"
$CrystalDiskMarkLogo.ImageLocation = $CrystalDiskMarkLogoFile
$CrystalDiskMarkLogo.BorderStyle = 0
$CrystalDiskMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CrystalDiskMarkLogo)

$CrystalDiskMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$CrystalDiskMarkCheckbox.Location = New-Object System.Drawing.Size(10,270) 
$CrystalDiskMarkCheckbox.Text = "       CrystalDiskMark"
$CrystalDiskMarkCheckbox.Width = 180
$CrystalDiskMarkCheckbox.Height = 20
$CrystalDiskMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CrystalDiskMarkCheckbox)

$GeekbenchLogo = New-Object System.Windows.Forms.PictureBox
$GeekbenchLogo.Width = 18
$GeekbenchLogo.Height = 18
$GeekbenchLogo.Location = New-Object System.Drawing.Size(30,290)
$GeekbenchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Geekbench.png"
$GeekbenchLogo.ImageLocation = $GeekbenchLogoFile
$GeekbenchLogo.BorderStyle = 0
$GeekbenchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GeekbenchLogo)

$GeekbenchCheckbox = New-Object System.Windows.Forms.Checkbox 
$GeekbenchCheckbox.Location = New-Object System.Drawing.Size(10,290) 
$GeekbenchCheckbox.Text = "       Geekbench"
$GeekbenchCheckbox.Width = 180
$GeekbenchCheckbox.Height = 20
$GeekbenchCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GeekbenchCheckbox)

$NovabenchLogo = New-Object System.Windows.Forms.PictureBox
$NovabenchLogo.Width = 18
$NovabenchLogo.Height = 18
$NovabenchLogo.Location = New-Object System.Drawing.Size(30,310)
$NovabenchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Novabench.png"
$NovabenchLogo.ImageLocation = $NovabenchLogoFile
$NovabenchLogo.BorderStyle = 0
$NovabenchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($NovabenchLogo)

$NovabenchCheckbox = New-Object System.Windows.Forms.Checkbox 
$NovabenchCheckbox.Location = New-Object System.Drawing.Size(10,310) 
$NovabenchCheckbox.Text = "       Novabench"
$NovabenchCheckbox.Width = 180
$NovabenchCheckbox.Height = 20
$NovabenchCheckbox.Font = $BodyFont
$Tab4.Controls.Add($NovabenchCheckbox)

$PCMarkLogo = New-Object System.Windows.Forms.PictureBox
$PCMarkLogo.Width = 18
$PCMarkLogo.Height = 18
$PCMarkLogo.Location = New-Object System.Drawing.Size(30,330)
$PCMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\PCMark.png"
$PCMarkLogo.ImageLocation = $PCMarkLogoFile
$PCMarkLogo.BorderStyle = 0
$PCMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($PCMarkLogo)

$PCMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$PCMarkCheckbox.Location = New-Object System.Drawing.Size(10,330) 
$PCMarkCheckbox.Text = "       PCMark"
$PCMarkCheckbox.Width = 180
$PCMarkCheckbox.Height = 20
$PCMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($PCMarkCheckbox)

$PerformanceTESTLogo = New-Object System.Windows.Forms.PictureBox
$PerformanceTESTLogo.Width = 18
$PerformanceTESTLogo.Height = 18
$PerformanceTESTLogo.Location = New-Object System.Drawing.Size(30,350)
$PerformanceTESTLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\PerformanceTEST.png"
$PerformanceTESTLogo.ImageLocation = $PerformanceTESTLogoFile
$PerformanceTESTLogo.BorderStyle = 0
$PerformanceTESTLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($PerformanceTESTLogo)

$PerformanceTESTCheckbox = New-Object System.Windows.Forms.Checkbox 
$PerformanceTESTCheckbox.Location = New-Object System.Drawing.Size(10,350) 
$PerformanceTESTCheckbox.Text = "       PerformanceTEST"
$PerformanceTESTCheckbox.Width = 180
$PerformanceTESTCheckbox.Height = 20
$PerformanceTESTCheckbox.Font = $BodyFont
$Tab4.Controls.Add($PerformanceTESTCheckbox)

$SuperpositionLogo = New-Object System.Windows.Forms.PictureBox
$SuperpositionLogo.Width = 18
$SuperpositionLogo.Height = 18
$SuperpositionLogo.Location = New-Object System.Drawing.Size(30,370)
$SuperpositionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Superposition.png"
$SuperpositionLogo.ImageLocation = $SuperpositionLogoFile
$SuperpositionLogo.BorderStyle = 0
$SuperpositionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SuperpositionLogo)

$SuperpositionCheckbox = New-Object System.Windows.Forms.Checkbox 
$SuperpositionCheckbox.Location = New-Object System.Drawing.Size(10,370) 
$SuperpositionCheckbox.Text = "       Superposition"
$SuperpositionCheckbox.Width = 180
$SuperpositionCheckbox.Height = 20
$SuperpositionCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SuperpositionCheckbox)

$UserBenchmarkLogo = New-Object System.Windows.Forms.PictureBox
$UserBenchmarkLogo.Width = 18
$UserBenchmarkLogo.Height = 18
$UserBenchmarkLogo.Location = New-Object System.Drawing.Size(30,390)
$UserBenchmarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\UserBenchmark.png"
$UserBenchmarkLogo.ImageLocation = $UserBenchmarkLogoFile
$UserBenchmarkLogo.BorderStyle = 0
$UserBenchmarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($UserBenchmarkLogo)

$UserBenchmarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$UserBenchmarkCheckbox.Location = New-Object System.Drawing.Size(10,390) 
$UserBenchmarkCheckbox.Text = "       UserBenchmark"
$UserBenchmarkCheckbox.Width = 180
$UserBenchmarkCheckbox.Height = 20
$UserBenchmarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($UserBenchmarkCheckbox)

$CPULabel = New-Object System.Windows.Forms.Label
$CPULabel.Location = New-Object System.Drawing.Size(200,10)
$CPULabel.Text = "CPU"
$CPULabel.Width = 180
$CPULabel.Height = 20
$CPULabel.Font = $HeaderFont
$Tab4.Controls.Add($CPULabel)

$IntelDiagLogo = New-Object System.Windows.Forms.PictureBox
$IntelDiagLogo.Width = 18
$IntelDiagLogo.Height = 18
$IntelDiagLogo.Location = New-Object System.Drawing.Size(220,30)
$IntelDiagLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\IntelDiag.png"
$IntelDiagLogo.ImageLocation = $IntelDiagLogoFile
$IntelDiagLogo.BorderStyle = 0
$IntelDiagLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($IntelDiagLogo)

$IntelDiagCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelDiagCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$IntelDiagCheckbox.Text = "       Intel Diag"
$IntelDiagCheckbox.Width = 180
$IntelDiagCheckbox.Height = 20
$IntelDiagCheckbox.Font = $BodyFont
$Tab4.Controls.Add($IntelDiagCheckbox)

$Prime95Logo = New-Object System.Windows.Forms.PictureBox
$Prime95Logo.Width = 18
$Prime95Logo.Height = 18
$Prime95Logo.Location = New-Object System.Drawing.Size(220,50)
$Prime95LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Prime95.png"
$Prime95Logo.ImageLocation = $Prime95LogoFile
$Prime95Logo.BorderStyle = 0
$Prime95Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($Prime95Logo)

$Prime95Checkbox = New-Object System.Windows.Forms.Checkbox 
$Prime95Checkbox.Location = New-Object System.Drawing.Size(200,50) 
$Prime95Checkbox.Text = "       Prime95"
$Prime95Checkbox.Width = 180
$Prime95Checkbox.Height = 20
$Prime95Checkbox.Font = $BodyFont
$Tab4.Controls.Add($Prime95Checkbox)

$DataRecoveryLabel = New-Object System.Windows.Forms.Label
$DataRecoveryLabel.Location = New-Object System.Drawing.Size(200,90)
$DataRecoveryLabel.Text = "Data Recovery"
$DataRecoveryLabel.Width = 180
$DataRecoveryLabel.Height = 20
$DataRecoveryLabel.Font = $HeaderFont
$Tab4.Controls.Add($DataRecoveryLabel)

$EaseUSDataRecoveryLogo = New-Object System.Windows.Forms.PictureBox
$EaseUSDataRecoveryLogo.Width = 18
$EaseUSDataRecoveryLogo.Height = 18
$EaseUSDataRecoveryLogo.Location = New-Object System.Drawing.Size(220,110)
$EaseUSDataRecoveryLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\EaseUSDataRecovery.png"
$EaseUSDataRecoveryLogo.ImageLocation = $EaseUSDataRecoveryLogoFile
$EaseUSDataRecoveryLogo.BorderStyle = 0
$EaseUSDataRecoveryLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($EaseUSDataRecoveryLogo)

$EaseUSDataRecoveryCheckbox = New-Object System.Windows.Forms.Checkbox 
$EaseUSDataRecoveryCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$EaseUSDataRecoveryCheckbox.Text = "       EaseUS"
$EaseUSDataRecoveryCheckbox.Width = 180
$EaseUSDataRecoveryCheckbox.Height = 20
$EaseUSDataRecoveryCheckbox.Font = $BodyFont
$Tab4.Controls.Add($EaseUSDataRecoveryCheckbox)

$RecuvaLogo = New-Object System.Windows.Forms.PictureBox
$RecuvaLogo.Width = 18
$RecuvaLogo.Height = 18
$RecuvaLogo.Location = New-Object System.Drawing.Size(220,130)
$RecuvaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Recuva.png"
$RecuvaLogo.ImageLocation = $RecuvaLogoFile
$RecuvaLogo.BorderStyle = 0
$RecuvaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RecuvaLogo)

$RecuvaCheckbox = New-Object System.Windows.Forms.Checkbox 
$RecuvaCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$RecuvaCheckbox.Text = "       Recuva"
$RecuvaCheckbox.Width = 180
$RecuvaCheckbox.Height = 20
$RecuvaCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RecuvaCheckbox)

$StellarLogo = New-Object System.Windows.Forms.PictureBox
$StellarLogo.Width = 18
$StellarLogo.Height = 18
$StellarLogo.Location = New-Object System.Drawing.Size(220,150)
$StellarLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Stellar.png"
$StellarLogo.ImageLocation = $StellarLogoFile
$StellarLogo.BorderStyle = 0
$StellarLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($StellarLogo)

$StellarCheckbox = New-Object System.Windows.Forms.Checkbox 
$StellarCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$StellarCheckbox.Text = "       Stellar"
$StellarCheckbox.Width = 180
$StellarCheckbox.Height = 20
$StellarCheckbox.Font = $BodyFont
$Tab4.Controls.Add($StellarCheckbox)

$DirectoryLabel = New-Object System.Windows.Forms.Label
$DirectoryLabel.Location = New-Object System.Drawing.Size(200,190)
$DirectoryLabel.Text = "Directory"
$DirectoryLabel.Width = 180
$DirectoryLabel.Height = 20
$DirectoryLabel.Font = $HeaderFont
$Tab4.Controls.Add($DirectoryLabel)

$CaptainNemoLogo = New-Object System.Windows.Forms.PictureBox
$CaptainNemoLogo.Width = 18
$CaptainNemoLogo.Height = 18
$CaptainNemoLogo.Location = New-Object System.Drawing.Size(220,210)
$CaptainNemoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CaptainNemo.png"
$CaptainNemoLogo.ImageLocation = $CaptainNemoLogoFile
$CaptainNemoLogo.BorderStyle = 0
$CaptainNemoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CaptainNemoLogo)

$CaptainNemoCheckbox = New-Object System.Windows.Forms.Checkbox 
$CaptainNemoCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$CaptainNemoCheckbox.Text = "       Captain Nemo"
$CaptainNemoCheckbox.Width = 180
$CaptainNemoCheckbox.Height = 20
$CaptainNemoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CaptainNemoCheckbox)

$EverythingLogo = New-Object System.Windows.Forms.PictureBox
$EverythingLogo.Width = 18
$EverythingLogo.Height = 18
$EverythingLogo.Location = New-Object System.Drawing.Size(220,230)
$EverythingLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Everything.png"
$EverythingLogo.ImageLocation = $EverythingLogoFile
$EverythingLogo.BorderStyle = 0
$EverythingLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($EverythingLogo)

$EverythingCheckbox = New-Object System.Windows.Forms.Checkbox 
$EverythingCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$EverythingCheckbox.Text = "       Everything"
$EverythingCheckbox.Width = 180
$EverythingCheckbox.Height = 20
$EverythingCheckbox.Font = $BodyFont
$Tab4.Controls.Add($EverythingCheckbox)

$TreeSizeLogo = New-Object System.Windows.Forms.PictureBox
$TreeSizeLogo.Width = 18
$TreeSizeLogo.Height = 18
$TreeSizeLogo.Location = New-Object System.Drawing.Size(220,250)
$TreeSizeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\TreeSize.png"
$TreeSizeLogo.ImageLocation = $TreeSizeLogoFile
$TreeSizeLogo.BorderStyle = 0
$TreeSizeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($TreeSizeLogo)

$TreeSizeCheckbox = New-Object System.Windows.Forms.Checkbox 
$TreeSizeCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$TreeSizeCheckbox.Text = "       TreeSize"
$TreeSizeCheckbox.Width = 180
$TreeSizeCheckbox.Height = 20
$TreeSizeCheckbox.Font = $BodyFont
$Tab4.Controls.Add($TreeSizeCheckbox)

$WinDirStatLogo = New-Object System.Windows.Forms.PictureBox
$WinDirStatLogo.Width = 18
$WinDirStatLogo.Height = 18
$WinDirStatLogo.Location = New-Object System.Drawing.Size(220,270)
$WinDirStatLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WinDirStat.png"
$WinDirStatLogo.ImageLocation = $WinDirStatLogoFile
$WinDirStatLogo.BorderStyle = 0
$WinDirStatLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WinDirStatLogo)

$WinDirStatCheckbox = New-Object System.Windows.Forms.Checkbox 
$WinDirStatCheckbox.Location = New-Object System.Drawing.Size(200,270) 
$WinDirStatCheckbox.Text = "       WinDirStat"
$WinDirStatCheckbox.Width = 180
$WinDirStatCheckbox.Height = 20
$WinDirStatCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WinDirStatCheckbox)

$WizTreeLogo = New-Object System.Windows.Forms.PictureBox
$WizTreeLogo.Width = 18
$WizTreeLogo.Height = 18
$WizTreeLogo.Location = New-Object System.Drawing.Size(220,290)
$WizTreeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WizTree.png"
$WizTreeLogo.ImageLocation = $WizTreeLogoFile
$WizTreeLogo.BorderStyle = 0
$WizTreeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WizTreeLogo)

$WizTreeCheckbox = New-Object System.Windows.Forms.Checkbox 
$WizTreeCheckbox.Location = New-Object System.Drawing.Size(200,290) 
$WizTreeCheckbox.Text = "       WizTree"
$WizTreeCheckbox.Width = 180
$WizTreeCheckbox.Height = 20
$WizTreeCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WizTreeCheckbox)

$GPULabel = New-Object System.Windows.Forms.Label
$GPULabel.Location = New-Object System.Drawing.Size(390,10)
$GPULabel.Text = "GPU"
$GPULabel.Width = 180
$GPULabel.Height = 20
$GPULabel.Font = $HeaderFont
$Tab4.Controls.Add($GPULabel)

$FurMarkLogo = New-Object System.Windows.Forms.PictureBox
$FurMarkLogo.Width = 18
$FurMarkLogo.Height = 18
$FurMarkLogo.Location = New-Object System.Drawing.Size(410,30)
$FurMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\FurMark.png"
$FurMarkLogo.ImageLocation = $FurMarkLogoFile
$FurMarkLogo.BorderStyle = 0
$FurMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($FurMarkLogo)

$FurMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$FurMarkCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$FurMarkCheckbox.Text = "       FurMark"
$FurMarkCheckbox.Width = 180
$FurMarkCheckbox.Height = 20
$FurMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($FurMarkCheckbox)

$HeavenLogo = New-Object System.Windows.Forms.PictureBox
$HeavenLogo.Width = 18
$HeavenLogo.Height = 18
$HeavenLogo.Location = New-Object System.Drawing.Size(410,50)
$HeavenLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Heaven.png"
$HeavenLogo.ImageLocation = $HeavenLogoFile
$HeavenLogo.BorderStyle = 0
$HeavenLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HeavenLogo)

$HeavenCheckbox = New-Object System.Windows.Forms.Checkbox 
$HeavenCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$HeavenCheckbox.Text = "       Heaven"
$HeavenCheckbox.Width = 180
$HeavenCheckbox.Height = 20
$HeavenCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HeavenCheckbox)

$KombustorLogo = New-Object System.Windows.Forms.PictureBox
$KombustorLogo.Width = 18
$KombustorLogo.Height = 18
$KombustorLogo.Location = New-Object System.Drawing.Size(410,70)
$KombustorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Kombustor.png"
$KombustorLogo.ImageLocation = $KombustorLogoFile
$KombustorLogo.BorderStyle = 0
$KombustorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($KombustorLogo)

$KombustorCheckbox = New-Object System.Windows.Forms.Checkbox 
$KombustorCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$KombustorCheckbox.Text = "       Kombustor"
$KombustorCheckbox.Width = 180
$KombustorCheckbox.Height = 20
$KombustorCheckbox.Font = $BodyFont
$Tab4.Controls.Add($KombustorCheckbox)

$HDDLabel = New-Object System.Windows.Forms.Label
$HDDLabel.Location = New-Object System.Drawing.Size(390,110)
$HDDLabel.Text = "HDD"
$HDDLabel.Width = 180
$HDDLabel.Height = 20
$HDDLabel.Font = $HeaderFont
$Tab4.Controls.Add($HDDLabel)

$AcronisLogo = New-Object System.Windows.Forms.PictureBox
$AcronisLogo.Width = 18
$AcronisLogo.Height = 18
$AcronisLogo.Location = New-Object System.Drawing.Size(410,130)
$AcronisLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Acronis.png"
$AcronisLogo.ImageLocation = $AcronisLogoFile
$AcronisLogo.BorderStyle = 0
$AcronisLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AcronisLogo)

$AcronisCheckbox = New-Object System.Windows.Forms.Checkbox 
$AcronisCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$AcronisCheckbox.Text = "       Acronis"
$AcronisCheckbox.Width = 180
$AcronisCheckbox.Height = 20
$AcronisCheckbox.Font = $BodyFont
$Tab4.Controls.Add($AcronisCheckbox)

$AOMEILogo = New-Object System.Windows.Forms.PictureBox
$AOMEILogo.Width = 18
$AOMEILogo.Height = 18
$AOMEILogo.Location = New-Object System.Drawing.Size(410,150)
$AOMEILogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\AOMEI.png"
$AOMEILogo.ImageLocation = $AOMEILogoFile
$AOMEILogo.BorderStyle = 0
$AOMEILogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AOMEILogo)

$AOMEICheckbox = New-Object System.Windows.Forms.Checkbox 
$AOMEICheckbox.Location = New-Object System.Drawing.Size(390,150) 
$AOMEICheckbox.Text = "       AOMEI"
$AOMEICheckbox.Width = 180
$AOMEICheckbox.Height = 20
$AOMEICheckbox.Font = $BodyFont
$Tab4.Controls.Add($AOMEICheckbox)

$CheckDiskGUILogo = New-Object System.Windows.Forms.PictureBox
$CheckDiskGUILogo.Width = 18
$CheckDiskGUILogo.Height = 18
$CheckDiskGUILogo.Location = New-Object System.Drawing.Size(410,170)
$CheckDiskGUILogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CheckDiskGUI.png"
$CheckDiskGUILogo.ImageLocation = $CheckDiskGUILogoFile
$CheckDiskGUILogo.BorderStyle = 0
$CheckDiskGUILogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CheckDiskGUILogo)

$CheckDiskGUICheckbox = New-Object System.Windows.Forms.Checkbox 
$CheckDiskGUICheckbox.Location = New-Object System.Drawing.Size(390,170) 
$CheckDiskGUICheckbox.Text = "       CheckDiskGUI"
$CheckDiskGUICheckbox.Width = 180
$CheckDiskGUICheckbox.Height = 20
$CheckDiskGUICheckbox.Font = $BodyFont
$Tab4.Controls.Add($CheckDiskGUICheckbox)

$CrystalDiskInfoLogo = New-Object System.Windows.Forms.PictureBox
$CrystalDiskInfoLogo.Width = 18
$CrystalDiskInfoLogo.Height = 18
$CrystalDiskInfoLogo.Location = New-Object System.Drawing.Size(410,190)
$CrystalDiskInfoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CrystalDiskInfo.png"
$CrystalDiskInfoLogo.ImageLocation = $CrystalDiskInfoLogoFile
$CrystalDiskInfoLogo.BorderStyle = 0
$CrystalDiskInfoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CrystalDiskInfoLogo)

$CrystalDiskInfoCheckbox = New-Object System.Windows.Forms.Checkbox 
$CrystalDiskInfoCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$CrystalDiskInfoCheckbox.Text = "       CrystalDiskInfo"
$CrystalDiskInfoCheckbox.Width = 180
$CrystalDiskInfoCheckbox.Height = 20
$CrystalDiskInfoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CrystalDiskInfoCheckbox)

$GSmartControlLogo = New-Object System.Windows.Forms.PictureBox
$GSmartControlLogo.Width = 18
$GSmartControlLogo.Height = 18
$GSmartControlLogo.Location = New-Object System.Drawing.Size(410,210)
$GSmartControlLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\GSmartControl.png"
$GSmartControlLogo.ImageLocation = $GSmartControlLogoFile
$GSmartControlLogo.BorderStyle = 0
$GSmartControlLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GSmartControlLogo)

$GSmartControlCheckbox = New-Object System.Windows.Forms.Checkbox 
$GSmartControlCheckbox.Location = New-Object System.Drawing.Size(390,210) 
$GSmartControlCheckbox.Text = "       GSmartControl"
$GSmartControlCheckbox.Width = 180
$GSmartControlCheckbox.Height = 20
$GSmartControlCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GSmartControlCheckbox)

$HDDScanLogo = New-Object System.Windows.Forms.PictureBox
$HDDScanLogo.Width = 18
$HDDScanLogo.Height = 18
$HDDScanLogo.Location = New-Object System.Drawing.Size(410,230)
$HDDScanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HDDScan.png"
$HDDScanLogo.ImageLocation = $HDDScanLogoFile
$HDDScanLogo.BorderStyle = 0
$HDDScanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HDDScanLogo)

$HDDScanCheckbox = New-Object System.Windows.Forms.Checkbox 
$HDDScanCheckbox.Location = New-Object System.Drawing.Size(390,230) 
$HDDScanCheckbox.Text = "       HDDScan"
$HDDScanCheckbox.Width = 180
$HDDScanCheckbox.Height = 20
$HDDScanCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HDDScanCheckbox)

$HDTuneProLogo = New-Object System.Windows.Forms.PictureBox
$HDTuneProLogo.Width = 18
$HDTuneProLogo.Height = 18
$HDTuneProLogo.Location = New-Object System.Drawing.Size(410,250)
$HDTuneProLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HDTunePro.png"
$HDTuneProLogo.ImageLocation = $HDTuneProLogoFile
$HDTuneProLogo.BorderStyle = 0
$HDTuneProLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HDTuneProLogo)

$HDTuneProCheckbox = New-Object System.Windows.Forms.Checkbox 
$HDTuneProCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$HDTuneProCheckbox.Text = "       HDTunePro"
$HDTuneProCheckbox.Width = 180
$HDTuneProCheckbox.Height = 20
$HDTuneProCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HDTuneProCheckbox)

$SamsungMagicianLogo = New-Object System.Windows.Forms.PictureBox
$SamsungMagicianLogo.Width = 18
$SamsungMagicianLogo.Height = 18
$SamsungMagicianLogo.Location = New-Object System.Drawing.Size(410,270)
$SamsungMagicianLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SamsungMagician.png"
$SamsungMagicianLogo.ImageLocation = $SamsungMagicianLogoFile
$SamsungMagicianLogo.BorderStyle = 0
$SamsungMagicianLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SamsungMagicianLogo)

$SamsungMagicianCheckbox = New-Object System.Windows.Forms.Checkbox 
$SamsungMagicianCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$SamsungMagicianCheckbox.Text = "       Samsung Magician"
$SamsungMagicianCheckbox.Width = 180
$SamsungMagicianCheckbox.Height = 20
$SamsungMagicianCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SamsungMagicianCheckbox)

$SeagateSeaToolsLogo = New-Object System.Windows.Forms.PictureBox
$SeagateSeaToolsLogo.Width = 18
$SeagateSeaToolsLogo.Height = 18
$SeagateSeaToolsLogo.Location = New-Object System.Drawing.Size(410,290)
$SeagateSeaToolsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SeagateSeaTools.png"
$SeagateSeaToolsLogo.ImageLocation = $SeagateSeaToolsLogoFile
$SeagateSeaToolsLogo.BorderStyle = 0
$SeagateSeaToolsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SeagateSeaToolsLogo)

$SeagateSeaToolsCheckbox = New-Object System.Windows.Forms.Checkbox 
$SeagateSeaToolsCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$SeagateSeaToolsCheckbox.Text = "       Seagate SeaTools"
$SeagateSeaToolsCheckbox.Width = 180
$SeagateSeaToolsCheckbox.Height = 20
$SeagateSeaToolsCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SeagateSeaToolsCheckbox)

$VictoriaLogo = New-Object System.Windows.Forms.PictureBox
$VictoriaLogo.Width = 18
$VictoriaLogo.Height = 18
$VictoriaLogo.Location = New-Object System.Drawing.Size(410,310)
$VictoriaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Victoria.png"
$VictoriaLogo.ImageLocation = $VictoriaLogoFile
$VictoriaLogo.BorderStyle = 0
$VictoriaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($VictoriaLogo)

$VictoriaCheckbox = New-Object System.Windows.Forms.Checkbox 
$VictoriaCheckbox.Location = New-Object System.Drawing.Size(390,310) 
$VictoriaCheckbox.Text = "       Victoria"
$VictoriaCheckbox.Width = 180
$VictoriaCheckbox.Height = 20
$VictoriaCheckbox.Font = $BodyFont
$Tab4.Controls.Add($VictoriaCheckbox)

$WDKitfoxLogo = New-Object System.Windows.Forms.PictureBox
$WDKitfoxLogo.Width = 18
$WDKitfoxLogo.Height = 18
$WDKitfoxLogo.Location = New-Object System.Drawing.Size(410,330)
$WDKitfoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WDKitfox.png"
$WDKitfoxLogo.ImageLocation = $WDKitfoxLogoFile
$WDKitfoxLogo.BorderStyle = 0
$WDKitfoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WDKitfoxLogo)

$WDKitfoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$WDKitfoxCheckbox.Location = New-Object System.Drawing.Size(390,330) 
$WDKitfoxCheckbox.Text = "       WD Kitfox"
$WDKitfoxCheckbox.Width = 180
$WDKitfoxCheckbox.Height = 20
$WDKitfoxCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WDKitfoxCheckbox)

$MonitoringLabel = New-Object System.Windows.Forms.Label
$MonitoringLabel.Location = New-Object System.Drawing.Size(580,10)
$MonitoringLabel.Text = "Monitoring"
$MonitoringLabel.Width = 180
$MonitoringLabel.Height = 20
$MonitoringLabel.Font = $HeaderFont
$Tab4.Controls.Add($MonitoringLabel)

$AfterburnerLogo = New-Object System.Windows.Forms.PictureBox
$AfterburnerLogo.Width = 18
$AfterburnerLogo.Height = 18
$AfterburnerLogo.Location = New-Object System.Drawing.Size(600,30)
$AfterburnerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Afterburner.png"
$AfterburnerLogo.ImageLocation = $AfterburnerLogoFile
$AfterburnerLogo.BorderStyle = 0
$AfterburnerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AfterburnerLogo)

$AfterburnerCheckbox = New-Object System.Windows.Forms.Checkbox 
$AfterburnerCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$AfterburnerCheckbox.Text = "       Afterburner"
$AfterburnerCheckbox.Width = 180
$AfterburnerCheckbox.Height = 20
$AfterburnerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($AfterburnerCheckbox)

$AIDA64Logo = New-Object System.Windows.Forms.PictureBox
$AIDA64Logo.Width = 18
$AIDA64Logo.Height = 18
$AIDA64Logo.Location = New-Object System.Drawing.Size(600,50)
$AIDA64LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\AIDA64.png"
$AIDA64Logo.ImageLocation = $AIDA64LogoFile
$AIDA64Logo.BorderStyle = 0
$AIDA64Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AIDA64Logo)

$AIDA64Checkbox = New-Object System.Windows.Forms.Checkbox 
$AIDA64Checkbox.Location = New-Object System.Drawing.Size(580,50) 
$AIDA64Checkbox.Text = "       AIDA64"
$AIDA64Checkbox.Width = 180
$AIDA64Checkbox.Height = 20
$AIDA64Checkbox.Font = $BodyFont
$Tab4.Controls.Add($AIDA64Checkbox)

$CoreTempLogo = New-Object System.Windows.Forms.PictureBox
$CoreTempLogo.Width = 18
$CoreTempLogo.Height = 18
$CoreTempLogo.Location = New-Object System.Drawing.Size(600,70)
$CoreTempLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CoreTemp.png"
$CoreTempLogo.ImageLocation = $CoreTempLogoFile
$CoreTempLogo.BorderStyle = 0
$CoreTempLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CoreTempLogo)

$CoreTempCheckbox = New-Object System.Windows.Forms.Checkbox 
$CoreTempCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$CoreTempCheckbox.Text = "       Core Temp"
$CoreTempCheckbox.Width = 180
$CoreTempCheckbox.Height = 20
$CoreTempCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CoreTempCheckbox)

$CPUZLogo = New-Object System.Windows.Forms.PictureBox
$CPUZLogo.Width = 18
$CPUZLogo.Height = 18
$CPUZLogo.Location = New-Object System.Drawing.Size(600,90)
$CPUZLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CPUZ.png"
$CPUZLogo.ImageLocation = $CPUZLogoFile
$CPUZLogo.BorderStyle = 0
$CPUZLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CPUZLogo)

$CPUZCheckbox = New-Object System.Windows.Forms.Checkbox 
$CPUZCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$CPUZCheckbox.Text = "       CPU-Z"
$CPUZCheckbox.Width = 180
$CPUZCheckbox.Height = 20
$CPUZCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CPUZCheckbox)

$GPUZLogo = New-Object System.Windows.Forms.PictureBox
$GPUZLogo.Width = 18
$GPUZLogo.Height = 18
$GPUZLogo.Location = New-Object System.Drawing.Size(600,110)
$GPUZLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\GPUZ.png"
$GPUZLogo.ImageLocation = $GPUZLogoFile
$GPUZLogo.BorderStyle = 0
$GPUZLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GPUZLogo)

$GPUZCheckbox = New-Object System.Windows.Forms.Checkbox 
$GPUZCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$GPUZCheckbox.Text = "       GPU-Z"
$GPUZCheckbox.Width = 180
$GPUZCheckbox.Height = 20
$GPUZCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GPUZCheckbox)

$HWinfoLogo = New-Object System.Windows.Forms.PictureBox
$HWinfoLogo.Width = 18
$HWinfoLogo.Height = 18
$HWinfoLogo.Location = New-Object System.Drawing.Size(600,130)
$HWinfoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HWinfo.png"
$HWinfoLogo.ImageLocation = $HWinfoLogoFile
$HWinfoLogo.BorderStyle = 0
$HWinfoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HWinfoLogo)

$HWinfoCheckbox = New-Object System.Windows.Forms.Checkbox 
$HWinfoCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$HWinfoCheckbox.Text = "       HWinfo"
$HWinfoCheckbox.Width = 180
$HWinfoCheckbox.Height = 20
$HWinfoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HWinfoCheckbox)

$HWMonitorLogo = New-Object System.Windows.Forms.PictureBox
$HWMonitorLogo.Width = 18
$HWMonitorLogo.Height = 18
$HWMonitorLogo.Location = New-Object System.Drawing.Size(600,150)
$HWMonitorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HWMonitor.png"
$HWMonitorLogo.ImageLocation = $HWMonitorLogoFile
$HWMonitorLogo.BorderStyle = 0
$HWMonitorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HWMonitorLogo)

$HWMonitorCheckbox = New-Object System.Windows.Forms.Checkbox 
$HWMonitorCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$HWMonitorCheckbox.Text = "       HWMonitor"
$HWMonitorCheckbox.Width = 180
$HWMonitorCheckbox.Height = 20
$HWMonitorCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HWMonitorCheckbox)

$OpenHardwareLogo = New-Object System.Windows.Forms.PictureBox
$OpenHardwareLogo.Width = 18
$OpenHardwareLogo.Height = 18
$OpenHardwareLogo.Location = New-Object System.Drawing.Size(600,170)
$OpenHardwareLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\OpenHardware.png"
$OpenHardwareLogo.ImageLocation = $OpenHardwareLogoFile
$OpenHardwareLogo.BorderStyle = 0
$OpenHardwareLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($OpenHardwareLogo)

$OpenHardwareCheckbox = New-Object System.Windows.Forms.Checkbox 
$OpenHardwareCheckbox.Location = New-Object System.Drawing.Size(580,170) 
$OpenHardwareCheckbox.Text = "       Open Hardware"
$OpenHardwareCheckbox.Width = 180
$OpenHardwareCheckbox.Height = 20
$OpenHardwareCheckbox.Font = $BodyFont
$Tab4.Controls.Add($OpenHardwareCheckbox)

$RainmeterLogo = New-Object System.Windows.Forms.PictureBox
$RainmeterLogo.Width = 18
$RainmeterLogo.Height = 18
$RainmeterLogo.Location = New-Object System.Drawing.Size(600,190)
$RainmeterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Rainmeter.png"
$RainmeterLogo.ImageLocation = $RainmeterLogoFile
$RainmeterLogo.BorderStyle = 0
$RainmeterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RainmeterLogo)

$RainmeterCheckbox = New-Object System.Windows.Forms.Checkbox 
$RainmeterCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$RainmeterCheckbox.Text = "       Rainmeter"
$RainmeterCheckbox.Width = 180
$RainmeterCheckbox.Height = 20
$RainmeterCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RainmeterCheckbox)

$RyzenMasterLogo = New-Object System.Windows.Forms.PictureBox
$RyzenMasterLogo.Width = 18
$RyzenMasterLogo.Height = 18
$RyzenMasterLogo.Location = New-Object System.Drawing.Size(600,210)
$RyzenMasterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\RyzenMaster.png"
$RyzenMasterLogo.ImageLocation = $RyzenMasterLogoFile
$RyzenMasterLogo.BorderStyle = 0
$RyzenMasterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RyzenMasterLogo)

$RyzenMasterCheckbox = New-Object System.Windows.Forms.Checkbox 
$RyzenMasterCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$RyzenMasterCheckbox.Text = "       Ryzen Master"
$RyzenMasterCheckbox.Width = 180
$RyzenMasterCheckbox.Height = 20
$RyzenMasterCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RyzenMasterCheckbox)

$SpeccyLogo = New-Object System.Windows.Forms.PictureBox
$SpeccyLogo.Width = 18
$SpeccyLogo.Height = 18
$SpeccyLogo.Location = New-Object System.Drawing.Size(600,230)
$SpeccyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Speccy.png"
$SpeccyLogo.ImageLocation = $SpeccyLogoFile
$SpeccyLogo.BorderStyle = 0
$SpeccyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SpeccyLogo)

$SpeccyCheckbox = New-Object System.Windows.Forms.Checkbox 
$SpeccyCheckbox.Location = New-Object System.Drawing.Size(580,230) 
$SpeccyCheckbox.Text = "       Speccy"
$SpeccyCheckbox.Width = 180
$SpeccyCheckbox.Height = 20
$SpeccyCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SpeccyCheckbox)

$WhySoSlowLogo = New-Object System.Windows.Forms.PictureBox
$WhySoSlowLogo.Width = 18
$WhySoSlowLogo.Height = 18
$WhySoSlowLogo.Location = New-Object System.Drawing.Size(600,250)
$WhySoSlowLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WhySoSlow.png"
$WhySoSlowLogo.ImageLocation = $WhySoSlowLogoFile
$WhySoSlowLogo.BorderStyle = 0
$WhySoSlowLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WhySoSlowLogo)

$WhySoSlowCheckbox = New-Object System.Windows.Forms.Checkbox 
$WhySoSlowCheckbox.Location = New-Object System.Drawing.Size(580,250) 
$WhySoSlowCheckbox.Text = "       WhySoSlow"
$WhySoSlowCheckbox.Width = 180
$WhySoSlowCheckbox.Height = 20
$WhySoSlowCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WhySoSlowCheckbox)

$NetworkLabel = New-Object System.Windows.Forms.Label
$NetworkLabel.Location = New-Object System.Drawing.Size(770,10)
$NetworkLabel.Text = "Network"
$NetworkLabel.Width = 180
$NetworkLabel.Height = 20
$NetworkLabel.Font = $HeaderFont
$Tab4.Controls.Add($NetworkLabel)

$WifiAnalyzerLogo = New-Object System.Windows.Forms.PictureBox
$WifiAnalyzerLogo.Width = 18
$WifiAnalyzerLogo.Height = 18
$WifiAnalyzerLogo.Location = New-Object System.Drawing.Size(790,30)
$WifiAnalyzerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WifiAnalyzer.png"
$WifiAnalyzerLogo.ImageLocation = $WifiAnalyzerLogoFile
$WifiAnalyzerLogo.BorderStyle = 0
$WifiAnalyzerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WifiAnalyzerLogo)

$WiFiAnalyzerCheckbox = New-Object System.Windows.Forms.Checkbox 
$WiFiAnalyzerCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$WiFiAnalyzerCheckbox.Text = "       Wifi Analyzer"
$WiFiAnalyzerCheckbox.Width = 180
$WiFiAnalyzerCheckbox.Height = 20
$WiFiAnalyzerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WiFiAnalyzerCheckbox)

$WiresharkLogo = New-Object System.Windows.Forms.PictureBox
$WiresharkLogo.Width = 18
$WiresharkLogo.Height = 18
$WiresharkLogo.Location = New-Object System.Drawing.Size(790,50)
$WiresharkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Wireshark.png"
$WiresharkLogo.ImageLocation = $WiresharkLogoFile
$WiresharkLogo.BorderStyle = 0
$WiresharkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WiresharkLogo)

$WiresharkCheckbox = New-Object System.Windows.Forms.Checkbox 
$WiresharkCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$WiresharkCheckbox.Text = "       Wireshark"
$WiresharkCheckbox.Width = 180
$WiresharkCheckbox.Height = 20
$WiresharkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WiresharkCheckbox)

$RAMLabel = New-Object System.Windows.Forms.Label
$RAMLabel.Location = New-Object System.Drawing.Size(770,90)
$RAMLabel.Text = "RAM"
$RAMLabel.Width = 180
$RAMLabel.Height = 20
$RAMLabel.Font = $HeaderFont
$Tab4.Controls.Add($RAMLabel)

$MemTest86Logo = New-Object System.Windows.Forms.PictureBox
$MemTest86Logo.Width = 18
$MemTest86Logo.Height = 18
$MemTest86Logo.Location = New-Object System.Drawing.Size(790,110)
$MemTest86LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\MemTest86.png"
$MemTest86Logo.ImageLocation = $MemTest86LogoFile
$MemTest86Logo.BorderStyle = 0
$MemTest86Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($MemTest86Logo)

$MemTest86Checkbox = New-Object System.Windows.Forms.Checkbox 
$MemTest86Checkbox.Location = New-Object System.Drawing.Size(770,110) 
$MemTest86Checkbox.Text = "       MemTest86"
$MemTest86Checkbox.Width = 180
$MemTest86Checkbox.Height = 20
$MemTest86Checkbox.Font = $BodyFont
$Tab4.Controls.Add($MemTest86Checkbox)

$WinMemoryDiagLogo = New-Object System.Windows.Forms.PictureBox
$WinMemoryDiagLogo.Width = 18
$WinMemoryDiagLogo.Height = 18
$WinMemoryDiagLogo.Location = New-Object System.Drawing.Size(790,130)
$WinMemoryDiagLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WinMemoryDiag.png"
$WinMemoryDiagLogo.ImageLocation = $WinMemoryDiagLogoFile
$WinMemoryDiagLogo.BorderStyle = 0
$WinMemoryDiagLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WinMemoryDiagLogo)

$WinMemoryDiagCheckbox = New-Object System.Windows.Forms.Checkbox 
$WinMemoryDiagCheckbox.Location = New-Object System.Drawing.Size(770,130) 
$WinMemoryDiagCheckbox.Text = "       Win Memory Diag"
$WinMemoryDiagCheckbox.Width = 180
$WinMemoryDiagCheckbox.Height = 20
$WinMemoryDiagCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WinMemoryDiagCheckbox)

$SystemLabel = New-Object System.Windows.Forms.Label
$SystemLabel.Location = New-Object System.Drawing.Size(770,170)
$SystemLabel.Text = "System Diag"
$SystemLabel.Width = 180
$SystemLabel.Height = 20
$SystemLabel.Font = $HeaderFont
$Tab4.Controls.Add($SystemLabel)

$ESETSysinspectorLogo = New-Object System.Windows.Forms.PictureBox
$ESETSysinspectorLogo.Width = 18
$ESETSysinspectorLogo.Height = 18
$ESETSysinspectorLogo.Location = New-Object System.Drawing.Size(790,190)
$ESETSysinspectorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\ESET.png"
$ESETSysinspectorLogo.ImageLocation = $ESETSysinspectorLogoFile
$ESETSysinspectorLogo.BorderStyle = 0
$ESETSysinspectorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($ESETSysinspectorLogo)

$ESETSysinspectorCheckbox = New-Object System.Windows.Forms.Checkbox 
$ESETSysinspectorCheckbox.Location = New-Object System.Drawing.Size(770,190) 
$ESETSysinspectorCheckbox.Text = "       ESET Sysinspector"
$ESETSysinspectorCheckbox.Width = 180
$ESETSysinspectorCheckbox.Height = 20
$ESETSysinspectorCheckbox.Font = $BodyFont
$Tab4.Controls.Add($ESETSysinspectorCheckbox)

$HeavyLoadLogo = New-Object System.Windows.Forms.PictureBox
$HeavyLoadLogo.Width = 18
$HeavyLoadLogo.Height = 18
$HeavyLoadLogo.Location = New-Object System.Drawing.Size(790,210)
$HeavyLoadLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HeavyLoad.png"
$HeavyLoadLogo.ImageLocation = $HeavyLoadLogoFile
$HeavyLoadLogo.BorderStyle = 0
$HeavyLoadLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HeavyLoadLogo)

$HeavyLoadCheckbox = New-Object System.Windows.Forms.Checkbox 
$HeavyLoadCheckbox.Location = New-Object System.Drawing.Size(770,210) 
$HeavyLoadCheckbox.Text = "       HeavyLoad"
$HeavyLoadCheckbox.Width = 180
$HeavyLoadCheckbox.Height = 20
$HeavyLoadCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HeavyLoadCheckbox)

$HPDiagLogo = New-Object System.Windows.Forms.PictureBox
$HPDiagLogo.Width = 18
$HPDiagLogo.Height = 18
$HPDiagLogo.Location = New-Object System.Drawing.Size(790,230)
$HPDiagLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HPDiag.png"
$HPDiagLogo.ImageLocation = $HPDiagLogoFile
$HPDiagLogo.BorderStyle = 0
$HPDiagLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HPDiagLogo)

$HPDiagCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPDiagCheckbox.Location = New-Object System.Drawing.Size(770,230) 
$HPDiagCheckbox.Text = "       HP Diag"
$HPDiagCheckbox.Width = 180
$HPDiagCheckbox.Height = 20
$HPDiagCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HPDiagCheckbox)

$OCCTLogo = New-Object System.Windows.Forms.PictureBox
$OCCTLogo.Width = 18
$OCCTLogo.Height = 18
$OCCTLogo.Location = New-Object System.Drawing.Size(790,250)
$OCCTLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\OCCT.png"
$OCCTLogo.ImageLocation = $OCCTLogoFile
$OCCTLogo.BorderStyle = 0
$OCCTLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($OCCTLogo)

$OCCTCheckbox = New-Object System.Windows.Forms.Checkbox 
$OCCTCheckbox.Location = New-Object System.Drawing.Size(770,250) 
$OCCTCheckbox.Text = "       OCCT"
$OCCTCheckbox.Width = 180
$OCCTCheckbox.Height = 20
$OCCTCheckbox.Font = $BodyFont
$Tab4.Controls.Add($OCCTCheckbox)

$UninstallerLabel = New-Object System.Windows.Forms.Label
$UninstallerLabel.Location = New-Object System.Drawing.Size(960,10)
$UninstallerLabel.Text = "Uninstaller"
$UninstallerLabel.Width = 180
$UninstallerLabel.Height = 20
$UninstallerLabel.Font = $HeaderFont
$Tab4.Controls.Add($UninstallerLabel)

$GeekUninstallerLogo = New-Object System.Windows.Forms.PictureBox
$GeekUninstallerLogo.Width = 18
$GeekUninstallerLogo.Height = 18
$GeekUninstallerLogo.Location = New-Object System.Drawing.Size(980,30)
$GeekUninstallerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\GeekUninstaller.png"
$GeekUninstallerLogo.ImageLocation = $GeekUninstallerLogoFile
$GeekUninstallerLogo.BorderStyle = 0
$GeekUninstallerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GeekUninstallerLogo)

$GeekUninstallerCheckbox = New-Object System.Windows.Forms.Checkbox 
$GeekUninstallerCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$GeekUninstallerCheckbox.Text = "       Geek Uninstaller"
$GeekUninstallerCheckbox.Width = 180
$GeekUninstallerCheckbox.Height = 20
$GeekUninstallerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GeekUninstallerCheckbox)

$RevoLogo = New-Object System.Windows.Forms.PictureBox
$RevoLogo.Width = 18
$RevoLogo.Height = 18
$RevoLogo.Location = New-Object System.Drawing.Size(980,50)
$RevoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Revo.png"
$RevoLogo.ImageLocation = $RevoLogoFile
$RevoLogo.BorderStyle = 0
$RevoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RevoLogo)

$RevoCheckbox = New-Object System.Windows.Forms.Checkbox 
$RevoCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$RevoCheckbox.Text = "       Revo Uninstaller"
$RevoCheckbox.Width = 180
$RevoCheckbox.Height = 20
$RevoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RevoCheckbox)

$Utilities2Label = New-Object System.Windows.Forms.Label
$Utilities2Label.Location = New-Object System.Drawing.Size(960,90) 
$Utilities2Label.Text = "Utilities"
$Utilities2Label.Width = 180
$Utilities2Label.Height = 20
$Utilities2Label.Font = $HeaderFont
$Tab4.Controls.Add($Utilities2Label)

$AutorunsLogo = New-Object System.Windows.Forms.PictureBox
$AutorunsLogo.Width = 18
$AutorunsLogo.Height = 18
$AutorunsLogo.Location = New-Object System.Drawing.Size(980,110)
$AutorunsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Autoruns.png"
$AutorunsLogo.ImageLocation = $AutorunsLogoFile
$AutorunsLogo.BorderStyle = 0
$AutorunsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AutorunsLogo)

$AutorunsCheckbox = New-Object System.Windows.Forms.Checkbox 
$AutorunsCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$AutorunsCheckbox.Text = "       Autoruns"
$AutorunsCheckbox.Width = 180
$AutorunsCheckbox.Height = 20
$AutorunsCheckbox.Font = $BodyFont
$Tab4.Controls.Add($AutorunsCheckbox)

$BlueScreenViewLogo = New-Object System.Windows.Forms.PictureBox
$BlueScreenViewLogo.Width = 18
$BlueScreenViewLogo.Height = 18
$BlueScreenViewLogo.Location = New-Object System.Drawing.Size(980,130)
$BlueScreenViewLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BlueScreenView.png"
$BlueScreenViewLogo.ImageLocation = $BlueScreenViewLogoFile
$BlueScreenViewLogo.BorderStyle = 0
$BlueScreenViewLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BlueScreenViewLogo)

$BlueScreenViewCheckbox = New-Object System.Windows.Forms.Checkbox 
$BlueScreenViewCheckbox.Location = New-Object System.Drawing.Size(960,130) 
$BlueScreenViewCheckbox.Text = "       BlueScreenView"
$BlueScreenViewCheckbox.Width = 180
$BlueScreenViewCheckbox.Height = 20
$BlueScreenViewCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BlueScreenViewCheckbox)

$CCleanerLogo = New-Object System.Windows.Forms.PictureBox
$CCleanerLogo.Width = 18
$CCleanerLogo.Height = 18
$CCleanerLogo.Location = New-Object System.Drawing.Size(980,150)
$CCleanerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CCleaner.png"
$CCleanerLogo.ImageLocation = $CCleanerLogoFile
$CCleanerLogo.BorderStyle = 0
$CCleanerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CCleanerLogo)

$CCleanerCheckbox = New-Object System.Windows.Forms.Checkbox 
$CCleanerCheckbox.Location = New-Object System.Drawing.Size(960,150) 
$CCleanerCheckbox.Text = "       CCleaner"
$CCleanerCheckbox.Width = 180
$CCleanerCheckbox.Height = 20
$CCleanerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CCleanerCheckbox)

$GlaryLogo = New-Object System.Windows.Forms.PictureBox
$GlaryLogo.Width = 18
$GlaryLogo.Height = 18
$GlaryLogo.Location = New-Object System.Drawing.Size(980,170)
$GlaryLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Glary.png"
$GlaryLogo.ImageLocation = $GlaryLogoFile
$GlaryLogo.BorderStyle = 0
$GlaryLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GlaryLogo)

$GlaryCheckbox = New-Object System.Windows.Forms.Checkbox 
$GlaryCheckbox.Location = New-Object System.Drawing.Size(960,170) 
$GlaryCheckbox.Text = "       Glary Utilities"
$GlaryCheckbox.Width = 180
$GlaryCheckbox.Height = 20
$GlaryCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GlaryCheckbox)

$SysinternalsSuiteLogo = New-Object System.Windows.Forms.PictureBox
$SysinternalsSuiteLogo.Width = 18
$SysinternalsSuiteLogo.Height = 18
$SysinternalsSuiteLogo.Location = New-Object System.Drawing.Size(980,190)
$SysinternalsSuiteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SysinternalsSuite.png"
$SysinternalsSuiteLogo.ImageLocation = $SysinternalsSuiteLogoFile
$SysinternalsSuiteLogo.BorderStyle = 0
$SysinternalsSuiteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SysinternalsSuiteLogo)

$SysinternalsSuiteCheckbox = New-Object System.Windows.Forms.Checkbox 
$SysinternalsSuiteCheckbox.Location = New-Object System.Drawing.Size(960,190) 
$SysinternalsSuiteCheckbox.Text = "       Sysinternals Suite"
$SysinternalsSuiteCheckbox.Width = 180
$SysinternalsSuiteCheckbox.Height = 20
$SysinternalsSuiteCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SysinternalsSuiteCheckbox)

$WhoCrashedLogo = New-Object System.Windows.Forms.PictureBox
$WhoCrashedLogo.Width = 18
$WhoCrashedLogo.Height = 18
$WhoCrashedLogo.Location = New-Object System.Drawing.Size(980,210)
$WhoCrashedLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WhoCrashed.png"
$WhoCrashedLogo.ImageLocation = $WhoCrashedLogoFile
$WhoCrashedLogo.BorderStyle = 0
$WhoCrashedLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WhoCrashedLogo)

$WhoCrashedCheckbox = New-Object System.Windows.Forms.Checkbox 
$WhoCrashedCheckbox.Location = New-Object System.Drawing.Size(960,210) 
$WhoCrashedCheckbox.Text = "       WhoCrashed"
$WhoCrashedCheckbox.Width = 180
$WhoCrashedCheckbox.Height = 20
$WhoCrashedCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WhoCrashedCheckbox)

# Tab 5 DRIVERS
$Tab5 = New-Object System.Windows.Forms.TabPage
$Tab5.Text = "Drivers"
$Tab5.Font = $TabFont
$Tab5.Autoscroll  = $True
$TabControl.Controls.Add($Tab5)

$DisplayLabel = New-Object System.Windows.Forms.Label
$DisplayLabel.Location = New-Object System.Drawing.Size(10,10)
$DisplayLabel.Text = "Display"
$DisplayLabel.Width = 180
$DisplayLabel.Height = 20
$DisplayLabel.Font = $HeaderFont
$Tab5.Controls.Add($DisplayLabel)

$AMDSoftwareLogo = New-Object System.Windows.Forms.PictureBox
$AMDSoftwareLogo.Width = 18
$AMDSoftwareLogo.Height = 18
$AMDSoftwareLogo.Location = New-Object System.Drawing.Size(30,30)
$AMDSoftwareLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\AMD.png"
$AMDSoftwareLogo.ImageLocation = $AMDSoftwareLogoFile
$AMDSoftwareLogo.BorderStyle = 0
$AMDSoftwareLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AMDSoftwareLogo)

$AMDSoftwareCheckbox = New-Object System.Windows.Forms.Checkbox 
$AMDSoftwareCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$AMDSoftwareCheckbox.Text = "       AMD Software"
$AMDSoftwareCheckbox.Width = 180
$AMDSoftwareCheckbox.Height = 20
$AMDSoftwareCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AMDSoftwareCheckbox)

$IntelGraphicsCCLogo = New-Object System.Windows.Forms.PictureBox
$IntelGraphicsCCLogo.Width = 18
$IntelGraphicsCCLogo.Height = 18
$IntelGraphicsCCLogo.Location = New-Object System.Drawing.Size(30,50)
$IntelGraphicsCCLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Intel.png"
$IntelGraphicsCCLogo.ImageLocation = $IntelGraphicsCCLogoFile
$IntelGraphicsCCLogo.BorderStyle = 0
$IntelGraphicsCCLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($IntelGraphicsCCLogo)

$IntelGraphicsCCCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelGraphicsCCCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$IntelGraphicsCCCheckbox.Text = "       Intel Graphics C.C."
$IntelGraphicsCCCheckbox.Width = 180
$IntelGraphicsCCCheckbox.Height = 20
$IntelGraphicsCCCheckbox.Font = $BodyFont
$Tab5.Controls.Add($IntelGraphicsCCCheckbox)

$NvidiaAppLogo = New-Object System.Windows.Forms.PictureBox
$NvidiaAppLogo.Width = 18
$NvidiaAppLogo.Height = 18
$NvidiaAppLogo.Location = New-Object System.Drawing.Size(30,70)
$NvidiaAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Nvidia.png"
$NvidiaAppLogo.ImageLocation = $NvidiaAppLogoFile
$NvidiaAppLogo.BorderStyle = 0
$NvidiaAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($NvidiaAppLogo)

$NvidiaAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$NvidiaAppCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$NvidiaAppCheckbox.Text = "       Nvidia App"
$NvidiaAppCheckbox.Width = 180
$NvidiaAppCheckbox.Height = 20
$NvidiaAppCheckbox.Font = $BodyFont
$Tab5.Controls.Add($NvidiaAppCheckbox)


$DriverToolsLabel = New-Object System.Windows.Forms.Label
$DriverToolsLabel.Location = New-Object System.Drawing.Size(10,110)
$DriverToolsLabel.Text = "Driver Tools"
$DriverToolsLabel.Width = 180
$DriverToolsLabel.Height = 20
$DriverToolsLabel.Font = $HeaderFont
$Tab5.Controls.Add($DriverToolsLabel)

$DisplayDriverUninstallerLogo = New-Object System.Windows.Forms.PictureBox
$DisplayDriverUninstallerLogo.Width = 18
$DisplayDriverUninstallerLogo.Height = 18
$DisplayDriverUninstallerLogo.Location = New-Object System.Drawing.Size(30,130)
$DisplayDriverUninstallerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\DDU.png"
$DisplayDriverUninstallerLogo.ImageLocation = $DisplayDriverUninstallerLogoFile
$DisplayDriverUninstallerLogo.BorderStyle = 0
$DisplayDriverUninstallerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DisplayDriverUninstallerLogo)

$DisplayDriverUninstallerCheckbox = New-Object System.Windows.Forms.Checkbox 
$DisplayDriverUninstallerCheckbox.Location = New-Object System.Drawing.Size(10,130) 
$DisplayDriverUninstallerCheckbox.Text = "       Display Uninstaller"
$DisplayDriverUninstallerCheckbox.Width = 180
$DisplayDriverUninstallerCheckbox.Height = 20
$DisplayDriverUninstallerCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DisplayDriverUninstallerCheckbox)

$DriverStoreExplorerLogo = New-Object System.Windows.Forms.PictureBox
$DriverStoreExplorerLogo.Width = 18
$DriverStoreExplorerLogo.Height = 18
$DriverStoreExplorerLogo.Location = New-Object System.Drawing.Size(30,150)
$DriverStoreExplorerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\DriverStore.png"
$DriverStoreExplorerLogo.ImageLocation = $DriverStoreExplorerLogoFile
$DriverStoreExplorerLogo.BorderStyle = 0
$DriverStoreExplorerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DriverStoreExplorerLogo)

$DriverStoreExplorerCheckbox = New-Object System.Windows.Forms.Checkbox 
$DriverStoreExplorerCheckbox.Location = New-Object System.Drawing.Size(10,150) 
$DriverStoreExplorerCheckbox.Text = "       Driver Explorer"
$DriverStoreExplorerCheckbox.Width = 180
$DriverStoreExplorerCheckbox.Height = 20
$DriverStoreExplorerCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DriverStoreExplorerCheckbox)

$MoboUtilitiesLabel = New-Object System.Windows.Forms.Label
$MoboUtilitiesLabel.Location = New-Object System.Drawing.Size(200,10)
$MoboUtilitiesLabel.Text = "Mobo Utilities"
$MoboUtilitiesLabel.Width = 180
$MoboUtilitiesLabel.Height = 20
$MoboUtilitiesLabel.Font = $HeaderFont
$Tab5.Controls.Add($MoboUtilitiesLabel)

$AcerCareCenterLogo = New-Object System.Windows.Forms.PictureBox
$AcerCareCenterLogo.Width = 18
$AcerCareCenterLogo.Height = 18
$AcerCareCenterLogo.Location = New-Object System.Drawing.Size(220,30)
$AcerCareCenterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Acer.png"
$AcerCareCenterLogo.ImageLocation = $AcerCareCenterLogoFile
$AcerCareCenterLogo.BorderStyle = 0
$AcerCareCenterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AcerCareCenterLogo)

$AcerCareCenterCheckbox = New-Object System.Windows.Forms.Checkbox 
$AcerCareCenterCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$AcerCareCenterCheckbox.Text = "       Acer Care Center"
$AcerCareCenterCheckbox.Width = 180
$AcerCareCenterCheckbox.Height = 20
$AcerCareCenterCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AcerCareCenterCheckbox)

$ASRockAppShopLogo = New-Object System.Windows.Forms.PictureBox
$ASRockAppShopLogo.Width = 18
$ASRockAppShopLogo.Height = 18
$ASRockAppShopLogo.Location = New-Object System.Drawing.Size(220,50)
$ASRockAppShopLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\ASRock.png"
$ASRockAppShopLogo.ImageLocation = $ASRockAppShopLogoFile
$ASRockAppShopLogo.BorderStyle = 0
$ASRockAppShopLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($ASRockAppShopLogo)

$ASRockAppShopCheckbox = New-Object System.Windows.Forms.Checkbox 
$ASRockAppShopCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$ASRockAppShopCheckbox.Text = "       ASRock App Shop"
$ASRockAppShopCheckbox.Width = 180
$ASRockAppShopCheckbox.Height = 20
$ASRockAppShopCheckbox.Font = $BodyFont
$Tab5.Controls.Add($ASRockAppShopCheckbox)

$ASUSArmouryCrateLogo = New-Object System.Windows.Forms.PictureBox
$ASUSArmouryCrateLogo.Width = 18
$ASUSArmouryCrateLogo.Height = 18
$ASUSArmouryCrateLogo.Location = New-Object System.Drawing.Size(220,70)
$ASUSArmouryCrateLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\ASUSArmouryCrate.png"
$ASUSArmouryCrateLogo.ImageLocation = $ASUSArmouryCrateLogoFile
$ASUSArmouryCrateLogo.BorderStyle = 0
$ASUSArmouryCrateLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($ASUSArmouryCrateLogo)

$ASUSArmouryCrateCheckbox = New-Object System.Windows.Forms.Checkbox 
$ASUSArmouryCrateCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$ASUSArmouryCrateCheckbox.Text = "       ASUS Armoury"
$ASUSArmouryCrateCheckbox.Width = 180
$ASUSArmouryCrateCheckbox.Height = 20
$ASUSArmouryCrateCheckbox.Font = $BodyFont
$Tab5.Controls.Add($ASUSArmouryCrateCheckbox)

$GigabyteCCLogo = New-Object System.Windows.Forms.PictureBox
$GigabyteCCLogo.Width = 18
$GigabyteCCLogo.Height = 18
$GigabyteCCLogo.Location = New-Object System.Drawing.Size(220,90)
$GigabyteCCLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Gigabyte.png"
$GigabyteCCLogo.ImageLocation = $GigabyteCCLogoFile
$GigabyteCCLogo.BorderStyle = 0
$GigabyteCCLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($GigabyteCCLogo)

$GigabyteCCCheckbox = New-Object System.Windows.Forms.Checkbox 
$GigabyteCCCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$GigabyteCCCheckbox.Text = "       Gigabyte C.C."
$GigabyteCCCheckbox.Width = 180
$GigabyteCCCheckbox.Height = 20
$GigabyteCCCheckbox.Font = $BodyFont
$Tab5.Controls.Add($GigabyteCCCheckbox)

$MSICenterLogo = New-Object System.Windows.Forms.PictureBox
$MSICenterLogo.Width = 18
$MSICenterLogo.Height = 18
$MSICenterLogo.Location = New-Object System.Drawing.Size(220,110)
$MSICenterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\MSICenter.png"
$MSICenterLogo.ImageLocation = $MSICenterLogoFile
$MSICenterLogo.BorderStyle = 0
$MSICenterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($MSICenterLogo)

$MSICenterCheckbox = New-Object System.Windows.Forms.Checkbox 
$MSICenterCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$MSICenterCheckbox.Text = "       MSI Center"
$MSICenterCheckbox.Width = 180
$MSICenterCheckbox.Height = 20
$MSICenterCheckbox.Font = $BodyFont
$Tab5.Controls.Add($MSICenterCheckbox)

$PrintersLabel = New-Object System.Windows.Forms.Label
$PrintersLabel.Location = New-Object System.Drawing.Size(390,10)
$PrintersLabel.Text = "Printers"
$PrintersLabel.Width = 180
$PrintersLabel.Height = 20
$PrintersLabel.Font = $HeaderFont
$Tab5.Controls.Add($PrintersLabel)

$BrotheriPrintScanLogo = New-Object System.Windows.Forms.PictureBox
$BrotheriPrintScanLogo.Width = 18
$BrotheriPrintScanLogo.Height = 18
$BrotheriPrintScanLogo.Location = New-Object System.Drawing.Size(410,30)
$BrotheriPrintScanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Brother.png"
$BrotheriPrintScanLogo.ImageLocation = $BrotheriPrintScanLogoFile
$BrotheriPrintScanLogo.BorderStyle = 0
$BrotheriPrintScanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($BrotheriPrintScanLogo)

$BrotheriPrintScanCheckbox = New-Object System.Windows.Forms.Checkbox 
$BrotheriPrintScanCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$BrotheriPrintScanCheckbox.Text = "       Brother iPrint&&Scan"
$BrotheriPrintScanCheckbox.Width = 180
$BrotheriPrintScanCheckbox.Height = 20
$BrotheriPrintScanCheckbox.Font = $BodyFont
$Tab5.Controls.Add($BrotheriPrintScanCheckbox)

$CanonPrintLogo = New-Object System.Windows.Forms.PictureBox
$CanonPrintLogo.Width = 18
$CanonPrintLogo.Height = 18
$CanonPrintLogo.Location = New-Object System.Drawing.Size(410,50)
$CanonPrintLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\CanonPrint.png"
$CanonPrintLogo.ImageLocation = $CanonPrintLogoFile
$CanonPrintLogo.BorderStyle = 0
$CanonPrintLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($CanonPrintLogo)

$CanonPrintCheckbox = New-Object System.Windows.Forms.Checkbox 
$CanonPrintCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$CanonPrintCheckbox.Text = "       Canon Print"
$CanonPrintCheckbox.Width = 180
$CanonPrintCheckbox.Height = 20
$CanonPrintCheckbox.Font = $BodyFont
$Tab5.Controls.Add($CanonPrintCheckbox)

$EpsonConnectLogo = New-Object System.Windows.Forms.PictureBox
$EpsonConnectLogo.Width = 18
$EpsonConnectLogo.Height = 18
$EpsonConnectLogo.Location = New-Object System.Drawing.Size(410,70)
$EpsonConnectLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\EpsonConnect.png"
$EpsonConnectLogo.ImageLocation = $EpsonConnectLogoFile
$EpsonConnectLogo.BorderStyle = 0
$EpsonConnectLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($EpsonConnectLogo)

$EpsonConnectCheckbox = New-Object System.Windows.Forms.Checkbox 
$EpsonConnectCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$EpsonConnectCheckbox.Text = "       Epson Connect"
$EpsonConnectCheckbox.Width = 180
$EpsonConnectCheckbox.Height = 20
$EpsonConnectCheckbox.Font = $BodyFont
$Tab5.Controls.Add($EpsonConnectCheckbox)

$HPSmartLogo = New-Object System.Windows.Forms.PictureBox
$HPSmartLogo.Width = 18
$HPSmartLogo.Height = 18
$HPSmartLogo.Location = New-Object System.Drawing.Size(410,90)
$HPSmartLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\HP.png"
$HPSmartLogo.ImageLocation = $HPSmartLogoFile
$HPSmartLogo.BorderStyle = 0
$HPSmartLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($HPSmartLogo)

$HPSmartCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPSmartCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$HPSmartCheckbox.Text = "       HP Smart"
$HPSmartCheckbox.Width = 180
$HPSmartCheckbox.Height = 20
$HPSmartCheckbox.Font = $BodyFont
$Tab5.Controls.Add($HPSmartCheckbox)

$LexmarkUtilityLogo = New-Object System.Windows.Forms.PictureBox
$LexmarkUtilityLogo.Width = 18
$LexmarkUtilityLogo.Height = 18
$LexmarkUtilityLogo.Location = New-Object System.Drawing.Size(410,110)
$LexmarkUtilityLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Lexmark.png"
$LexmarkUtilityLogo.ImageLocation = $LexmarkUtilityLogoFile
$LexmarkUtilityLogo.BorderStyle = 0
$LexmarkUtilityLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($LexmarkUtilityLogo)

$LexmarkUtilityCheckbox = New-Object System.Windows.Forms.Checkbox 
$LexmarkUtilityCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$LexmarkUtilityCheckbox.Text = "       Lexmark Utility"
$LexmarkUtilityCheckbox.Width = 180
$LexmarkUtilityCheckbox.Height = 20
$LexmarkUtilityCheckbox.Font = $BodyFont
$Tab5.Controls.Add($LexmarkUtilityCheckbox)

$OEMUtilitiesLabel = New-Object System.Windows.Forms.Label
$OEMUtilitiesLabel.Location = New-Object System.Drawing.Size(580,10)
$OEMUtilitiesLabel.Text = "OEM Utilities"
$OEMUtilitiesLabel.Width = 180
$OEMUtilitiesLabel.Height = 20
$OEMUtilitiesLabel.Font = $HeaderFont
$Tab5.Controls.Add($OEMUtilitiesLabel)

$DellCommandUpdateLogo = New-Object System.Windows.Forms.PictureBox
$DellCommandUpdateLogo.Width = 18
$DellCommandUpdateLogo.Height = 18
$DellCommandUpdateLogo.Location = New-Object System.Drawing.Size(600,30)
$DellCommandUpdateLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Dell.png"
$DellCommandUpdateLogo.ImageLocation = $DellCommandUpdateLogoFile
$DellCommandUpdateLogo.BorderStyle = 0
$DellCommandUpdateLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DellCommandUpdateLogo)

$DellCommandUpdateCheckbox = New-Object System.Windows.Forms.Checkbox 
$DellCommandUpdateCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$DellCommandUpdateCheckbox.Text = "       Dell Update"
$DellCommandUpdateCheckbox.Width = 180
$DellCommandUpdateCheckbox.Height = 20
$DellCommandUpdateCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DellCommandUpdateCheckbox)

$DellSupportLogo = New-Object System.Windows.Forms.PictureBox
$DellSupportLogo.Width = 18
$DellSupportLogo.Height = 18
$DellSupportLogo.Location = New-Object System.Drawing.Size(600,50)
$DellSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Dell.png"
$DellSupportLogo.ImageLocation = $DellSupportLogoFile
$DellSupportLogo.BorderStyle = 0
$DellSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DellSupportLogo)

$DellSupportCheckbox = New-Object System.Windows.Forms.Checkbox 
$DellSupportCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$DellSupportCheckbox.Text = "       Dell Support"
$DellSupportCheckbox.Width = 180
$DellSupportCheckbox.Height = 20
$DellSupportCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DellSupportCheckbox)

$HPImageAssistantLogo = New-Object System.Windows.Forms.PictureBox
$HPImageAssistantLogo.Width = 18
$HPImageAssistantLogo.Height = 18
$HPImageAssistantLogo.Location = New-Object System.Drawing.Size(600,70)
$HPImageAssistantLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\HP.png"
$HPImageAssistantLogo.ImageLocation = $HPImageAssistantLogoFile
$HPImageAssistantLogo.BorderStyle = 0
$HPImageAssistantLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($HPImageAssistantLogo)

$HPImageAssistantCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPImageAssistantCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$HPImageAssistantCheckbox.Text = "       HP Image Assistant"
$HPImageAssistantCheckbox.Width = 180
$HPImageAssistantCheckbox.Height = 20
$HPImageAssistantCheckbox.Font = $BodyFont
$Tab5.Controls.Add($HPImageAssistantCheckbox)

$HPSupportLogo = New-Object System.Windows.Forms.PictureBox
$HPSupportLogo.Width = 18
$HPSupportLogo.Height = 18
$HPSupportLogo.Location = New-Object System.Drawing.Size(600,90)
$HPSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\HP.png"
$HPSupportLogo.ImageLocation = $HPSupportLogoFile
$HPSupportLogo.BorderStyle = 0
$HPSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($HPSupportLogo)

$HPSupportCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPSupportCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$HPSupportCheckbox.Text = "       HP Support"
$HPSupportCheckbox.Width = 180
$HPSupportCheckbox.Height = 20
$HPSupportCheckbox.Font = $BodyFont
$Tab5.Controls.Add($HPSupportCheckbox)

$IntelSupportLogo = New-Object System.Windows.Forms.PictureBox
$IntelSupportLogo.Width = 18
$IntelSupportLogo.Height = 18
$IntelSupportLogo.Location = New-Object System.Drawing.Size(600,110)
$IntelSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Intel.png"
$IntelSupportLogo.ImageLocation = $IntelSupportLogoFile
$IntelSupportLogo.BorderStyle = 0
$IntelSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($IntelSupportLogo)

$IntelSupportCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelSupportCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$IntelSupportCheckbox.Text = "       Intel Support"
$IntelSupportCheckbox.Width = 180
$IntelSupportCheckbox.Height = 20
$IntelSupportCheckbox.Font = $BodyFont
$Tab5.Controls.Add($IntelSupportCheckbox)

$LenovoSystemUpdateLogo = New-Object System.Windows.Forms.PictureBox
$LenovoSystemUpdateLogo.Width = 18
$LenovoSystemUpdateLogo.Height = 18
$LenovoSystemUpdateLogo.Location = New-Object System.Drawing.Size(600,130)
$LenovoSystemUpdateLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Lenovo.png"
$LenovoSystemUpdateLogo.ImageLocation = $LenovoSystemUpdateLogoFile
$LenovoSystemUpdateLogo.BorderStyle = 0
$LenovoSystemUpdateLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($LenovoSystemUpdateLogo)

$LenovoSystemUpdateCheckbox = New-Object System.Windows.Forms.Checkbox 
$LenovoSystemUpdateCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$LenovoSystemUpdateCheckbox.Text = "       Lenovo Update"
$LenovoSystemUpdateCheckbox.Width = 180
$LenovoSystemUpdateCheckbox.Height = 20
$LenovoSystemUpdateCheckbox.Font = $BodyFont
$Tab5.Controls.Add($LenovoSystemUpdateCheckbox)

$LenovoVantageLogo = New-Object System.Windows.Forms.PictureBox
$LenovoVantageLogo.Width = 18
$LenovoVantageLogo.Height = 18
$LenovoVantageLogo.Location = New-Object System.Drawing.Size(600,150)
$LenovoVantageLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Lenovo.png"
$LenovoVantageLogo.ImageLocation = $LenovoVantageLogoFile
$LenovoVantageLogo.BorderStyle = 0
$LenovoVantageLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($LenovoVantageLogo)

$LenovoVantageCheckbox = New-Object System.Windows.Forms.Checkbox 
$LenovoVantageCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$LenovoVantageCheckbox.Text = "       Lenovo Vantage"
$LenovoVantageCheckbox.Width = 180
$LenovoVantageCheckbox.Height = 20
$LenovoVantageCheckbox.Font = $BodyFont
$Tab5.Controls.Add($LenovoVantageCheckbox)

$MyASUSLogo = New-Object System.Windows.Forms.PictureBox
$MyASUSLogo.Width = 18
$MyASUSLogo.Height = 18
$MyASUSLogo.Location = New-Object System.Drawing.Size(600,170)
$MyASUSLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\ASUSArmouryCrate.png"
$MyASUSLogo.ImageLocation = $MyASUSLogoFile
$MyASUSLogo.BorderStyle = 0
$MyASUSLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($MyASUSLogo)

$MyASUSCheckbox = New-Object System.Windows.Forms.Checkbox 
$MyASUSCheckbox.Location = New-Object System.Drawing.Size(580,170) 
$MyASUSCheckbox.Text = "       MyASUS"
$MyASUSCheckbox.Width = 180
$MyASUSCheckbox.Height = 20
$MyASUSCheckbox.Font = $BodyFont
$Tab5.Controls.Add($MyASUSCheckbox)

$SamsungUpdateLogo = New-Object System.Windows.Forms.PictureBox
$SamsungUpdateLogo.Width = 18
$SamsungUpdateLogo.Height = 18
$SamsungUpdateLogo.Location = New-Object System.Drawing.Size(600,190)
$SamsungUpdateLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SamsungMagician.png"
$SamsungUpdateLogo.ImageLocation = $SamsungUpdateLogoFile
$SamsungUpdateLogo.BorderStyle = 0
$SamsungUpdateLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SamsungUpdateLogo)

$SamsungUpdateCheckbox = New-Object System.Windows.Forms.Checkbox 
$SamsungUpdateCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$SamsungUpdateCheckbox.Text = "       Samsung Update"
$SamsungUpdateCheckbox.Width = 180
$SamsungUpdateCheckbox.Height = 20
$SamsungUpdateCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SamsungUpdateCheckbox)

$SurfaceLogo = New-Object System.Windows.Forms.PictureBox
$SurfaceLogo.Width = 18
$SurfaceLogo.Height = 18
$SurfaceLogo.Location = New-Object System.Drawing.Size(600,210)
$SurfaceLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Surface.png"
$SurfaceLogo.ImageLocation = $SurfaceLogoFile
$SurfaceLogo.BorderStyle = 0
$SurfaceLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SurfaceLogo)

$SurfaceCheckbox = New-Object System.Windows.Forms.Checkbox 
$SurfaceCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$SurfaceCheckbox.Text = "       Surface"
$SurfaceCheckbox.Width = 180
$SurfaceCheckbox.Height = 20
$SurfaceCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SurfaceCheckbox)

$PeripheralSoftwareLabel = New-Object System.Windows.Forms.Label
$PeripheralSoftwareLabel.Location = New-Object System.Drawing.Size(770,10)
$PeripheralSoftwareLabel.Text = "Peripheral Software"
$PeripheralSoftwareLabel.Width = 180
$PeripheralSoftwareLabel.Height = 20
$PeripheralSoftwareLabel.Font = $HeaderFont
$Tab5.Controls.Add($PeripheralSoftwareLabel)

$AstroCommandCenterLogo = New-Object System.Windows.Forms.PictureBox
$AstroCommandCenterLogo.Width = 18
$AstroCommandCenterLogo.Height = 18
$AstroCommandCenterLogo.Location = New-Object System.Drawing.Size(790,30)
$AstroCommandCenterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Astro.png"
$AstroCommandCenterLogo.ImageLocation = $AstroCommandCenterLogoFile
$AstroCommandCenterLogo.BorderStyle = 0
$AstroCommandCenterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AstroCommandCenterLogo)

$AstroCommandCenterCheckbox = New-Object System.Windows.Forms.Checkbox 
$AstroCommandCenterCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$AstroCommandCenterCheckbox.Text = "       Astro C.C."
$AstroCommandCenterCheckbox.Width = 180
$AstroCommandCenterCheckbox.Height = 20
$AstroCommandCenterCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AstroCommandCenterCheckbox)

$LogitechOptionsPlusLogo = New-Object System.Windows.Forms.PictureBox
$LogitechOptionsPlusLogo.Width = 18
$LogitechOptionsPlusLogo.Height = 18
$LogitechOptionsPlusLogo.Location = New-Object System.Drawing.Size(790,50)
$LogitechOptionsPlusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\LogitechOptions.png"
$LogitechOptionsPlusLogo.ImageLocation = $LogitechOptionsPlusLogoFile
$LogitechOptionsPlusLogo.BorderStyle = 0
$LogitechOptionsPlusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($LogitechOptionsPlusLogo)

$LogitechOptionsPlusCheckbox = New-Object System.Windows.Forms.Checkbox 
$LogitechOptionsPlusCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$LogitechOptionsPlusCheckbox.Text = "       Logitech Options+"
$LogitechOptionsPlusCheckbox.Width = 180
$LogitechOptionsPlusCheckbox.Height = 20
$LogitechOptionsPlusCheckbox.Font = $BodyFont
$Tab5.Controls.Add($LogitechOptionsPlusCheckbox)

$TurtleBeachAudioHubLogo = New-Object System.Windows.Forms.PictureBox
$TurtleBeachAudioHubLogo.Width = 18
$TurtleBeachAudioHubLogo.Height = 18
$TurtleBeachAudioHubLogo.Location = New-Object System.Drawing.Size(790,70)
$TurtleBeachAudioHubLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\TurtleBeach.png"
$TurtleBeachAudioHubLogo.ImageLocation = $TurtleBeachAudioHubLogoFile
$TurtleBeachAudioHubLogo.BorderStyle = 0
$TurtleBeachAudioHubLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($TurtleBeachAudioHubLogo)

$TurtleBeachAudioHubCheckbox = New-Object System.Windows.Forms.Checkbox 
$TurtleBeachAudioHubCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$TurtleBeachAudioHubCheckbox.Text = "       Turtle Beach Hub"
$TurtleBeachAudioHubCheckbox.Width = 180
$TurtleBeachAudioHubCheckbox.Height = 20
$TurtleBeachAudioHubCheckbox.Font = $BodyFont
$Tab5.Controls.Add($TurtleBeachAudioHubCheckbox)

$RGBSoftwareLabel = New-Object System.Windows.Forms.Label
$RGBSoftwareLabel.Location = New-Object System.Drawing.Size(960,10)
$RGBSoftwareLabel.Text = "RGB Software"
$RGBSoftwareLabel.Width = 180
$RGBSoftwareLabel.Height = 20
$RGBSoftwareLabel.Font = $HeaderFont
$Tab5.Controls.Add($RGBSoftwareLabel)

$CorsairICUELogo = New-Object System.Windows.Forms.PictureBox
$CorsairICUELogo.Width = 18
$CorsairICUELogo.Height = 18
$CorsairICUELogo.Location = New-Object System.Drawing.Size(980,30)
$CorsairICUELogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\CorsairICUE.png"
$CorsairICUELogo.ImageLocation = $CorsairICUELogoFile
$CorsairICUELogo.BorderStyle = 0
$CorsairICUELogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($CorsairICUELogo)

$CorsairICUECheckbox = New-Object System.Windows.Forms.Checkbox 
$CorsairICUECheckbox.Location = New-Object System.Drawing.Size(960,30) 
$CorsairICUECheckbox.Text = "       Corsair iCUE"
$CorsairICUECheckbox.Width = 180
$CorsairICUECheckbox.Height = 20
$CorsairICUECheckbox.Font = $BodyFont
$Tab5.Controls.Add($CorsairICUECheckbox)

$GloriousCoreLogo = New-Object System.Windows.Forms.PictureBox
$GloriousCoreLogo.Width = 18
$GloriousCoreLogo.Height = 18
$GloriousCoreLogo.Location = New-Object System.Drawing.Size(980,50)
$GloriousCoreLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Glorious.png"
$GloriousCoreLogo.ImageLocation = $GloriousCoreLogoFile
$GloriousCoreLogo.BorderStyle = 0
$GloriousCoreLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($GloriousCoreLogo)

$GloriousCoreCheckbox = New-Object System.Windows.Forms.Checkbox 
$GloriousCoreCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$GloriousCoreCheckbox.Text = "       Glorious Core"
$GloriousCoreCheckbox.Width = 180
$GloriousCoreCheckbox.Height = 20
$GloriousCoreCheckbox.Font = $BodyFont
$Tab5.Controls.Add($GloriousCoreCheckbox)

$LogitechGHUBLogo = New-Object System.Windows.Forms.PictureBox
$LogitechGHUBLogo.Width = 18
$LogitechGHUBLogo.Height = 18
$LogitechGHUBLogo.Location = New-Object System.Drawing.Size(980,70)
$LogitechGHUBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\Logitech.png"
$LogitechGHUBLogo.ImageLocation = $LogitechGHUBLogoFile
$LogitechGHUBLogo.BorderStyle = 0
$LogitechGHUBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($LogitechGHUBLogo)

$LogitechGHUBCheckbox = New-Object System.Windows.Forms.Checkbox 
$LogitechGHUBCheckbox.Location = New-Object System.Drawing.Size(960,70) 
$LogitechGHUBCheckbox.Text = "       Logitech G HUB"
$LogitechGHUBCheckbox.Width = 180
$LogitechGHUBCheckbox.Height = 20
$LogitechGHUBCheckbox.Font = $BodyFont
$Tab5.Controls.Add($LogitechGHUBCheckbox)

$MasterPlusLogo = New-Object System.Windows.Forms.PictureBox
$MasterPlusLogo.Width = 18
$MasterPlusLogo.Height = 18
$MasterPlusLogo.Location = New-Object System.Drawing.Size(980,90)
$MasterPlusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\MasterPlus.png"
$MasterPlusLogo.ImageLocation = $MasterPlusLogoFile
$MasterPlusLogo.BorderStyle = 0
$MasterPlusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($MasterPlusLogo)

$MasterPlusCheckbox = New-Object System.Windows.Forms.Checkbox 
$MasterPlusCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$MasterPlusCheckbox.Text = "       MasterPlus+"
$MasterPlusCheckbox.Width = 180
$MasterPlusCheckbox.Height = 20
$MasterPlusCheckbox.Font = $BodyFont
$Tab5.Controls.Add($MasterPlusCheckbox)

$NZXTCAMLogo = New-Object System.Windows.Forms.PictureBox
$NZXTCAMLogo.Width = 18
$NZXTCAMLogo.Height = 18
$NZXTCAMLogo.Location = New-Object System.Drawing.Size(980,110)
$NZXTCAMLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\NZXT.png"
$NZXTCAMLogo.ImageLocation = $NZXTCAMLogoFile
$NZXTCAMLogo.BorderStyle = 0
$NZXTCAMLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($NZXTCAMLogo)

$NZXTCAMCheckbox = New-Object System.Windows.Forms.Checkbox 
$NZXTCAMCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$NZXTCAMCheckbox.Text = "       NZXT CAM"
$NZXTCAMCheckbox.Width = 180
$NZXTCAMCheckbox.Height = 20
$NZXTCAMCheckbox.Font = $BodyFont
$Tab5.Controls.Add($NZXTCAMCheckbox)

$OpenRGBLogo = New-Object System.Windows.Forms.PictureBox
$OpenRGBLogo.Width = 18
$OpenRGBLogo.Height = 18
$OpenRGBLogo.Location = New-Object System.Drawing.Size(980,130)
$OpenRGBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\OpenRGB.png"
$OpenRGBLogo.ImageLocation = $OpenRGBLogoFile
$OpenRGBLogo.BorderStyle = 0
$OpenRGBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($OpenRGBLogo)

$OpenRGBCheckbox = New-Object System.Windows.Forms.Checkbox 
$OpenRGBCheckbox.Location = New-Object System.Drawing.Size(960,130) 
$OpenRGBCheckbox.Text = "       OpenRGB"
$OpenRGBCheckbox.Width = 180
$OpenRGBCheckbox.Height = 20
$OpenRGBCheckbox.Font = $BodyFont
$Tab5.Controls.Add($OpenRGBCheckbox)

$RazerChromaLogo = New-Object System.Windows.Forms.PictureBox
$RazerChromaLogo.Width = 18
$RazerChromaLogo.Height = 18
$RazerChromaLogo.Location = New-Object System.Drawing.Size(980,150)
$RazerChromaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\RazerChroma.png"
$RazerChromaLogo.ImageLocation = $RazerChromaLogoFile
$RazerChromaLogo.BorderStyle = 0
$RazerChromaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($RazerChromaLogo)

$RazerChromaCheckbox = New-Object System.Windows.Forms.Checkbox 
$RazerChromaCheckbox.Location = New-Object System.Drawing.Size(960,150) 
$RazerChromaCheckbox.Text = "       Razer Chroma"
$RazerChromaCheckbox.Width = 180
$RazerChromaCheckbox.Height = 20
$RazerChromaCheckbox.Font = $BodyFont
$Tab5.Controls.Add($RazerChromaCheckbox)

$RazerSynapseLogo = New-Object System.Windows.Forms.PictureBox
$RazerSynapseLogo.Width = 18
$RazerSynapseLogo.Height = 18
$RazerSynapseLogo.Location = New-Object System.Drawing.Size(980,170)
$RazerSynapseLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\RazerSynapse.png"
$RazerSynapseLogo.ImageLocation = $RazerSynapseLogoFile
$RazerSynapseLogo.BorderStyle = 0
$RazerSynapseLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($RazerSynapseLogo)

$RazerSynapseCheckbox = New-Object System.Windows.Forms.Checkbox 
$RazerSynapseCheckbox.Location = New-Object System.Drawing.Size(960,170) 
$RazerSynapseCheckbox.Text = "       Razer Synapse"
$RazerSynapseCheckbox.Width = 180
$RazerSynapseCheckbox.Height = 20
$RazerSynapseCheckbox.Font = $BodyFont
$Tab5.Controls.Add($RazerSynapseCheckbox)

$SignalRGBLogo = New-Object System.Windows.Forms.PictureBox
$SignalRGBLogo.Width = 18
$SignalRGBLogo.Height = 18
$SignalRGBLogo.Location = New-Object System.Drawing.Size(980,190)
$SignalRGBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\SignalRGB.png"
$SignalRGBLogo.ImageLocation = $SignalRGBLogoFile
$SignalRGBLogo.BorderStyle = 0
$SignalRGBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SignalRGBLogo)

$SignalRGBCheckbox = New-Object System.Windows.Forms.Checkbox 
$SignalRGBCheckbox.Location = New-Object System.Drawing.Size(960,190) 
$SignalRGBCheckbox.Text = "       SignalRGB"
$SignalRGBCheckbox.Width = 180
$SignalRGBCheckbox.Height = 20
$SignalRGBCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SignalRGBCheckbox)

$SteelSeriesGGLogo = New-Object System.Windows.Forms.PictureBox
$SteelSeriesGGLogo.Width = 18
$SteelSeriesGGLogo.Height = 18
$SteelSeriesGGLogo.Location = New-Object System.Drawing.Size(980,210)
$SteelSeriesGGLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\SteelSeries.png"
$SteelSeriesGGLogo.ImageLocation = $SteelSeriesGGLogoFile
$SteelSeriesGGLogo.BorderStyle = 0
$SteelSeriesGGLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SteelSeriesGGLogo)

$SteelSeriesGGCheckbox = New-Object System.Windows.Forms.Checkbox 
$SteelSeriesGGCheckbox.Location = New-Object System.Drawing.Size(960,210) 
$SteelSeriesGGCheckbox.Text = "       SteelSeries GG"
$SteelSeriesGGCheckbox.Width = 180
$SteelSeriesGGCheckbox.Height = 20
$SteelSeriesGGCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SteelSeriesGGCheckbox)

$TTRGBPlusLogo = New-Object System.Windows.Forms.PictureBox
$TTRGBPlusLogo.Width = 18
$TTRGBPlusLogo.Height = 18
$TTRGBPlusLogo.Location = New-Object System.Drawing.Size(980,230)
$TTRGBPlusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Drivers\TTRGBPlus.png"
$TTRGBPlusLogo.ImageLocation = $TTRGBPlusLogoFile
$TTRGBPlusLogo.BorderStyle = 0
$TTRGBPlusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($TTRGBPlusLogo)

$TTRGBPlusCheckbox = New-Object System.Windows.Forms.Checkbox 
$TTRGBPlusCheckbox.Location = New-Object System.Drawing.Size(960,230) 
$TTRGBPlusCheckbox.Text = "       TT RGB Plus"
$TTRGBPlusCheckbox.Width = 180
$TTRGBPlusCheckbox.Height = 20
$TTRGBPlusCheckbox.Font = $BodyFont
$Tab5.Controls.Add($TTRGBPlusCheckbox)

# Tab 6 SECURITY

$Tab6 = New-Object System.Windows.Forms.TabPage
$Tab6.Text = "Security"
$Tab6.Font = $TabFont
$Tab6.Autoscroll  = $True
$TabControl.Controls.Add($Tab6)

$AntiMalwareLabel = New-Object System.Windows.Forms.Label
$AntiMalwareLabel.Location = New-Object System.Drawing.Size(10,10)
$AntiMalwareLabel.Text = "Anti-Malware"
$AntiMalwareLabel.Width = 180
$AntiMalwareLabel.Height = 20
$AntiMalwareLabel.Font = $HeaderFont
$Tab6.Controls.Add($AntiMalwareLabel)

$AdwCleanerLogo = New-Object System.Windows.Forms.PictureBox
$AdwCleanerLogo.Width = 18
$AdwCleanerLogo.Height = 18
$AdwCleanerLogo.Location = New-Object System.Drawing.Size(30,30)
$AdwCleanerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\AdwCleaner.png"
$AdwCleanerLogo.ImageLocation = $AdwCleanerLogoFile
$AdwCleanerLogo.BorderStyle = 0
$AdwCleanerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($AdwCleanerLogo)

$AdwCleanerCheckbox = New-Object System.Windows.Forms.Checkbox 
$AdwCleanerCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$AdwCleanerCheckbox.Text = "       AdwCleaner"
$AdwCleanerCheckbox.Width = 180
$AdwCleanerCheckbox.Height = 20
$AdwCleanerCheckbox.Font = $BodyFont
$Tab6.Controls.Add($AdwCleanerCheckbox)

$MalwareBytesLogo = New-Object System.Windows.Forms.PictureBox
$MalwareBytesLogo.Width = 18
$MalwareBytesLogo.Height = 18
$MalwareBytesLogo.Location = New-Object System.Drawing.Size(30,50)
$MalwareBytesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\MalwareBytes.png"
$MalwareBytesLogo.ImageLocation = $MalwareBytesLogoFile
$MalwareBytesLogo.BorderStyle = 0
$MalwareBytesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($MalwareBytesLogo)

$MalwareBytesCheckbox = New-Object System.Windows.Forms.Checkbox 
$MalwareBytesCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$MalwareBytesCheckbox.Text = "       MalwareBytes"
$MalwareBytesCheckbox.Width = 180
$MalwareBytesCheckbox.Height = 20
$MalwareBytesCheckbox.Font = $BodyFont
$Tab6.Controls.Add($MalwareBytesCheckbox)

$OSArmorLogo = New-Object System.Windows.Forms.PictureBox
$OSArmorLogo.Width = 18
$OSArmorLogo.Height = 18
$OSArmorLogo.Location = New-Object System.Drawing.Size(30,70)
$OSArmorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\OSArmor.png"
$OSArmorLogo.ImageLocation = $OSArmorLogoFile
$OSArmorLogo.BorderStyle = 0
$OSArmorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($OSArmorLogo)

$OSArmorCheckbox = New-Object System.Windows.Forms.Checkbox 
$OSArmorCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$OSArmorCheckbox.Text = "       OSArmor"
$OSArmorCheckbox.Width = 180
$OSArmorCheckbox.Height = 20
$OSArmorCheckbox.Font = $BodyFont
$Tab6.Controls.Add($OSArmorCheckbox)

$AntivirusLabel = New-Object System.Windows.Forms.Label
$AntivirusLabel.Location = New-Object System.Drawing.Size(200,10)
$AntivirusLabel.Text = "Antivirus"
$AntivirusLabel.Width = 180
$AntivirusLabel.Height = 20
$AntivirusLabel.Font = $HeaderFont
$Tab6.Controls.Add($AntivirusLabel)

$AvastLogo = New-Object System.Windows.Forms.PictureBox
$AvastLogo.Width = 18
$AvastLogo.Height = 18
$AvastLogo.Location = New-Object System.Drawing.Size(220,30)
$AvastLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Avast.png"
$AvastLogo.ImageLocation = $AvastLogoFile
$AvastLogo.BorderStyle = 0
$AvastLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($AvastLogo)

$AvastCheckbox = New-Object System.Windows.Forms.Checkbox
$AvastCheckbox.Location = New-Object System.Drawing.Size(200,30)
$AvastCheckbox.Text = "       Avast"
$AvastCheckbox.Width = 180
$AvastCheckbox.Height = 20
$AvastCheckbox.Font = $BodyFont
$Tab6.Controls.Add($AvastCheckbox)

$AVGLogo = New-Object System.Windows.Forms.PictureBox
$AVGLogo.Width = 18
$AVGLogo.Height = 18
$AVGLogo.Location = New-Object System.Drawing.Size(220,50)
$AVGLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\AVG.png"
$AVGLogo.ImageLocation = $AVGLogoFile
$AVGLogo.BorderStyle = 0
$AVGLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($AVGLogo)

$AVGCheckbox = New-Object System.Windows.Forms.Checkbox 
$AVGCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$AVGCheckbox.Text = "       AVG"
$AVGCheckbox.Width = 180
$AVGCheckbox.Height = 20
$AVGCheckbox.Font = $BodyFont
$Tab6.Controls.Add($AVGCheckbox)

$AviraLogo = New-Object System.Windows.Forms.PictureBox
$AviraLogo.Width = 18
$AviraLogo.Height = 18
$AviraLogo.Location = New-Object System.Drawing.Size(220,70)
$AviraLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Avira.png"
$AviraLogo.ImageLocation = $AviraLogoFile
$AviraLogo.BorderStyle = 0
$AviraLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($AviraLogo)

$AviraCheckbox = New-Object System.Windows.Forms.Checkbox 
$AviraCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$AviraCheckbox.Text = "       Avira"
$AviraCheckbox.Width = 180
$AviraCheckbox.Height = 20
$AviraCheckbox.Font = $BodyFont
$Tab6.Controls.Add($AviraCheckbox)

$BitdefenderLogo = New-Object System.Windows.Forms.PictureBox
$BitdefenderLogo.Width = 18
$BitdefenderLogo.Height = 18
$BitdefenderLogo.Location = New-Object System.Drawing.Size(220,90)
$BitdefenderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Bitdefender.png"
$BitdefenderLogo.ImageLocation = $BitdefenderLogoFile
$BitdefenderLogo.BorderStyle = 0
$BitdefenderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($BitdefenderLogo)

$BitdefenderCheckbox = New-Object System.Windows.Forms.Checkbox 
$BitdefenderCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$BitdefenderCheckbox.Text = "       Bitdefender"
$BitdefenderCheckbox.Width = 180
$BitdefenderCheckbox.Height = 20
$BitdefenderCheckbox.Font = $BodyFont
$Tab6.Controls.Add($BitdefenderCheckbox)

$ESETNod32Logo = New-Object System.Windows.Forms.PictureBox
$ESETNod32Logo.Width = 18
$ESETNod32Logo.Height = 18
$ESETNod32Logo.Location = New-Object System.Drawing.Size(220,110)
$ESETNod32LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\ESET.png"
$ESETNod32Logo.ImageLocation = $ESETNod32LogoFile
$ESETNod32Logo.BorderStyle = 0
$ESETNod32Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($ESETNod32Logo)

$ESETNod32Checkbox = New-Object System.Windows.Forms.Checkbox 
$ESETNod32Checkbox.Location = New-Object System.Drawing.Size(200,110) 
$ESETNod32Checkbox.Text = "       ESET Nod32"
$ESETNod32Checkbox.Width = 180
$ESETNod32Checkbox.Height = 20
$ESETNod32Checkbox.Font = $BodyFont
$Tab6.Controls.Add($ESETNod32Checkbox)

$Norton360Logo = New-Object System.Windows.Forms.PictureBox
$Norton360Logo.Width = 18
$Norton360Logo.Height = 18
$Norton360Logo.Location = New-Object System.Drawing.Size(220,130)
$Norton360LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Norton360.png"
$Norton360Logo.ImageLocation = $Norton360LogoFile
$Norton360Logo.BorderStyle = 0
$Norton360Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($Norton360Logo)

$Norton360Checkbox = New-Object System.Windows.Forms.Checkbox 
$Norton360Checkbox.Location = New-Object System.Drawing.Size(200,130) 
$Norton360Checkbox.Text = "       Norton360"
$Norton360Checkbox.Width = 180
$Norton360Checkbox.Height = 20
$Norton360Checkbox.Font = $BodyFont
$Tab6.Controls.Add($Norton360Checkbox)

$PandaLogo = New-Object System.Windows.Forms.PictureBox
$PandaLogo.Width = 18
$PandaLogo.Height = 18
$PandaLogo.Location = New-Object System.Drawing.Size(220,150)
$PandaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Panda.png"
$PandaLogo.ImageLocation = $PandaLogoFile
$PandaLogo.BorderStyle = 0
$PandaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($PandaLogo)

$PandaCheckbox = New-Object System.Windows.Forms.Checkbox 
$PandaCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$PandaCheckbox.Text = "       Panda"
$PandaCheckbox.Width = 180
$PandaCheckbox.Height = 20
$PandaCheckbox.Font = $BodyFont
$Tab6.Controls.Add($PandaCheckbox)

$TotalAVLogo = New-Object System.Windows.Forms.PictureBox
$TotalAVLogo.Width = 18
$TotalAVLogo.Height = 18
$TotalAVLogo.Location = New-Object System.Drawing.Size(220,170)
$TotalAVLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\TotalAV.png"
$TotalAVLogo.ImageLocation = $TotalAVLogoFile
$TotalAVLogo.BorderStyle = 0
$TotalAVLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($TotalAVLogo)

$TotalAVCheckbox = New-Object System.Windows.Forms.Checkbox 
$TotalAVCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$TotalAVCheckbox.Text = "       TotalAV"
$TotalAVCheckbox.Width = 180
$TotalAVCheckbox.Height = 20
$TotalAVCheckbox.Font = $BodyFont
$Tab6.Controls.Add($TotalAVCheckbox)

$TrendMicroLogo = New-Object System.Windows.Forms.PictureBox
$TrendMicroLogo.Width = 18
$TrendMicroLogo.Height = 18
$TrendMicroLogo.Location = New-Object System.Drawing.Size(220,190)
$TrendMicroLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\TrendMicro.png"
$TrendMicroLogo.ImageLocation = $TrendMicroLogoFile
$TrendMicroLogo.BorderStyle = 0
$TrendMicroLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($TrendMicroLogo)

$TrendMicroCheckbox = New-Object System.Windows.Forms.Checkbox 
$TrendMicroCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$TrendMicroCheckbox.Text = "       TrendMicro"
$TrendMicroCheckbox.Width = 180
$TrendMicroCheckbox.Height = 20
$TrendMicroCheckbox.Font = $BodyFont
$Tab6.Controls.Add($TrendMicroCheckbox)

$WebrootLogo = New-Object System.Windows.Forms.PictureBox
$WebrootLogo.Width = 18
$WebrootLogo.Height = 18
$WebrootLogo.Location = New-Object System.Drawing.Size(220,210)
$WebrootLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Webroot.png"
$WebrootLogo.ImageLocation = $WebrootLogoFile
$WebrootLogo.BorderStyle = 0
$WebrootLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($WebrootLogo)

$WebrootCheckbox = New-Object System.Windows.Forms.Checkbox 
$WebrootCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$WebrootCheckbox.Text = "       Webroot"
$WebrootCheckbox.Width = 180
$WebrootCheckbox.Height = 20
$WebrootCheckbox.Font = $BodyFont
$Tab6.Controls.Add($WebrootCheckbox)

$BackupLabel = New-Object System.Windows.Forms.Label
$BackupLabel.Location = New-Object System.Drawing.Size(390,10)
$BackupLabel.Text = "Backup"
$BackupLabel.Width = 180
$BackupLabel.Height = 20
$BackupLabel.Font = $HeaderFont
$Tab6.Controls.Add($BackupLabel)

$CitrixLogo = New-Object System.Windows.Forms.PictureBox
$CitrixLogo.Width = 18
$CitrixLogo.Height = 18
$CitrixLogo.Location = New-Object System.Drawing.Size(410,30)
$CitrixLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Citrix.png"
$CitrixLogo.ImageLocation = $CitrixLogoFile
$CitrixLogo.BorderStyle = 0
$CitrixLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($CitrixLogo)

$CitrixCheckbox = New-Object System.Windows.Forms.Checkbox 
$CitrixCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$CitrixCheckbox.Text = "       Citrix"
$CitrixCheckbox.Width = 180
$CitrixCheckbox.Height = 20
$CitrixCheckbox.Font = $BodyFont
$Tab6.Controls.Add($CitrixCheckbox)

$DropboxLogo = New-Object System.Windows.Forms.PictureBox
$DropboxLogo.Width = 18
$DropboxLogo.Height = 18
$DropboxLogo.Location = New-Object System.Drawing.Size(410,50)
$DropboxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Dropbox.png"
$DropboxLogo.ImageLocation = $DropboxLogoFile
$DropboxLogo.BorderStyle = 0
$DropboxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($DropboxLogo)

$DropboxCheckbox = New-Object System.Windows.Forms.Checkbox 
$DropboxCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$DropboxCheckbox.Text = "       Dropbox"
$DropboxCheckbox.Width = 180
$DropboxCheckbox.Height = 20
$DropboxCheckbox.Font = $BodyFont
$Tab6.Controls.Add($DropboxCheckbox)

$GoogleDriveLogo = New-Object System.Windows.Forms.PictureBox
$GoogleDriveLogo.Width = 18
$GoogleDriveLogo.Height = 18
$GoogleDriveLogo.Location = New-Object System.Drawing.Size(410,70)
$GoogleDriveLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\GoogleDrive.png"
$GoogleDriveLogo.ImageLocation = $GoogleDriveLogoFile
$GoogleDriveLogo.BorderStyle = 0
$GoogleDriveLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($GoogleDriveLogo)

$GoogleDriveCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoogleDriveCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$GoogleDriveCheckbox.Text = "       Google Drive"
$GoogleDriveCheckbox.Width = 180
$GoogleDriveCheckbox.Height = 20
$GoogleDriveCheckbox.Font = $BodyFont
$Tab6.Controls.Add($GoogleDriveCheckbox)

$iCloudLogo = New-Object System.Windows.Forms.PictureBox
$iCloudLogo.Width = 18
$iCloudLogo.Height = 18
$iCloudLogo.Location = New-Object System.Drawing.Size(410,90)
$iCloudLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\iCloud.png"
$iCloudLogo.ImageLocation = $iCloudLogoFile
$iCloudLogo.BorderStyle = 0
$iCloudLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($iCloudLogo)

$iCloudCheckbox = New-Object System.Windows.Forms.Checkbox 
$iCloudCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$iCloudCheckbox.Text = "       iCloud"
$iCloudCheckbox.Width = 180
$iCloudCheckbox.Height = 20
$iCloudCheckbox.Font = $BodyFont
$Tab6.Controls.Add($iCloudCheckbox)

$DuplicatiLogo = New-Object System.Windows.Forms.PictureBox
$DuplicatiLogo.Width = 18
$DuplicatiLogo.Height = 18
$DuplicatiLogo.Location = New-Object System.Drawing.Size(410,110)
$DuplicatiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Duplicati.png"
$DuplicatiLogo.ImageLocation = $DuplicatiLogoFile
$DuplicatiLogo.BorderStyle = 0
$DuplicatiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($DuplicatiLogo)

$DuplicatiCheckbox = New-Object System.Windows.Forms.Checkbox 
$DuplicatiCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$DuplicatiCheckbox.Text = "       Duplicati"
$DuplicatiCheckbox.Width = 180
$DuplicatiCheckbox.Height = 20
$DuplicatiCheckbox.Font = $BodyFont
$Tab6.Controls.Add($DuplicatiCheckbox)

$TodoBackupLogo = New-Object System.Windows.Forms.PictureBox
$TodoBackupLogo.Width = 18
$TodoBackupLogo.Height = 18
$TodoBackupLogo.Location = New-Object System.Drawing.Size(410,130)
$TodoBackupLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\TodoBackup.png"
$TodoBackupLogo.ImageLocation = $TodoBackupLogoFile
$TodoBackupLogo.BorderStyle = 0
$TodoBackupLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($TodoBackupLogo)

$TodoBackupCheckbox = New-Object System.Windows.Forms.Checkbox 
$TodoBackupCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$TodoBackupCheckbox.Text = "       Todo Backup"
$TodoBackupCheckbox.Width = 180
$TodoBackupCheckbox.Height = 20
$TodoBackupCheckbox.Font = $BodyFont
$Tab6.Controls.Add($TodoBackupCheckbox)

$DashboardLabel = New-Object System.Windows.Forms.Label
$DashboardLabel.Location = New-Object System.Drawing.Size(390,170)
$DashboardLabel.Text = "Dashboard"
$DashboardLabel.Width = 180
$DashboardLabel.Height = 20
$DashboardLabel.Font = $HeaderFont
$Tab6.Controls.Add($DashboardLabel)

$DefenderLogo = New-Object System.Windows.Forms.PictureBox
$DefenderLogo.Width = 18
$DefenderLogo.Height = 18
$DefenderLogo.Location = New-Object System.Drawing.Size(410,190)
$DefenderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Defender.png"
$DefenderLogo.ImageLocation = $DefenderLogoFile
$DefenderLogo.BorderStyle = 0
$DefenderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($DefenderLogo)

$DefenderCheckbox = New-Object System.Windows.Forms.Checkbox 
$DefenderCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$DefenderCheckbox.Text = "       Defender"
$DefenderCheckbox.Width = 180
$DefenderCheckbox.Height = 20
$DefenderCheckbox.Font = $BodyFont
$Tab6.Controls.Add($DefenderCheckbox)

$EncryptDeleteLabel = New-Object System.Windows.Forms.Label
$EncryptDeleteLabel.Location = New-Object System.Drawing.Size(390,230)
$EncryptDeleteLabel.Text = "Encrypt/Delete"
$EncryptDeleteLabel.Width = 180
$EncryptDeleteLabel.Height = 20
$EncryptDeleteLabel.Font = $HeaderFont
$Tab6.Controls.Add($EncryptDeleteLabel)

$CipherShedLogo = New-Object System.Windows.Forms.PictureBox
$CipherShedLogo.Width = 18
$CipherShedLogo.Height = 18
$CipherShedLogo.Location = New-Object System.Drawing.Size(410,250)
$CipherShedLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\CipherShed.png"
$CipherShedLogo.ImageLocation = $CipherShedLogoFile
$CipherShedLogo.BorderStyle = 0
$CipherShedLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($CipherShedLogo)

$CipherShedCheckbox = New-Object System.Windows.Forms.Checkbox 
$CipherShedCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$CipherShedCheckbox.Text = "       CipherShed"
$CipherShedCheckbox.Width = 180
$CipherShedCheckbox.Height = 20
$CipherShedCheckbox.Font = $BodyFont
$Tab6.Controls.Add($CipherShedCheckbox)

$EraserLogo = New-Object System.Windows.Forms.PictureBox
$EraserLogo.Width = 18
$EraserLogo.Height = 18
$EraserLogo.Location = New-Object System.Drawing.Size(410,270)
$EraserLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Eraser.png"
$EraserLogo.ImageLocation = $EraserLogoFile
$EraserLogo.BorderStyle = 0
$EraserLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($EraserLogo)

$EraserCheckbox = New-Object System.Windows.Forms.Checkbox 
$EraserCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$EraserCheckbox.Text = "       Eraser"
$EraserCheckbox.Width = 180
$EraserCheckbox.Height = 20
$EraserCheckbox.Font = $BodyFont
$Tab6.Controls.Add($EraserCheckbox)

$VeraCryptLogo = New-Object System.Windows.Forms.PictureBox
$VeraCryptLogo.Width = 18
$VeraCryptLogo.Height = 18
$VeraCryptLogo.Location = New-Object System.Drawing.Size(410,290)
$VeraCryptLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\VeraCrypt.png"
$VeraCryptLogo.ImageLocation = $VeraCryptLogoFile
$VeraCryptLogo.BorderStyle = 0
$VeraCryptLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($VeraCryptLogo)

$VeraCryptCheckbox = New-Object System.Windows.Forms.Checkbox 
$VeraCryptCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$VeraCryptCheckbox.Text = "       VeraCrypt"
$VeraCryptCheckbox.Width = 180
$VeraCryptCheckbox.Height = 20
$VeraCryptCheckbox.Font = $BodyFont
$Tab6.Controls.Add($VeraCryptCheckbox)

$FirewallLabel = New-Object System.Windows.Forms.Label
$FirewallLabel.Location = New-Object System.Drawing.Size(580,10)
$FirewallLabel.Text = "Firewall"
$FirewallLabel.Width = 180
$FirewallLabel.Height = 20
$FirewallLabel.Font = $HeaderFont
$Tab6.Controls.Add($FirewallLabel)

$GlassWireLogo = New-Object System.Windows.Forms.PictureBox
$GlassWireLogo.Width = 18
$GlassWireLogo.Height = 18
$GlassWireLogo.Location = New-Object System.Drawing.Size(600,30)
$GlassWireLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\GlassWire.png"
$GlassWireLogo.ImageLocation = $GlassWireLogoFile
$GlassWireLogo.BorderStyle = 0
$GlassWireLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($GlassWireLogo)

$GlassWireCheckbox = New-Object System.Windows.Forms.Checkbox 
$GlassWireCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$GlassWireCheckbox.Text = "       GlassWire"
$GlassWireCheckbox.Width = 180
$GlassWireCheckbox.Height = 20
$GlassWireCheckbox.Font = $BodyFont
$Tab6.Controls.Add($GlassWireCheckbox)

$SimpleWallLogo = New-Object System.Windows.Forms.PictureBox
$SimpleWallLogo.Width = 18
$SimpleWallLogo.Height = 18
$SimpleWallLogo.Location = New-Object System.Drawing.Size(600,50)
$SimpleWallLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\SimpleWall.png"
$SimpleWallLogo.ImageLocation = $SimpleWallLogoFile
$SimpleWallLogo.BorderStyle = 0
$SimpleWallLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($SimpleWallLogo)

$SimpleWallCheckbox = New-Object System.Windows.Forms.Checkbox 
$SimpleWallCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$SimpleWallCheckbox.Text = "       SimpleWall"
$SimpleWallCheckbox.Width = 180
$SimpleWallCheckbox.Height = 20
$SimpleWallCheckbox.Font = $BodyFont
$Tab6.Controls.Add($SimpleWallCheckbox)

$PWManagerLabel = New-Object System.Windows.Forms.Label
$PWManagerLabel.Location = New-Object System.Drawing.Size(580,90)
$PWManagerLabel.Text = "PW Manager"
$PWManagerLabel.Width = 180
$PWManagerLabel.Height = 20
$PWManagerLabel.Font = $HeaderFont
$Tab6.Controls.Add($PWManagerLabel)

$LastPassAppLogo = New-Object System.Windows.Forms.PictureBox
$LastPassAppLogo.Width = 18
$LastPassAppLogo.Height = 18
$LastPassAppLogo.Location = New-Object System.Drawing.Size(600,110)
$LastPassAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\LastPass.png"
$LastPassAppLogo.ImageLocation = $LastPassAppLogoFile
$LastPassAppLogo.BorderStyle = 0
$LastPassAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($LastPassAppLogo)

$LastPassAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$LastPassAppCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$LastPassAppCheckbox.Text = "       LastPass"
$LastPassAppCheckbox.Width = 180
$LastPassAppCheckbox.Height = 20
$LastPassAppCheckbox.Font = $BodyFont
$Tab6.Controls.Add($LastPassAppCheckbox)

$NordPassLogo = New-Object System.Windows.Forms.PictureBox
$NordPassLogo.Width = 18
$NordPassLogo.Height = 18
$NordPassLogo.Location = New-Object System.Drawing.Size(600,130)
$NordPassLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\NordPass.png"
$NordPassLogo.ImageLocation = $NordPassLogoFile
$NordPassLogo.BorderStyle = 0
$NordPassLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($NordPassLogo)

$NordPassCheckbox = New-Object System.Windows.Forms.Checkbox 
$NordPassCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$NordPassCheckbox.Text = "       NordPass"
$NordPassCheckbox.Width = 180
$NordPassCheckbox.Height = 20
$NordPassCheckbox.Font = $BodyFont
$Tab6.Controls.Add($NordPassCheckbox)

$PrivacyLabel = New-Object System.Windows.Forms.Label
$PrivacyLabel.Location = New-Object System.Drawing.Size(580,170)
$PrivacyLabel.Text = "Privacy"
$PrivacyLabel.Width = 180
$PrivacyLabel.Height = 20
$PrivacyLabel.Font = $HeaderFont
$Tab6.Controls.Add($PrivacyLabel)

$AntiBeaconLogo = New-Object System.Windows.Forms.PictureBox
$AntiBeaconLogo.Width = 18
$AntiBeaconLogo.Height = 18
$AntiBeaconLogo.Location = New-Object System.Drawing.Size(600,190)
$AntiBeaconLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\AntiBeacon.png"
$AntiBeaconLogo.ImageLocation = $AntiBeaconLogoFile
$AntiBeaconLogo.BorderStyle = 0
$AntiBeaconLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($AntiBeaconLogo)

$AntiBeaconCheckbox = New-Object System.Windows.Forms.Checkbox 
$AntiBeaconCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$AntiBeaconCheckbox.Text = "       Anti-Beacon"
$AntiBeaconCheckbox.Width = 180
$AntiBeaconCheckbox.Height = 20
$AntiBeaconCheckbox.Font = $BodyFont
$Tab6.Controls.Add($AntiBeaconCheckbox)

$OOShutUp10Logo = New-Object System.Windows.Forms.PictureBox
$OOShutUp10Logo.Width = 18
$OOShutUp10Logo.Height = 18
$OOShutUp10Logo.Location = New-Object System.Drawing.Size(600,210)
$OOShutUp10LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\OOShutUp10.png"
$OOShutUp10Logo.ImageLocation = $OOShutUp10LogoFile
$OOShutUp10Logo.BorderStyle = 0
$OOShutUp10Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($OOShutUp10Logo)

$OOShutUp10Checkbox = New-Object System.Windows.Forms.Checkbox 
$OOShutUp10Checkbox.Location = New-Object System.Drawing.Size(580,210) 
$OOShutUp10Checkbox.Text = "       O&&OShutUp10++"
$OOShutUp10Checkbox.Width = 180
$OOShutUp10Checkbox.Height = 20
$OOShutUp10Checkbox.Font = $BodyFont
$Tab6.Controls.Add($OOShutUp10Checkbox)

$SecondOpinionLabel = New-Object System.Windows.Forms.Label
$SecondOpinionLabel.Location = New-Object System.Drawing.Size(770,10)
$SecondOpinionLabel.Text = "Second Opinion"
$SecondOpinionLabel.Width = 180
$SecondOpinionLabel.Height = 20
$SecondOpinionLabel.Font = $HeaderFont
$Tab6.Controls.Add($SecondOpinionLabel)

$ESETScannerLogo = New-Object System.Windows.Forms.PictureBox
$ESETScannerLogo.Width = 18
$ESETScannerLogo.Height = 18
$ESETScannerLogo.Location = New-Object System.Drawing.Size(790,30)
$ESETScannerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\ESET.png"
$ESETScannerLogo.ImageLocation = $ESETScannerLogoFile
$ESETScannerLogo.BorderStyle = 0
$ESETScannerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($ESETScannerLogo)

$ESETScannerCheckbox = New-Object System.Windows.Forms.Checkbox 
$ESETScannerCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$ESETScannerCheckbox.Text = "       ESET Scanner"
$ESETScannerCheckbox.Width = 180
$ESETScannerCheckbox.Height = 20
$ESETScannerCheckbox.Font = $BodyFont
$Tab6.Controls.Add($ESETScannerCheckbox)

$EmergencyKitLogo = New-Object System.Windows.Forms.PictureBox
$EmergencyKitLogo.Width = 18
$EmergencyKitLogo.Height = 18
$EmergencyKitLogo.Location = New-Object System.Drawing.Size(790,50)
$EmergencyKitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\EmergencyKit.png"
$EmergencyKitLogo.ImageLocation = $EmergencyKitLogoFile
$EmergencyKitLogo.BorderStyle = 0
$EmergencyKitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($EmergencyKitLogo)

$EmergencyKitCheckbox = New-Object System.Windows.Forms.Checkbox 
$EmergencyKitCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$EmergencyKitCheckbox.Text = "       Emergency Kit"
$EmergencyKitCheckbox.Width = 180
$EmergencyKitCheckbox.Height = 20
$EmergencyKitCheckbox.Font = $BodyFont
$Tab6.Controls.Add($EmergencyKitCheckbox)

$HitmanProLogo = New-Object System.Windows.Forms.PictureBox
$HitmanProLogo.Width = 18
$HitmanProLogo.Height = 18
$HitmanProLogo.Location = New-Object System.Drawing.Size(790,70)
$HitmanProLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\HitmanPro.png"
$HitmanProLogo.ImageLocation = $HitmanProLogoFile
$HitmanProLogo.BorderStyle = 0
$HitmanProLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($HitmanProLogo)

$HitmanProCheckbox = New-Object System.Windows.Forms.Checkbox 
$HitmanProCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$HitmanProCheckbox.Text = "       HitmanPro"
$HitmanProCheckbox.Width = 180
$HitmanProCheckbox.Height = 20
$HitmanProCheckbox.Font = $BodyFont
$Tab6.Controls.Add($HitmanProCheckbox)

$SophosSCLogo = New-Object System.Windows.Forms.PictureBox
$SophosSCLogo.Width = 18
$SophosSCLogo.Height = 18
$SophosSCLogo.Location = New-Object System.Drawing.Size(790,90)
$SophosSCLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Sophos.png"
$SophosSCLogo.ImageLocation = $SophosSCLogoFile
$SophosSCLogo.BorderStyle = 0
$SophosSCLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($SophosSCLogo)

$SophosSCCheckbox = New-Object System.Windows.Forms.Checkbox 
$SophosSCCheckbox.Location = New-Object System.Drawing.Size(770,90) 
$SophosSCCheckbox.Text = "       Sophos S&&C"
$SophosSCCheckbox.Width = 180
$SophosSCCheckbox.Height = 20
$SophosSCCheckbox.Font = $BodyFont
$Tab6.Controls.Add($SophosSCCheckbox)

$VPNLabel = New-Object System.Windows.Forms.Label
$VPNLabel.Location = New-Object System.Drawing.Size(960,10)
$VPNLabel.Text = "VPN"
$VPNLabel.Width = 180
$VPNLabel.Height = 20
$VPNLabel.Font = $HeaderFont
$Tab6.Controls.Add($VPNLabel)

$IPVanishLogo = New-Object System.Windows.Forms.PictureBox
$IPVanishLogo.Width = 18
$IPVanishLogo.Height = 18
$IPVanishLogo.Location = New-Object System.Drawing.Size(980,30)
$IPVanishLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\IPVanish.png"
$IPVanishLogo.ImageLocation = $IPVanishLogoFile
$IPVanishLogo.BorderStyle = 0
$IPVanishLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($IPVanishLogo)

$IPVanishCheckbox = New-Object System.Windows.Forms.Checkbox 
$IPVanishCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$IPVanishCheckbox.Text = "       IPVanish"
$IPVanishCheckbox.Width = 180
$IPVanishCheckbox.Height = 20
$IPVanishCheckbox.Font = $BodyFont
$Tab6.Controls.Add($IPVanishCheckbox)

$NordVPNLogo = New-Object System.Windows.Forms.PictureBox
$NordVPNLogo.Width = 18
$NordVPNLogo.Height = 18
$NordVPNLogo.Location = New-Object System.Drawing.Size(980,50)
$NordVPNLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\NordVPN.png"
$NordVPNLogo.ImageLocation = $NordVPNLogoFile
$NordVPNLogo.BorderStyle = 0
$NordVPNLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($NordVPNLogo)

$NordVPNCheckbox = New-Object System.Windows.Forms.Checkbox 
$NordVPNCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$NordVPNCheckbox.Text = "       NordVPN"
$NordVPNCheckbox.Width = 180
$NordVPNCheckbox.Height = 20
$NordVPNCheckbox.Font = $BodyFont
$Tab6.Controls.Add($NordVPNCheckbox)

$ProtonVPNLogo = New-Object System.Windows.Forms.PictureBox
$ProtonVPNLogo.Width = 18
$ProtonVPNLogo.Height = 18
$ProtonVPNLogo.Location = New-Object System.Drawing.Size(980,70)
$ProtonVPNLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\ProtonVPN.png"
$ProtonVPNLogo.ImageLocation = $ProtonVPNLogoFile
$ProtonVPNLogo.BorderStyle = 0
$ProtonVPNLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($ProtonVPNLogo)

$ProtonVPNCheckbox = New-Object System.Windows.Forms.Checkbox 
$ProtonVPNCheckbox.Location = New-Object System.Drawing.Size(960,70) 
$ProtonVPNCheckbox.Text = "       ProtonVPN"
$ProtonVPNCheckbox.Width = 180
$ProtonVPNCheckbox.Height = 20
$ProtonVPNCheckbox.Font = $BodyFont
$Tab6.Controls.Add($ProtonVPNCheckbox)

$SurfsharkLogo = New-Object System.Windows.Forms.PictureBox
$SurfsharkLogo.Width = 18
$SurfsharkLogo.Height = 18
$SurfsharkLogo.Location = New-Object System.Drawing.Size(980,90)
$SurfsharkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Surfshark.png"
$SurfsharkLogo.ImageLocation = $SurfsharkLogoFile
$SurfsharkLogo.BorderStyle = 0
$SurfsharkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab6.Controls.Add($SurfsharkLogo)

$SurfsharkCheckbox = New-Object System.Windows.Forms.Checkbox 
$SurfsharkCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$SurfsharkCheckbox.Text = "       Surfshark"
$SurfsharkCheckbox.Width = 180
$SurfsharkCheckbox.Height = 20
$SurfsharkCheckbox.Font = $BodyFont
$Tab6.Controls.Add($SurfsharkCheckbox)

# Tab 7 SEARCH
$Tab7 = New-Object System.Windows.Forms.TabPage
$Tab7.Text = "Search"
$Tab7.Font = $TabFont
$Tab7.Autoscroll  = $True
$TabControl.Controls.Add($Tab7)

$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Location = New-Object System.Drawing.Point(10, 10)
$searchBox.Width = 500
$searchBox.Font = $BodyFont
# Attach Enter key handler to searchBox
$searchBox.Add_KeyDown({
    if ($_.KeyCode -eq "Enter") {
        $_.Handled = $true
        $_.SuppressKeyPress = $true
        $searchButton.PerformClick()
    }
})
$Tab7.Controls.Add($searchBox)

$searchButton = New-Object System.Windows.Forms.Button
$searchButton.Location = New-Object System.Drawing.Point(530, 10)
$searchButton.Size = New-Object System.Drawing.Size(100,30)
$searchButton.Text = "Search"
$searchButton.Font = $ButtonFont
$Tab7.Controls.Add($searchButton)

$searchInstalledButton = New-Object System.Windows.Forms.Button
$searchInstalledButton.Location = New-Object System.Drawing.Point(680, 10)
$searchInstalledButton.Size = New-Object System.Drawing.Size(150,30)
$searchInstalledButton.Text = "Search Installed"
$searchInstalledButton.Font = $ButtonFont
$Tab7.Controls.Add($searchInstalledButton)

$listInstalledButton = New-Object System.Windows.Forms.Button
$listInstalledButton.Location = New-Object System.Drawing.Point(880, 10)
$listInstalledButton.Size = New-Object System.Drawing.Size(150,30)
$listInstalledButton.Text = "List Installed"
$listInstalledButton.Font = $ButtonFont
$Tab7.Controls.Add($listInstalledButton)

$installButton = New-Object System.Windows.Forms.Button
$installButton.Location = New-Object System.Drawing.Point(10, 540)
$installButton.Size = New-Object System.Drawing.Size(100,30)
$installButton.Text = "Install"
$installButton.Font = $ButtonFont
$Tab7.Controls.Add($installButton)

$uninstallButton = New-Object System.Windows.Forms.Button
$uninstallButton.Location = New-Object System.Drawing.Point(1064, 540)
$uninstallButton.Size = New-Object System.Drawing.Size(100,30)
$uninstallButton.Text = "Uninstall"
$uninstallButton.Font = $ButtonFont
$Tab7.Controls.Add($uninstallButton)

$listBox = New-Object System.Windows.Forms.ListBox
$listBox.Location = New-Object System.Drawing.Point(10, 50)
$listBox.Width = 1154
$listBox.Height = 470
$listBox.HorizontalScrollbar = $true
$listBox.Font = $ListBoxFont
$listBox.Items.Clear()
$Tab7.Controls.Add($listBox)

# Tab 8 TASKS
$Tab8 = New-Object System.Windows.Forms.TabPage
$Tab8.Text = "Tasks"
$Tab8.Font = $TabFont
$Tab8.Autoscroll  = $True
$TabControl.Controls.Add($Tab8)

$DisableLabel = New-Object System.Windows.Forms.Label
$DisableLabel.Location = New-Object System.Drawing.Size(10,10)
$DisableLabel.Text = "Disable"
$DisableLabel.Width = 180
$DisableLabel.Height = 20
$DisableLabel.Font = $HeaderFont
$Tab8.Controls.Add($DisableLabel)

$AnimationsLogo = New-Object System.Windows.Forms.PictureBox
$AnimationsLogo.Width = 18
$AnimationsLogo.Height = 18
$AnimationsLogo.Location = New-Object System.Drawing.Size(30,30)
$AnimationsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Animations.png"
$AnimationsLogo.ImageLocation = $AnimationsLogoFile
$AnimationsLogo.BorderStyle = 0
$AnimationsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AnimationsLogo)

$AnimationsCheckbox = New-Object System.Windows.Forms.Checkbox 
$AnimationsCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$AnimationsCheckbox.Text = "       Animations"
$AnimationsCheckbox.Width = 180
$AnimationsCheckbox.Height = 20
$AnimationsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AnimationsCheckbox)

$EncryptionLogo = New-Object System.Windows.Forms.PictureBox
$EncryptionLogo.Width = 18
$EncryptionLogo.Height = 18
$EncryptionLogo.Location = New-Object System.Drawing.Size(30,50)
$EncryptionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Encryption.png"
$EncryptionLogo.ImageLocation = $EncryptionLogoFile
$EncryptionLogo.BorderStyle = 0
$EncryptionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($EncryptionLogo)

$EncryptionCheckbox = New-Object System.Windows.Forms.Checkbox 
$EncryptionCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$EncryptionCheckbox.Text = "       Encryption"
$EncryptionCheckbox.Width = 180
$EncryptionCheckbox.Height = 20
$EncryptionCheckbox.Font = $BodyFont
$Tab8.Controls.Add($EncryptionCheckbox)

$HighlightsLogo = New-Object System.Windows.Forms.PictureBox
$HighlightsLogo.Width = 18
$HighlightsLogo.Height = 18
$HighlightsLogo.Location = New-Object System.Drawing.Size(30,70)
$HighlightsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Highlights.png"
$HighlightsLogo.ImageLocation = $HighlightsLogoFile
$HighlightsLogo.BorderStyle = 0
$HighlightsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($HighlightsLogo)

$HighlightsCheckbox = New-Object System.Windows.Forms.Checkbox 
$HighlightsCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$HighlightsCheckbox.Text = "       Highlights"
$HighlightsCheckbox.Width = 180
$HighlightsCheckbox.Height = 20
$HighlightsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($HighlightsCheckbox)

$NotificationsLogo = New-Object System.Windows.Forms.PictureBox
$NotificationsLogo.Width = 18
$NotificationsLogo.Height = 18
$NotificationsLogo.Location = New-Object System.Drawing.Size(30,90)
$NotificationsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Notifications.png"
$NotificationsLogo.ImageLocation = $NotificationsLogoFile
$NotificationsLogo.BorderStyle = 0
$NotificationsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($NotificationsLogo)

$NotificationsCheckbox = New-Object System.Windows.Forms.Checkbox 
$NotificationsCheckbox.Location = New-Object System.Drawing.Size(10,90) 
$NotificationsCheckbox.Text = "       Notifications"
$NotificationsCheckbox.Width = 180
$NotificationsCheckbox.Height = 20
$NotificationsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($NotificationsCheckbox)

$SleepLogo = New-Object System.Windows.Forms.PictureBox
$SleepLogo.Width = 18
$SleepLogo.Height = 18
$SleepLogo.Location = New-Object System.Drawing.Size(30,110)
$SleepLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Sleep.png"
$SleepLogo.ImageLocation = $SleepLogoFile
$SleepLogo.BorderStyle = 0
$SleepLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($SleepLogo)

$SleepCheckbox = New-Object System.Windows.Forms.Checkbox 
$SleepCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$SleepCheckbox.Text = "       Sleep"
$SleepCheckbox.Width = 180
$SleepCheckbox.Height = 20
$SleepCheckbox.Font = $BodyFont
$Tab8.Controls.Add($SleepCheckbox)

$SnapWindowsLogo = New-Object System.Windows.Forms.PictureBox
$SnapWindowsLogo.Width = 18
$SnapWindowsLogo.Height = 18
$SnapWindowsLogo.Location = New-Object System.Drawing.Size(30,130)
$SnapWindowsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SnapWindows.png"
$SnapWindowsLogo.ImageLocation = $SnapWindowsLogoFile
$SnapWindowsLogo.BorderStyle = 0
$SnapWindowsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($SnapWindowsLogo)

$SnapWindowsCheckbox = New-Object System.Windows.Forms.Checkbox 
$SnapWindowsCheckbox.Location = New-Object System.Drawing.Size(10,130) 
$SnapWindowsCheckbox.Text = "       Snap Windows"
$SnapWindowsCheckbox.Width = 180
$SnapWindowsCheckbox.Height = 20
$SnapWindowsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($SnapWindowsCheckbox)

$SuggestionsLogo = New-Object System.Windows.Forms.PictureBox
$SuggestionsLogo.Width = 18
$SuggestionsLogo.Height = 18
$SuggestionsLogo.Location = New-Object System.Drawing.Size(30,150)
$SuggestionsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Suggestions.png"
$SuggestionsLogo.ImageLocation = $SuggestionsLogoFile
$SuggestionsLogo.BorderStyle = 0
$SuggestionsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($SuggestionsLogo)

$SuggestionsCheckbox = New-Object System.Windows.Forms.Checkbox 
$SuggestionsCheckbox.Location = New-Object System.Drawing.Size(10,150) 
$SuggestionsCheckbox.Text = "       Suggestions"
$SuggestionsCheckbox.Width = 180
$SuggestionsCheckbox.Height = 20
$SuggestionsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($SuggestionsCheckbox)

$TaskViewLogo = New-Object System.Windows.Forms.PictureBox
$TaskViewLogo.Width = 18
$TaskViewLogo.Height = 18
$TaskViewLogo.Location = New-Object System.Drawing.Size(30,170)
$TaskViewLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\TaskView.png"
$TaskViewLogo.ImageLocation = $TaskViewLogoFile
$TaskViewLogo.BorderStyle = 0
$TaskViewLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($TaskViewLogo)

$TaskViewCheckbox = New-Object System.Windows.Forms.Checkbox 
$TaskViewCheckbox.Location = New-Object System.Drawing.Size(10,170) 
$TaskViewCheckbox.Text = "       TaskView Icon"
$TaskViewCheckbox.Width = 180
$TaskViewCheckbox.Height = 20
$TaskViewCheckbox.Font = $BodyFont
$Tab8.Controls.Add($TaskViewCheckbox)

$TelemetryLogo = New-Object System.Windows.Forms.PictureBox
$TelemetryLogo.Width = 18
$TelemetryLogo.Height = 18
$TelemetryLogo.Location = New-Object System.Drawing.Size(30,190)
$TelemetryLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Telemetry.png"
$TelemetryLogo.ImageLocation = $TelemetryLogoFile
$TelemetryLogo.BorderStyle = 0
$TelemetryLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($TelemetryLogo)

$TelemetryCheckbox = New-Object System.Windows.Forms.Checkbox 
$TelemetryCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$TelemetryCheckbox.Text = "       Telemetry"
$TelemetryCheckbox.Width = 180
$TelemetryCheckbox.Height = 20
$TelemetryCheckbox.Font = $BodyFont
$Tab8.Controls.Add($TelemetryCheckbox)

$TransparencyLogo = New-Object System.Windows.Forms.PictureBox
$TransparencyLogo.Width = 18
$TransparencyLogo.Height = 18
$TransparencyLogo.Location = New-Object System.Drawing.Size(30,210)
$TransparencyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Transparency.png"
$TransparencyLogo.ImageLocation = $TransparencyLogoFile
$TransparencyLogo.BorderStyle = 0
$TransparencyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($TransparencyLogo)

$TransparencyCheckbox = New-Object System.Windows.Forms.Checkbox 
$TransparencyCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$TransparencyCheckbox.Text = "       Transparency"
$TransparencyCheckbox.Width = 180
$TransparencyCheckbox.Height = 20
$TransparencyCheckbox.Font = $BodyFont
$Tab8.Controls.Add($TransparencyCheckbox)

$WidgetsLogo = New-Object System.Windows.Forms.PictureBox
$WidgetsLogo.Width = 18
$WidgetsLogo.Height = 18
$WidgetsLogo.Location = New-Object System.Drawing.Size(30,230)
$WidgetsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Widgets.png"
$WidgetsLogo.ImageLocation = $WidgetsLogoFile
$WidgetsLogo.BorderStyle = 0
$WidgetsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($WidgetsLogo)

$WidgetsCheckbox = New-Object System.Windows.Forms.Checkbox 
$WidgetsCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$WidgetsCheckbox.Text = "       Widgets Icon"
$WidgetsCheckbox.Width = 180
$WidgetsCheckbox.Height = 20
$WidgetsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($WidgetsCheckbox)

# Xbox Services
$XboxServicesLogo = New-Object System.Windows.Forms.PictureBox
$XboxServicesLogo.Width = 18
$XboxServicesLogo.Height = 18
$XboxServicesLogo.Location = New-Object System.Drawing.Size(30,250)
$XboxServicesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\XboxServices.png"
$XboxServicesLogo.ImageLocation = $XboxServicesLogoFile
$XboxServicesLogo.BorderStyle = 0
$XboxServicesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($XboxServicesLogo)

$XboxServicesCheckbox = New-Object System.Windows.Forms.Checkbox 
$XboxServicesCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$XboxServicesCheckbox.Text = "       Xbox Services"
$XboxServicesCheckbox.Width = 180
$XboxServicesCheckbox.Height = 20
$XboxServicesCheckbox.Font = $BodyFont
$Tab8.Controls.Add($XboxServicesCheckbox)

# Disables (if present): XblAuthManager, XblGameSave, XboxGipSvc, XboxNetApiSvc

# Logo for "Select All" Disable
$DisableAllLogo = New-Object System.Windows.Forms.PictureBox
$DisableAllLogo.Width = 18
$DisableAllLogo.Height = 18
$DisableAllLogo.Location = New-Object System.Drawing.Size(30,270)
$DisableAllLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SelectAll.png"
$DisableAllLogo.ImageLocation = $DisableAllLogoFile
$DisableAllLogo.BorderStyle = 0
$DisableAllLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$Tab8.Controls.Add($DisableAllLogo)

# Checkbox for "Select All" Disable
$DisableAllCheckbox = New-Object System.Windows.Forms.CheckBox
$DisableAllCheckbox.Location = New-Object System.Drawing.Size(10,270)
$DisableAllCheckbox.Text = "       Select All"
$DisableAllCheckbox.Width = 180
$DisableAllCheckbox.Height = 20
$DisableAllCheckbox.Font = $BodyFont
$Tab8.Controls.Add($DisableAllCheckbox)

# Array of Disable checkboxes
$DisableAllCheckboxes = @($AnimationsCheckbox, $EncryptionCheckbox, $HighlightsCheckbox, $NotificationsCheckbox, $SnapWindowsCheckbox, $SleepCheckbox, $SuggestionsCheckbox, $TaskviewCheckbox, $TelemetryCheckbox, $TransparencyCheckbox, $WidgetsCheckbox, $XboxServicesCheckbox)

# Event: Toggle all Disable checkboxes when "Select All" is clicked
$DisableAllCheckbox.Add_CheckedChanged({
    foreach ($cb in $DisableAllCheckboxes) {
        $cb.Checked = $DisableAllCheckbox.Checked
    }
})

$EnableLabel = New-Object System.Windows.Forms.Label
$EnableLabel.Location = New-Object System.Drawing.Size(200,10)
$EnableLabel.Text = "Enable"
$EnableLabel.Width = 180
$EnableLabel.Height = 20
$EnableLabel.Font = $HeaderFont
$Tab8.Controls.Add($EnableLabel)

$AccentColorLogo = New-Object System.Windows.Forms.PictureBox
$AccentColorLogo.Width = 18
$AccentColorLogo.Height = 18
$AccentColorLogo.Location = New-Object System.Drawing.Size(220,30)
$AccentColorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AccentColor.png"
$AccentColorLogo.ImageLocation = $AccentColorLogoFile
$AccentColorLogo.BorderStyle = 0
$AccentColorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AccentColorLogo)

$AccentColorCheckbox = New-Object System.Windows.Forms.Checkbox 
$AccentColorCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$AccentColorCheckbox.Text = "       Accent Color"
$AccentColorCheckbox.Width = 180
$AccentColorCheckbox.Height = 20
$AccentColorCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AccentColorCheckbox)

$ClassicContextLogo = New-Object System.Windows.Forms.PictureBox
$ClassicContextLogo.Width = 18
$ClassicContextLogo.Height = 18
$ClassicContextLogo.Location = New-Object System.Drawing.Size(220,50)
$ClassicContextLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\ClassicContext.png"
$ClassicContextLogo.ImageLocation = $ClassicContextLogoFile
$ClassicContextLogo.BorderStyle = 0
$ClassicContextLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($ClassicContextLogo)

$ClassicContextCheckbox = New-Object System.Windows.Forms.Checkbox 
$ClassicContextCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$ClassicContextCheckbox.Text = "       Classic Context"
$ClassicContextCheckbox.Width = 180
$ClassicContextCheckbox.Height = 20
$ClassicContextCheckbox.Font = $BodyFont
$Tab8.Controls.Add($ClassicContextCheckbox)

$ClipboardHistoryLogo = New-Object System.Windows.Forms.PictureBox
$ClipboardHistoryLogo.Width = 18
$ClipboardHistoryLogo.Height = 18
$ClipboardHistoryLogo.Location = New-Object System.Drawing.Size(220,70)
$ClipboardHistoryLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\ClipboardHistory.png"
$ClipboardHistoryLogo.ImageLocation = $ClipboardHistoryLogoFile
$ClipboardHistoryLogo.BorderStyle = 0
$ClipboardHistoryLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($ClipboardHistoryLogo)

$ClipboardHistoryCheckbox = New-Object System.Windows.Forms.Checkbox 
$ClipboardHistoryCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$ClipboardHistoryCheckbox.Text = "       Clipboard History"
$ClipboardHistoryCheckbox.Width = 180
$ClipboardHistoryCheckbox.Height = 20
$ClipboardHistoryCheckbox.Font = $BodyFont
$Tab8.Controls.Add($ClipboardHistoryCheckbox)

$DarkModeLogo = New-Object System.Windows.Forms.PictureBox
$DarkModeLogo.Width = 18
$DarkModeLogo.Height = 18
$DarkModeLogo.Location = New-Object System.Drawing.Size(220,90)
$DarkModeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\DarkMode.png"
$DarkModeLogo.ImageLocation = $DarkModeLogoFile
$DarkModeLogo.BorderStyle = 0
$DarkModeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($DarkModeLogo)

$DarkModeCheckbox = New-Object System.Windows.Forms.Checkbox 
$DarkModeCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$DarkModeCheckbox.Text = "       Dark Mode"
$DarkModeCheckbox.Width = 180
$DarkModeCheckbox.Height = 20
$DarkModeCheckbox.Font = $BodyFont
$Tab8.Controls.Add($DarkModeCheckbox)

$FileExtensionsLogo = New-Object System.Windows.Forms.PictureBox
$FileExtensionsLogo.Width = 18
$FileExtensionsLogo.Height = 18
$FileExtensionsLogo.Location = New-Object System.Drawing.Size(220,110)
$FileExtensionsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\FileExtensions.png"
$FileExtensionsLogo.ImageLocation = $FileExtensionsLogoFile
$FileExtensionsLogo.BorderStyle = 0
$FileExtensionsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($FileExtensionsLogo)

$FileExtensionsCheckbox = New-Object System.Windows.Forms.Checkbox 
$FileExtensionsCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$FileExtensionsCheckbox.Text = "       File Extensions"
$FileExtensionsCheckbox.Width = 180
$FileExtensionsCheckbox.Height = 20
$FileExtensionsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($FileExtensionsCheckbox)

$HiddenFilesLogo = New-Object System.Windows.Forms.PictureBox
$HiddenFilesLogo.Width = 18
$HiddenFilesLogo.Height = 18
$HiddenFilesLogo.Location = New-Object System.Drawing.Size(220,130)
$HiddenFilesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\HiddenFiles.png"
$HiddenFilesLogo.ImageLocation = $HiddenFilesLogoFile
$HiddenFilesLogo.BorderStyle = 0
$HiddenFilesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($HiddenFilesLogo)

$HiddenFilesCheckbox = New-Object System.Windows.Forms.Checkbox 
$HiddenFilesCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$HiddenFilesCheckbox.Text = "       Hidden Files"
$HiddenFilesCheckbox.Width = 180
$HiddenFilesCheckbox.Height = 20
$HiddenFilesCheckbox.Font = $BodyFont
$Tab8.Controls.Add($HiddenFilesCheckbox)

$LeftTaskbarLogo = New-Object System.Windows.Forms.PictureBox
$LeftTaskbarLogo.Width = 18
$LeftTaskbarLogo.Height = 18
$LeftTaskbarLogo.Location = New-Object System.Drawing.Size(220,150)
$LeftTaskbarLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\LeftTaskbar.png"
$LeftTaskbarLogo.ImageLocation = $LeftTaskbarLogoFile
$LeftTaskbarLogo.BorderStyle = 0
$LeftTaskbarLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($LeftTaskbarLogo)

$LeftTaskbarCheckbox = New-Object System.Windows.Forms.Checkbox 
$LeftTaskbarCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$LeftTaskbarCheckbox.Text = "       Left Taskbar"
$LeftTaskbarCheckbox.Width = 180
$LeftTaskbarCheckbox.Height = 20
$LeftTaskbarCheckbox.Font = $BodyFont
$Tab8.Controls.Add($LeftTaskbarCheckbox)

$NightLightLogo = New-Object System.Windows.Forms.PictureBox
$NightLightLogo.Width = 18
$NightLightLogo.Height = 18
$NightLightLogo.Location = New-Object System.Drawing.Size(220,170)
$NightLightLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\NightLight.png"
$NightLightLogo.ImageLocation = $NightLightLogoFile
$NightLightLogo.BorderStyle = 0
$NightLightLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($NightLightLogo)

$NightLightCheckbox = New-Object System.Windows.Forms.Checkbox 
$NightLightCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$NightLightCheckbox.Text = "       Night Light"
$NightLightCheckbox.Width = 180
$NightLightCheckbox.Height = 20
$NightLightCheckbox.Font = $BodyFont
$Tab8.Controls.Add($NightLightCheckbox)

$ShowSecondsLogo = New-Object System.Windows.Forms.PictureBox
$ShowSecondsLogo.Width = 18
$ShowSecondsLogo.Height = 18
$ShowSecondsLogo.Location = New-Object System.Drawing.Size(220,190)
$ShowSecondsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\ShowSeconds.png"
$ShowSecondsLogo.ImageLocation = $ShowSecondsLogoFile
$ShowSecondsLogo.BorderStyle = 0
$ShowSecondsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($ShowSecondsLogo)

$ShowSecondsCheckbox = New-Object System.Windows.Forms.Checkbox 
$ShowSecondsCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$ShowSecondsCheckbox.Text = "       Show Seconds"
$ShowSecondsCheckbox.Width = 180
$ShowSecondsCheckbox.Height = 20
$ShowSecondsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($ShowSecondsCheckbox)

# Logo for "Select All" Enable
$EnableAllLogo = New-Object System.Windows.Forms.PictureBox
$EnableAllLogo.Width = 18
$EnableAllLogo.Height = 18
$EnableAllLogo.Location = New-Object System.Drawing.Size(220,210)
$EnableAllLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SelectAll.png"
$EnableAllLogo.ImageLocation = $EnableAllLogoFile
$EnableAllLogo.BorderStyle = 0
$EnableAllLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$Tab8.Controls.Add($EnableAllLogo)

# Checkbox for "Select All" Enable
$EnableAllCheckbox = New-Object System.Windows.Forms.CheckBox
$EnableAllCheckbox.Location = New-Object System.Drawing.Size(200,210)
$EnableAllCheckbox.Text = "       Select All"
$EnableAllCheckbox.Width = 180
$EnableAllCheckbox.Height = 20
$EnableAllCheckbox.Font = $BodyFont
$Tab8.Controls.Add($EnableAllCheckbox)

# Array of Enable checkboxes
$EnableAllCheckboxes = @($AccentColorCheckbox, $ClassicContextCheckbox, $ClipboardHistoryCheckbox, $DarkModeCheckbox, $FileExtensionsCheckbox, $HiddenFilesCheckbox, $LeftTaskbarCheckbox, $NightLightCheckbox, $ShowSecondsCheckbox)

# Event: Toggle all Enable checkboxes when "Select All" is clicked
$EnableAllCheckbox.Add_CheckedChanged({
    foreach ($cb in $EnableAllCheckboxes) {
        $cb.Checked = $EnableAllCheckbox.Checked
    }
})

$ShortcutsLabel = New-Object System.Windows.Forms.Label
$ShortcutsLabel.Location = New-Object System.Drawing.Size(390,10)
$ShortcutsLabel.Text = "Shortcuts"
$ShortcutsLabel.Width = 180
$ShortcutsLabel.Height = 20
$ShortcutsLabel.Font = $HeaderFont
$Tab8.Controls.Add($ShortcutsLabel)

$AmazonShortcutLogo = New-Object System.Windows.Forms.PictureBox
$AmazonShortcutLogo.Width = 18
$AmazonShortcutLogo.Height = 18
$AmazonShortcutLogo.Location = New-Object System.Drawing.Size(410,30)
$AmazonShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AmazonShortcut.png"
$AmazonShortcutLogo.ImageLocation = $AmazonShortcutLogoFile
$AmazonShortcutLogo.BorderStyle = 0
$AmazonShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AmazonShortcutLogo)

$AmazonShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$AmazonShortcutCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$AmazonShortcutCheckbox.Text = "       Amazon"
$AmazonShortcutCheckbox.Width = 180
$AmazonShortcutCheckbox.Height = 20
$AmazonShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AmazonShortcutCheckbox)

$AOLShortcutLogo = New-Object System.Windows.Forms.PictureBox
$AOLShortcutLogo.Width = 18
$AOLShortcutLogo.Height = 18
$AOLShortcutLogo.Location = New-Object System.Drawing.Size(410,50)
$AOLShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AOLShortcut.png"
$AOLShortcutLogo.ImageLocation = $AOLShortcutLogoFile
$AOLShortcutLogo.BorderStyle = 0
$AOLShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AOLShortcutLogo)

$AOLShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$AOLShortcutCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$AOLShortcutCheckbox.Text = "       AOL"
$AOLShortcutCheckbox.Width = 180
$AOLShortcutCheckbox.Height = 20
$AOLShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AOLShortcutCheckbox)

$AOLMailShortcutLogo = New-Object System.Windows.Forms.PictureBox
$AOLMailShortcutLogo.Width = 18
$AOLMailShortcutLogo.Height = 18
$AOLMailShortcutLogo.Location = New-Object System.Drawing.Size(410,70)
$AOLMailShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AOLMailShortcut.png"
$AOLMailShortcutLogo.ImageLocation = $AOLMailShortcutLogoFile
$AOLMailShortcutLogo.BorderStyle = 0
$AOLMailShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AOLMailShortcutLogo)

$AOLMailShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$AOLMailShortcutCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$AOLMailShortcutCheckbox.Text = "       AOL Mail"
$AOLMailShortcutCheckbox.Width = 180
$AOLMailShortcutCheckbox.Height = 20
$AOLMailShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AOLMailShortcutCheckbox)

$BestBuyShortcutLogo = New-Object System.Windows.Forms.PictureBox
$BestBuyShortcutLogo.Width = 18
$BestBuyShortcutLogo.Height = 18
$BestBuyShortcutLogo.Location = New-Object System.Drawing.Size(410,90)
$BestBuyShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\BestBuyShortcut.png"
$BestBuyShortcutLogo.ImageLocation = $BestBuyShortcutLogoFile
$BestBuyShortcutLogo.BorderStyle = 0
$BestBuyShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($BestBuyShortcutLogo)

$BestBuyShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$BestBuyShortcutCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$BestBuyShortcutCheckbox.Text = "       Best Buy"
$BestBuyShortcutCheckbox.Width = 180
$BestBuyShortcutCheckbox.Height = 20
$BestBuyShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($BestBuyShortcutCheckbox)

$FacebookShortcutLogo = New-Object System.Windows.Forms.PictureBox
$FacebookShortcutLogo.Width = 18
$FacebookShortcutLogo.Height = 18
$FacebookShortcutLogo.Location = New-Object System.Drawing.Size(410,110)
$FacebookShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\FacebookShortcut.png"
$FacebookShortcutLogo.ImageLocation = $FacebookShortcutLogoFile
$FacebookShortcutLogo.BorderStyle = 0
$FacebookShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($FacebookShortcutLogo)

$FacebookShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$FacebookShortcutCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$FacebookShortcutCheckbox.Text = "       Facebook"
$FacebookShortcutCheckbox.Width = 180
$FacebookShortcutCheckbox.Height = 20
$FacebookShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($FacebookShortcutCheckbox)

$GmailShortcutLogo = New-Object System.Windows.Forms.PictureBox
$GmailShortcutLogo.Width = 18
$GmailShortcutLogo.Height = 18
$GmailShortcutLogo.Location = New-Object System.Drawing.Size(410,130)
$GmailShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\GmailShortcut.png"
$GmailShortcutLogo.ImageLocation = $GmailShortcutLogoFile
$GmailShortcutLogo.BorderStyle = 0
$GmailShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($GmailShortcutLogo)

$GmailShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$GmailShortcutCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$GmailShortcutCheckbox.Text = "       Gmail"
$GmailShortcutCheckbox.Width = 180
$GmailShortcutCheckbox.Height = 20
$GmailShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($GmailShortcutCheckbox)

$GoogleShortcutLogo = New-Object System.Windows.Forms.PictureBox
$GoogleShortcutLogo.Width = 18
$GoogleShortcutLogo.Height = 18
$GoogleShortcutLogo.Location = New-Object System.Drawing.Size(410,150)
$GoogleShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\GoogleShortcut.png"
$GoogleShortcutLogo.ImageLocation = $GoogleShortcutLogoFile
$GoogleShortcutLogo.BorderStyle = 0
$GoogleShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($GoogleShortcutLogo)

$GoogleShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoogleShortcutCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$GoogleShortcutCheckbox.Text = "       Google"
$GoogleShortcutCheckbox.Width = 180
$GoogleShortcutCheckbox.Height = 20
$GoogleShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($GoogleShortcutCheckbox)

$OfficeShortcutsLogo = New-Object System.Windows.Forms.PictureBox
$OfficeShortcutsLogo.Width = 18
$OfficeShortcutsLogo.Height = 18
$OfficeShortcutsLogo.Location = New-Object System.Drawing.Size(410,170)
$OfficeShortcutsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\OfficeShortcuts.png"
$OfficeShortcutsLogo.ImageLocation = $OfficeShortcutsLogoFile
$OfficeShortcutsLogo.BorderStyle = 0
$OfficeShortcutsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($OfficeShortcutsLogo)

$OfficeShortcutsCheckbox = New-Object System.Windows.Forms.Checkbox 
$OfficeShortcutsCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$OfficeShortcutsCheckbox.Text = "       Office"
$OfficeShortcutsCheckbox.Width = 180
$OfficeShortcutsCheckbox.Height = 20
$OfficeShortcutsCheckbox.Font = $BodyFont
$Tab8.Controls.Add($OfficeShortcutsCheckbox)

$RedditShortcutLogo = New-Object System.Windows.Forms.PictureBox
$RedditShortcutLogo.Width = 18
$RedditShortcutLogo.Height = 18
$RedditShortcutLogo.Location = New-Object System.Drawing.Size(410,190)
$RedditShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\RedditShortcut.png"
$RedditShortcutLogo.ImageLocation = $RedditShortcutLogoFile
$RedditShortcutLogo.BorderStyle = 0
$RedditShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($RedditShortcutLogo)

$RedditShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$RedditShortcutCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$RedditShortcutCheckbox.Text = "       Reddit"
$RedditShortcutCheckbox.Width = 180
$RedditShortcutCheckbox.Height = 20
$RedditShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($RedditShortcutCheckbox)

$YahooShortcutLogo = New-Object System.Windows.Forms.PictureBox
$YahooShortcutLogo.Width = 18
$YahooShortcutLogo.Height = 18
$YahooShortcutLogo.Location = New-Object System.Drawing.Size(410,210)
$YahooShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YahooShortcut.png"
$YahooShortcutLogo.ImageLocation = $YahooShortcutLogoFile
$YahooShortcutLogo.BorderStyle = 0
$YahooShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($YahooShortcutLogo)

$YahooShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$YahooShortcutCheckbox.Location = New-Object System.Drawing.Size(390,210) 
$YahooShortcutCheckbox.Text = "       Yahoo"
$YahooShortcutCheckbox.Width = 180
$YahooShortcutCheckbox.Height = 20
$YahooShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($YahooShortcutCheckbox)

$YahooMailShortcutLogo = New-Object System.Windows.Forms.PictureBox
$YahooMailShortcutLogo.Width = 18
$YahooMailShortcutLogo.Height = 18
$YahooMailShortcutLogo.Location = New-Object System.Drawing.Size(410,230)
$YahooMailShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YahooMailShortcut.png"
$YahooMailShortcutLogo.ImageLocation = $YahooMailShortcutLogoFile
$YahooMailShortcutLogo.BorderStyle = 0
$YahooMailShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($YahooMailShortcutLogo)

$YahooMailShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$YahooMailShortcutCheckbox.Location = New-Object System.Drawing.Size(390,230) 
$YahooMailShortcutCheckbox.Text = "       Yahoo Mail"
$YahooMailShortcutCheckbox.Width = 180
$YahooMailShortcutCheckbox.Height = 20
$YahooMailShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($YahooMailShortcutCheckbox)

$YouTubeShortcutLogo = New-Object System.Windows.Forms.PictureBox
$YouTubeShortcutLogo.Width = 18
$YouTubeShortcutLogo.Height = 18
$YouTubeShortcutLogo.Location = New-Object System.Drawing.Size(410,250)
$YouTubeShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YouTubeShortcut.png"
$YouTubeShortcutLogo.ImageLocation = $YouTubeShortcutLogoFile
$YouTubeShortcutLogo.BorderStyle = 0
$YouTubeShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($YouTubeShortcutLogo)

$YouTubeShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$YouTubeShortcutCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$YouTubeShortcutCheckbox.Text = "       YouTube"
$YouTubeShortcutCheckbox.Width = 180
$YouTubeShortcutCheckbox.Height = 20
$YouTubeShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($YouTubeShortcutCheckbox)

$XShortcutLogo = New-Object System.Windows.Forms.PictureBox
$XShortcutLogo.Width = 18
$XShortcutLogo.Height = 18
$XShortcutLogo.Location = New-Object System.Drawing.Size(410,270)
$XShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\XShortcut.png"
$XShortcutLogo.ImageLocation = $XShortcutLogoFile
$XShortcutLogo.BorderStyle = 0
$XShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($XShortcutLogo)

$XShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$XShortcutCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$XShortcutCheckbox.Text = "       X"
$XShortcutCheckbox.Width = 180
$XShortcutCheckbox.Height = 20
$XShortcutCheckbox.Font = $BodyFont
$Tab8.Controls.Add($XShortcutCheckbox)

$SystemPrepLabel = New-Object System.Windows.Forms.Label
$SystemPrepLabel.Location = New-Object System.Drawing.Size(580,10)
$SystemPrepLabel.Text = "System Prep"
$SystemPrepLabel.Width = 180
$SystemPrepLabel.Height = 20
$SystemPrepLabel.Font = $HeaderFont
$Tab8.Controls.Add($SystemPrepLabel)

$AppUpdatesLogo = New-Object System.Windows.Forms.PictureBox
$AppUpdatesLogo.Width = 18
$AppUpdatesLogo.Height = 18
$AppUpdatesLogo.Location = New-Object System.Drawing.Size(600,30)
$AppUpdatesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AppUpdates.png"
$AppUpdatesLogo.ImageLocation = $AppUpdatesLogoFile
$AppUpdatesLogo.BorderStyle = 0
$AppUpdatesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AppUpdatesLogo)

$AppUpdatesCheckbox = New-Object System.Windows.Forms.Checkbox 
$AppUpdatesCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$AppUpdatesCheckbox.Text = "       App Updates"
$AppUpdatesCheckbox.Width = 180
$AppUpdatesCheckbox.Height = 20
$AppUpdatesCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AppUpdatesCheckbox)

$AutoRestartLogo = New-Object System.Windows.Forms.PictureBox
$AutoRestartLogo.Width = 18
$AutoRestartLogo.Height = 18
$AutoRestartLogo.Location = New-Object System.Drawing.Size(600,50)
$AutoRestartLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AutoRestart.png"
$AutoRestartLogo.ImageLocation = $AutoRestartLogoFile
$AutoRestartLogo.BorderStyle = 0
$AutoRestartLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AutoRestartLogo)

$AutoRestartCheckbox = New-Object System.Windows.Forms.Checkbox 
$AutoRestartCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$AutoRestartCheckbox.Text = "       Auto Restart"
$AutoRestartCheckbox.Width = 180
$AutoRestartCheckbox.Height = 20
$AutoRestartCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AutoRestartCheckbox)

$AutoTimeZoneLogo = New-Object System.Windows.Forms.PictureBox
$AutoTimeZoneLogo.Width = 18
$AutoTimeZoneLogo.Height = 18
$AutoTimeZoneLogo.Location = New-Object System.Drawing.Size(600,70)
$AutoTimeZoneLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AutoTimeZone.png"
$AutoTimeZoneLogo.ImageLocation = $AutoTimeZoneLogoFile
$AutoTimeZoneLogo.BorderStyle = 0
$AutoTimeZoneLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($AutoTimeZoneLogo)

$AutoTimeZoneCheckbox = New-Object System.Windows.Forms.Checkbox 
$AutoTimeZoneCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$AutoTimeZoneCheckbox.Text = "       Auto Time Zone"
$AutoTimeZoneCheckbox.Width = 180
$AutoTimeZoneCheckbox.Height = 20
$AutoTimeZoneCheckbox.Font = $BodyFont
$Tab8.Controls.Add($AutoTimeZoneCheckbox)

$CleanupLogo = New-Object System.Windows.Forms.PictureBox
$CleanupLogo.Width = 18
$CleanupLogo.Height = 18
$CleanupLogo.Location = New-Object System.Drawing.Size(600,90)
$CleanupLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Cleanup.png"
$CleanupLogo.ImageLocation = $CleanupLogoFile
$CleanupLogo.BorderStyle = 0
$CleanupLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($CleanupLogo)

$CleanupCheckbox = New-Object System.Windows.Forms.Checkbox 
$CleanupCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$CleanupCheckbox.Text = "       Cleanup"
$CleanupCheckbox.Width = 180
$CleanupCheckbox.Height = 20
$CleanupCheckbox.Font = $BodyFont
$Tab8.Controls.Add($CleanupCheckbox)

$RestorePointLogo = New-Object System.Windows.Forms.PictureBox
$RestorePointLogo.Width = 18
$RestorePointLogo.Height = 18
$RestorePointLogo.Location = New-Object System.Drawing.Size(600,110)
$RestorePointLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\RestorePoint.png"
$RestorePointLogo.ImageLocation = $RestorePointLogoFile
$RestorePointLogo.BorderStyle = 0
$RestorePointLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($RestorePointLogo)

$RestorePointCheckbox = New-Object System.Windows.Forms.Checkbox 
$RestorePointCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$RestorePointCheckbox.Text = "       Restore Point"
$RestorePointCheckbox.Width = 180
$RestorePointCheckbox.Height = 20
$RestorePointCheckbox.Font = $BodyFont
$Tab8.Controls.Add($RestorePointCheckbox)

$WindowsUpdatesLogo = New-Object System.Windows.Forms.PictureBox
$WindowsUpdatesLogo.Width = 18
$WindowsUpdatesLogo.Height = 18
$WindowsUpdatesLogo.Location = New-Object System.Drawing.Size(600,130)
$WindowsUpdatesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\WindowsUpdates.png"
$WindowsUpdatesLogo.ImageLocation = $WindowsUpdatesLogoFile
$WindowsUpdatesLogo.BorderStyle = 0
$WindowsUpdatesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($WindowsUpdatesLogo)

$WindowsUpdatesCheckbox = New-Object System.Windows.Forms.Checkbox 
$WindowsUpdatesCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$WindowsUpdatesCheckbox.Text = "       Windows Updates"
$WindowsUpdatesCheckbox.Width = 180
$WindowsUpdatesCheckbox.Height = 20
$WindowsUpdatesCheckbox.Font = $BodyFont
$Tab8.Controls.Add($WindowsUpdatesCheckbox)

# Logo for "Select All" System Prep
$SystemPrepAllLogo = New-Object System.Windows.Forms.PictureBox
$SystemPrepAllLogo.Width = 18
$SystemPrepAllLogo.Height = 18
$SystemPrepAllLogo.Location = New-Object System.Drawing.Size(600,150)
$SystemPrepAllLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SelectAll.png"
$SystemPrepAllLogo.ImageLocation = $SystemPrepAllLogoFile
$SystemPrepAllLogo.BorderStyle = 0
$SystemPrepAllLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$Tab8.Controls.Add($SystemPrepAllLogo)

# Checkbox for "Select All" System Prep
$SystemPrepAllCheckbox = New-Object System.Windows.Forms.CheckBox
$SystemPrepAllCheckbox.Location = New-Object System.Drawing.Size(580,150)
$SystemPrepAllCheckbox.Text = "       Select All"
$SystemPrepAllCheckbox.Width = 180
$SystemPrepAllCheckbox.Height = 20
$SystemPrepAllCheckbox.Font = $BodyFont
$Tab8.Controls.Add($SystemPrepAllCheckbox)

# Array of System Prep checkboxes
$SystemPrepCheckboxes = @($AppUpdatesCheckbox, $AutoRestartCheckbox, $AutoTimeZoneCheckbox, $CleanupCheckbox, $RestorePointCheckbox, $WindowsUpdatesCheckbox)

# Event: Toggle all System Prep checkboxes when "Select All" is clicked
$SystemPrepAllCheckbox.Add_CheckedChanged({
    foreach ($cb in $SystemPrepCheckboxes) {
        $cb.Checked = $SystemPrepAllCheckbox.Checked
    }
})

$UninstallLabel = New-Object System.Windows.Forms.Label
$UninstallLabel.Location = New-Object System.Drawing.Size(580,190)
$UninstallLabel.Text = "Uninstall"
$UninstallLabel.Width = 180
$UninstallLabel.Height = 20
$UninstallLabel.Font = $HeaderFont
$Tab8.Controls.Add($UninstallLabel)

$BloatwareLogo = New-Object System.Windows.Forms.PictureBox
$BloatwareLogo.Width = 18
$BloatwareLogo.Height = 18
$BloatwareLogo.Location = New-Object System.Drawing.Size(600,210)
$BloatwareLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Bloatware.png"
$BloatwareLogo.ImageLocation = $BloatwareLogoFile
$BloatwareLogo.BorderStyle = 0
$BloatwareLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($BloatwareLogo)

$BloatwareCheckbox = New-Object System.Windows.Forms.Checkbox 
$BloatwareCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$BloatwareCheckbox.Text = "       Bloatware"
$BloatwareCheckbox.Width = 180
$BloatwareCheckbox.Height = 20
$BloatwareCheckbox.Font = $BodyFont
$Tab8.Controls.Add($BloatwareCheckbox)

$MCPRLogo = New-Object System.Windows.Forms.PictureBox
$MCPRLogo.Width = 18
$MCPRLogo.Height = 18
$MCPRLogo.Location = New-Object System.Drawing.Size(600,230)
$MCPRLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\MCPR.png"
$MCPRLogo.ImageLocation = $MCPRLogoFile
$MCPRLogo.BorderStyle = 0
$MCPRLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($MCPRLogo)

$MCPRCheckbox = New-Object System.Windows.Forms.Checkbox 
$MCPRCheckbox.Location = New-Object System.Drawing.Size(580,230) 
$MCPRCheckbox.Text = "       McAfee"
$MCPRCheckbox.Width = 180
$MCPRCheckbox.Height = 20
$MCPRCheckbox.Font = $BodyFont
$Tab8.Controls.Add($MCPRCheckbox)

$OneDriveLogo = New-Object System.Windows.Forms.PictureBox
$OneDriveLogo.Width = 18
$OneDriveLogo.Height = 18
$OneDriveLogo.Location = New-Object System.Drawing.Size(600,250)
$OneDriveLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\OneDrive.png"
$OneDriveLogo.ImageLocation = $OneDriveLogoFile
$OneDriveLogo.BorderStyle = 0
$OneDriveLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($OneDriveLogo)

$OneDriveCheckbox = New-Object System.Windows.Forms.Checkbox 
$OneDriveCheckbox.Location = New-Object System.Drawing.Size(580,250) 
$OneDriveCheckbox.Text = "       OneDrive"
$OneDriveCheckbox.Width = 180
$OneDriveCheckbox.Height = 20
$OneDriveCheckbox.Font = $BodyFont
$Tab8.Controls.Add($OneDriveCheckbox)

$RUNButton = New-Object System.Windows.Forms.Button
$RUNButton.Location = New-Object System.Drawing.Size(975,100)
$RUNButton.Size = New-Object System.Drawing.Size(150,50)
$RUNButton.Text = "RUN"
$RUNButton.Font = $RunFont
$Tab8.Controls.Add($RUNButton)

$ZeroTwo = New-Object System.Windows.Forms.PictureBox
$ZeroTwo.Width = 400
$ZeroTwo.Height = 488
$ZeroTwo.Location = New-Object System.Drawing.Size(775,90)
$ZeroTwoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\ZeroTwo.png"
$ZeroTwo.ImageLocation = $ZeroTwoFile
$ZeroTwo.BorderStyle = 0
$ZeroTwo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab8.Controls.Add($ZeroTwo)

#---------------------------------------------------------------------------------------------
# Event Handlers

function Execute {

$form.ShowInTaskbar = $False
$form.Hide()
Clear
Show-Console | Out-Null

# Sets the Desktop Path
$desktopPath = [Environment]::GetFolderPath("Desktop")

# Shell 
$shell = New-Object -ComObject WScript.Shell

# Edge path for icon shortcuts
$edgeExePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

# Disable Sleep
$schemeGuid = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67' 
$schemeName = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'
function assert-ok { param([string]$What="powercfg"); if ($LASTEXITCODE -ne 0) { Write-Host "[WARNING] $What failed (exit $LASTEXITCODE). Continuing." -ForegroundColor Yellow } }
$prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
assert-ok
try {
	powercfg -setactive $schemeGuid 2>$null
	if ($LASTEXITCODE -ne 0) { 
    	$null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
    	assert-ok
    	$null = powercfg -changename $schemeGuid $schemeName $schemeDescr
    	$null = powercfg -setactive $schemeGuid
    	assert-ok
    	$settings = 'monitor-timeout-ac', 'monitor-timeout-dc', 'disk-timeout-ac', 'disk-timeout-dc', 'standby-timeout-ac', 'standby-timeout-dc', 'hibernate-timeout-ac', 'hibernate-timeout-dc'
    	foreach ($setting in $settings) {
      	powercfg -change $setting 0 # 0 == Never
      	assert-ok
    }
}

# Settings
# Disable
if ($EncryptionCheckbox.Checked) { 
    Write-Host "Disable Device Encryption" -ForegroundColor Cyan
    try {
        $bitlocker = Get-BitLockerVolume -MountPoint "C:" -ErrorAction Stop
    } catch {
        Write-Host "[WARNING] Unable to query BitLocker status. Device Encryption state unknown`n" -ForegroundColor Yellow
        return
    }
    if ($bitlocker.VolumeStatus -eq "FullyEncrypted" -or $bitlocker.VolumeStatus -eq "EncryptionInProgress") {
        try {
            Disable-BitLocker -MountPoint "C:" -ErrorAction Stop
            Write-Host "[DONE] Disable Device Encryption completed and decrypting in the background`n" -ForegroundColor Green
        } catch {
            Write-Host "[ERROR] Unable to disable Device Encryption: $($_.Exception.Message)`n" -ForegroundColor Red
        }
    } else {
        Write-Host "[DONE] Device Encryption is already disabled`n" -ForegroundColor Green
    }
}

if ($AppUpdatesCheckbox.Checked) {
    Write-Host "Manual App Updates" -ForegroundColor Cyan
    try {
        Start-Process ms-windows-store://downloadsandupdates -ErrorAction Stop
        Write-Host "[DONE] Continuing script`n" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Could not open Microsoft Store for updates: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

if ($AnimationsCheckbox.Checked) {
    Write-Host "Disable Animations" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Name MinAnimate -Value 0
    Write-Host "[DONE] Disable Animations completed`n" -ForegroundColor Green
}

if ($TransparencyCheckbox.Checked) {
    Write-Host "Disable Transparency Effects" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" -Name EnableTransparency -Value 0
    Write-Host "[DONE] Disable Transparency Effects completed`n" -ForegroundColor Green
}

if ($NotificationsCheckbox.Checked) {
    Write-Host "Disable Notifications" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\PushNotifications" -Name ToastEnabled -Value 0
    Write-Host "[DONE] Disable Notifications completed`n" -ForegroundColor Green
}

if ($SnapWindowsCheckbox.Checked) {
    Write-Host "Disable Snap Windows" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name "DockMoving" -Value 0
    Write-Host "[DONE] Disable Snap Windows completed`n" -ForegroundColor Green
}

if ($TelemetryCheckbox.Checked) {
    Write-Host "Disable Telemetry" -ForegroundColor Cyan

    # Location Tracking
    try {
        if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location") {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -Name "Value" -Value "Deny" -ErrorAction Stop
            Write-Host "Location Tracking disabled"
        }
    } catch { Write-Host "[ERROR] Location Tracking: $($_.Exception.Message)" -ForegroundColor Red }

    # Advertising ID
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -Name "Enabled" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "Advertising ID disabled"
    } catch { Write-Host "[ERROR] Advertising ID: $($_.Exception.Message)" -ForegroundColor Red }

    # Tailored Experiences
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -Name "TailoredExperiencesWithDiagnosticDataEnabled" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "Tailored Experiences disabled"
    } catch { Write-Host "[ERROR] Tailored Experiences: $($_.Exception.Message)" -ForegroundColor Red }

    # Feedback Frequency (Win10 + Win11)
    try {
        # Policy key (Win11 + Win10)
        $dcPol = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
        if (!(Test-Path $dcPol)) {
            New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows" -Name "DataCollection" -Force | Out-Null
        }
        Set-ItemProperty -Path $dcPol -Name "DoNotShowFeedbackNotifications" -Type DWord -Value 1 -ErrorAction Stop
        Write-Host "Feedback notifications disabled"

        # Legacy Win10 fallback
        $siuf = "HKCU:\Software\Microsoft\Siuf\Rules"
        if (!(Test-Path $siuf)) {
            New-Item -Path "HKCU:\Software\Microsoft\Siuf" -Name "Rules" -Force | Out-Null
        }
        Set-ItemProperty -Path $siuf -Name "NumberOfSIUFInPeriod" -Type DWord -Value 0 -ErrorAction Stop
        New-ItemProperty -Path $siuf -Name "PeriodInNanoSeconds" -PropertyType QWord -Value 0 -Force | Out-Null
        Write-Host "Feedback frequency set to 'Never' (legacy)"
    } catch { Write-Host "[ERROR] Feedback Frequency: $($_.Exception.Message)" -ForegroundColor Red }

    # Typing and Inking Data
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\InputPersonalization" -Name "RestrictImplicitTextCollection" -Type DWord -Value 1 -ErrorAction Stop
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\InputPersonalization" -Name "RestrictImplicitInkCollection" -Type DWord -Value 1 -ErrorAction Stop
        Write-Host "Typing and Inking Data disabled"
    } catch { Write-Host "[ERROR] Typing and Inking: $($_.Exception.Message)" -ForegroundColor Red }

    # Activity History
    try {
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableActivityFeed" -Type DWord -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "PublishUserActivities" -Type DWord -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "UploadUserActivities" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "Activity History disabled"
    } catch { Write-Host "[ERROR] Activity History: $($_.Exception.Message)" -ForegroundColor Red }

    # App Launch Tracking
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Start_TrackProgs" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "App Launch Tracking disabled"
    } catch { Write-Host "[ERROR] App Launch Tracking: $($_.Exception.Message)" -ForegroundColor Red }

    # Find My Device
    try {
        if (Test-Path "HKLM:\SOFTWARE\Microsoft\Settings\FindMyDevice") {
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Settings\FindMyDevice" -Name "LocationSyncEnabled" -Type DWord -Value 0 -ErrorAction Stop
            Write-Host "Find My Device disabled"
        }
    } catch { Write-Host "[ERROR] Find My Device: $($_.Exception.Message)" -ForegroundColor Red }

    # Diagnostic Data (basic telemetry)
    try {
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Type DWord -Value 1 -ErrorAction Stop
        Write-Host "Optional Diagnostic Data disabled"
    } catch { Write-Host "[ERROR] Diagnostic Data: $($_.Exception.Message)" -ForegroundColor Red }

    Write-Host "[DONE] Disable Telemetry completed`n" -ForegroundColor Green
}

if ($SuggestionsCheckbox.Checked) {
    Write-Host "Disabling Suggestions, Tips, and Recommendations" -ForegroundColor Cyan

    try {
        # Disable Start Menu Suggestions
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338393Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338389Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable Suggestions for Apps in Start (like "Suggested apps")
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338388Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable "Finish Setting Up Your Device" prompts
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" -Name "ScoobeSystemSettingEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable "Get tips, tricks, and suggestions" notifications
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SoftLandingEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable "Suggested Apps" notifications
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-310093Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable Windows Welcome Experience
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338387Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable Automatic Installation of Suggested Apps
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "ContentDeliveryAllowed" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "OemPreInstalledAppsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "PreInstalledAppsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "PreInstalledAppsEverEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SilentInstalledAppsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SystemPaneSuggestionsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        Write-Host "[DONE] Suggestions and tips disabled.`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to disable suggestions and tips: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Disable Task View Button (Win10/11)
if ($TaskViewCheckbox.Checked) {
    Write-Host "Disabling Task View Button" -ForegroundColor Cyan

    try {
        # Attempt classic registry key
        $taskbarKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        if (!(Test-Path $taskbarKey)) { New-Item -Path $taskbarKey -Force | Out-Null }
        Set-ItemProperty -Path $taskbarKey -Name "ShowTaskViewButton" -Type DWord -Value 0 -ErrorAction Stop

        # Force Explorer refresh
        Stop-Process -Name explorer -Force
        Write-Host "[DONE] Task View button disabled`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to disable Task View: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Disable Widgets (Win11)
if ($WidgetsCheckbox.Checked) {
    Write-Host "Disabling Widgets Button" -ForegroundColor Cyan
    try {
        # HKCU version (user-level)
        $advKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        if (!(Test-Path $advKey)) { New-Item -Path $advKey -Force | Out-Null }
        Set-ItemProperty -Path $advKey -Name "TaskbarDa" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # HKLM policy version (system-level, stronger)
        $policyKey = "HKLM:\SOFTWARE\Policies\Microsoft\Dsh"
        if (!(Test-Path $policyKey)) { New-Item -Path $policyKey -Force | Out-Null }
        Set-ItemProperty -Path $policyKey -Name "AllowNewsAndInterests" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        Stop-Process -Name explorer -Force
        Write-Host "[DONE] Widgets disabled`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to disable Widgets: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Disable Search Highlights (Win10 + Win11 support)
if ($HighlightsCheckbox.Checked) {
    Write-Host "Disable Search Highlights" -ForegroundColor Cyan
    try {
        # Win11 toggle
        if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings") {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings" -Name "IsDynamicSearchBoxEnabled" -Type DWord -Value 0 -ErrorAction Stop
        }
        # Win10 fallback
        if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search") {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "EnableDynamicContentInWSB" -Type DWord -Value 0 -ErrorAction Stop
        }
        Write-Host "[DONE] Search Highlights disabled`n" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Failed to disable Search Highlights: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

# Disable Xbox Services
if ($XboxServicesCheckbox.Checked) {
    Write-Host "Disable Xbox Services" -ForegroundColor Cyan
    try {
        # Disables (if present): XblAuthManager, XblGameSave, XboxGipSvc, XboxNetApiSvc
        $disabled = @()
        foreach ($svcName in @('XblAuthManager','XblGameSave','XboxGipSvc','XboxNetApiSvc')) {
            $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
            if ($svc) {
                if ($svc.Status -ne 'Stopped') { Stop-Service -Name $svcName -Force -ErrorAction SilentlyContinue }
                Set-Service -Name $svcName -StartupType Disabled -ErrorAction SilentlyContinue
                $disabled += $svcName
            }
        }
        if ($disabled.Count -gt 0) {
            Write-Host ("[DONE] Xbox services disabled: " + ($disabled -join ', ') + "`n") -ForegroundColor Green
        } else {
            Write-Host "[SKIPPED] No Xbox services were found to disable.`n" -ForegroundColor DarkGray
        }
    } catch {
        Write-Host "[ERROR] Failed to disable Xbox services: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

# Enable
if ($AccentColorCheckbox.Checked) {
    Write-Host "Enable Accent Color on Taskbar" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\DWM" -Name ColorPrevalence -Value 1
    Write-Host "[DONE] Enable Accent Color on Taskbar completed`n" -ForegroundColor Green
}

if ($ClassicContextCheckbox.Checked) {
    Write-Host "Enable Classic Context Menu" -ForegroundColor Cyan
    New-Item -Path "HKCU:\Software\Classes\CLSIfD\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" -Force | Out-Null
    Write-Host "[DONE] Enable Classic Context Menu completed`n" -ForegroundColor Green
}

if ($ShowSecondsCheckbox.Checked) {
    Write-Host "Enable Seconds on Taskbar Clock" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name ShowSecondsInSystemClock -Value 1
    Write-Host "[DONE] Enable Seconds on Taskbar Clock completed`n" -ForegroundColor Green
}

if ($ClipboardHistoryCheckbox.Checked) {
    Write-Host "Enable Clipboard History" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Clipboard" -Name EnableClipboardHistory -Value 1
    Write-Host "[DONE] Enable Clipboard History completed`n" -ForegroundColor Green
}

if ($DarkModeCheckbox.Checked) { 
    Write-Host "Enable Dark Mode" -ForegroundColor Cyan 
    $path = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize"
    Set-ItemProperty -Path $path -Name AppsUseLightTheme -Value 0
    Set-ItemProperty -Path $path -Name SystemUsesLightTheme -Value 0
    Write-Host "[DONE] Enable Dark Mode completed`n" -ForegroundColor Green
}

if ($HiddenFilesCheckbox.Checked) {
    Write-Host "Enable Show Hidden Files" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Hidden" -Type DWord -Value 1
    Write-Host "[DONE] Enable Show Hidden Files enabled`n"
}

if ($FileExtensionsCheckbox.Checked) {
    Write-Host "Enable File Extensions" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "HideFileExt" -Type DWord -Value 0
    Write-Host "[DONE] Enable File Extensions`n"
}

if ($NightLightCheckbox.Checked) {
    Write-Host "Enable Night Light with custom schedule" -ForegroundColor Cyan

    try {
        # === CONFIGURATION ===
        # Start / End times are in minutes since midnight (0 - 1439)
        $StartTimeMinutes = 1140   # 19:00 (7:00 PM)
        $EndTimeMinutes   = 420    # 07:00 (7:00 AM)
        $StrengthValue    = 128    # 0-255 (0 = cool, 255 = very warm)

        # Registry path for Night Light settings
        $nightLightPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount\Current\default$windows.data.bluelightreduction.settings\Current'

        # Build binary data structure:
        # DWORDs in order: Version, Enabled, ScheduleMode, Start, End, Strength
        $version      = [BitConverter]::GetBytes(2) # Schema version
        $enabled      = [BitConverter]::GetBytes(1) # Enable Night Light
        $scheduleMode = [BitConverter]::GetBytes(2) # 2 = Custom Schedule
        $startMinutes = [BitConverter]::GetBytes($StartTimeMinutes)
        $endMinutes   = [BitConverter]::GetBytes($EndTimeMinutes)
        $strength     = [BitConverter]::GetBytes($StrengthValue)

        $data = $version + $enabled + $scheduleMode + $startMinutes + $endMinutes + $strength

        # Write to registry
        Set-ItemProperty -Path $nightLightPath -Name Data -Value $data -ErrorAction Stop

        Write-Host "[DONE] Enable Night Light with custom schedule $($StartTimeMinutes/60):$("{0:D2}" -f ($StartTimeMinutes%60)) - $($EndTimeMinutes/60):$("{0:D2}" -f ($EndTimeMinutes%60)), Strength: $StrengthValue (0-255) completed`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to configure Night Light schedule: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Taskbar alignment with OS version check
if ($LeftTaskbarCheckbox.Checked) {
    Write-Host "Enable Left Taskbar Alignment" -ForegroundColor Cyan
    $osBuild = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").CurrentBuildNumber
    if ([int]$osBuild -ge 22000) {
        try {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarAl" -Type DWord -Value 0 -ErrorAction Stop
            Write-Host "[DONE] Taskbar Left Alignment completed`n" -ForegroundColor Green
        } catch {
            Write-Host "[ERROR] Failed to set Taskbar Alignment: $($_.Exception.Message)`n" -ForegroundColor Red
        }
    } else {
        Write-Host "[INFO] Taskbar alignment option is only available on Windows 11`n" -ForegroundColor Yellow
    }
}

if ($AutoTimeZoneCheckbox.Checked) {
    Write-Host "Set Automatic Time Zone" -ForegroundColor Cyan

    try {
        # --- Enable required services ---
        Set-Service lfsvc -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service lfsvc -ErrorAction SilentlyContinue
        Set-Service tzautoupdate -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service tzautoupdate -ErrorAction SilentlyContinue
        Set-Service w32time -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service w32time -ErrorAction SilentlyContinue

        # --- Turn ON both ---
        reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\DateTime\AllowTimeZoneUpdate" /v "Value" /t REG_DWORD /d 1 /f | Out-Null
        reg add "HKLM\SYSTEM\CurrentControlSet\Services\tzautoupdate" /v "Start" /t REG_DWORD /d 3 /f | Out-Null
        reg add "HKLM\SYSTEM\CurrentControlSet\Services\W32Time" /v "Start" /t REG_DWORD /d 3 /f | Out-Null
        tzutil /autotimezone enable | Out-Null
        Start-Sleep -Seconds 2

        # --- Toggle OFF then ON ---
        tzutil /autotimezone disable | Out-Null
        reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\DateTime\AllowTimeZoneUpdate" /v "Value" /t REG_DWORD /d 0 /f | Out-Null
        Start-Sleep -Seconds 2
        reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\DateTime\AllowTimeZoneUpdate" /v "Value" /t REG_DWORD /d 1 /f | Out-Null
        tzutil /autotimezone enable | Out-Null

        # --- Force immediate time sync ---
        Start-Sleep -Seconds 1
        w32tm /resync | Out-Null

        Write-Host "[DONE] Set Automatic Time Zone completed.`n" -ForegroundColor Green
    }
    catch {
        Write-Host "[ERROR] Failed to toggle automatic time settings: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

if($MCPRCheckbox.Checked) {  
    try {
        Write-Host "McAfee Consumer Product Removal" -ForegroundColor Cyan 

        $url  = "https://github.com/andrew-s-taylor/public/raw/main/De-Bloat/mcafeeclean.zip"
        $dest = "$env:TEMP\MCPR.zip"
        $extractPath = "$env:TEMP\MCPR"
        $mcCleanup = Join-Path $extractPath "Mccleanup.exe"

        Invoke-WebRequest -Uri $url -OutFile $dest -Verbose -ErrorAction Stop

        if (Test-Path $extractPath) {
            Remove-Item $extractPath -Recurse -Force -ErrorAction SilentlyContinue
        }

        Expand-Archive $dest -DestinationPath $extractPath -Force

        if (Test-Path $mcCleanup) {
            Write-Host "Removing McAfee products" -ForegroundColor Cyan

            $args = "-p StopServices,MFSY,PEF,MXD,CSP,Sustainability,MOCP,MFP,APPSTATS,Auth,EMproxy,FWdiver,HW,MAS,MAT,MBK,MCPR,McProxy,McSvcHost,VUL,MHN,MNA,MOBK,MPFP,MPFPCU,MPS,SHRED,MPSCU,MQC,MQCCU,MSAD,MSHR,MSK,MSKCU,MWL,NMC,RedirSvc,VS,REMEDIATION,MSC,YAP,TRUEKEY,LAM,PCB,Symlink,SafeConnect,MGS,WMIRemover,RESIDUE -v -s"

            $proc = Start-Process $mcCleanup -ArgumentList $args -PassThru -Wait -ErrorAction Stop

            if ($proc.ExitCode -eq 0) {
                Write-Host "[DONE] McAfee Consumer Product Removal completed (reboot recommended)`n" -ForegroundColor Green
            } else {
                Write-Host "[WARNING] McAfee cleanup finished with exit code $($proc.ExitCode) (reboot may still be required)`n" -ForegroundColor Yellow
            }
        }
        else {
            Write-Host "[ERROR] Mccleanup.exe was not found after extracting MCPR.zip`n" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "[ERROR] McAfee Consumer Product Removal failed: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

if($TrendMicroCheckbox.Checked) { 
	write-Host "Installing TrendMicro" -ForegroundColor Cyan 
	$url = "https://files.trendmicro.com/products/Titanium/17.9/BBY/11132025/TrendMicro_17.9_MR_64bit.exe"
	$dest = "$env:TEMP\TrendMicro.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose
	start-sleep -Seconds 180
	write-Host "[DONE] Installing TrendMicro completed`n" -ForegroundColor Green 
}

if($NvidiaAppCheckbox.Checked) { 
	write-Host "Installing Nvidia App" -ForegroundColor Cyan 
	$url = "https://uk.download.nvidia.com/nvapp/client/11.0.6.383/NVIDIA_app_v11.0.6.383.exe"
	$dest = "$env:TEMP\Nvidia.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Nvidia App completed`n" -ForegroundColor Green 
}

if ($AMDSoftwareCheckbox.Checked) {
	Write-Host "Installing AMD Software." -ForegroundColor Cyan
    Write-Host "AMD Adrenalin requires a manual install." -ForegroundColor Yellow
    Write-Host "A browser window has been opened." -ForegroundColor Yellow
    Write-Host "Download and install AMD Adrenalin, then press ENTER to continue." -ForegroundColor Yellow
    Start-Process "https://www.amd.com/en/support/download/drivers.html"
    Read-Host "Press ENTER once AMD installation is complete"
    Write-Host "[DONE] AMD Software completed`n" -ForegroundColor Green
}

if($EpsonConnectCheckbox.Checked) { 
	write-Host "Installing Epson Connect" -ForegroundColor Cyan 
	$url = "https://ftp.epson.com/drivers/ECPSU_143.exe"
	$dest = "$env:TEMP\ECPSU.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Epson Connect completed`n" -ForegroundColor Green 
}

if($NoxPlayerCheckbox.Checked) { 
	write-Host "Installing NoxPlayer" -ForegroundColor Cyan 
	$url = "https://www.bignox.com/en/download/fullPackage?formal"
	$dest = "$env:TEMP\NoxPlayer.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing NoxPlayer completed`n" -ForegroundColor Green 
}

if($MTGOCheckbox.Checked) { 
    write-Host "Installing MTGO" -ForegroundColor Cyan 
	$url = "https://mtgo.patch.daybreakgames.com/patch/mtg/live/client/setup.exe?v=9"
	$dest = "$env:TEMP\MTGO.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose 
	start-sleep 240
	write-Host "[DONE] Installing MTGO completed`n" -ForegroundColor Green        	   				
}

if($Project64Checkbox.Checked) { 
	write-Host "Installing Project64" -ForegroundColor Cyan 
	$url = "https://www.pj64-emu.com/file/setup-project64-3-0-1-5664-2df3434/"
	$dest = "$env:TEMP\Project64.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing Project64 completed`n" -ForegroundColor Green        	   				
}

if ($MTGArenaCheckbox.Checked) {
    Install-Game -GameName "MTG Arena" -WingetId "WizardsoftheCoast.MTGALauncher" -SubFolder "MTG\Arena"
}

if ($OSUCheckbox.Checked) {
    Install-Game -GameName "Osu!" -WingetId "ppy.osu" -SubFolder "Osu"
}

if ($SteamCheckbox.Checked) {
    Install-Game -GameName "Steam" -WingetId "Valve.Steam" -SubFolder "Steam"
}

if ($EpicGamesCheckbox.Checked) {
    Install-Game -GameName "Epic Games" -WingetId "EpicGames.EpicGamesLauncher" -SubFolder "Epic Games"
}

if ($BattleCheckbox.Checked) {
    Install-Game -GameName "Battle.net" -WingetId "Blizzard.BattleNet" -SubFolder "Battle.net"
}

if ($EACheckbox.Checked) {
    Install-Game -GameName "EA Desktop" -WingetId "ElectronicArts.EADesktop" -SubFolder "Electronic Arts\EA Desktop"
}

if ($MinecraftCheckbox.Checked) {
    Install-Game -GameName "Minecraft" -WingetId "Mojang.MinecraftLauncher" -SubFolder "Minecraft"
}

if ($UbisoftConnectCheckbox.Checked) {
    Install-Game -GameName "Ubisoft Connect" -WingetId "Ubisoft.Connect" -SubFolder "Ubisoft"
}
	
if ($LoLCheckbox.Checked) {
    Install-Game -GameName "League of Legends" -WingetId "RiotGames.LeagueOfLegends.NA" -SubFolder "Riot Games\League of Legends"
}
	
if ($ValorantCheckbox.Checked) {
    Install-Game -GameName "Valorant" -WingetId "RiotGames.Valorant.NA" -SubFolder "Riot Games\Valorant"
}

if ($VortexCheckbox.Checked) {
    Install-Game -GameName "Nexus Mods Vortex" -WingetId "NexusMods.Vortex" -SubFolder "Mods\NexusMods"
}

if ($CurseForgeCheckbox.Checked) {
    Install-Game -GameName "CurseForge" -WingetId "Overwolf.CurseForge" -SubFolder "Mods\CurseForge"
}

if ($WeModCheckbox.Checked) {
    Install-Game -GameName "WeMod" -WingetId "WeMod.WeMod" -SubFolder "Mods\WeMod"
}

if ($DolphinCheckbox.Checked) {
    Install-Game -GameName "Dolphin Emulator" -WingetId "DolphinEmulator.Dolphin" -SubFolder "Emulators\GC Wii\Dolphin"
}

if ($CemuCheckbox.Checked) {
    Install-Game -GameName "Cemu Emulator" -WingetId "Cemu.Cemu" -SubFolder "Emulators\Wii U\Cemu"
}

if ($DeSmuMECheckbox.Checked) {
    Install-Game -GameName "DeSmuME Emulator" -WingetId "TASVideos.Desmume" -SubFolder "Emulators\DS\DeSmuME"
}

if ($DOSBoxCheckbox.Checked) {
    Install-Game -GameName "DOSBox" -WingetId "DOSBox.DOSBox" -SubFolder "Emulators\DOS\DOSBox"
}

if ($PPSSPPCheckbox.Checked) {
    Install-Game -GameName "PPSSPP Emulator" -WingetId "PPSSPPTeam.PPSSPP" -SubFolder "Emulators\PSP\PPSSPP"
}

if ($RedreamCheckbox.Checked) {
    Install-Game -GameName "Redream Emulator" -WingetId "redream.redream" -SubFolder "Emulators\Dreamcast\Redream"
}

if ($VisualBoyAdvanceCheckbox.Checked) {
    Install-Game -GameName "VisualBoyAdvance-M" -WingetId "VisualBoyAdvance-M.VisualBoyAdvance-M" -SubFolder "Emulators\GBA\VisualBoyAdvance"
}

if ($XemuCheckbox.Checked) {
    Install-Game -GameName "Xemu Emulator" -WingetId "xemu-project.xemu" -SubFolder "Emulators\XBox\Xemu"
}

if ($XeniaCheckbox.Checked) {
    Install-Game -GameName "Xenia Emulator" -WingetId "xenia-project.xenia" -SubFolder "Emulators\XBox360\Xenia"
}

if ($RetroArchEmulationCheckbox.Checked -or $RetroArchCheckbox.Checked) {
    Install-Game -GameName "RetroArch" -WingetId "Libretro.RetroArch" -SubFolder "Emulators\RetroArch"
}

# Symlink
if ($RobloxCheckbox.Checked) {
    $gamesDrive = Get-GamesDrive -EligibleDriveLetters ((Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }).DeviceID | ForEach-Object { $_.TrimEnd(':') })
    $targetFolder = "${gamesDrive}:\Roblox"
    $defaultFolder = "C:\Program Files (x86)\Roblox"
    $installerPath = "$env:TEMP\RobloxPlayerInstaller.exe"

    Write-Host "Downloading Roblox installer" -ForegroundColor Cyan
    Invoke-WebRequest -Uri "https://setup.rbxcdn.com/RobloxPlayerInstaller.exe" -OutFile $installerPath

    Write-Host "Running Roblox installer" -ForegroundColor Cyan
    $proc = Start-Process -FilePath $installerPath -PassThru

    # Wait for installer to exit (so it finishes writing files)
    Write-Host "Waiting for installer to finish" -ForegroundColor Yellow
    $proc.WaitForExit()

    # Wait until Roblox auto-launches (a sign install is complete)
    Write-Host "Waiting for Roblox client to auto-launch" -ForegroundColor Yellow
    while (-not (Get-Process "RobloxPlayerBeta" -ErrorAction SilentlyContinue)) {
        Start-Sleep -Seconds 2
    }

    # Kill auto-launched client so script can continue
    Write-Host "Closing Roblox client" -ForegroundColor Yellow
    Get-Process "RobloxPlayerBeta" -ErrorAction SilentlyContinue | Stop-Process -Force

    # Move installation to chosen drive
    Write-Host "Moving Roblox to $targetFolder" -ForegroundColor Cyan
    if (Test-Path $targetFolder) { Remove-Item $targetFolder -Recurse -Force }
    Move-Item $defaultFolder $targetFolder -Force

    # Create symlink back at C:\
    cmd /c mklink /D "$defaultFolder" "$targetFolder" | Out-Null

    Write-Host "[DONE] Roblox installation completed on $gamesDrive" -ForegroundColor Green
}

if($RockstarCheckbox.Checked) {  
	write-Host "Installing Rockstar Launcher" -ForegroundColor Cyan 
	$url = "https://gamedownloads.rockstargames.com/public/installer/Rockstar-Games-Launcher.exe"
	$dest = "$env:TEMP\Rockstar.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verbose -wait
	write-Host "[DONE] Installing Rockstar Launcher completed"`n -ForegroundColor Green 
	}	

if($MAMECheckbox.Checked) {  
	write-Host "Installing MAME" -ForegroundColor Cyan 
	$url = "https://github.com/mamedev/mame/releases/download/mame0261/mame0261b_64bit.exe"
	$dest = "$env:TEMP\MAME.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verbose -wait
	write-Host "[DONE] Installing MAME completed"`n -ForegroundColor Green 
	}

if($BakkesModCheckbox.Checked) {  
	write-Host "Installing BakkesMod" -ForegroundColor Cyan 
	$url = "https://github.com/bakkesmodorg/BakkesModInjectorCpp/releases/latest/download/BakkesModSetup.zip"
	$dest = "$env:TEMP\BakkesMod.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$env:TEMP\BakkesMod" -Force 
	start-process "$env:Temp\BakkesMod\BakkesModSetup.exe" -verb runas -verbose -wait
	write-Host "[DONE] Installing BakkesMod completed"`n -ForegroundColor Green 
	}

if($FiveMCheckbox.Checked) { 
	write-Host "Installing FiveM" -ForegroundColor Cyan 
	$url = "https://runtime.fivem.net/client/FiveM.exe"
	$dest = "$env:TEMP\FiveM.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing FiveM completed"`n -ForegroundColor Green 
	}

if($CryEngineCheckbox.Checked) { 
	write-Host "Installing CryEngine" -ForegroundColor Cyan 
	$url = "https://content.cryengine.com/cryengine-launcher/CRYENGINE_Launcher.exe"
	$dest = "$env:TEMP\CryEngine.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing CryEngine completed"`n -ForegroundColor Green 
	}

if ($GroundControlCheckbox.Checked) {
    Write-Host "Installing StreamElements Ground Control" -ForegroundColor Cyan
    $url = "https://link.streamelements.com/gc-win"
    $dest = "$env:TEMP\GroundControlSetup.exe"
    Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
    Start-Process $dest -Wait -Verbose
    Write-Host "[DONE] Installing StreamElements Ground Control completed`n" -ForegroundColor Green
}

if ($MeldStudioCheckbox.Checked) {
    Write-Host "Installing Meld Studio" -ForegroundColor Cyan
    $url = "https://packages.streamwithmeld.com/ref/MeldStudio.beta.appinstaller"
    Invoke-Expression "Start-Process ms-appinstaller://$url -Wait"
    Write-Host "[DONE] Installing Meld Studio completed`n" -ForegroundColor Green
}
	
if ($CheatEngineCheckbox.Checked) {
    Write-Host "Opening Cheat Engine download page" -ForegroundColor Cyan  
    Start-Process "https://www.cheatengine.org/downloads.php"
    Write-Host "Please download and install Cheat Engine manually from the opened page" -ForegroundColor Yellow
    Write-Host "Press Enter once you're done to continue..."
    [void][System.Console]::ReadLine()
    Write-Host "[DONE] Installing Cheat Engine complete`n" -ForegroundColor Green
}

if($EdenCheckbox.Checked) {       
	write-Host "Opening Eden download page" -ForegroundColor Cyan   
 	Start-Process "https://github.com/eden-emulator/Releases/releases"
	Write-Host "Please download Eden manually from the opened page" -ForegroundColor Yellow
    Write-Host "Press Enter once you're done to continue..."
    [void][System.Console]::ReadLine()
    write-Host "[DONE] Installing Eden completed`n" -ForegroundColor Green   
	}

if($MasterPlusCheckbox.Checked){
    Write-Host "Installing Cooler Master MasterPlus+" -ForegroundColor Cyan
    $url = "https://linkto.cm/masterplus/"
    $zip = "$env:TEMP\MasterPlus.zip"
    $target = "$env:TEMP\MasterPlus"
    if(Test-Path $target){Remove-Item $target -Recurse -Force}
    Invoke-WebRequest -Uri $url -OutFile $zip -Verbose
    Expand-Archive $zip -DestinationPath $target -Force
    $exe=Get-ChildItem -Path $target -Recurse -Include "*.exe" -ErrorAction SilentlyContinue|Select-Object -First 1
    if($exe){
        $newExe=Join-Path $target "MasterPlusSetup.exe"
        Copy-Item $exe.FullName $newExe -Force
        Start-Process $newExe -Wait -Verbose
        Write-Host "[DONE] Installing Cooler Master MasterPlus+ completed`n" -ForegroundColor Green
    }else{
        Write-Host "Error: Installer not found inside extracted folder." -ForegroundColor Red
    }
}

if($GloriousCoreCheckbox.Checked){
    Write-Host "Installing Glorious Core" -ForegroundColor Cyan
    $url = "https://gloriouscore.nyc3.digitaloceanspaces.com/CORE2/app/GloriousCORE_2.1.10_Setup.zip"
    $zip = "$env:TEMP\GloriousCore.zip"
    $target = "$env:TEMP\GloriousCore"
    if(Test-Path $target){Remove-Item $target -Recurse -Force}
    Invoke-WebRequest -Uri $url -OutFile $zip -Verbose
    Expand-Archive $zip -DestinationPath $target -Force
    $exe=Get-ChildItem -Path $target -Recurse -Include "*.exe" -ErrorAction SilentlyContinue|Select-Object -First 1
    if($exe){
        $newExe=Join-Path $target "GloriousCoreSetup.exe"
        Copy-Item $exe.FullName $newExe -Force
        Start-Process $newExe -Wait -Verbose
        Write-Host "[DONE] Installing Glorious Core completed`n" -ForegroundColor Green
    }else{
        Write-Host "Error: Installer not found inside extracted folder." -ForegroundColor Red
    }
}

if($ASRockAppShopCheckbox.Checked){
    Write-Host "Installing ASRock App Shop" -ForegroundColor Cyan
    $url = "https://www.asrock.com/feature/appshop/dl.asp"
    $zip = "$env:TEMP\ASRockAppShop.zip"
    $target = "$env:TEMP\ASRockAppShop"
    if(Test-Path $target){Remove-Item $target -Recurse -Force}
    Invoke-WebRequest -Uri $url -OutFile $zip -Verbose
    Expand-Archive $zip -DestinationPath $target -Force
    $exe=Get-ChildItem -Path $target -Recurse -Include "*AppShop*.exe" -ErrorAction SilentlyContinue|Select-Object -First 1
    if($exe){
        $newExe=Join-Path $target "AppShopSetup.exe"
        Copy-Item $exe.FullName $newExe -Force
        Start-Process $newExe -Wait -Verbose
        Write-Host "[DONE] Installing ASRock App Shop completed`n" -ForegroundColor Green
    }else{
        Write-Host "Error: Installer not found inside extracted folder." -ForegroundColor Red
    }
}

if($GigabyteCCCheckbox.Checked){
    Write-Host "Installing Gigabyte Control Center" -ForegroundColor Cyan
    $url = "https://download.gigabyte.com/FileList/Utility/GCC_25.08.04.01.zip"
    $zip = "$env:TEMP\GigabyteCC.zip"
    $target = "$env:TEMP\GigabyteCC"
    if(Test-Path $target){Remove-Item $target -Recurse -Force}
    Invoke-WebRequest -Uri $url -OutFile $zip -Verbose
    Expand-Archive $zip -DestinationPath $target -Force
    $exe=Get-ChildItem -Path $target -Recurse -Include "*.exe" -ErrorAction SilentlyContinue|Select-Object -First 1
    if($exe){
        $newExe=Join-Path $target "GigabyteCCSetup.exe"
        Copy-Item $exe.FullName $newExe -Force
        Start-Process $newExe -Wait -Verbose
        Write-Host "[DONE] Installing Gigabyte Control Center completed`n" -ForegroundColor Green
    }else{
        Write-Host "Error: Installer not found inside extracted folder." -ForegroundColor Red
    }
}

if ($ChatGPTCheckbox.Checked) {
    Write-Host "Installing ChatGPT (Official)" -ForegroundColor Cyan
    $url = "https://get.microsoft.com/installer/download/9NT1R1C2HH7J?hl=en-us&gl=us&referrer=storeforweb"
    $dest = "$env:TEMP\ChatGPTInstaller.exe"
    if (Test-Path $dest) {
        Remove-Item $dest -Force
    }
    Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
    if (Test-Path $dest) {
        Start-Process $dest -Wait -Verbose
        Write-Host "[DONE] Installing ChatGPT completed`n" -ForegroundColor Green
    }
    else {
        Write-Host "Error: Download failed." -ForegroundColor Red
    }
}

if($RyzenMasterCheckbox.Checked) {  
	write-Host "Installing Ryzen Master" -ForegroundColor Cyan 
	$url = "https://download.amd.com/Desktop/amd-ryzen-master.exe"
	$dest = "$env:TEMP\RyzenMaster.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Ryzen Master completed"`n -ForegroundColor Green 
	}

if($HPSupportCheckbox.Checked) {  
	write-Host "Installing HP Support Assistant" -ForegroundColor Cyan 
	$url = "https://ftp.hp.com/pub/softpaq/sp114001-114500/sp114036.exe"
	$dest = "$env:TEMP\HPSA.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest /s -verb runas -verbose -wait
	write-Host "[DONE] Installing HP Support Assistant completed"`n -ForegroundColor Green 
	}

if($DellSupportCheckbox.Checked) {  
	write-Host "Installing Dell SupportAssist" -ForegroundColor Cyan 
	$url = "https://downloads.dell.com/serviceability/catalog/SupportAssistInstaller.exe"
	$dest = "$env:TEMP\DellSA.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Dell SupportAssist completed"`n -ForegroundColor Green 
	}

if($RazerSynapseCheckbox.Checked) {  
	write-Host "Installing Razer Synapse" -ForegroundColor Cyan 
	$url = "https://rzr.to/synapse-pc-download"
	$dest = "$env:TEMP\RazerSynapse.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing Razer Synapse completed"`n -ForegroundColor Green 
	}

if($BitTorrentCheckbox.Checked) {
	write-Host "Installing BitTorrent" -ForegroundColor Cyan 
	$url = "https://download-new.utorrent.com/endpoint/bittorrent/os/windows/track/stable/"
	$dest = "$env:TEMP\BitTorrent.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing BitTorrent completed"`n -ForegroundColor Green 
	}

if($uTorrentCheckbox.Checked) {
	write-Host "Installing uTorrent" -ForegroundColor Cyan 
	$url = "https://download-hr.utorrent.com/track/stable/endpoint/utorrent/os/windows"
	$dest = "$env:TEMP\uTorrent.exe" 
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing uTorrent completed"`n -ForegroundColor Green 
	}

if($StellarCheckbox.Checked) {  
	write-Host "Installing Stellar Data Recovery" -ForegroundColor Cyan 
	$url = "https://cloud.stellarinfo.com/StellarDataRecovery-H.exe"
	$dest = "$env:TEMP\Stellar.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing Stellar Data Recovery completed"`n -ForegroundColor Green 
	}

if($CaptainNemoCheckbox.Checked) {  
	write-Host "Installing Captain Nemo Pro" -ForegroundColor Cyan 
	$url = "https://dl.dropboxusercontent.com/s/5i93kadp5p3z0gr/nemopro.zip"
	$dest = "$env:TEMP\CaptainNemo.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$env:TEMP\CaptainNemo" -Force
	start-process "$env:Temp\CaptainNemo\CaptainNemo.exe" -verbose -wait
	write-Host "[DONE] Installing Captain Nemo Pro completed"`n -ForegroundColor Green 
	}
	
if($BlenderBenchmarkCheckbox.Checked) {  
	write-Host "Installing Blender Benchmark" -ForegroundColor Cyan 
	$url = "https://download.blender.org/release/BlenderBenchmark2.0/launcher/benchmark-launcher-3.1.0-windows.zip"
	$dest = "$env:TEMP\BlenderBenchmark.zip"
	$extractedPath="$env:TEMP\BlenderBenchmark"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath $extractedPath -Force
	$exePath = Join-Path -Path $extractedPath -ChildPath "benchmark-launcher.exe"
	Move-Item -Path $exePath -Destination $desktopPath -Force
	write-Host "[DONE] Installing Blender Benchmark completed"`n -ForegroundColor Green
	}	

if($CheckDiskGUICheckbox.Checked) {  
	write-Host "Installing CheckDiskGUI" -ForegroundColor Cyan 
	$url = "https://www.filecroco.com/download-file/download-checkdiskgui/117/108/"
	$dest = "$desktopPath\CheckDiskGUI.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing CheckDiskGUI completed"`n -ForegroundColor Green 
	}

if($ESETSysinspectorCheckbox.Checked) {  
	write-Host "Installing ESETSysinspector" -ForegroundColor Cyan 
	$url = "https://download.eset.com/com/eset/tools/diagnosis/sysinspector/latest/sysinspector_nt64_enu.exe"
	$dest = "$desktopPath\ESETSysinspector.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing ESETSysinspector completed"`n -ForegroundColor Green 
	}

if($CipherShedCheckbox.Checked) {  
	write-Host "Installing CipherShed" -ForegroundColor Cyan 
	$url = "https://github.com/CipherShed/CipherShedBuilds/raw/v0.7.4.0-20151231/builds/be4dc698ffdc8d4414dbde838c2ddc7143c9dac2/pyeron%2Cjason/1451581628/src/Release/Setup%20Files/CipherShed-Setup-0.7.4.0.exe"
	$dest = "$desktopPath\CipherShed.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing CipherShed completed"`n -ForegroundColor Green 
	}

if($ESETScannerCheckbox.Checked) {  
	write-Host "Installing ESETScanner" -ForegroundColor Cyan 
	$url = "https://download.eset.com/com/eset/tools/online_scanner/latest/esetonlinescanner.exe"
	$dest = "$desktopPath\ESETScanner.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing ESETScanner completed"`n -ForegroundColor Green 
	}

if($EmergencyKitCheckbox.Checked) {  
	write-Host "Installing Emsisoft EmergencyKit" -ForegroundColor Cyan 
	$url = "https://dl.emsisoft.com/EmsisoftEmergencyKit.exe"
	$dest = "$desktopPath\EmergencyKit.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing Emsisoft EmergencyKit completed"`n -ForegroundColor Green 
	}

if($HitmanProCheckbox.Checked) {  
	write-Host "Installing HitmanPro" -ForegroundColor Cyan 
	$url = "https://download.sophos.com/endpoint/clients/HitmanPro_x64.exe"
	$dest = "$desktopPath\HitmanPro.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing HitmanPro completed"`n -ForegroundColor Green 
	}

if($SophosSCCheckbox.Checked) {  
	write-Host "Installing Sophos Scan & Clean" -ForegroundColor Cyan 
	$url = "https://download.sophos.com/tools/SophosScanAndClean_x64.exe"
	$dest = "$desktopPath\SophosSC.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing Sophos Scan & Clean completed"`n -ForegroundColor Green 
	}

if($NovabenchCheckbox.Checked) {  
	write-Host "Installing Novebench" -ForegroundColor Cyan 
	$url = "https://novabench.com/files/novabench.msi"
	$dest = "$env:TEMP\Novabench.msi"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process msiexec -ArgumentList "/i $env:Temp\Novabench.msi /qn" -verbose -wait
	write-Host "[DONE] Installing Novabench completed"`n -ForegroundColor Green 
	}

if($IntelDiagCheckbox.Checked) {
	write-Host "Installing Intel Processor Diagnostic Tool" -ForegroundColor Cyan 
	$url = "https://downloadmirror.intel.com/19792/IPDT_Installer_4.1.9.41_64bit.msi"
	$dest = "$env:TEMP\IntelDiag.msi"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process msiexec -ArgumentList "/i $env:Temp\IntelDiag.msi /qn" -verbose -wait
	write-Host "[DONE] Installing Intel Processor Diagnostic Tool completed"`n -ForegroundColor Green 
	}

if($UserBenchmarkCheckbox.Checked) {  
	write-Host "Installing UserBenchmark" -ForegroundColor Cyan 
	$url = "https://www.userbenchmark.com/resources/download/UserBenchmarkInstaller.exe"
	$dest = "$env:TEMP\UserBenchmark.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	start-process $dest -verb runas -verbose -wait
	write-Host "[DONE] Installing UserBenchmark completed"`n -ForegroundColor Green 
	}

if($DPCLatCheckerCheckbox.Checked) {
	Write-Host "Downloading DPCLatChecker" -ForegroundColor Cyan 
	$url = "https://www.wagnardsoft.com/dpclatency/dpclatency%20v1.0.0.7.exe"
	$dest = "$env:TEMP\DPCLatChecker.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	start-process $dest -verb runas -verbose -wait
	Write-Host "[DONE] DPCLatChecker completed"`n -ForegroundColor Green 
	}
	
if($PandaCheckbox.Checked) {
	Write-Host "Downloading Panda Antivirus" -ForegroundColor Cyan 
	$url = "https://repository.pandasecurity.com/Panda/FREEAV/193309/PANDAFREEAV.exe"
	$dest = "$env:TEMP\Panda.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	start-process $dest -verb runas -verbose -wait
	Write-Host "[DONE] Installing Panda Antivirus completed"`n -ForegroundColor Green 
	}
	
if($RPCS3Checkbox.Checked) {  
	write-Host "Installing RPCS3" -ForegroundColor Cyan 
	$url = "https://github.com/RPCS3/rpcs3-binaries-win/releases/download/build-69238bfc23444cc12ba8a2a3c73e5ee7ffde3262/rpcs3-v0.0.29-15840-69238bfc_win64.7z"
	$dest = "$desktopPath\RPCS3.7z"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	write-Host "[DONE] Installing RPCS3 completed"`n -ForegroundColor Green 
	}

if($BrutalDoomCheckbox.Checked) {
	Write-Host "Downloading BrutalDoom" -ForegroundColor Cyan 
	$url = "https://www.moddb.com/downloads/mirror/95667/121/70a7daaea4e3d956e2efc67743527461/?referer=https%3A%2F%2Fwww.moddb.com%2Fmods%2Fbrutal-doom%2Fdownloads"
	$dest = "$desktopPath\BrutalDoom.rar"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Write-Host "[DONE] BrutalDoom completed"`n -ForegroundColor Green 
	}

if($TTRGBPlusCheckbox.Checked) {  
	Write-Host "Downloading TT RGB Plus" -ForegroundColor Cyan
	$url = "https://bit.ly/TTRGBPlusV219"
	$dest = "$env:TEMP\TTRGBPlus.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Expand-Archive -Path $dest -DestinationPath $desktopPath/TTRGBPlus -Force
	Write-Host "[DONE] Downloading TT RGB Plus completed`n" -ForegroundColor Green
	}

if($ePSXeCheckbox.Checked) {  
	write-Host "Installing ePSXe" -ForegroundColor Cyan 
	$url = "http://www.epsxe.com/files/ePSXe205.zip"
	$dest = "$env:TEMP\ePSXe.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\ePSXe" -Force 
	write-Host "[DONE] Installing ePSXe completed"`n -ForegroundColor Green 
	}

if($HiganCheckbox.Checked) {  
	write-Host "Installing Higan" -ForegroundColor Cyan 
	$url = "https://github.com/higan-emu/higan/releases/download/v110/higan-v110-windows-x86_64.zip"
	$dest = "$env:TEMP\Higan.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Higan" -Force 
	write-Host "[DONE] Installing Higan completed"`n -ForegroundColor Green 
	}

if($KegaFusionCheckbox.Checked) {  
	write-Host "Installing Kega Fusion" -ForegroundColor Cyan 
	$url = "https://dl.emulator-zone.com/download.php/emulators/genesis/fusion/Fusion364.zip"
	$dest = "$env:TEMP\KegaFusion.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Kega Fusion" -Force 
	write-Host "[DONE] Installing Kega Fusion completed"`n -ForegroundColor Green 
	}

if($NestopiaCheckbox.Checked) {  
	write-Host "Installing Nestopia" -ForegroundColor Cyan 
	$url = "https://dl.emulator-zone.com/download.php/emulators/nes/nestopia/nestopia_1.52.0-win32.zip"
	$dest = "$env:TEMP\Nestopia.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Nestopia" -Force 
	write-Host "[DONE] Installing Nestopia completed"`n -ForegroundColor Green 
	}
	
if($AzaharCheckbox.Checked) { 
	write-Host "Installing Azahar" -ForegroundColor Cyan  
	$url = "https://github.com/azahar-emu/azahar/releases/download/2125.1.3/azahar-windows-msys2-2125.1.3-installer.exe"
	$dest = "$desktopPath\Azahar.exe"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
   	write-Host "[DONE] Installing Azahar completed"`n -ForegroundColor Green 	
	}

if($YabauseCheckbox.Checked) {  
	write-Host "Installing Yabause" -ForegroundColor Cyan 
	$url = "https://download.tuxfamily.org/yabause/releases/travis-ci/yabause-latest-win64.zip"
	$dest = "$env:TEMP\Yabause.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Yabause" -Force
	write-Host "[DONE] Installing Yabause completed"`n -ForegroundColor Green 
	}

if($OpenHardwareCheckbox.Checked) {  
	write-Host "Installing Open Hardware Monitor" -ForegroundColor Cyan 
	$url = "https://openhardwaremonitor.org/files/openhardwaremonitor-v0.9.6.zip"
	$dest = "$env:TEMP\OpenHardware.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Open Hardware" -Force 
	write-Host "[DONE] Installing Open Hardware Monitor completed"`n -ForegroundColor Green 
	}

if($Prime95Checkbox.Checked) {  
	write-Host "Installing Prime95" -ForegroundColor Cyan 
	$url = "https://www.mersenne.org/download/software/v30/30.8/p95v308b17.win64.zip"
	$dest = "$env:TEMP\Prime95.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Prime95" -Force 
	write-Host "[DONE] Installing Prime95 completed"`n -ForegroundColor Green 
	}

if($MemTest86Checkbox.Checked) {  
	write-Host "Installing MemTest86" -ForegroundColor Cyan 
	$url = "https://www.memtest86.com/downloads/memtest86-usb.zip"
	$dest = "$env:TEMP\MemTest86.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\MemTest86" -Force 
	write-Host "[DONE] Installing MemTest86 completed"`n -ForegroundColor Green 
	}

if($HDDScanCheckbox.Checked) {  
	write-Host "Installing HDDScan" -ForegroundColor Cyan 
	$url = "https://hddscan.com/download/HDDScan.zip"
	$dest = "$env:TEMP\HDDScan.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\HDDScan" -Force 
	write-Host "[DONE] Installing HDDScan completed"`n -ForegroundColor Green 
	}

if($BatteryInfoViewCheckbox.Checked) {
	Write-Host "Running BatteryInfoView" -ForegroundColor Cyan 
	$url = "https://www.nirsoft.net/utils/batteryinfoview.zip"
	$dest = "$env:TEMP\batteryinfoview.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Battery Info View" -Force
	Write-Host "[DONE] BatteryInfoView completed"`n -ForegroundColor Green 
	}

if($CmderCheckbox.Checked) {
	Write-Host "Running Cmder" -ForegroundColor Cyan 
	$url = "https://github.com/cmderdev/cmder/releases/download/v1.3.24/cmder.zip"
	$dest = "$env:TEMP\Cmder.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Cmder" -Force
	Write-Host "[DONE] Cmder completed"`n -ForegroundColor Green 
	}

if($DoomInfiniteCheckbox.Checked) {
	Write-Host "Downloading Doom Infinite" -ForegroundColor Cyan 
	$url = "https://www.moddb.com/downloads/mirror/257498/124/315cf4faf064e2f024016a33fa0997b0"
	$dest = "$env:TEMP\DoomInfinite.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Doom Infinite" -Force
	Write-Host "[DONE] DoomInfinite completed"`n -ForegroundColor Green 
	}

if($LiveSplitCheckbox.Checked) {
	Write-Host "Downloading LiveSplit" -ForegroundColor Cyan 
	$url = "https://github.com/LiveSplit/LiveSplit/releases/download/1.8.26/LiveSplit_1.8.26.zip"
	$dest = "$env:TEMP\LiveSplit.zip"
	Invoke-WebRequest -Uri $urlLiveSplit -OutFile $destLiveSplit -Verbose
	Expand-Archive $destLiveSplit -DestinationPath "$desktopPath\LiveSplit" -Force
	Write-Host "[DONE] LiveSplit completed"`n -ForegroundColor Green 
	}

if($BlueScreenViewCheckbox.Checked) {
	Write-Host "Downloading BlueScreenView" -ForegroundColor Cyan 
	$url = "https://www.nirsoft.net/utils/bluescreenview.zip"
	$dest = "$env:TEMP\BlueScreenView.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\Blue Screen View" -Force
	Write-Host "[DONE] BlueScreenView completed"`n -ForegroundColor Green 
	}

if($EqualizerAPOCheckbox.Checked) {
	Write-Host "Downloading EqualizerAPO" -ForegroundColor Cyan 
	$url = "https://equalizerapo.com/EqualizerAPO64-1.2.1.zip"
	$dest = "$env:TEMP\EqualizerAPO.zip"
	Invoke-WebRequest -Uri $url -OutFile $dest -Verbose
	Expand-Archive $dest -DestinationPath "$desktopPath\EqualizerAPO" -Force
	Write-Host "[DONE] EqualizerAPO completed"`n -ForegroundColor Green 
	}

if ($Office365Checkbox.Checked) {
    Write-Host "Office365" -ForegroundColor Cyan
    $url  = "https://raw.githubusercontent.com/MeldingSoftware/Apps/main/OfficeSetup365.exe"
    $dest = Join-Path $env:TEMP "OfficeSetup365.exe"
    Invoke-WebRequest -Uri $url -OutFile $dest -ErrorAction Stop
    Start-Process -FilePath $dest -ErrorAction Stop -wait 
    Write-Host "[DONE] Office365 completed`n" -ForegroundColor Green
}

if($WinMemoryDiagCheckbox.Checked) {
	write-Host "Opening Windows Memory Diagnostic Tool" -ForegroundColor Cyan
	write-Host "CHOOSE Check for problems the next time I start my computer" -ForegroundColor Cyan
	Start-Process -FilePath mdsched
	$processWinMemDiag = Get-Process | Where-Object { $_.ProcessName -eq "MdSched" }
	while ($processWinMemDiag -ne $null) {
    		Start-Sleep -Seconds 5  # Wait for 5 seconds
    		$processWinMemDiag = Get-Process | Where-Object { $_.ProcessName -eq "MdSched" }
		}
	write-Host "[DONE] Closed Windows Memory Diagnostic Tool completed"`n -ForegroundColor Green
	}

# ----------------------------------------------------
# Winget
# ----------------------------------------------------
$WingetInstalls = @(
    @{ Checkbox = $NetCheckbox;                    Label = '.NET 4.8 Developer Pack';              Id = 'Microsoft.DotNet.Framework.DeveloperPack_4' },
    @{ Checkbox = $7ZipCheckbox;                   Label = '7-Zip';                                Id = '7zip.7zip' },
    @{ Checkbox = $AcrobatReaderCheckbox;          Label = 'Acrobat Reader';                       Id = 'Adobe.Acrobat.Reader.64-bit' },
    @{ Checkbox = $AdwCleanerCheckbox;             Label = 'AdwCleaner';                           Id = 'Malwarebytes.AdwCleaner' },
    @{ Checkbox = $AIDA64Checkbox;                 Label = 'AIDA64';                               Id = 'FinalWire.AIDA64.Extreme' },
    @{ Checkbox = $AcerCareCenterCheckbox;         Label = 'Acer Care Center';                     Id = '9P8BB54NQNQ4' },
    @{ Checkbox = $AcronisCheckbox;                Label = 'Acronis Cyber Protect Home Office';    Id = 'Acronis.CyberProtectHomeOffice' },
    @{ Checkbox = $AOMEICheckbox;                  Label = 'AOMEI Partition Assistant';              Id = 'AOMEI.PartitionAssistant' },
    @{ Checkbox = $AfterburnerCheckbox;            Label = 'MSI Afterburner';                      Id = 'Guru3D.Afterburner' },
    @{ Checkbox = $AmazonMusicCheckbox;            Label = 'Amazon Music';                         Id = 'Amazon.Music' },
    @{ Checkbox = $AndroidStudioCheckbox;          Label = 'Android Studio';                       Id = 'Google.AndroidStudio.Beta' },
    @{ Checkbox = $AnkiCheckbox;                   Label = 'Anki';                                 Id = 'Anki.Anki' },
    @{ Checkbox = $AntiBeaconCheckbox;             Label = 'Spybot Anti-Beacon';                   Id = 'SaferNetworking.SpybotAntiBeacon' },
    @{ Checkbox = $AntiMicroXCheckbox;             Label = 'AntiMicroX';                           Id = 'AntiMicroX.antimicrox' },
    @{ Checkbox = $ASUSArmouryCrateCheckbox;       Label = 'ASUS Armoury Crate';                   Id = 'Asus.ArmouryCrate' },
    @{ Checkbox = $AstroCommandCenterCheckbox;     Label = 'Astro Command Center';                 Id = '9PFZ8RFZG5X4' },
    @{ Checkbox = $AudacityCheckbox;               Label = 'Audacity';                             Id = 'Audacity.Audacity' },
    @{ Checkbox = $AutorunsCheckbox;               Label = 'Autoruns';                             Id = 'Microsoft.Sysinternals.Autoruns' },
    @{ Checkbox = $AvastCheckbox;                  Label = 'Avast';                                Id = 'XPDNZJFNCR1B07' },
    @{ Checkbox = $AVGCheckbox;                    Label = 'AVG';                                  Id = 'XP8BX2DWV7TF50' },
    @{ Checkbox = $AviraCheckbox;                  Label = 'Avira';                                Id = 'XPFD23M0L795KD' },
    @{ Checkbox = $BatteryMonCheckbox;             Label = 'BatteryMon';                           Id = 'PassmarkSoftware.BatteryMon' },
    @{ Checkbox = $BitdefenderCheckbox;            Label = 'Bitdefender';                          Id = 'Bitdefender.Bitdefender' },
    @{ Checkbox = $BlenderCheckbox;                Label = 'Blender';                              Id = 'BlenderFoundation.Blender' },
    @{ Checkbox = $BlueStacksCheckbox;             Label = 'BlueStacks';                           Id = 'BlueStack.BlueStacks' },
    @{ Checkbox = $BraveCheckbox;                  Label = 'Brave';                                Id = 'XP8C9QZMS2PC1T' },
    @{ Checkbox = $BrotheriPrintScanCheckbox;      Label = 'Brother iPrint&Scan';                  Id = 'Brother.iPrintScan' },
    @{ Checkbox = $BurpSuiteCheckbox;              Label = 'Burp Suite';                           Id = 'PortSwigger.BurpSuite.Community' },
    @{ Checkbox = $CanonPrintCheckbox;             Label = 'Canon Print';                          Id = '9PMK584KQVC2' },
    @{ Checkbox = $CapCutCheckbox;                 Label = 'CapCut';                               Id = 'ByteDance.CapCut' },
    @{ Checkbox = $CCleanerCheckbox;               Label = 'CCleaner';                             Id = 'Piriform.CCleaner' },
    @{ Checkbox = $ChromeCheckbox;                 Label = 'Google Chrome';                        Id = 'Google.Chrome' },
    @{ Checkbox = $CinebenchCheckbox;              Label = 'Cinebench';                            Id = '9PGZKJC81Q7J' },
    @{ Checkbox = $CitrixCheckbox;                 Label = 'Citrix Workspace';                     Id = 'Citrix.Workspace' },
    @{ Checkbox = $ClickUpCheckbox;                Label = 'ClickUp';                              Id = 'ClickUp.ClickUp' },
    @{ Checkbox = $ClaudeCheckbox;                 Label = 'Claude';                               Id = 'Anthropic.Claude' },
    @{ Checkbox = $CLionCheckbox;                  Label = 'CLion';                                Id = 'JetBrains.CLion.EAP' },
    @{ Checkbox = $Construct3Checkbox;             Label = 'Construct 3';                          Id = '9NBZ6CP2P37P' },
    @{ Checkbox = $CoreTempCheckbox;               Label = 'Core Temp';                            Id = 'ALCPU.CoreTemp' },
    @{ Checkbox = $CorsairICUECheckbox;            Label = 'Corsair iCUE';                         Id = 'Corsair.iCUE.4' },
    @{ Checkbox = $CPUZCheckbox;                   Label = 'CPU-Z';                                Id = 'CPUID.CPU-Z' },
    @{ Checkbox = $CrystalDiskInfoCheckbox;        Label = 'CrystalDiskInfo';                      Id = 'XP8K4RGX25G3GM' },
    @{ Checkbox = $CrystalDiskMarkCheckbox;        Label = 'CrystalDiskMark';                      Id = 'CrystalDewWorld.CrystalDiskMark' },
    @{ Checkbox = $VisualCheckbox;                 Label = 'C++ Redistributable X64';              Id = 'Microsoft.VC++2015-2022Redist-x64' },
    @{ Checkbox = $DataGripCheckbox;               Label = 'DataGrip';                             Id = 'JetBrains.DataGrip' },
    @{ Checkbox = $DataSpellCheckbox;              Label = 'DataSpell';                            Id = 'JetBrains.DataSpell' },
    @{ Checkbox = $DefenderCheckbox;               Label = 'Microsoft Defender';                   Id = '9P6PMZTM93LR' },
    @{ Checkbox = $DellCommandUpdateCheckbox;      Label = 'Dell Command Update';                   Id = 'Dell.CommandUpdate'; ExtraArgs = @('--silent') },
    @{ Checkbox = $DiscordCheckbox;                Label = 'Discord';                              Id = 'Discord.Discord' },
    @{ Checkbox = $DisplayDriverUninstallerCheckbox; Label = 'Display Driver Uninstaller';           Id = 'Wagnardsoft.DisplayDriverUninstaller'; ExtraArgs = @('--silent') },
    @{ Checkbox = $DriverStoreExplorerCheckbox;     Label = 'Driver Store Explorer';                  Id = 'lostindark.DriverStoreExplorer' },
    @{ Checkbox = $DropboxCheckbox;                Label = 'Dropbox';                              Id = 'Dropbox.Dropbox' },
    @{ Checkbox = $DS4WindowsCheckbox;             Label = 'DS4Windows';                           Id = 'Ryochan7.DS4Windows' },
    @{ Checkbox = $DuckDuckGoCheckbox;             Label = 'DuckDuckGo Browser';                   Id = 'DuckDuckGo.DesktopBrowser' },
    @{ Checkbox = $DuolingoCheckbox;               Label = 'Duolingo';                             Id = '9WZDNCRCV5XN' },
    @{ Checkbox = $DuplicatiCheckbox;              Label = 'Duplicati';                            Id = 'Duplicati.Duplicati' },
    @{ Checkbox = $EaseUSDataRecoveryCheckbox;     Label = 'EaseUS Data Recovery';                 Id = 'EaseUS.DataRecovery' },
    @{ Checkbox = $EclipseCheckbox;                Label = 'Eclipse IDE for Java and DSL Developers'; Id = 'EclipseFoundation.Eclipse.DSL' },
    @{ Checkbox = $ElgatoStreamDeckCheckbox;       Label = 'Elgato Stream Deck';                   Id = 'XP8BSN2SF4XCJZ' },
    @{ Checkbox = $EraserCheckbox;                 Label = 'Eraser';                               Id = 'Eraser.Eraser' },
    @{ Checkbox = $EmulationStationCheckbox;       Label = 'Emulation Station';                    Id = 'ES-DE.EmulationStation-DE' },
    @{ Checkbox = $ESETNod32Checkbox;              Label = 'ESET NOD32';                           Id = 'ESET.Nod32' },
    @{ Checkbox = $EvernoteCheckbox;               Label = 'Evernote';                             Id = '9WZDNCRFJ3MB' },
    @{ Checkbox = $EverythingCheckbox;             Label = 'Everything';                           Id = 'voidtools.Everything' },
    @{ Checkbox = $ExodusCheckbox;                 Label = 'Exodus';                               Id = 'ExodusMovement.Exodus' },
    @{ Checkbox = $FirefoxCheckbox;                Label = 'Firefox';                              Id = 'Mozilla.Firefox' },
    @{ Checkbox = $FLStudioCheckbox;               Label = 'FL Studio';                            Id = 'ImageLine.FLStudio' },
    @{ Checkbox = $FluxCheckbox;                   Label = 'f.lux';                                Id = 'flux.flux' },
    @{ Checkbox = $GameMakerCheckbox;              Label = 'GameMaker';                            Id = 'YoYoGames.GameMaker.Studio.2' },
    @{ Checkbox = $GarminCheckbox;                 Label = 'Garmin Express';                       Id = 'Garmin.Express' },
    @{ Checkbox = $GeekbenchCheckbox;              Label = 'Geekbench 6';                          Id = 'PrimateLabs.Geekbench.6' },
    @{ Checkbox = $GeekUninstallerCheckbox;        Label = 'Geek Uninstaller';                     Id = 'GeekUninstaller.GeekUninstaller' },
    @{ Checkbox = $GeminiCheckbox;                 Label = 'Gemini';                               Id = '9NBLGGH4TJFP' },
    @{ Checkbox = $GimpCheckbox;                   Label = 'GIMP';                                 Id = 'GIMP.GIMP' },
    @{ Checkbox = $GitCheckbox;                    Label = 'Git';                                  Id = 'Git.Git' },
    @{ Checkbox = $GitHubDesktopCheckbox;          Label = 'GitHub Desktop';                       Id = 'GitHub.GitHubDesktop' },
    @{ Checkbox = $GitLFSCheckbox;                 Label = 'Git LFS';                              Id = 'GitHub.GitLFS' },
    @{ Checkbox = $GlassWireCheckbox;              Label = 'GlassWire';                            Id = 'GlassWire.GlassWire' },
    @{ Checkbox = $GlaryCheckbox;                  Label = 'Glary Utilities';                      Id = 'Glarysoft.GlaryUtilities' },
    @{ Checkbox = $GoCheckbox;                     Label = 'Go';                                   Id = 'GoLang.Go' },
    @{ Checkbox = $GodotCheckbox;                  Label = 'Godot';                                Id = 'GodotEngine.GodotEngine' },
    @{ Checkbox = $GoLandCheckbox;                 Label = 'GoLand';                               Id = 'JetBrains.GoLand' },
    @{ Checkbox = $GoogleDriveCheckbox;            Label = 'Google Drive';                         Id = 'Google.GoogleDrive' },
    @{ Checkbox = $GoogleEarthProCheckbox;         Label = 'Google Earth Pro';                     Id = 'Google.EarthPro' },
    @{ Checkbox = $GSmartControlCheckbox;          Label = 'GSmartControl';                        Id = 'GSmartControl.GSmartControl' },
    @{ Checkbox = $GPUZCheckbox;                   Label = 'GPU-Z';                                Id = 'TechPowerUp.GPU-Z' },
    @{ Checkbox = $GrammarlyAppCheckbox;           Label = 'Grammarly';                            Id = 'Grammarly.Grammarly' },
    @{ Checkbox = $GreenshotCheckbox;              Label = 'Greenshot';                            Id = 'Greenshot.Greenshot' },
    @{ Checkbox = $HamachiCheckbox;                Label = 'Hamachi';                              Id = 'LogMeIn.Hamachi' },
    @{ Checkbox = $HandbrakeCheckbox;              Label = 'HandBrake';                            Id = 'HandBrake.HandBrake' },
    @{ Checkbox = $HDTuneProCheckbox;              Label = 'HD Tune Pro';                          Id = 'EFDSoftware.HDTunePro' },
    @{ Checkbox = $HeavenCheckbox;                 Label = 'Heaven';                               Id = 'Unigine.HeavenBenchmark' },
    @{ Checkbox = $HeavyLoadCheckbox;              Label = 'HeavyLoad';                            Id = 'JAMSoftware.HeavyLoad' },
    @{ Checkbox = $HPDiagCheckbox;                 Label = 'HP Diagnostics';                       Id = '9P4PNDG7L782' },
    @{ Checkbox = $HPImageAssistantCheckbox;       Label = 'HP Image Assistant';                    Id = 'HP.ImageAssistant'; ExtraArgs = @('--silent') },
    @{ Checkbox = $HPSmartCheckbox;                Label = 'HP Smart';                             Id = '9WZDNCRFHWLH' },
    @{ Checkbox = $HWinfoCheckbox;                 Label = 'HWiNFO';                               Id = 'REALiX.HWiNFO' },
    @{ Checkbox = $HWMonitorCheckbox;              Label = 'HWMonitor';                            Id = 'CPUID.HWMonitor' },
    @{ Checkbox = $HyperCheckbox;                  Label = 'Hyper';                                Id = 'Vercel.Hyper' },
    @{ Checkbox = $iCloudCheckbox;                 Label = 'iCloud';                               Id = '9PKTQ5699M62' },
    @{ Checkbox = $IntelGraphicsCCCheckbox;        Label = 'Intel Graphics Command Center';        Id = '9PLFNLNT3G5G' },
    @{ Checkbox = $IntelSupportCheckbox;           Label = 'Intel Driver and Support Assistant';   Id = 'Intel.IntelDriverAndSupportAssistant' },
    @{ Checkbox = $IntelliJCheckbox;               Label = 'IntelliJ';                             Id = 'JetBrains.IntelliJIDEA.Community.EAP' },
    @{ Checkbox = $iTunesCheckbox;                 Label = 'iTunes';                               Id = 'Apple.iTunes' },
    @{ Checkbox = $IPVanishCheckbox;               Label = 'IPVanish';                             Id = 'IPVanish.IPVanish' },
    @{ Checkbox = $JavaCheckbox;                   Label = 'Java';                                 Id = 'Oracle.JavaRuntimeEnvironment' },
    @{ Checkbox = $JavaJDKCheckbox;                Label = 'Java SE Development Kit 22';           Id = 'Oracle.JDK.22' },
    @{ Checkbox = $JetBrainsToolboxCheckbox;       Label = 'JetBrains Toolbox';                    Id = 'JetBrains.Toolbox' },
    @{ Checkbox = $JMeterCheckbox;                 Label = 'Apache JMeter';                        Id = 'DEVCOM.JMeter' },
    @{ Checkbox = $KodiCheckbox;                   Label = 'Kodi';                                 Id = 'XBMCFoundation.Kodi' },
    @{ Checkbox = $KombustorCheckbox;              Label = 'MSI Kombustor';                        Id = 'MSI.Kombustor.4' },
    @{ Checkbox = $LastPassAppCheckbox;            Label = 'LastPass';                             Id = 'LogMeIn.LastPass' },
    @{ Checkbox = $LatencyMonCheckbox;             Label = 'LatencyMon';                           Id = 'Resplendence.LatencyMon' },
    @{ Checkbox = $LenovoSystemUpdateCheckbox;     Label = 'Lenovo System Update';                  Id = 'Lenovo.SystemUpdate'; ExtraArgs = @('--silent') },
    @{ Checkbox = $LenovoVantageCheckbox;          Label = 'Lenovo Vantage';                       Id = '9WZDNCRFJ4MV' },
    @{ Checkbox = $LexmarkUtilityCheckbox;         Label = 'Lexmark Printer Home';                 Id = '9WZDNCRFJCPF' },
    @{ Checkbox = $LibreOfficeCheckbox;            Label = 'LibreOffice';                          Id = 'TheDocumentFoundation.LibreOffice' },
    @{ Checkbox = $LightworksCheckbox;             Label = 'Lightworks';                           Id = 'LWKS.lightworks' },
    @{ Checkbox = $LogitechGHUBCheckbox;           Label = 'Logitech G Hub';                       Id = 'Logitech.GHUB' },
    @{ Checkbox = $LogitechOptionsPlusCheckbox;    Label = 'Logitech Options+';                    Id = 'Logitech.Options' },
    @{ Checkbox = $MalwareBytesCheckbox;           Label = 'Malwarebytes';                         Id = 'Malwarebytes.Malwarebytes' },
    @{ Checkbox = $MendeleyCheckbox;               Label = 'Mendeley';                             Id = 'Elsevier.MendeleyReferenceManager' },
    @{ Checkbox = $MongoDBCheckbox;                Label = 'MongoDB';                              Id = 'MongoDB.Server' },
    @{ Checkbox = $MSICenterCheckbox;              Label = 'MSI Center';                           Id = '9NVMNJCR03XV' },
    @{ Checkbox = $MyASUSCheckbox;                 Label = 'MyASUS';                               Id = '9N7R5S6B0ZZH' },
    @{ Checkbox = $MySQLCheckbox;                  Label = 'MySQL';                                Id = 'Oracle.MySQL' },
    @{ Checkbox = $NetflixCheckbox;                Label = 'Netflix';                              Id = '9WZDNCRFJ3TJ' },
    @{ Checkbox = $NodejsCheckbox;                 Label = 'Node.js';                              Id = 'OpenJS.NodeJS' },
    @{ Checkbox = $NordPassCheckbox;               Label = 'NordPass';                             Id = 'NordSecurity.NordPass' },
    @{ Checkbox = $NordVPNCheckbox;                Label = 'NordVPN';                              Id = 'NordSecurity.NordVPN' },
    @{ Checkbox = $NotepadCheckbox;                Label = 'Notepad++';                            Id = 'Notepad++.Notepad++' },
    @{ Checkbox = $Norton360Checkbox;              Label = 'Norton 360';                           Id = 'XPFNZKWN35KD6Z' },
    @{ Checkbox = $NZXTCAMCheckbox;                Label = 'NZXT CAM';                             Id = 'NZXT.CAM' },
    @{ Checkbox = $OBSStudioCheckbox;              Label = 'OBS Studio';                           Id = 'OBSProject.OBSStudio' },
    @{ Checkbox = $OCCTCheckbox;                   Label = 'OCCT';                                 Id = 'OCBase.OCCT.Personal' },
    @{ Checkbox = $ObsidianCheckbox;               Label = 'Obsidian';                             Id = 'Obsidian.Obsidian' },
    @{ Checkbox = $OOShutUp10Checkbox;             Label = 'O&OShutUp10++';                        Id = 'OO-Software.ShutUp10' },
    @{ Checkbox = $OneDriveCheckbox;               Label = 'OneDrive';                             Id = 'Microsoft.OneDrive' },
    @{ Checkbox = $OpenOfficeCheckbox;             Label = 'OpenOffice';                           Id = 'Apache.OpenOffice' },
    @{ Checkbox = $OpenRGBCheckbox;                Label = 'OpenRGB';                              Id = 'CalcProgrammer1.OpenRGB' },
    @{ Checkbox = $OperaCheckbox;                  Label = 'Opera';                                Id = 'Opera.Opera' },
    @{ Checkbox = $OperaGXCheckbox;                Label = 'Opera GX';                             Id = 'Opera.OperaGX' },
    @{ Checkbox = $OSArmorCheckbox;                Label = 'OSArmor';                              Id = 'NoVirusThanks.OSArmor.Personal' },
    @{ Checkbox = $Paint3DCheckbox;                Label = 'Paint 3D';                             Id = '9NBLGGH5FV99' },
    @{ Checkbox = $PaintNETCheckbox;               Label = 'Paint.NET';                            Id = 'dotPDNLLC.paintdotnet' },
    @{ Checkbox = $PerformanceTESTCheckbox;        Label = 'PerformanceTEST';                      Id = '9NX2VQG25JXJ' },
    @{ Checkbox = $PerplexityCheckbox;             Label = 'Perplexity';                           Id = 'XP8JNQFBQH6PVF' },
    @{ Checkbox = $PhpStormCheckbox;               Label = 'PhpStorm';                             Id = 'JetBrains.PHPStorm' },
    @{ Checkbox = $PlexCheckbox;                   Label = 'Plex';                                 Id = 'Plex.PlexMediaServer' },
    @{ Checkbox = $PlayniteCheckbox;               Label = 'Playnite';                             Id = 'Playnite.Playnite' },
    @{ Checkbox = $PostgreSQLCheckbox;             Label = 'PostgreSQL';                           Id = 'PostgreSQL.PostgreSQL' },
    @{ Checkbox = $PostmanCheckbox;                Label = 'Postman';                              Id = 'Postman.Postman' },
    @{ Checkbox = $PowerToysCheckbox;              Label = 'PowerToys';                            Id = 'XP89DCGQ3K6VLD' },
    @{ Checkbox = $ProtonVPNCheckbox;              Label = 'ProtonVPN';                            Id = 'Proton.ProtonVPN' },
    @{ Checkbox = $PuTTYCheckbox;                  Label = 'PuTTY';                                Id = 'PuTTY.PuTTY' },
    @{ Checkbox = $PyCharmCheckbox;                Label = 'PyCharm';                              Id = 'JetBrains.PyCharm.Community.EAP' },
    @{ Checkbox = $Python3Checkbox;                Label = 'Python 3.13';                          Id = 'Python.Python.3.13' },
    @{ Checkbox = $qBittorrentCheckbox;            Label = 'qBittorrent';                          Id = 'qBittorrent.qBittorrent' },
    @{ Checkbox = $QuickenCheckbox;                Label = 'Quicken';                              Id = 'Quicken.Quicken' },
    @{ Checkbox = $RCheckbox;                      Label = 'R';                                    Id = 'RProject.R' },
    @{ Checkbox = $RainmeterCheckbox;              Label = 'Rainmeter';                            Id = 'Rainmeter.Rainmeter' },
    @{ Checkbox = $RazerChromaCheckbox;            Label = 'Razer Chroma';                         Id = '9PG8DNKL06M6' },
    @{ Checkbox = $RazerCortexCheckbox;            Label = 'Razer Cortex';                         Id = '9PK9W5QV2PKX' },
    @{ Checkbox = $RecuvaCheckbox;                 Label = 'Recuva';                               Id = 'Piriform.Recuva' },
    @{ Checkbox = $RedisCheckbox;                  Label = 'Redis Insite';                         Id = 'XP8K1GHCB0F1R2' },
    @{ Checkbox = $RevoCheckbox;                   Label = 'Revo Uninstaller';                     Id = 'RevoUninstaller.RevoUninstaller' },
    @{ Checkbox = $RiderCheckbox;                  Label = 'Rider';                                Id = 'JetBrains.Rider' },
    @{ Checkbox = $RufusCheckbox;                  Label = 'Rufus';                                Id = 'Rufus.Rufus' },
    @{ Checkbox = $RubyCheckbox;                   Label = 'Ruby';                                 Id = 'RubyInstallerTeam.Ruby.3.2' },
    @{ Checkbox = $RubyMineCheckbox;               Label = 'RubyMine';                             Id = 'JetBrains.RubyMine' },
    @{ Checkbox = $RustupCheckbox;                 Label = 'Rustup';                               Id = 'Rustlang.Rustup' },
    @{ Checkbox = $SamsungMagicianCheckbox;        Label = 'Samsung Magician';                     Id = 'XPDDT99J9GKB5C' },
    @{ Checkbox = $SamsungUpdateCheckbox;          Label = 'Samsung Update';                       Id = '9NQ3HDB99VBF' },
    @{ Checkbox = $SeagateSeaToolsCheckbox;        Label = 'Seagate SeaTools';                     Id = 'Seagate.SeaTools' },
    @{ Checkbox = $ShareXCheckbox;                 Label = 'ShareX';                               Id = 'ShareX.ShareX' },
    @{ Checkbox = $SignalRGBCheckbox;              Label = 'SignalRGB';                            Id = 'WhirlwindFX.SignalRgb' },
    @{ Checkbox = $SimpleWallCheckbox;             Label = 'SimpleWall';                           Id = 'Henry++.simplewall' },
    @{ Checkbox = $SlackCheckbox;                  Label = 'Slack';                                Id = 'SlackTechnologies.Slack' },
    @{ Checkbox = $SoapUICheckbox;                 Label = 'SoapUI';                               Id = 'SmartBear.SoapUI' },
    @{ Checkbox = $SourcetreeCheckbox;             Label = 'Sourcetree';                           Id = 'Atlassian.Sourcetree' },
    @{ Checkbox = $SpeccyCheckbox;                 Label = 'Speccy';                               Id = 'Piriform.Speccy' },
    @{ Checkbox = $SpecialKCheckbox;               Label = 'Special K';                            Id = 'SpecialK.SpecialK' },
    @{ Checkbox = $SpotifyCheckbox;                Label = 'Spotify';                              Id = 'Spotify.Spotify' },
    @{ Checkbox = $SQLiteCheckbox;                 Label = 'SQLite';                               Id = 'SQLite.SQLite' },
    @{ Checkbox = $SteelSeriesGGCheckbox;          Label = 'SteelSeries GG';                       Id = 'SteelSeries.GG' },
    @{ Checkbox = $StrawberryPerlCheckbox;         Label = 'StrawberryPerl';                       Id = 'StrawberryPerl.StrawberryPerl' },
    @{ Checkbox = $StreamlabsCheckbox;             Label = 'Streamlabs';                           Id = 'Streamlabs.Streamlabs' },
    @{ Checkbox = $SublimeTextCheckbox;            Label = 'Sublime Text';                         Id = 'SublimeHQ.SublimeText.4' },
    @{ Checkbox = $SuperF4Checkbox;                Label = 'SuperF4';                              Id = 'StefanSundin.Superf4' },
    @{ Checkbox = $SuperpositionCheckbox;          Label = 'Superposition Benchmark';              Id = 'Unigine.SuperpositionBenchmark' },
    @{ Checkbox = $SurfaceCheckbox;                Label = 'Surface';                              Id = 'Microsoft.SurfaceApp' },
    @{ Checkbox = $SurfsharkCheckbox;              Label = 'Surfshark';                            Id = 'Surfshark.Surfshark' },
    @{ Checkbox = $SwiftCheckbox;                  Label = 'Swift';                                Id = 'Swift.Toolchain' },
    @{ Checkbox = $SysinternalsSuiteCheckbox;      Label = 'Sysinternals Suite';                   Id = 'Microsoft.Sysinternals.Suite' },
    @{ Checkbox = $TeamViewerCheckbox;             Label = 'TeamViewer';                           Id = 'TeamViewer.TeamViewer' },
    @{ Checkbox = $TeamsCheckbox;                  Label = 'Teams';                                Id = 'XP8BT8DW290MPQ' },
    @{ Checkbox = $TelegramCheckbox;               Label = 'Telegram';                             Id = 'Telegram.TelegramDesktop' },
    @{ Checkbox = $ThunderbirdCheckbox;            Label = 'Thunderbird';                          Id = 'Mozilla.Thunderbird' },
    @{ Checkbox = $TodoBackupCheckbox;             Label = 'Todo Backup';                          Id = 'EaseUS.TodoBackup' },
    @{ Checkbox = $TorCheckbox;                    Label = 'Tor Browser';                          Id = 'TorProject.TorBrowser' },
    @{ Checkbox = $TortoiseGitCheckbox;            Label = 'TortoiseGit';                          Id = 'TortoiseGit.TortoiseGit' },
    @{ Checkbox = $TotalAVCheckbox;                Label = 'TotalAV';                              Id = 'XPDNTPM3BG8CV1' },
    @{ Checkbox = $TreeSizeCheckbox;               Label = 'TreeSize Free';                        Id = 'JAMSoftware.TreeSize.Free' },
    @{ Checkbox = $TurtleBeachAudioHubCheckbox;    Label = 'Turtle Beach Audio Hub';               Id = 'TurtleBeach.AudioHub' },
    @{ Checkbox = $UnityCheckbox;                  Label = 'Unity';                                Id = 'Unity.Unity.2022' },
    @{ Checkbox = $VeraCryptCheckbox;              Label = 'VeraCrypt';                            Id = 'IDRIX.VeraCrypt' },
    @{ Checkbox = $VictoriaCheckbox;               Label = 'Victoria';                             Id = 'Victoria.Victoria' },
    @{ Checkbox = $VLCCheckbox;                    Label = 'VLC Player';                           Id = 'VideoLAN.VLC' },
    @{ Checkbox = $VirtualBoxCheckbox;             Label = 'VirtualBox';                           Id = 'Oracle.VirtualBox' },
    @{ Checkbox = $VisualStudioCheckbox;           Label = 'Visual Studio 2022 Community';         Id = 'Microsoft.VisualStudio.2022.Community' },
    @{ Checkbox = $WDKitfoxCheckbox;               Label = 'WD Kitfox';                            Id = 'WesternDigital.Kitfox' },
    @{ Checkbox = $WebrootCheckbox;                Label = 'Webroot SecureAnywhere';               Id = 'Webroot.SecureAnywhere' },
    @{ Checkbox = $WebStormCheckbox;               Label = 'WebStorm';                             Id = 'JetBrains.WebStorm.EAP' },
    @{ Checkbox = $WhatsAppCheckbox;               Label = 'WhatsApp';                             Id = 'WhatsApp.WhatsApp' },
    @{ Checkbox = $WiFiAnalyzerCheckbox;           Label = 'WiFi Analyzer';                        Id = '9NBLGGH33N0N' },
    @{ Checkbox = $WiresharkCheckbox;              Label = 'Wireshark';                            Id = 'WiresharkFoundation.Wireshark' },
    @{ Checkbox = $WinDirStatCheckbox;             Label = 'WinDirStat';                           Id = 'WinDirStat.WinDirStat' },
    @{ Checkbox = $WinRARCheckbox;                 Label = 'WinRAR';                               Id = 'RARLab.WinRAR' },
    @{ Checkbox = $WiseGameBoosterCheckbox;        Label = 'Wise Game Booster';                    Id = 'WiseCleaner.WiseGameBooster' },
    @{ Checkbox = $WizTreeCheckbox;                Label = 'WizTree';                              Id = 'AntibodySoftware.WizTree' },
    @{ Checkbox = $WhoCrashedCheckbox;             Label = 'WhoCrashed';                           Id = 'Resplendence.WhoCrashed' },
    @{ Checkbox = $WhySoSlowCheckbox;              Label = 'WhySoSlow';                            Id = 'Resplendence.WhySoSlow' },
    @{ Checkbox = $ZAPCheckbox;                    Label = 'ZAP';                                  Id = 'Zap.Zap' },
    @{ Checkbox = $ZoomCheckbox;                   Label = 'Zoom';                                 Id = 'Zoom.Zoom' }
)


foreach ($app in $WingetInstalls) {
    $extra = @()
    if ($app.ContainsKey('ExtraArgs') -and $app.ExtraArgs) { $extra = $app.ExtraArgs }

    Invoke-WingetItem -Checkbox $app.Checkbox -Label $app.Label -IdOrName $app.Id -ExtraArgs $extra
}	
	
if($BloatwareCheckbox.Checked) {
	$AppsList = @(
	'ACGMediaPlayer',
	'ActiproSoftwareLLC',
	'AdobeSystemsIncorporated.AdobePhotoshopExpress',
	'Amazon.com.Amazon',
	'AmazonVideo.PrimeVideo',
	'Asphalt8Airborne',
	'AutodeskSketchBook',
	'C27EB4BA.DropboxOEM',
	'CaesarsSlotsFreeCasino',
	'Clipchamp.Clipchamp',
	'COOKINGFEVER',
	'CyberLinkMediaSuiteEssentials',
	'Disney',
	'DisneyMagicKingdoms',
	'Dolby',
	'DrawboardPDF',
	'Duolingo-LearnLanguagesforFree',
	'EclipseManager',
	'Facebook',
	'FarmVille2CountryEscape',
	'fitbit',
	'Flipboard',
	'HiddenCity',
	'HULULLC.HULUPLUS',
	'iHeartRadio',
	'Instagram',
	'king.com.BubbleWitch3Saga',
	'king.com.CandyCrushSaga',
	'king.com.CandyCrushSodaSaga',
	'Kodi',
	'LinkedInforWindows',
	'MarchofEmpires',
	'Microsoft.3DBuilder',
	'Microsoft.549981C3F5F10',
	'Microsoft.BingFinance',
	'Microsoft.BingFoodAndDrink',
	'Microsoft.BingHealthAndFitness',
	'Microsoft.BingNews',
	'Microsoft.BingSearch',
	'Microsoft.BingSports',
	'Microsoft.BingTranslator',
	'Microsoft.BingTravel',
	'Microsoft.BingWeather',
	'Microsoft.Copilot',
	'Microsoft.GamingApp',
	'Microsoft.GetHelp',
	'Microsoft.Getstarted',
	'Microsoft.Messaging',
	'Microsoft.Microsoft3DViewer',
	'Microsoft.MicrosoftJournal',
	'Microsoft.MicrosoftOfficeHub',
	'Microsoft.MicrosoftPowerBIForWindows',
	'Microsoft.MicrosoftSolitaireCollection',
	'Microsoft.MicrosoftStickyNotes',
	'Microsoft.MixedReality.Portal',
	'Microsoft.Music.Preview',
	'Microsoft.NetworkSpeedTest',
	'Microsoft.News',
	'Microsoft.Office.OneNote',
	'Microsoft.Office.Sway',
	'Microsoft.OneConnect',
	'Microsoft.OutlookForWindows',
	'Microsoft.People',
	'Microsoft.PowerAutomateDesktop',
	'Microsoft.Print3D',
	'Microsoft.RemoteDesktop',
	'Microsoft.ScreenSketch',
	'Microsoft.SkypeApp',
	'Microsoft.Todos',
	'Microsoft.Whiteboard',
	'Microsoft.Windows.DevHome',
	'Microsoft.WindowsAlarms',
	'Microsoft.WindowsCalculator',
	'Microsoft.WindowsCamera',
	'Microsoft.windowscommunicationsapps',
	'Microsoft.WindowsFeedbackHub',
	'Microsoft.WindowsMaps',
	'Microsoft.WindowsPhone',
	'Microsoft.WindowsSoundRecorder',
	'Microsoft.Xbox.TCUI',
	'Microsoft.XboxApp',
	'Microsoft.XboxGameOverlay',
	'Microsoft.XboxGamingOverlay',
	'Microsoft.XboxIdentityProvider',
	'Microsoft.XboxSpeechToTextOverlay',
	'Microsoft.YourPhone',
	'Microsoft.ZuneMusic',
	'Microsoft.ZuneVideo',
	'MicrosoftCorporationII.MicrosoftFamily',
	'MicrosoftCorporationII.QuickAssist',
	'MicrosoftTeams',
	'MicrosoftWindows.CrossDevice',
	'MixedRealityLearning',
	'Movies & TV',
	'MSTeams',
	'Netflix',
	'NYTCrossword',
	'OneCalendar',
	'PandoraMediaInc',
	'PhototasticCollage',
	'PicsArt-PhotoStudio',
	'Plex',
	'PolarrPhotoEditorAcademicEdition',
	'Royal Revolt',
	'Shazam',
	'Sidia.LiveWallpaper',
	'SlingTV',
	'Speed Test',
	'Spotify',
	'TikTok',
	'TuneInRadio',
	'Twitter',
	'Viber',
	'WhatsApp',
	'WinZipUniversal',
	'Wunderlist',
	'XING'
)

# Cache provisioned packages once
$provPkgs = Get-AppxProvisionedPackage -Online

Write-Host "Removing bloatware" -ForegroundColor Cyan

foreach ($App in $AppsList) {
    # Installed (per-user) removal
    $installed = Get-AppxPackage -Name $App -AllUsers -ErrorAction SilentlyContinue
    if ($installed) {
        foreach ($pkg in $installed) {
            Write-Verbose "Removing installed: $($pkg.PackageFullName)"
            Remove-AppxPackage -Package $pkg.PackageFullName -ErrorAction SilentlyContinue 
        }
    } else {
        Write-Verbose "Not installed: $App"
    }

    # Provisioned (new-user) removal
    $prov = $provPkgs | Where-Object { $_.DisplayName -eq $App }
    if ($prov) {
        Write-Verbose "Removing provisioned: $($prov.PackageName)"
        Remove-AppxProvisionedPackage -Online -PackageName $prov.PackageName -ErrorAction SilentlyContinue 
    } else {
        Write-Verbose "No provisioned package found for: $App"
    }
}

Write-Host "[DONE] Removing bloatware completed`n" -ForegroundColor Green
}

# Shortcuts
$WebShortcuts = @(
    @{ Checkbox = $FurMarkCheckbox;         Name = 'FurMark';      Url = 'https://geeks3d.com/dl/show/728' },
    @{ Checkbox = $LaunchBoxCheckbox;       Name = 'LaunchBox';    Url = 'https://www.launchbox-app.com/download' },
    @{ Checkbox = $PCSX2Checkbox;           Name = 'PCSX2';        Url = 'http://pcsx2.net' },
    @{ Checkbox = $TModLoaderCheckbox;      Name = 'TModLoader';   Url = 'https://store.steampowered.com/app/1281930/tModLoader/' },
    @{ Checkbox = $RandomizersCheckbox;     Name = 'Randomizers';  Url = 'https://www.debigare.com/randomizers/' },
    @{ Checkbox = $3DMarkCheckbox;          Name = '3DMark';       Url = 'https://store.steampowered.com/app/223850/3DMark/' },
    @{ Checkbox = $PCMarkCheckbox;          Name = 'PCMark 10';    Url = 'https://store.steampowered.com/app/524390/PCMark_10/' },
    @{ Checkbox = $CodecksCheckbox;         Name = 'Codecks';      Url = 'https://www.codecks.io' },
    @{ Checkbox = $HacknPlanCheckbox;       Name = 'HacknPlan';    Url = 'https://hacknplan.com' },
    @{ Checkbox = $AmazonShortcutCheckbox;  Name = 'Amazon';       Url = 'https://amazon.com' },
    @{ Checkbox = $AOLShortcutCheckbox;     Name = 'AOL';          Url = 'https://aol.com' },
    @{ Checkbox = $AOLMailShortcutCheckbox; Name = 'AOL Mail';     Url = 'https://mail.aol.com' },
    @{ Checkbox = $BestBuyShortcutCheckbox; Name = 'Best Buy';     Url = 'https://bestbuy.com' },
    @{ Checkbox = $FacebookShortcutCheckbox;Name = 'Facebook';    Url = 'https://www.facebook.com' },
    @{ Checkbox = $GmailShortcutCheckbox;   Name = 'Gmail';       Url = 'https://www.gmail.com' },
    @{ Checkbox = $GoogleShortcutCheckbox;  Name = 'Google';      Url = 'https://www.google.com' },
    @{ Checkbox = $RedditShortcutCheckbox;  Name = 'Reddit';      Url = 'https://www.reddit.com' },
    @{ Checkbox = $YahooShortcutCheckbox;   Name = 'Yahoo';       Url = 'https://www.yahoo.com' },
    @{ Checkbox = $YahooMailShortcutCheckbox;Name='Yahoo Mail';   Url = 'https://mail.yahoo.com' },
    @{ Checkbox = $YouTubeShortcutCheckbox; Name = 'YouTube';     Url = 'https://www.youtube.com' },
    @{ Checkbox = $XShortcutCheckbox;       Name = 'X';           Url = 'https://www.x.com' },
    @{ Checkbox = $GrokCheckbox;            Name = 'Grok';        Url = 'https://grok.com' }
)

foreach ($s in $WebShortcuts) {
    if ($s.Checkbox -and $s.Checkbox.Checked) {
        Write-Host "$($s.Name) shortcut" -ForegroundColor Cyan
        try {
            New-WebShortcut -Name $s.Name -Url $s.Url `
                -Shell $shell -DesktopPath $desktopPath -IconPath $edgeExePath
            Write-Host "[DONE] $($s.Name) shortcut completed`n" -ForegroundColor Green
        } catch {
            Write-Host "[ERROR] $($s.Name) shortcut failed: $($_.Exception.Message)`n" -ForegroundColor Red
        }
    }
}


if($OfficeShortcutsCheckbox.Checked) {  
	try {
    		write-Host "Create Office shortcuts" -ForegroundColor Cyan 
    		Copy-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Word.lnk" -Destination "C:\Users\Public\Desktop" -Force -ErrorAction Stop
    		Copy-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Excel.lnk" -Destination "C:\Users\Public\Desktop" -Force -ErrorAction Stop
    		Copy-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\PowerPoint.lnk" -Destination "C:\Users\Public\Desktop" -Force -ErrorAction Stop
    		write-Host "[DONE] Create Office shortcuts completed"`n -ForegroundColor Green 
		}
	catch {
    		write-Host "An error occurred: $_" -ForegroundColor Red
		}
	}
	
if ($GSSupportCheckbox.Checked) {
    Write-Host "Downloading Geek Squad Support" -ForegroundColor Cyan
    $url  = "https://raw.githubusercontent.com/MeldingSoftware/Apps/main/Geek%20Squad%20Support.exe"
    $dest = Join-Path $desktopPath "Geek Squad Support.exe"
    try {
        Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -ErrorAction Stop
        Write-Host "[DONE] Geek Squad Support completed`n" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Download failed: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

# Windows Updates	
if ($WindowsUpdatesCheckbox.Checked) {
    Write-Host "Windows Updates" -ForegroundColor Cyan 
    # Enable "Get the latest updates as soon as they're available" if registry key exists
    $uxSettingsPath = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"
    if (Test-Path $uxSettingsPath) {
        try {
            Set-ItemProperty -Path $uxSettingsPath -Name "IsContinuousInnovationOptedIn" -Type DWord -Value 1 -ErrorAction Stop
            Write-Host "Enabled ""Get the latest updates as soon as they're available"""
        } catch {
            Write-Host "Failed to enable latest updates toggle: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "Latest updates toggle not found (likely not supported on this system)" -ForegroundColor Yellow
    }
	
    try {
        Install-PackageProvider -Name NuGet -Force
        Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
        Install-Module -Name PSWindowsUpdate -Force
        Import-Module PSWindowsUpdate
		Write-Host "Installing Windows Updates..." -ForegroundColor Yellow 
        Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade'
        Write-Host "[DONE] Windows Updates completed`n" -ForegroundColor Green 
    } catch {
        Write-Host "Windows Update process failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

if ($CleanupCheckbox.Checked) {
    Write-Host "Cleanup Tasks" -ForegroundColor Cyan

    # Disable Start Menu Recommendations (Recent Items)
    try {
        $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        Set-ItemProperty -Path $regPath -Name Start_TrackDocs -Value 0 -ErrorAction Stop
        Write-Host "Start Menu Recommendations disabled"
    } catch {
        Write-Warning "Failed to disable Start Menu Recommendations: $_"
    }

    # Clear Recent Files (Jump Lists + Quick Access)
    try {
        $recentPaths = @(
            "$env:APPDATA\Microsoft\Windows\Recent",
            "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations",
            "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations"
        )
        foreach ($path in $recentPaths) {
            Remove-Item "$path\*" -Force -Recurse -ErrorAction SilentlyContinue
        }

        # Clear Explorer MRU (Extra improvement)
        try {
            (New-Object -ComObject Shell.Application).NameSpace(0).Self.InvokeVerb("Clear Recent Items")
            Write-Host "Explorer Recent Items history cleared"
        } catch {
            Write-Warning "Failed to clear Explorer Recent Items via COM: $_"
        }

        Write-Host "Recent Files cleared"
    } catch {
        Write-Warning "Error clearing Recent items: $_"
    }

    # Clear Temp Files
    try {
        $tempPath = $env:TEMP
        Remove-Item "$tempPath\*" -Force -Recurse -ErrorAction SilentlyContinue
        Write-Host "Temp Files cleared"
    } catch {
        Write-Warning "Error clearing Temp files: $_"
    }

    # Empty Recycle Bin
    try {
        Clear-RecycleBin -Force -ErrorAction SilentlyContinue
        Write-Host "Recycle Bin emptied"
    } catch {
        Write-Warning "Unable to clear Recycle Bin: $_"
    }

    # Restart Explorer to apply Start Menu changes
    try {
        Stop-Process -Name explorer -Force
    } catch {
        Write-Warning "Explorer restart failed: $_"
    }

    Write-Host "[DONE] Cleanup tasks completed.`n" -ForegroundColor Green
}

# Re-Enable Sleep Settings
} finally { 
  powercfg -setactive $prevGuid
}

if ($SleepCheckbox.Checked) {
    Write-Host "Disable turning off display and sleep" -ForegroundColor Cyan

    try {
        # Get the active power scheme GUID
        $activeScheme = (powercfg /getactivescheme) -match 'GUID:\s+([a-fA-F0-9\-]+)' | Out-Null
        $guid = $matches[1]

        # Set Display Timeout to Never (0) for AC power
        powercfg /setacvalueindex $guid SUB_VIDEO VIDEOIDLE 0

        # Set Display Timeout to Never (0) for DC power (laptops)
        powercfg /setdcvalueindex $guid SUB_VIDEO VIDEOIDLE 0

        # Set Sleep Timeout to Never (0) for AC power
        powercfg /setacvalueindex $guid SUB_SLEEP STANDBYIDLE 0

        # Set Sleep Timeout to Never (0) for DC power (laptops)
        powercfg /setdcvalueindex $guid SUB_SLEEP STANDBYIDLE 0

        # Apply the updated power plan
        powercfg /setactive $guid

        Write-Host "[DONE] Disable display turn-off and sleep completed`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to apply sleep/display settings: $($_.Exception.Message)" -ForegroundColor Red
    }
}

if ($RestorePointCheckbox.Checked) {
    Write-Host "Enable System Restore and Creating Restore Point" -ForegroundColor Cyan
    try {
        Enable-ComputerRestore -Drive "C:\" -ErrorAction Stop
        Checkpoint-Computer -Description "Initial Setup Restore Point" -RestorePointType "MODIFY_SETTINGS"
        Write-Host "[DONE] Enable System Restore and Creating Restore Point completed`n"
    } catch {
        Write-Host "Failed to enable System Restore or create restore point: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

if ($AutoRestartCheckbox.Checked) {
	Shutdown /r /t 0
}

}

#---------------------------------------------------------------------------------------------
# Add Clicks
$RUNButton.Add_Click({ Execute })

$searchButton.Add_Click({ Search })

$searchInstalledButton.Add_Click({ Installed })

$installButton.Add_Click({ Install })

$listInstalledButton.Add_Click({ ListInstalled })

$uninstallButton.Add_Click({ Uninstall })

#---------------------------------------------------------------------------------------------
# This Displays The Form
[void] $Form.ShowDialog()