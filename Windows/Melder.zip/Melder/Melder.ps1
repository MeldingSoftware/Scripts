# Add The Required C#, .Net, Namespace, And Classes

Add-Type -AssemblyName System.Windows.Forms

#---------------------------------------------------------------------------------------------
# Initiate A Form Object

$Form = New-Object System.Windows.Forms.Form
$Form.AutoScroll = $True 
$Form.Text = "Melder"
$Form.Size = New-Object System.Drawing.Size(1200,650)
$Form.StartPosition = "CenterScreen"

# Fonts
$TabFont = New-Object System.Drawing.Font("Arial",13,[System.Drawing.Fontstyle]::Bold)
$HeaderFont = New-Object System.Drawing.Font("Times New Roman",13,[System.Drawing.Fontstyle]::Regular)
$BodyFont = New-Object System.Drawing.Font("Times New Roman",11,[System.Drawing.Fontstyle]::Regular)
$RunFont = New-Object System.Drawing.Font("Arial",17,[System.Drawing.Fontstyle]::Bold)
$ButtonFont = New-Object System.Drawing.Font("Arial",11,[System.Drawing.Fontstyle]::Bold)
$ListBoxFont = New-Object System.Drawing.Font("Lucida Console",10.5,[System.Drawing.Fontstyle]::Regular)

$TabControl = New-Object System.Windows.Forms.TabControl
$TabControl.Dock = [System.Windows.Forms.DockStyle]::Fill
$TabControl.Font = $TabFont
$Form.Controls.Add($TabControl)

#---------------------------------------------------------------------------------------------
# Functions

# DLL's for show, hide, and focus console
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);

[DllImport("user32.dll")]
public static extern bool SetForegroundWindow(IntPtr hWnd);
'

function Show-Console
{
    $consolePtr = [Console.Window]::GetConsoleWindow()

    # Hide = 0,
    # ShowNormal = 1,
    # ShowMinimized = 2,
    # ShowMaximized = 3,
    # Maximize = 3,
    # ShowNormalNoActivate = 4,
    # Show = 5,
    # Minimize = 6,
    # ShowMinNoActivate = 7,
    # ShowNoActivate = 8,
    # Restore = 9,
    # ShowDefault = 10,
    # ForceMinimized = 11

    [Console.Window]::ShowWindow($consolePtr, 3)              # Show/maximize console
    [Console.Window]::SetForegroundWindow($consolePtr) | Out-Null  # Ensure focus
}

function Hide-Console
{
    $consolePtr = [Console.Window]::GetConsoleWindow()
    #0 hide
    [Console.Window]::ShowWindow($consolePtr, 0)
}

function Focus-Console {
    $consolePtr = [Console.Window]::GetConsoleWindow()
    if ($consolePtr -ne [IntPtr]::Zero) {
        [Console.Window]::SetForegroundWindow($consolePtr) | Out-Null
    }
}

#Hide console when form is shown
$Form.Add_Shown({
	$Form.Activate()
	Hide-Console | Out-Null
})

function FindDependenciesFolder {
    param (
        [string]$rootPath
    )

    $DependenciesFolder = Get-ChildItem -Path $rootPath -Recurse -Directory -Filter "Dependencies" -ErrorAction SilentlyContinue

    if ($DependenciesFolder) {
        return $DependenciesFolder.FullName
    } 
	else {
        return $null
    }
}

function Search {

# Search for the specified app and display the results in a list box
    $searchButton.Text = "Loading"
    $searchText = $searchBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a search term", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        $searchButton.Text = "Search"
        return
    }
    try {
        $results = winget search $searchText | Select-Object -Skip 2
        if ($results) {
            $listBox.Items.Clear()
			foreach ($result in $results) {
				$listBox.Items.Add($result)
			}
        } else {
            [System.Windows.Forms.MessageBox]::Show("No results found for '$($searchText)'", "No Results", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    } catch {
        Write-Host "Error: $_"
        [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
    $searchButton.Text = "Search"

}

function Installed {

 # Search for an installed app and display the results in a list box
    $searchInstalledButton.Text = "Loading"
    $searchText = $searchBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a search term", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        $searchInstalledButton.Text = "Search Installed"
        return
    }
    try {
        $results = winget list $searchText | Select-Object -Skip 2
        if ($results) {
            $listBox.Items.Clear()
            foreach ($result in $results) {
				$listBox.Items.Add($result)
			}
        } else {
            [System.Windows.Forms.MessageBox]::Show("No results found for '$($searchText)'", "No Results", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    } catch {
        Write-Host "Error: $_"
        [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
    $searchInstalledButton.Text = "Search Installed"

}

function ListInstalled {
    # List all installed apps and return the results
    $listInstalledButton.Text = "Loading"
    $searchText = $searchBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($searchText)) {
        $searchText = ""
    }
    try {
        $results = winget list $searchText | Select-Object -Skip 2
        if ($results) {
            $listBox.Items.Clear()
            foreach ($result in $results) {
                $listBox.Items.Add($result)
            }
        } else {
            [System.Windows.Forms.MessageBox]::Show("No results found for '$($searchText)'", "No Results", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    } catch {
        Write-Host "Error: $_"
        [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
    $listInstalledButton.Text = "List Installed"
}

function Install {

# Install the selected app
    $selected = $listBox.SelectedItem
    if ($selected) {
        $installButton.Text = "Loading"
        try {
			$packageName = ($selected -split '\s+', 3)[1]
            winget install $packageName --accept-source-agreements --accept-package-agreements
			 
        } catch {
            Write-Host "Error: $_"
            [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
        $installButton.Text = "Install"
    }

}

function Uninstall {
    # Uninstall the selected installed app
    $selected = $listBox.SelectedItem
    if ($selected) {
        $uninstallButton.Text = "Loading"
        try {
            # Split the selected item to extract the package ID
            $packageName = ($selected -split '\s+', 3)[1]
            winget uninstall $packageName 
        } catch {
            Write-Host "Error: $_"
            [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
        $uninstallButton.Text = "Uninstall"
    }
}

function Get-GamesDrive {
    param (
        [string[]]$EligibleDriveLetters
    )

    # If already set, reuse it
    if ($Global:GamesDrive) {
        return $Global:GamesDrive
    }

    # If only C: exists, pick it automatically without asking
    if ($EligibleDriveLetters.Count -eq 1 -and $EligibleDriveLetters -contains 'C') {
        $Global:GamesDrive = 'C'
        return $Global:GamesDrive
    }

    # Otherwise, prompt the user once
    Write-Host "Available internal hard drives:"
    $EligibleDriveLetters | ForEach-Object { Write-Host "${_}:" }

    while ($true) {
        Focus-Console  # make sure console has focus before asking
        $selectedDrive = Read-Host "Enter the drive letter where you want to install games (e.g., D)"
        $selectedDrive = $selectedDrive.ToUpper()

        if ($EligibleDriveLetters -notcontains $selectedDrive) {
            Write-Host "The drive letter '$selectedDrive' is not eligible. Please enter a valid drive letter." -ForegroundColor Red
        }
        else {
            $Global:GamesDrive = $selectedDrive
            return $Global:GamesDrive
        }
    }
}

function Install-Game {
    param (
        [string]$GameName,
        [string]$WingetId,
        [string]$SubFolder
    )

    Write-Host "Installing $GameName" -ForegroundColor Cyan
    $eligibleDriveLetters = (Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }).DeviceID | ForEach-Object { $_.TrimEnd(':') }

    # Default success flag
    $installationSuccess = $false

    # If only C: exists, force install there
    if ($eligibleDriveLetters.Count -eq 1 -and $eligibleDriveLetters -contains 'C') {
        winget install $WingetId --accept-source-agreements --accept-package-agreements
        Write-Host "[DONE] Installing $GameName completed`n" -ForegroundColor Green
        $installationSuccess = $true
    }
    else {
        $gamesDrive = Get-GamesDrive -EligibleDriveLetters $eligibleDriveLetters
        $installFolder = "${gamesDrive}:\$SubFolder"

        winget install $WingetId --location "$installFolder" --accept-source-agreements --accept-package-agreements
        Write-Host "[DONE] Installing $GameName completed`n" -ForegroundColor Green
        $installationSuccess = $true
    }

    if (!$installationSuccess) {
        Write-Host "Installation of $GameName canceled" -ForegroundColor Red
    }
}

#---------------------------------------------------------------------------------------------
# Extensions 

$AllExtensions = @{
    "1Password"      = @{ Edge="dppgmdbiimibapkepcbdbmkaabgiofem;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="aeblfdkhhhdcdjpifhhbdiojplfjncoa;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/1password-x-password-manager/latest.xpi" }
    "Bitwarden"      = @{ Edge="jbkfoedolllekgbhcbcoahefnbanhhlh;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="nngceckbapebfimnlniiiahkandclblb;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/bitwarden-password-manager/latest.xpi" }
    "Dark Reader"    = @{ Edge="ifoakfbpdcdoeenechcleahebpibofpc;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="eimadpbcbfnmbkopoojfekhnkhdbieeh;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi" }
    "Grammarly"      = @{ Edge="cnlefmmeadmemmdciolhbnfeacpdfbkd;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="kbfnbcaeplbcioakkpcpgfkobkghlhen;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/grammarly-1/latest.xpi" }
    "LastPass"       = @{ Edge="bbcinlkgjjkejfdpemiealijmmooekmp;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="hdokiejnpimakedhajhdlcegeplioahd;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/lastpass-password-manager/latest.xpi" }
    "Momentum"       = @{ Edge="jdoanlopeanabgejgmdncljhkdplcfed;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="laookkfknpbbblfpciffpaejjkokdgca;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/momentumdash/latest.xpi" }
    "Privacy Badger" = @{ Edge="mkejgcgkdlddbggjhhflekkondicpnop;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="pkehgijcmpdhfbdbbnkijodmdjhbjlgp;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/privacy-badger17/latest.xpi" }
    "SponsorBlock"   = @{ Edge="mbmgnelfcpoecdepckhlhegpcehmpmji;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="mnjggcdmjocbbbhaepdhchncahnbgone;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/sponsorblock/latest.xpi" }
    "Todoist"        = @{ Edge="fgcjgjggdkjmafpnbcplcdkbfogcbonk;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="jldhpllghnbhlbpcmnajkpdmadaolakh;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/todoist-for-firefox/latest.xpi" }
    "uBlock Origin"  = @{ Edge="odfafepnkmbhccpbejgmiehpchacaeak;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="cjpalhdlnbpafiamejdnhcphjbkeiagm;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi" }
    "ViolentMonkey"  = @{ Edge="eeagobfjdenkkddmbclomhiblgggliao;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="jinjaccalgkegednnccohejagnlnfdag;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/violentmonkey/latest.xpi" }
    "YouTube Nonstop"= @{ Edge="lgakodbaikpcnfpmanpenlgaghdaifbm;https://edge.microsoft.com/extensionwebstorebase/v1/crx"; Chromium="leocdjkjmjnhlkbinhjjcoimbgokcipa;https://clients2.google.com/service/update2/crx"; Firefox="https://addons.mozilla.org/firefox/downloads/latest/youtube-nonstop/latest.xpi" }
}

function Add-ExtensionRegistry {
    param (
        [string]$RegPath,          # e.g. SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist
        [string]$ExtensionString   # "<extID>;<update_url>"
    )

    $extID = $ExtensionString.Split(';')[0]

    # Ensure key exists
    $full = "HKLM:\$RegPath"
    if (!(Test-Path $full)) {
        New-Item -Path $full -Force | Out-Null
    }

    # Check if already present
    $existing = (reg query "HKLM\$RegPath" 2>$null)
    if ($existing -match [Regex]::Escape($extID)) {
        return $false  # already there
    }

    # Find next numeric slot
    $used = @()
    foreach ($line in $existing) {
        if ($line -match "^\s+(\d+)\s+REG_SZ") { $used += [int]$matches[1] }
    }
    $slot = 1
    while ($used -contains $slot) { $slot++ }

    reg add "HKLM\$RegPath" /v $slot /t REG_SZ /d $ExtensionString /f | Out-Null
    return $true
}

function Install-Extension {
    param([string]$Name)

    $ext = $AllExtensions[$Name]
    if (-not $ext) { return }

    Write-Host "Installing $Name" -ForegroundColor Cyan
    $Added = $false

    # --- Kill browsers first ---
    $browsersToKill = @("msedge", "chrome", "firefox")
    foreach ($b in $browsersToKill) {
        Get-Process $b -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Seconds 2

    # --- Edge ---
    $EdgePath = "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe"
    if ((Test-Path $EdgePath) -and $ext.Edge) {
        if (Add-ExtensionRegistry "SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist" $ext.Edge) {
            Write-Host "  Added in Edge" -ForegroundColor Yellow
            $Added = $true
        } else {
            Write-Host "  Already listed in Edge policy" -ForegroundColor DarkGray
        }
    }

    # --- Chrome ---
    $ChromePath = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
    if ((Test-Path $ChromePath) -and $ext.Chromium) {
        if (Add-ExtensionRegistry "SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist" $ext.Chromium) {
            Write-Host "  Added in Chrome" -ForegroundColor Yellow
            $Added = $true
        } else {
            Write-Host "  Already listed in Chrome policy" -ForegroundColor DarkGray
        }
    }

    # --- Firefox ---
    $FirefoxPath = "$env:ProgramFiles\Mozilla Firefox\firefox.exe"
    if ((Test-Path $FirefoxPath) -and $ext.Firefox) {
        $PolicyDir  = "$env:ProgramFiles\Mozilla Firefox\distribution"
        $PolicyFile = "$PolicyDir\policies.json"

        if (!(Test-Path $PolicyDir)) { New-Item -ItemType Directory -Path $PolicyDir -Force | Out-Null }

        $existingInstallList = @()
        if (Test-Path $PolicyFile) {
            try {
                $raw = Get-Content $PolicyFile -Raw
                $json = $null
                try { $json = $raw | ConvertFrom-Json -ErrorAction Stop } catch {}
                if ($json -and $json.policies -and $json.policies.Extensions -and $json.policies.Extensions.Install) {
                    $existingInstallList = [System.Collections.ArrayList]@($json.policies.Extensions.Install)
                }
            } catch {}
        }

        if ($existingInstallList -contains $ext.Firefox) {
            Write-Host "  Already listed in Firefox policy" -ForegroundColor DarkGray
        } else {
            $newList = @()
            if ($existingInstallList.Count -gt 0) { $newList = $existingInstallList }
            $newList += $ext.Firefox

            $PolicyJson = @{
                policies = @{
                    Extensions = @{
                        Install = $newList
                    }
                }
            } | ConvertTo-Json -Depth 5

            $PolicyJson | Out-File -Encoding ASCII -FilePath $PolicyFile -Force
            Write-Host "  Added in Firefox" -ForegroundColor Yellow
            $Added = $true
        }
    }
}


#---------------------------------------------------------------------------------------------
# Startup

# Hide progress bar
$ProgressPreference = 'SilentlyContinue'

$targetVersion = [Version]"1.27.210.0"
$appinstallerInstalled = Get-AppPackage -Name "Microsoft.DesktopAppInstaller" -ErrorAction SilentlyContinue

# Get the current directory where the script is executed
$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Check if App Installer is missing or outdated
if (-not $appinstallerInstalled -or ([Version]$appinstallerInstalled.Version -lt $targetVersion)) {
    Write-Host "App Installer is missing or outdated" -ForegroundColor Yellow

    # Install dependencies
    Write-Host "Installing required dependencies" -ForegroundColor Cyan
    $DependenciesFolder = FindDependenciesFolder -rootPath $currentDirectory

    if ($DependenciesFolder) {
        $vcLibs = Join-Path -Path $DependenciesFolder -ChildPath "Microsoft.VCLibs.140.00.UWPDesktop.x64.appx"
        if (Test-Path $vcLibs) {
            Add-AppxPackage -Path $vcLibs -ErrorAction SilentlyContinue
        }

        $uiXaml286Path = Join-Path -Path $DependenciesFolder -ChildPath "Microsoft.UI.Xaml.2.8.appx"
        if (Test-Path $uiXaml286Path) {
            Add-AppxPackage -Path $uiXaml286Path -ErrorAction SilentlyContinue
        }

        Write-Host "[DONE] Dependencies installed.`n" -ForegroundColor Green
    }

    # Automatically download and silently install App Installer
    $downloadUrl = "https://github.com/microsoft/winget-cli/releases/download/v1.12.210-preview/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle"
    $bundlePath = Join-Path $env:TEMP "Microsoft.DesktopAppInstaller.msixbundle"

    Write-Host "Downloading App Installer" -ForegroundColor Cyan
    Invoke-WebRequest -Uri $downloadUrl -OutFile $bundlePath -UseBasicParsing
	Write-Host "[DONE] Downloading App Installer complete`n" -ForegroundColor Green
	
    Write-Host "Installing App Installer" -ForegroundColor Cyan
    try {
        Add-AppxPackage -Path $bundlePath -ErrorAction Stop
		Write-Host "[DONE] Installing App Installer complete`n" -ForegroundColor Green
    } catch {
        Write-Warning "Failed to install App Installer: $_"
    }
}

#---------------------------------------------------------------------------------------------
# Build The Form Components And Add To Form

# Tab 1
$Tab1 = New-Object System.Windows.Forms.TabPage
$Tab1.Text = "General"
$Tab1.Font = $TabFont
$Tab1.Autoscroll  = $True
$TabControl.Controls.Add($Tab1)

$AudioLabel = New-Object System.Windows.Forms.Label
$AudioLabel.Location = New-Object System.Drawing.Size(10,10)
$AudioLabel.Text = "Audio"
$AudioLabel.Width = 180
$AudioLabel.Height = 20
$AudioLabel.Font = $HeaderFont
$Tab1.Controls.Add($AudioLabel)

$AudacityLogo = New-Object System.Windows.Forms.PictureBox
$AudacityLogo.Width = 18
$AudacityLogo.Height = 18
$AudacityLogo.Location = New-Object System.Drawing.Size(30,30)
$AudacityLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Audacity.png"
$AudacityLogo.ImageLocation = $AudacityLogoFile
$AudacityLogo.BorderStyle = 0
$AudacityLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AudacityLogo)

$AudacityCheckbox = New-Object System.Windows.Forms.Checkbox 
$AudacityCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$AudacityCheckbox.Text = "       Audacity"
$AudacityCheckbox.Width = 180
$AudacityCheckbox.Height = 20
$AudacityCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AudacityCheckbox)

$FLStudioLogo = New-Object System.Windows.Forms.PictureBox
$FLStudioLogo.Width = 18
$FLStudioLogo.Height = 18
$FLStudioLogo.Location = New-Object System.Drawing.Size(30,50)
$FLStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\FLStudio.png"
$FLStudioLogo.ImageLocation = $FLStudioLogoFile
$FLStudioLogo.BorderStyle = 0
$FLStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($FLStudioLogo)

$FLStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$FLStudioCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$FLStudioCheckbox.Text = "       FL Studio"
$FLStudioCheckbox.Width = 180
$FLStudioCheckbox.Height = 20
$FLStudioCheckbox.Font = $BodyFont
$Tab1.Controls.Add($FLStudioCheckbox)

$BrowsersLabel = New-Object System.Windows.Forms.Label
$BrowsersLabel.Location = New-Object System.Drawing.Size(10,90)
$BrowsersLabel.Text = "Browsers"
$BrowsersLabel.Width = 180
$BrowsersLabel.Height = 20
$BrowsersLabel.Font = $HeaderFont
$Tab1.Controls.Add($BrowsersLabel)

$BraveLogo = New-Object System.Windows.Forms.PictureBox
$BraveLogo.Width = 18
$BraveLogo.Height = 18
$BraveLogo.Location = New-Object System.Drawing.Size(30,110)
$BraveLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Brave.png"
$BraveLogo.ImageLocation = $BraveLogoFile
$BraveLogo.BorderStyle = 0
$BraveLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($BraveLogo)

$BraveCheckbox = New-Object System.Windows.Forms.Checkbox 
$BraveCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$BraveCheckbox.Text = "       Brave"
$BraveCheckbox.Width = 180
$BraveCheckbox.Height = 20
$BraveCheckbox.Font = $BodyFont
$Tab1.Controls.Add($BraveCheckbox)

$ChromeLogo = New-Object System.Windows.Forms.PictureBox
$ChromeLogo.Width = 18
$ChromeLogo.Height = 18
$ChromeLogo.Location = New-Object System.Drawing.Size(30,130)
$ChromeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Chrome.png"
$ChromeLogo.ImageLocation = $ChromeLogoFile
$ChromeLogo.BorderStyle = 0
$ChromeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ChromeLogo)

$ChromeCheckbox = New-Object System.Windows.Forms.Checkbox 
$ChromeCheckbox.Location = New-Object System.Drawing.Size(10,130) 
$ChromeCheckbox.Text = "       Chrome"
$ChromeCheckbox.Width = 180
$ChromeCheckbox.Height = 20
$ChromeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ChromeCheckbox)

$DuckDuckGoLogo = New-Object System.Windows.Forms.PictureBox
$DuckDuckGoLogo.Width = 18
$DuckDuckGoLogo.Height = 18
$DuckDuckGoLogo.Location = New-Object System.Drawing.Size(30,150)
$DuckDuckGoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\DuckDuckGo.png"
$DuckDuckGoLogo.ImageLocation = $DuckDuckGoLogoFile
$DuckDuckGoLogo.BorderStyle = 0
$DuckDuckGoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DuckDuckGoLogo)

$DuckDuckGoCheckbox = New-Object System.Windows.Forms.Checkbox 
$DuckDuckGoCheckbox.Location = New-Object System.Drawing.Size(10,150) 
$DuckDuckGoCheckbox.Text = "       DuckDuckGo"
$DuckDuckGoCheckbox.Width = 180
$DuckDuckGoCheckbox.Height = 20
$DuckDuckGoCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DuckDuckGoCheckbox)

$FirefoxLogo = New-Object System.Windows.Forms.PictureBox
$FirefoxLogo.Width = 18
$FirefoxLogo.Height = 18
$FirefoxLogo.Location = New-Object System.Drawing.Size(30,170)
$FirefoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Firefox.png"
$FirefoxLogo.ImageLocation = $FirefoxLogoFile
$FirefoxLogo.BorderStyle = 0
$FirefoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($FirefoxLogo)

$FirefoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$FirefoxCheckbox.Location = New-Object System.Drawing.Size(10,170) 
$FirefoxCheckbox.Text = "       Firefox"
$FirefoxCheckbox.Width = 180
$FirefoxCheckbox.Height = 20
$FirefoxCheckbox.Font = $BodyFont
$Tab1.Controls.Add($FirefoxCheckbox)

$OperaLogo = New-Object System.Windows.Forms.PictureBox
$OperaLogo.Width = 18
$OperaLogo.Height = 18
$OperaLogo.Location = New-Object System.Drawing.Size(30,190)
$OperaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Opera.png"
$OperaLogo.ImageLocation = $OperaLogoFile
$OperaLogo.BorderStyle = 0
$OperaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OperaLogo)

$OperaCheckbox = New-Object System.Windows.Forms.Checkbox 
$OperaCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$OperaCheckbox.Text = "       Opera"
$OperaCheckbox.Width = 180
$OperaCheckbox.Height = 20
$OperaCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OperaCheckbox)

$OperaGXLogo = New-Object System.Windows.Forms.PictureBox
$OperaGXLogo.Width = 18
$OperaGXLogo.Height = 18
$OperaGXLogo.Location = New-Object System.Drawing.Size(30,210)
$OperaGXLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\OperaGX.png"
$OperaGXLogo.ImageLocation = $OperaGXLogoFile
$OperaGXLogo.BorderStyle = 0
$OperaGXLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OperaGXLogo)

$OperaGXCheckbox = New-Object System.Windows.Forms.Checkbox 
$OperaGXCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$OperaGXCheckbox.Text = "       Opera GX"
$OperaGXCheckbox.Width = 180
$OperaGXCheckbox.Height = 20
$OperaGXCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OperaGXCheckbox)

$TorLogo = New-Object System.Windows.Forms.PictureBox
$TorLogo.Width = 18
$TorLogo.Height = 18
$TorLogo.Location = New-Object System.Drawing.Size(30,230)
$TorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Tor.png"
$TorLogo.ImageLocation = $TorLogoFile
$TorLogo.BorderStyle = 0
$TorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TorLogo)

$TorCheckbox = New-Object System.Windows.Forms.Checkbox 
$TorCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$TorCheckbox.Text = "       Tor"
$TorCheckbox.Width = 180
$TorCheckbox.Height = 20
$TorCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TorCheckbox)

$CompressionLabel = New-Object System.Windows.Forms.Label
$CompressionLabel.Location = New-Object System.Drawing.Size(10,270)
$CompressionLabel.Text = "Compression"
$CompressionLabel.Width = 180
$CompressionLabel.Height = 20
$CompressionLabel.Font = $HeaderFont
$Tab1.Controls.Add($CompressionLabel)

$7ZipLogo = New-Object System.Windows.Forms.PictureBox
$7ZipLogo.Width = 18
$7ZipLogo.Height = 18
$7ZipLogo.Location = New-Object System.Drawing.Size(30,290)
$7ZipLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\7Zip.png"
$7ZipLogo.ImageLocation = $7ZipLogoFile
$7ZipLogo.BorderStyle = 0
$7ZipLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($7ZipLogo)

$7ZipCheckbox = New-Object System.Windows.Forms.Checkbox 
$7ZipCheckbox.Location = New-Object System.Drawing.Size(10,290) 
$7ZipCheckbox.Text = "       7-Zip"
$7ZipCheckbox.Width = 180
$7ZipCheckbox.Height = 20
$7ZipCheckbox.Font = $BodyFont
$Tab1.Controls.Add($7ZipCheckbox)

$WinRARLogo = New-Object System.Windows.Forms.PictureBox
$WinRARLogo.Width = 18
$WinRARLogo.Height = 18
$WinRARLogo.Location = New-Object System.Drawing.Size(30,310)
$WinRARLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\WinRAR.png"
$WinRARLogo.ImageLocation = $WinRARLogoFile
$WinRARLogo.BorderStyle = 0
$WinRARLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($WinRARLogo)

$WinRARCheckbox = New-Object System.Windows.Forms.Checkbox 
$WinRARCheckbox.Location = New-Object System.Drawing.Size(10,310) 
$WinRARCheckbox.Text = "       WinRAR"
$WinRARCheckbox.Width = 180
$WinRARCheckbox.Height = 20
$WinRARCheckbox.Font = $BodyFont
$Tab1.Controls.Add($WinRARCheckbox)

$DocumentsLabel = New-Object System.Windows.Forms.Label
$DocumentsLabel.Location = New-Object System.Drawing.Size(200,10)
$DocumentsLabel.Text = "Documents"
$DocumentsLabel.Width = 180
$DocumentsLabel.Height = 20
$DocumentsLabel.Font = $HeaderFont
$Tab1.Controls.Add($DocumentsLabel)

$AcrobatReaderLogo = New-Object System.Windows.Forms.PictureBox
$AcrobatReaderLogo.Width = 18
$AcrobatReaderLogo.Height = 18
$AcrobatReaderLogo.Location = New-Object System.Drawing.Size(220,30)
$AcrobatReaderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\AcrobatReader.png"
$AcrobatReaderLogo.ImageLocation = $AcrobatReaderLogoFile
$AcrobatReaderLogo.BorderStyle = 0
$AcrobatReaderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AcrobatReaderLogo)

$AcrobatReaderCheckbox = New-Object System.Windows.Forms.Checkbox 
$AcrobatReaderCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$AcrobatReaderCheckbox.Text = "       Acrobat Reader"
$AcrobatReaderCheckbox.Width = 180
$AcrobatReaderCheckbox.Height = 20
$AcrobatReaderCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AcrobatReaderCheckbox)

$EvernoteLogo = New-Object System.Windows.Forms.PictureBox
$EvernoteLogo.Width = 18
$EvernoteLogo.Height = 18
$EvernoteLogo.Location = New-Object System.Drawing.Size(220,50)
$EvernoteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Evernote.png"
$EvernoteLogo.ImageLocation = $EvernoteLogoFile
$EvernoteLogo.BorderStyle = 0
$EvernoteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($EvernoteLogo)

$EvernoteCheckbox = New-Object System.Windows.Forms.Checkbox 
$EvernoteCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$EvernoteCheckbox.Text = "       Evernote"
$EvernoteCheckbox.Width = 180
$EvernoteCheckbox.Height = 20
$EvernoteCheckbox.Font = $BodyFont
$Tab1.Controls.Add($EvernoteCheckbox)

$GrammarlyAppLogo = New-Object System.Windows.Forms.PictureBox
$GrammarlyAppLogo.Width = 18
$GrammarlyAppLogo.Height = 18
$GrammarlyAppLogo.Location = New-Object System.Drawing.Size(220,70)
$GrammarlyAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Grammarly.png"
$GrammarlyAppLogo.ImageLocation = $GrammarlyAppLogoFile
$GrammarlyAppLogo.BorderStyle = 0
$GrammarlyAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GrammarlyAppLogo)

$GrammarlyAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$GrammarlyAppCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$GrammarlyAppCheckbox.Text = "       Grammarly"
$GrammarlyAppCheckbox.Width = 180
$GrammarlyAppCheckbox.Height = 20
$GrammarlyAppCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GrammarlyAppCheckbox)

$LibreOfficeLogo = New-Object System.Windows.Forms.PictureBox
$LibreOfficeLogo.Width = 18
$LibreOfficeLogo.Height = 18
$LibreOfficeLogo.Location = New-Object System.Drawing.Size(220,90)
$LibreOfficeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\LibreOffice.png"
$LibreOfficeLogo.ImageLocation = $LibreOfficeLogoFile
$LibreOfficeLogo.BorderStyle = 0
$LibreOfficeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($LibreOfficeLogo)

$LibreOfficeCheckbox = New-Object System.Windows.Forms.Checkbox 
$LibreOfficeCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$LibreOfficeCheckbox.Text = "       Libre Office"
$LibreOfficeCheckbox.Width = 180
$LibreOfficeCheckbox.Height = 20
$LibreOfficeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($LibreOfficeCheckbox)

$ObsidianLogo = New-Object System.Windows.Forms.PictureBox
$ObsidianLogo.Width = 18
$ObsidianLogo.Height = 18
$ObsidianLogo.Location = New-Object System.Drawing.Size(220,110)
$ObsidianLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Obsidian.png"
$ObsidianLogo.ImageLocation = $ObsidianLogoFile
$ObsidianLogo.BorderStyle = 0
$ObsidianLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ObsidianLogo)

$ObsidianCheckbox = New-Object System.Windows.Forms.Checkbox 
$ObsidianCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$ObsidianCheckbox.Text = "       Obsidian"
$ObsidianCheckbox.Width = 180
$ObsidianCheckbox.Height = 20
$ObsidianCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ObsidianCheckbox)

$Office365Logo = New-Object System.Windows.Forms.PictureBox
$Office365Logo.Width = 18
$Office365Logo.Height = 18
$Office365Logo.Location = New-Object System.Drawing.Size(220,130)
$Office365LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Office365.png"
$Office365Logo.ImageLocation = $Office365LogoFile
$Office365Logo.BorderStyle = 0
$Office365Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($Office365Logo)

$Office365Checkbox = New-Object System.Windows.Forms.Checkbox 
$Office365Checkbox.Location = New-Object System.Drawing.Size(200,130) 
$Office365Checkbox.Text = "       Office365"
$Office365Checkbox.Width = 180
$Office365Checkbox.Height = 20
$Office365Checkbox.Font = $BodyFont
$Tab1.Controls.Add($Office365Checkbox)

$OpenOfficeLogo = New-Object System.Windows.Forms.PictureBox
$OpenOfficeLogo.Width = 18
$OpenOfficeLogo.Height = 18
$OpenOfficeLogo.Location = New-Object System.Drawing.Size(220,150)
$OpenOfficeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\OpenOffice.png"
$OpenOfficeLogo.ImageLocation = $OpenOfficeLogoFile
$OpenOfficeLogo.BorderStyle = 0
$OpenOfficeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OpenOfficeLogo)

$OpenOfficeCheckbox = New-Object System.Windows.Forms.Checkbox 
$OpenOfficeCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$OpenOfficeCheckbox.Text = "       Open Office"
$OpenOfficeCheckbox.Width = 180
$OpenOfficeCheckbox.Height = 20
$OpenOfficeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OpenOfficeCheckbox)

$DriversLabel = New-Object System.Windows.Forms.Label
$DriversLabel.Location = New-Object System.Drawing.Size(200,190)
$DriversLabel.Text = "Drivers"
$DriversLabel.Width = 180
$DriversLabel.Height = 20
$DriversLabel.Font = $HeaderFont
$Tab1.Controls.Add($DriversLabel)

$AMDSoftwareLogo = New-Object System.Windows.Forms.PictureBox
$AMDSoftwareLogo.Width = 18
$AMDSoftwareLogo.Height = 18
$AMDSoftwareLogo.Location = New-Object System.Drawing.Size(220,210)
$AMDSoftwareLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\AMD.png"
$AMDSoftwareLogo.ImageLocation = $AMDSoftwareLogoFile
$AMDSoftwareLogo.BorderStyle = 0
$AMDSoftwareLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AMDSoftwareLogo)

$AMDSoftwareCheckbox = New-Object System.Windows.Forms.Checkbox 
$AMDSoftwareCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$AMDSoftwareCheckbox.Text = "       AMD Software"
$AMDSoftwareCheckbox.Width = 180
$AMDSoftwareCheckbox.Height = 20
$AMDSoftwareCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AMDSoftwareCheckbox)

$CanonPrintLogo = New-Object System.Windows.Forms.PictureBox
$CanonPrintLogo.Width = 18
$CanonPrintLogo.Height = 18
$CanonPrintLogo.Location = New-Object System.Drawing.Size(220,230)
$CanonPrintLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\CanonPrint.png"
$CanonPrintLogo.ImageLocation = $CanonPrintLogoFile
$CanonPrintLogo.BorderStyle = 0
$CanonPrintLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($CanonPrintLogo)

$CanonPrintCheckbox = New-Object System.Windows.Forms.Checkbox 
$CanonPrintCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$CanonPrintCheckbox.Text = "       Canon Print"
$CanonPrintCheckbox.Width = 180
$CanonPrintCheckbox.Height = 20
$CanonPrintCheckbox.Font = $BodyFont
$Tab1.Controls.Add($CanonPrintCheckbox)

$DellSupportLogo = New-Object System.Windows.Forms.PictureBox
$DellSupportLogo.Width = 18
$DellSupportLogo.Height = 18
$DellSupportLogo.Location = New-Object System.Drawing.Size(220,250)
$DellSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\DellSupport.png"
$DellSupportLogo.ImageLocation = $DellSupportLogoFile
$DellSupportLogo.BorderStyle = 0
$DellSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DellSupportLogo)

$DellSupportCheckbox = New-Object System.Windows.Forms.Checkbox 
$DellSupportCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$DellSupportCheckbox.Text = "       Dell Support"
$DellSupportCheckbox.Width = 180
$DellSupportCheckbox.Height = 20
$DellSupportCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DellSupportCheckbox)

$EpsonConnectLogo = New-Object System.Windows.Forms.PictureBox
$EpsonConnectLogo.Width = 18
$EpsonConnectLogo.Height = 18
$EpsonConnectLogo.Location = New-Object System.Drawing.Size(220,270)
$EpsonConnectLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\EpsonConnect.png"
$EpsonConnectLogo.ImageLocation = $EpsonConnectLogoFile
$EpsonConnectLogo.BorderStyle = 0
$EpsonConnectLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($EpsonConnectLogo)

$EpsonConnectCheckbox = New-Object System.Windows.Forms.Checkbox 
$EpsonConnectCheckbox.Location = New-Object System.Drawing.Size(200,270) 
$EpsonConnectCheckbox.Text = "       Epson Connect"
$EpsonConnectCheckbox.Width = 180
$EpsonConnectCheckbox.Height = 20
$EpsonConnectCheckbox.Font = $BodyFont
$Tab1.Controls.Add($EpsonConnectCheckbox)

$HPSmartLogo = New-Object System.Windows.Forms.PictureBox
$HPSmartLogo.Width = 18
$HPSmartLogo.Height = 18
$HPSmartLogo.Location = New-Object System.Drawing.Size(220,290)
$HPSmartLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\HPSmart.png"
$HPSmartLogo.ImageLocation = $HPSmartLogoFile
$HPSmartLogo.BorderStyle = 0
$HPSmartLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($HPSmartLogo)

$HPSmartCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPSmartCheckbox.Location = New-Object System.Drawing.Size(200,290) 
$HPSmartCheckbox.Text = "       HP Smart"
$HPSmartCheckbox.Width = 180
$HPSmartCheckbox.Height = 20
$HPSmartCheckbox.Font = $BodyFont
$Tab1.Controls.Add($HPSmartCheckbox)

$HPSupportLogo = New-Object System.Windows.Forms.PictureBox
$HPSupportLogo.Width = 18
$HPSupportLogo.Height = 18
$HPSupportLogo.Location = New-Object System.Drawing.Size(220,310)
$HPSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\HPSupport.png"
$HPSupportLogo.ImageLocation = $HPSupportLogoFile
$HPSupportLogo.BorderStyle = 0
$HPSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($HPSupportLogo)

$HPSupportCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPSupportCheckbox.Location = New-Object System.Drawing.Size(200,310) 
$HPSupportCheckbox.Text = "       HP Support"
$HPSupportCheckbox.Width = 180
$HPSupportCheckbox.Height = 20
$HPSupportCheckbox.Font = $BodyFont
$Tab1.Controls.Add($HPSupportCheckbox)

$IntelSupportLogo = New-Object System.Windows.Forms.PictureBox
$IntelSupportLogo.Width = 18
$IntelSupportLogo.Height = 18
$IntelSupportLogo.Location = New-Object System.Drawing.Size(220,330)
$IntelSupportLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\IntelSupport.png"
$IntelSupportLogo.ImageLocation = $IntelSupportLogoFile
$IntelSupportLogo.BorderStyle = 0
$IntelSupportLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($IntelSupportLogo)

$IntelSupportAssistantCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelSupportAssistantCheckbox.Location = New-Object System.Drawing.Size(200,330) 
$IntelSupportAssistantCheckbox.Text = "       Intel Support"
$IntelSupportAssistantCheckbox.Width = 180
$IntelSupportAssistantCheckbox.Height = 20
$IntelSupportAssistantCheckbox.Font = $BodyFont
$Tab1.Controls.Add($IntelSupportAssistantCheckbox)

$NvidiaLogo = New-Object System.Windows.Forms.PictureBox
$NvidiaLogo.Width = 18
$NvidiaLogo.Height = 18
$NvidiaLogo.Location = New-Object System.Drawing.Size(220,350)
$NvidiaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Nvidia.png"
$NvidiaLogo.ImageLocation = $NvidiaLogoFile
$NvidiaLogo.BorderStyle = 0
$NvidiaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($NvidiaLogo)

$NvidiaCheckbox = New-Object System.Windows.Forms.Checkbox 
$NvidiaCheckbox.Location = New-Object System.Drawing.Size(200,350) 
$NvidiaCheckbox.Text = "       Nvidia App"
$NvidiaCheckbox.Width = 180
$NvidiaCheckbox.Height = 20
$NvidiaCheckbox.Font = $BodyFont
$Tab1.Controls.Add($NvidiaCheckbox)

$EducationalLabel = New-Object System.Windows.Forms.Label
$EducationalLabel.Location = New-Object System.Drawing.Size(200,390)
$EducationalLabel.Text = "Educational"
$EducationalLabel.Width = 180
$EducationalLabel.Height = 20
$EducationalLabel.Font = $HeaderFont
$Tab1.Controls.Add($EducationalLabel)

$AnkiLogo = New-Object System.Windows.Forms.PictureBox
$AnkiLogo.Width = 18
$AnkiLogo.Height = 18
$AnkiLogo.Location = New-Object System.Drawing.Size(220,410)
$AnkiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Anki.png"
$AnkiLogo.ImageLocation = $AnkiLogoFile
$AnkiLogo.BorderStyle = 0
$AnkiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AnkiLogo)

$AnkiCheckbox = New-Object System.Windows.Forms.Checkbox 
$AnkiCheckbox.Location = New-Object System.Drawing.Size(200,410) 
$AnkiCheckbox.Text = "       Anki"
$AnkiCheckbox.Width = 180
$AnkiCheckbox.Height = 20
$AnkiCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AnkiCheckbox)

$DuolingoLogo = New-Object System.Windows.Forms.PictureBox
$DuolingoLogo.Width = 18
$DuolingoLogo.Height = 18
$DuolingoLogo.Location = New-Object System.Drawing.Size(220,430)
$DuolingoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Duolingo.png"
$DuolingoLogo.ImageLocation = $DuolingoLogoFile
$DuolingoLogo.BorderStyle = 0
$DuolingoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DuolingoLogo)

$DuolingoCheckbox = New-Object System.Windows.Forms.Checkbox 
$DuolingoCheckbox.Location = New-Object System.Drawing.Size(200,430) 
$DuolingoCheckbox.Text = "       Duolingo"
$DuolingoCheckbox.Width = 180
$DuolingoCheckbox.Height = 20
$DuolingoCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DuolingoCheckbox)

$MendeleyLogo = New-Object System.Windows.Forms.PictureBox
$MendeleyLogo.Width = 18
$MendeleyLogo.Height = 18
$MendeleyLogo.Location = New-Object System.Drawing.Size(220,450)
$MendeleyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Mendeley.png"
$MendeleyLogo.ImageLocation = $MendeleyLogoFile
$MendeleyLogo.BorderStyle = 0
$MendeleyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($MendeleyLogo)

$MendeleyCheckbox = New-Object System.Windows.Forms.Checkbox 
$MendeleyCheckbox.Location = New-Object System.Drawing.Size(200,450) 
$MendeleyCheckbox.Text = "       Mendeley"
$MendeleyCheckbox.Width = 180
$MendeleyCheckbox.Height = 20
$MendeleyCheckbox.Font = $BodyFont
$Tab1.Controls.Add($MendeleyCheckbox)

$FinanceLabel = New-Object System.Windows.Forms.Label
$FinanceLabel.Location = New-Object System.Drawing.Size(390,10)
$FinanceLabel.Text = "Finance"
$FinanceLabel.Width = 180
$FinanceLabel.Height = 20
$FinanceLabel.Font = $HeaderFont
$Tab1.Controls.Add($FinanceLabel)

$ExodusLogo = New-Object System.Windows.Forms.PictureBox
$ExodusLogo.Width = 18
$ExodusLogo.Height = 18
$ExodusLogo.Location = New-Object System.Drawing.Size(410,30)
$ExodusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Exodus.png"
$ExodusLogo.ImageLocation = $ExodusLogoFile
$ExodusLogo.BorderStyle = 0
$ExodusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ExodusLogo)

$ExodusCheckbox = New-Object System.Windows.Forms.Checkbox 
$ExodusCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$ExodusCheckbox.Text = "       Exodus"
$ExodusCheckbox.Width = 180
$ExodusCheckbox.Height = 20
$ExodusCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ExodusCheckbox)

$QuickenLogo = New-Object System.Windows.Forms.PictureBox
$QuickenLogo.Width = 18
$QuickenLogo.Height = 18
$QuickenLogo.Location = New-Object System.Drawing.Size(410,50)
$QuickenLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Quicken.png"
$QuickenLogo.ImageLocation = $QuickenLogoFile
$QuickenLogo.BorderStyle = 0
$QuickenLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($QuickenLogo)

$QuickenCheckbox = New-Object System.Windows.Forms.Checkbox 
$QuickenCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$QuickenCheckbox.Text = "       Quicken"
$QuickenCheckbox.Width = 180
$QuickenCheckbox.Height = 20
$QuickenCheckbox.Font = $BodyFont
$Tab1.Controls.Add($QuickenCheckbox)

$ImagingLabel = New-Object System.Windows.Forms.Label
$ImagingLabel.Location = New-Object System.Drawing.Size(390,90)
$ImagingLabel.Text = "Imaging"
$ImagingLabel.Width = 180
$ImagingLabel.Height = 20
$ImagingLabel.Font = $HeaderFont
$Tab1.Controls.Add($ImagingLabel)

$BlenderLogo = New-Object System.Windows.Forms.PictureBox
$BlenderLogo.Width = 18
$BlenderLogo.Height = 18
$BlenderLogo.Location = New-Object System.Drawing.Size(410,110)
$BlenderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Blender.png"
$BlenderLogo.ImageLocation = $BlenderLogoFile
$BlenderLogo.BorderStyle = 0
$BlenderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($BlenderLogo)

$BlenderCheckbox = New-Object System.Windows.Forms.Checkbox
$BlenderCheckbox.Location = New-Object System.Drawing.Size(390,110)
$BlenderCheckbox.Text = "       Blender"
$BlenderCheckbox.Width = 180
$BlenderCheckbox.Height = 20
$BlenderCheckbox.Font = $BodyFont
$Tab1.Controls.Add($BlenderCheckbox)

$GimpLogo = New-Object System.Windows.Forms.PictureBox
$GimpLogo.Width = 18
$GimpLogo.Height = 18
$GimpLogo.Location = New-Object System.Drawing.Size(410,130)
$GimpLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Gimp.png"
$GimpLogo.ImageLocation = $GimpLogoFile
$GimpLogo.BorderStyle = 0
$GimpLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GimpLogo)

$GimpCheckbox = New-Object System.Windows.Forms.Checkbox
$GimpCheckbox.Location = New-Object System.Drawing.Size(390,130)
$GimpCheckbox.Text = "       Gimp"
$GimpCheckbox.Width = 180
$GimpCheckbox.Height = 20
$GimpCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GimpCheckbox)

$GreenshotLogo = New-Object System.Windows.Forms.PictureBox
$GreenshotLogo.Width = 18
$GreenshotLogo.Height = 18
$GreenshotLogo.Location = New-Object System.Drawing.Size(410,150)
$GreenshotLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Greenshot.png"
$GreenshotLogo.ImageLocation = $GreenshotLogoFile
$GreenshotLogo.BorderStyle = 0
$GreenshotLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GreenshotLogo)

$GreenshotCheckbox = New-Object System.Windows.Forms.Checkbox
$GreenshotCheckbox.Location = New-Object System.Drawing.Size(390,150)
$GreenshotCheckbox.Text = "       Greenshot"
$GreenshotCheckbox.Width = 180
$GreenshotCheckbox.Height = 20
$GreenshotCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GreenshotCheckbox)

$Paint3DLogo = New-Object System.Windows.Forms.PictureBox
$Paint3DLogo.Width = 18
$Paint3DLogo.Height = 18
$Paint3DLogo.Location = New-Object System.Drawing.Size(410,170)
$Paint3DLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Paint3D.png"
$Paint3DLogo.ImageLocation = $Paint3DLogoFile
$Paint3DLogo.BorderStyle = 0
$Paint3DLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($Paint3DLogo)

$Paint3DCheckbox = New-Object System.Windows.Forms.Checkbox
$Paint3DCheckbox.Location = New-Object System.Drawing.Size(390,170)
$Paint3DCheckbox.Text = "       Paint3D"
$Paint3DCheckbox.Width = 180
$Paint3DCheckbox.Height = 20
$Paint3DCheckbox.Font = $BodyFont
$Tab1.Controls.Add($Paint3DCheckbox)

$PaintNETLogo = New-Object System.Windows.Forms.PictureBox
$PaintNETLogo.Width = 18
$PaintNETLogo.Height = 18
$PaintNETLogo.Location = New-Object System.Drawing.Size(410,190)
$PaintNETLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Paint.net.png"
$PaintNETLogo.ImageLocation = $PaintNETLogoFile
$PaintNETLogo.BorderStyle = 0
$PaintNETLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PaintNETLogo)

$PaintNETCheckbox = New-Object System.Windows.Forms.Checkbox 
$PaintNETCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$PaintNETCheckbox.Text = "       Paint.NET"
$PaintNETCheckbox.Width = 180
$PaintNETCheckbox.Height = 20
$PaintNETCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PaintNETCheckbox)

$ShareXLogo = New-Object System.Windows.Forms.PictureBox
$ShareXLogo.Width = 18
$ShareXLogo.Height = 18
$ShareXLogo.Location = New-Object System.Drawing.Size(410,210)
$ShareXLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\ShareX.png"
$ShareXLogo.ImageLocation = $ShareXLogoFile
$ShareXLogo.BorderStyle = 0
$ShareXLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ShareXLogo)

$ShareXCheckbox = New-Object System.Windows.Forms.Checkbox
$ShareXCheckbox.Location = New-Object System.Drawing.Size(390,210)
$ShareXCheckbox.Text = "       ShareX"
$ShareXCheckbox.Width = 180
$ShareXCheckbox.Height = 20
$ShareXCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ShareXCheckbox)

$MediaLabel = New-Object System.Windows.Forms.Label
$MediaLabel.Location = New-Object System.Drawing.Size(390,250)
$MediaLabel.Text = "Media"
$MediaLabel.Width = 180
$MediaLabel.Height = 20
$MediaLabel.Font = $HeaderFont
$Tab1.Controls.Add($MediaLabel)

$AmazonMusicLogo = New-Object System.Windows.Forms.PictureBox
$AmazonMusicLogo.Width = 18
$AmazonMusicLogo.Height = 18
$AmazonMusicLogo.Location = New-Object System.Drawing.Size(410,270)
$AmazonMusicLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Amazon.png"
$AmazonMusicLogo.ImageLocation = $AmazonMusicLogoFile
$AmazonMusicLogo.BorderStyle = 0
$AmazonMusicLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($AmazonMusicLogo)

$AmazonMusicCheckbox = New-Object System.Windows.Forms.Checkbox 
$AmazonMusicCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$AmazonMusicCheckbox.Text = "       Amazon Music"
$AmazonMusicCheckbox.Width = 180
$AmazonMusicCheckbox.Height = 20
$AmazonMusicCheckbox.Font = $BodyFont
$Tab1.Controls.Add($AmazonMusicCheckbox)

$iTunesLogo = New-Object System.Windows.Forms.PictureBox
$iTunesLogo.Width = 18
$iTunesLogo.Height = 18
$iTunesLogo.Location = New-Object System.Drawing.Size(410,290)
$iTunesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\iTunes.png"
$iTunesLogo.ImageLocation = $iTunesLogoFile
$iTunesLogo.BorderStyle = 0
$iTunesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($iTunesLogo)

$iTunesCheckbox = New-Object System.Windows.Forms.Checkbox 
$iTunesCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$iTunesCheckbox.Text = "       iTunes"
$iTunesCheckbox.Width = 180
$iTunesCheckbox.Height = 20
$iTunesCheckbox.Font = $BodyFont
$Tab1.Controls.Add($iTunesCheckbox)

$KodiLogo = New-Object System.Windows.Forms.PictureBox
$KodiLogo.Width = 18
$KodiLogo.Height = 18
$KodiLogo.Location = New-Object System.Drawing.Size(410,310)
$KodiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Kodi.png"
$KodiLogo.ImageLocation = $KodiLogoFile
$KodiLogo.BorderStyle = 0
$KodiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($KodiLogo)

$KodiCheckbox = New-Object System.Windows.Forms.Checkbox 
$KodiCheckbox.Location = New-Object System.Drawing.Size(390,310) 
$KodiCheckbox.Text = "       Kodi"
$KodiCheckbox.Width = 180
$KodiCheckbox.Height = 20
$KodiCheckbox.Font = $BodyFont
$Tab1.Controls.Add($KodiCheckbox)

$NetflixLogo = New-Object System.Windows.Forms.PictureBox
$NetflixLogo.Width = 18
$NetflixLogo.Height = 18
$NetflixLogo.Location = New-Object System.Drawing.Size(410,330)
$NetflixLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Netflix.png"
$NetflixLogo.ImageLocation = $NetflixLogoFile
$NetflixLogo.BorderStyle = 0
$NetflixLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($NetflixLogo)

$NetflixCheckbox = New-Object System.Windows.Forms.Checkbox 
$NetflixCheckbox.Location = New-Object System.Drawing.Size(390,330) 
$NetflixCheckbox.Text = "       Netflix"
$NetflixCheckbox.Width = 180
$NetflixCheckbox.Height = 20
$NetflixCheckbox.Font = $BodyFont
$Tab1.Controls.Add($NetflixCheckbox)

$PlexLogo = New-Object System.Windows.Forms.PictureBox
$PlexLogo.Width = 18
$PlexLogo.Height = 18
$PlexLogo.Location = New-Object System.Drawing.Size(410,350)
$PlexLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Plex.png"
$PlexLogo.ImageLocation = $PlexLogoFile
$PlexLogo.BorderStyle = 0
$PlexLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PlexLogo)

$PlexCheckbox = New-Object System.Windows.Forms.Checkbox 
$PlexCheckbox.Location = New-Object System.Drawing.Size(390,350) 
$PlexCheckbox.Text = "       Plex"
$PlexCheckbox.Width = 180
$PlexCheckbox.Height = 20
$PlexCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PlexCheckbox)

$SpotifyLogo = New-Object System.Windows.Forms.PictureBox
$SpotifyLogo.Width = 18
$SpotifyLogo.Height = 18
$SpotifyLogo.Location = New-Object System.Drawing.Size(410,370)
$SpotifyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Spotify.png"
$SpotifyLogo.ImageLocation = $SpotifyLogoFile
$SpotifyLogo.BorderStyle = 0
$SpotifyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SpotifyLogo)

$SpotifyCheckbox = New-Object System.Windows.Forms.Checkbox 
$SpotifyCheckbox.Location = New-Object System.Drawing.Size(390,370) 
$SpotifyCheckbox.Text = "       Spotify"
$SpotifyCheckbox.Width = 180
$SpotifyCheckbox.Height = 20
$SpotifyCheckbox.Font = $BodyFont
$Tab1.Controls.Add($SpotifyCheckbox)

$VLCLogo = New-Object System.Windows.Forms.PictureBox
$VLCLogo.Width = 18
$VLCLogo.Height = 18
$VLCLogo.Location = New-Object System.Drawing.Size(410,390)
$VLCLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\VLC.png"
$VLCLogo.ImageLocation = $VLCLogoFile
$VLCLogo.BorderStyle = 0
$VLCLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($VLCLogo)

$VLCCheckbox = New-Object System.Windows.Forms.Checkbox 
$VLCCheckbox.Location = New-Object System.Drawing.Size(390,390) 
$VLCCheckbox.Text = "       VLC Player"
$VLCCheckbox.Width = 180
$VLCCheckbox.Height = 20
$VLCCheckbox.Font = $BodyFont
$Tab1.Controls.Add($VLCCheckbox)

$P2PLabel = New-Object System.Windows.Forms.Label
$P2PLabel.Location = New-Object System.Drawing.Size(580,10)
$P2PLabel.Text = "P2P"
$P2PLabel.Width = 180
$P2PLabel.Height = 20
$P2PLabel.Font = $HeaderFont
$Tab1.Controls.Add($P2PLabel)

$BitTorrentLogo = New-Object System.Windows.Forms.PictureBox
$BitTorrentLogo.Width = 18
$BitTorrentLogo.Height = 18
$BitTorrentLogo.Location = New-Object System.Drawing.Size(600,30)
$BitTorrentLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\BitTorrent.png"
$BitTorrentLogo.ImageLocation = $BitTorrentLogoFile
$BitTorrentLogo.BorderStyle = 0
$BitTorrentLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($BitTorrentLogo)

$BitTorrentCheckbox = New-Object System.Windows.Forms.Checkbox 
$BitTorrentCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$BitTorrentCheckbox.Text = "       BitTorrent"
$BitTorrentCheckbox.Width = 180
$BitTorrentCheckbox.Height = 20
$BitTorrentCheckbox.Font = $BodyFont
$Tab1.Controls.Add($BitTorrentCheckbox)

$qBittorrentLogo = New-Object System.Windows.Forms.PictureBox
$qBittorrentLogo.Width = 18
$qBittorrentLogo.Height = 18
$qBittorrentLogo.Location = New-Object System.Drawing.Size(600,50)
$qBittorrentLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\qBittorrent.png"
$qBittorrentLogo.ImageLocation = $qBittorrentLogoFile
$qBittorrentLogo.BorderStyle = 0
$qBittorrentLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($qBittorrentLogo)

$qBittorrentCheckbox = New-Object System.Windows.Forms.Checkbox 
$qBittorrentCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$qBittorrentCheckbox.Text = "       qBittorrent"
$qBittorrentCheckbox.Width = 180
$qBittorrentCheckbox.Height = 20
$qBittorrentCheckbox.Font = $BodyFont
$Tab1.Controls.Add($qBittorrentCheckbox)

$uTorrentLogo = New-Object System.Windows.Forms.PictureBox
$uTorrentLogo.Width = 18
$uTorrentLogo.Height = 18
$uTorrentLogo.Location = New-Object System.Drawing.Size(600,70)
$uTorrentLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\uTorrent.png"
$uTorrentLogo.ImageLocation = $uTorrentLogoFile
$uTorrentLogo.BorderStyle = 0
$uTorrentLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($uTorrentLogo)

$uTorrentCheckbox = New-Object System.Windows.Forms.Checkbox 
$uTorrentCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$uTorrentCheckbox.Text = "       uTorrent"
$uTorrentCheckbox.Width = 180
$uTorrentCheckbox.Height = 20
$uTorrentCheckbox.Font = $BodyFont
$Tab1.Controls.Add($uTorrentCheckbox)

$RGBLabel = New-Object System.Windows.Forms.Label
$RGBLabel.Location = New-Object System.Drawing.Size(580,110)
$RGBLabel.Text = "RGB"
$RGBLabel.Width = 180
$RGBLabel.Height = 20
$RGBLabel.Font = $HeaderFont
$Tab1.Controls.Add($RGBLabel)

$CorsairiCueLogo = New-Object System.Windows.Forms.PictureBox
$CorsairiCueLogo.Width = 18
$CorsairiCueLogo.Height = 18
$CorsairiCueLogo.Location = New-Object System.Drawing.Size(600,130)
$CorsairiCueLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\CorsairiCue.png"
$CorsairiCueLogo.ImageLocation = $CorsairiCueLogoFile
$CorsairiCueLogo.BorderStyle = 0
$CorsairiCueLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($CorsairiCueLogo)

$CorsairiCueCheckbox = New-Object System.Windows.Forms.Checkbox 
$CorsairiCueCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$CorsairiCueCheckbox.Text = "       Corsair iCue"
$CorsairiCueCheckbox.Width = 180
$CorsairiCueCheckbox.Height = 20
$CorsairiCueCheckbox.Font = $BodyFont
$Tab1.Controls.Add($CorsairiCueCheckbox)

$GloriousCoreLogo = New-Object System.Windows.Forms.PictureBox
$GloriousCoreLogo.Width = 18
$GloriousCoreLogo.Height = 18
$GloriousCoreLogo.Location = New-Object System.Drawing.Size(600,150)
$GloriousCoreLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Glorious.png"
$GloriousCoreLogo.ImageLocation = $GloriousCoreLogoFile
$GloriousCoreLogo.BorderStyle = 0
$GloriousCoreLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GloriousCoreLogo)

$GloriousCoreCheckbox = New-Object System.Windows.Forms.Checkbox 
$GloriousCoreCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$GloriousCoreCheckbox.Text = "       Glorious Core"
$GloriousCoreCheckbox.Width = 180
$GloriousCoreCheckbox.Height = 20
$GloriousCoreCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GloriousCoreCheckbox)

$LogitechGHubLogo = New-Object System.Windows.Forms.PictureBox
$LogitechGHubLogo.Width = 18
$LogitechGHubLogo.Height = 18
$LogitechGHubLogo.Location = New-Object System.Drawing.Size(600,170)
$LogitechGHubLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Logitech.png"
$LogitechGHubLogo.ImageLocation = $LogitechGHubLogoFile
$LogitechGHubLogo.BorderStyle = 0
$LogitechGHubLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($LogitechGHubLogo)

$LogitechGHubCheckbox = New-Object System.Windows.Forms.Checkbox 
$LogitechGHubCheckbox.Location = New-Object System.Drawing.Size(580,170) 
$LogitechGHubCheckbox.Text = "       Logitech GHub"
$LogitechGHubCheckbox.Width = 180
$LogitechGHubCheckbox.Height = 20
$LogitechGHubCheckbox.Font = $BodyFont
$Tab1.Controls.Add($LogitechGHubCheckbox)

$NZXTCamLogo = New-Object System.Windows.Forms.PictureBox
$NZXTCamLogo.Width = 18
$NZXTCamLogo.Height = 18
$NZXTCamLogo.Location = New-Object System.Drawing.Size(600,190)
$NZXTCamLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\NZXT.png"
$NZXTCamLogo.ImageLocation = $NZXTCamLogoFile
$NZXTCamLogo.BorderStyle = 0
$NZXTCamLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($NZXTCamLogo)

$NZXTCamCheckbox = New-Object System.Windows.Forms.Checkbox 
$NZXTCamCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$NZXTCamCheckbox.Text = "       NZXT Cam"
$NZXTCamCheckbox.Width = 180
$NZXTCamCheckbox.Height = 20
$NZXTCamCheckbox.Font = $BodyFont
$Tab1.Controls.Add($NZXTCamCheckbox)

$OpenRGBLogo = New-Object System.Windows.Forms.PictureBox
$OpenRGBLogo.Width = 18
$OpenRGBLogo.Height = 18
$OpenRGBLogo.Location = New-Object System.Drawing.Size(600,210)
$OpenRGBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\OpenRGB.png"
$OpenRGBLogo.ImageLocation = $OpenRGBLogoFile
$OpenRGBLogo.BorderStyle = 0
$OpenRGBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OpenRGBLogo)

$OpenRGBCheckbox = New-Object System.Windows.Forms.Checkbox 
$OpenRGBCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$OpenRGBCheckbox.Text = "       Open RGB"
$OpenRGBCheckbox.Width = 180
$OpenRGBCheckbox.Height = 20
$OpenRGBCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OpenRGBCheckbox)

$RazerChromaLogo = New-Object System.Windows.Forms.PictureBox
$RazerChromaLogo.Width = 18
$RazerChromaLogo.Height = 18
$RazerChromaLogo.Location = New-Object System.Drawing.Size(600,230)
$RazerChromaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\RazerChroma.png"
$RazerChromaLogo.ImageLocation = $RazerChromaLogoFile
$RazerChromaLogo.BorderStyle = 0
$RazerChromaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($RazerChromaLogo)

$RazerChromaCheckbox = New-Object System.Windows.Forms.Checkbox 
$RazerChromaCheckbox.Location = New-Object System.Drawing.Size(580,230) 
$RazerChromaCheckbox.Text = "       Razer Chroma"
$RazerChromaCheckbox.Width = 180
$RazerChromaCheckbox.Height = 20
$RazerChromaCheckbox.Font = $BodyFont
$Tab1.Controls.Add($RazerChromaCheckbox)

$RazerSynapseLogo = New-Object System.Windows.Forms.PictureBox
$RazerSynapseLogo.Width = 18
$RazerSynapseLogo.Height = 18
$RazerSynapseLogo.Location = New-Object System.Drawing.Size(600,250)
$RazerSynapseLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\RazerSynapse.png"
$RazerSynapseLogo.ImageLocation = $RazerSynapseLogoFile
$RazerSynapseLogo.BorderStyle = 0
$RazerSynapseLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($RazerSynapseLogo)

$RazerSynapseCheckbox = New-Object System.Windows.Forms.Checkbox 
$RazerSynapseCheckbox.Location = New-Object System.Drawing.Size(580,250) 
$RazerSynapseCheckbox.Text = "       Razer Synapse"
$RazerSynapseCheckbox.Width = 180
$RazerSynapseCheckbox.Height = 20
$RazerSynapseCheckbox.Font = $BodyFont
$Tab1.Controls.Add($RazerSynapseCheckbox)

$SignalRGBLogo = New-Object System.Windows.Forms.PictureBox
$SignalRGBLogo.Width = 18
$SignalRGBLogo.Height = 18
$SignalRGBLogo.Location = New-Object System.Drawing.Size(600,270)
$SignalRGBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\SignalRGB.png"
$SignalRGBLogo.ImageLocation = $SignalRGBLogoFile
$SignalRGBLogo.BorderStyle = 0
$SignalRGBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SignalRGBLogo)
 
$SignalRGBCheckbox = New-Object System.Windows.Forms.Checkbox 
$SignalRGBCheckbox.Location = New-Object System.Drawing.Size(580,270) 
$SignalRGBCheckbox.Text = "       SignalRGB"
$SignalRGBCheckbox.Width = 180
$SignalRGBCheckbox.Height = 20
$SignalRGBCheckbox.Font = $BodyFont
$Tab1.Controls.Add($SignalRGBCheckbox)

$TTRGBPlusLogo = New-Object System.Windows.Forms.PictureBox
$TTRGBPlusLogo.Width = 18
$TTRGBPlusLogo.Height = 18
$TTRGBPlusLogo.Location = New-Object System.Drawing.Size(600,290)
$TTRGBPlusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\TTRGBPlus.png"
$TTRGBPlusLogo.ImageLocation = $TTRGBPlusLogoFile
$TTRGBPlusLogo.BorderStyle = 0
$TTRGBPlusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TTRGBPlusLogo)

$TTRGBPlusCheckbox = New-Object System.Windows.Forms.Checkbox 
$TTRGBPlusCheckbox.Location = New-Object System.Drawing.Size(580,290) 
$TTRGBPlusCheckbox.Text = "       TT RGB Plus"
$TTRGBPlusCheckbox.Width = 180
$TTRGBPlusCheckbox.Height = 20
$TTRGBPlusCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TTRGBPlusCheckbox)

$SocialLabel = New-Object System.Windows.Forms.Label
$SocialLabel.Location = New-Object System.Drawing.Size(770,10)
$SocialLabel.Text = "Social"
$SocialLabel.Width = 180
$SocialLabel.Height = 20
$SocialLabel.Font = $HeaderFont
$Tab1.Controls.Add($SocialLabel)

$DiscordLogo = New-Object System.Windows.Forms.PictureBox
$DiscordLogo.Width = 18
$DiscordLogo.Height = 18
$DiscordLogo.Location = New-Object System.Drawing.Size(790,30)
$DiscordLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Discord.png"
$DiscordLogo.ImageLocation = $DiscordLogoFile
$DiscordLogo.BorderStyle = 0
$DiscordLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($DiscordLogo)

$DiscordCheckbox = New-Object System.Windows.Forms.Checkbox 
$DiscordCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$DiscordCheckbox.Text = "       Discord"
$DiscordCheckbox.Width = 180
$DiscordCheckbox.Height = 20
$DiscordCheckbox.Font = $BodyFont
$Tab1.Controls.Add($DiscordCheckbox)

$SkypeLogo = New-Object System.Windows.Forms.PictureBox
$SkypeLogo.Width = 18
$SkypeLogo.Height = 18
$SkypeLogo.Location = New-Object System.Drawing.Size(790,50)
$SkypeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Skype.png"
$SkypeLogo.ImageLocation = $SkypeLogoFile
$SkypeLogo.BorderStyle = 0
$SkypeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SkypeLogo)

$SkypeCheckbox = New-Object System.Windows.Forms.Checkbox 
$SkypeCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$SkypeCheckbox.Text = "       Skype"
$SkypeCheckbox.Width = 180
$SkypeCheckbox.Height = 20
$SkypeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($SkypeCheckbox)

$SlackLogo = New-Object System.Windows.Forms.PictureBox
$SlackLogo.Width = 18
$SlackLogo.Height = 18
$SlackLogo.Location = New-Object System.Drawing.Size(790,70)
$SlackLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Slack.png"
$SlackLogo.ImageLocation = $SlackLogoFile
$SlackLogo.BorderStyle = 0
$SlackLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SlackLogo)

$SlackCheckbox = New-Object System.Windows.Forms.Checkbox 
$SlackCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$SlackCheckbox.Text = "       Slack"
$SlackCheckbox.Width = 180
$SlackCheckbox.Height = 20
$SlackCheckbox.Font = $BodyFont
$Tab1.Controls.Add($SlackCheckbox)

$TeamsLogo = New-Object System.Windows.Forms.PictureBox
$TeamsLogo.Width = 18
$TeamsLogo.Height = 18
$TeamsLogo.Location = New-Object System.Drawing.Size(790,90)
$TeamsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Teams.png"
$TeamsLogo.ImageLocation = $TeamsLogoFile
$TeamsLogo.BorderStyle = 0
$TeamsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TeamsLogo)

$TeamsCheckbox = New-Object System.Windows.Forms.Checkbox 
$TeamsCheckbox.Location = New-Object System.Drawing.Size(770,90) 
$TeamsCheckbox.Text = "       Teams"
$TeamsCheckbox.Width = 180
$TeamsCheckbox.Height = 20
$TeamsCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TeamsCheckbox)

$TeamviewerLogo = New-Object System.Windows.Forms.PictureBox
$TeamviewerLogo.Width = 18
$TeamviewerLogo.Height = 18
$TeamviewerLogo.Location = New-Object System.Drawing.Size(790,110)
$TeamviewerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Teamviewer.png"
$TeamviewerLogo.ImageLocation = $TeamviewerLogoFile
$TeamviewerLogo.BorderStyle = 0
$TeamviewerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TeamviewerLogo)

$TeamViewerCheckbox = New-Object System.Windows.Forms.Checkbox 
$TeamViewerCheckbox.Location = New-Object System.Drawing.Size(770,110) 
$TeamViewerCheckbox.Text = "       TeamViewer"
$TeamViewerCheckbox.Width = 180
$TeamViewerCheckbox.Height = 20
$TeamViewerCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TeamViewerCheckbox)

$TelegramLogo = New-Object System.Windows.Forms.PictureBox
$TelegramLogo.Width = 18
$TelegramLogo.Height = 18
$TelegramLogo.Location = New-Object System.Drawing.Size(790,130)
$TelegramLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Telegram.png"
$TelegramLogo.ImageLocation = $TelegramLogoFile
$TelegramLogo.BorderStyle = 0
$TelegramLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($TelegramLogo)

$TelegramCheckbox = New-Object System.Windows.Forms.Checkbox 
$TelegramCheckbox.Location = New-Object System.Drawing.Size(770,130) 
$TelegramCheckbox.Text = "       Telegram"
$TelegramCheckbox.Width = 180
$TelegramCheckbox.Height = 20
$TelegramCheckbox.Font = $BodyFont
$Tab1.Controls.Add($TelegramCheckbox)

$ThunderbirdLogo = New-Object System.Windows.Forms.PictureBox
$ThunderbirdLogo.Width = 18
$ThunderbirdLogo.Height = 18
$ThunderbirdLogo.Location = New-Object System.Drawing.Size(790,150)
$ThunderbirdLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Thunderbird.png"
$ThunderbirdLogo.ImageLocation = $ThunderbirdLogoFile
$ThunderbirdLogo.BorderStyle = 0
$ThunderbirdLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ThunderbirdLogo)

$ThunderbirdCheckbox = New-Object System.Windows.Forms.Checkbox 
$ThunderbirdCheckbox.Location = New-Object System.Drawing.Size(770,150) 
$ThunderbirdCheckbox.Text = "       Thunderbird"
$ThunderbirdCheckbox.Width = 180
$ThunderbirdCheckbox.Height = 20
$ThunderbirdCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ThunderbirdCheckbox)

$WhatsAppLogo = New-Object System.Windows.Forms.PictureBox
$WhatsAppLogo.Width = 18
$WhatsAppLogo.Height = 18
$WhatsAppLogo.Location = New-Object System.Drawing.Size(790,170)
$WhatsAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\WhatsApp.png"
$WhatsAppLogo.ImageLocation = $WhatsAppLogoFile
$WhatsAppLogo.BorderStyle = 0
$WhatsAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($WhatsAppLogo)

$WhatsAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$WhatsAppCheckbox.Location = New-Object System.Drawing.Size(770,170) 
$WhatsAppCheckbox.Text = "       WhatsApp"
$WhatsAppCheckbox.Width = 180
$WhatsAppCheckbox.Height = 20
$WhatsAppCheckbox.Font = $BodyFont
$Tab1.Controls.Add($WhatsAppCheckbox)

$ZoomLogo = New-Object System.Windows.Forms.PictureBox
$ZoomLogo.Width = 18
$ZoomLogo.Height = 18
$ZoomLogo.Location = New-Object System.Drawing.Size(790,190)
$ZoomLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Zoom.png"
$ZoomLogo.ImageLocation = $ZoomLogoFile
$ZoomLogo.BorderStyle = 0
$ZoomLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($ZoomLogo)

$ZoomCheckbox = New-Object System.Windows.Forms.Checkbox 
$ZoomCheckbox.Location = New-Object System.Drawing.Size(770,190) 
$ZoomCheckbox.Text = "       Zoom"
$ZoomCheckbox.Width = 180
$ZoomCheckbox.Height = 20
$ZoomCheckbox.Font = $BodyFont
$Tab1.Controls.Add($ZoomCheckbox)

$TravelLabel = New-Object System.Windows.Forms.Label
$TravelLabel.Location = New-Object System.Drawing.Size(960,10)
$TravelLabel.Text = "Travel"
$TravelLabel.Width = 180
$TravelLabel.Height = 20
$TravelLabel.Font = $HeaderFont
$Tab1.Controls.Add($TravelLabel)

$GarminLogo = New-Object System.Windows.Forms.PictureBox
$GarminLogo.Width = 18
$GarminLogo.Height = 18
$GarminLogo.Location = New-Object System.Drawing.Size(980,30)
$GarminLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Garmin.png"
$GarminLogo.ImageLocation = $GarminLogoFile
$GarminLogo.BorderStyle = 0
$GarminLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GarminLogo)

$GarminCheckbox = New-Object System.Windows.Forms.Checkbox 
$GarminCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$GarminCheckbox.Text = "       Garmin Express"
$GarminCheckbox.Width = 180
$GarminCheckbox.Height = 20
$GarminCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GarminCheckbox)

$GoogleEarthProLogo = New-Object System.Windows.Forms.PictureBox
$GoogleEarthProLogo.Width = 18
$GoogleEarthProLogo.Height = 18
$GoogleEarthProLogo.Location = New-Object System.Drawing.Size(980,50)
$GoogleEarthProLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\GoogleEarthPro.png"
$GoogleEarthProLogo.ImageLocation = $GoogleEarthProLogoFile
$GoogleEarthProLogo.BorderStyle = 0
$GoogleEarthProLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($GoogleEarthProLogo)

$GoogleEarthProCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoogleEarthProCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$GoogleEarthProCheckbox.Text = "       Google Earth Pro"
$GoogleEarthProCheckbox.Width = 180
$GoogleEarthProCheckbox.Height = 20
$GoogleEarthProCheckbox.Font = $BodyFont
$Tab1.Controls.Add($GoogleEarthProCheckbox)

$UtilitiesLabel = New-Object System.Windows.Forms.Label
$UtilitiesLabel.Location = New-Object System.Drawing.Size(960,90)
$UtilitiesLabel.Text = "Utilities"
$UtilitiesLabel.Width = 180
$UtilitiesLabel.Height = 20
$UtilitiesLabel.Font = $HeaderFont
$Tab1.Controls.Add($UtilitiesLabel)

$FluxLogo = New-Object System.Windows.Forms.PictureBox
$FluxLogo.Width = 18
$FluxLogo.Height = 18
$FluxLogo.Location = New-Object System.Drawing.Size(980,110)
$FluxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Flux.png"
$FluxLogo.ImageLocation = $FluxLogoFile
$FluxLogo.BorderStyle = 0
$FluxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($FluxLogo)

$FluxCheckbox = New-Object System.Windows.Forms.Checkbox 
$FluxCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$FluxCheckbox.Text = "       F.lux"
$FluxCheckbox.Width = 180
$FluxCheckbox.Height = 20
$FluxCheckbox.Font = $BodyFont
$Tab1.Controls.Add($FluxCheckbox)

$PowerToysLogo = New-Object System.Windows.Forms.PictureBox
$PowerToysLogo.Width = 18
$PowerToysLogo.Height = 18
$PowerToysLogo.Location = New-Object System.Drawing.Size(980,130)
$PowerToysLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\PowerToys.png"
$PowerToysLogo.ImageLocation = $PowerToysLogoFile
$PowerToysLogo.BorderStyle = 0
$PowerToysLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($PowerToysLogo)

$PowerToysCheckbox = New-Object System.Windows.Forms.Checkbox 
$PowerToysCheckbox.Location = New-Object System.Drawing.Size(960,130) 
$PowerToysCheckbox.Text = "       PowerToys"
$PowerToysCheckbox.Width = 180
$PowerToysCheckbox.Height = 20
$PowerToysCheckbox.Font = $BodyFont
$Tab1.Controls.Add($PowerToysCheckbox)

$RufusLogo = New-Object System.Windows.Forms.PictureBox
$RufusLogo.Width = 18
$RufusLogo.Height = 18
$RufusLogo.Location = New-Object System.Drawing.Size(980,150)
$RufusLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Rufus.png"
$RufusLogo.ImageLocation = $RufusLogoFile
$RufusLogo.BorderStyle = 0
$RufusLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($RufusLogo)

$RufusCheckbox = New-Object System.Windows.Forms.Checkbox 
$RufusCheckbox.Location = New-Object System.Drawing.Size(960,150) 
$RufusCheckbox.Text = "       Rufus"
$RufusCheckbox.Width = 180
$RufusCheckbox.Height = 20
$RufusCheckbox.Font = $BodyFont
$RufusCheckbox.AutoSize = $True
$Tab1.Controls.Add($RufusCheckbox)

$SuperF4Logo = New-Object System.Windows.Forms.PictureBox
$SuperF4Logo.Width = 18
$SuperF4Logo.Height = 18
$SuperF4Logo.Location = New-Object System.Drawing.Size(980,170)
$SuperF4LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\SuperF4.png"
$SuperF4Logo.ImageLocation = $SuperF4LogoFile
$SuperF4Logo.BorderStyle = 0
$SuperF4Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($SuperF4Logo)

$SuperF4Checkbox = New-Object System.Windows.Forms.Checkbox 
$SuperF4Checkbox.Location = New-Object System.Drawing.Size(960,170) 
$SuperF4Checkbox.Text = "       SuperF4"
$SuperF4Checkbox.Width = 180
$SuperF4Checkbox.Height = 20
$SuperF4Checkbox.Font = $BodyFont
$SuperF4Checkbox.AutoSize = $True
$Tab1.Controls.Add($SuperF4Checkbox)

$VideoLabel = New-Object System.Windows.Forms.Label
$VideoLabel.Location = New-Object System.Drawing.Size(960,210)
$VideoLabel.Text = "Video"
$VideoLabel.Width = 180
$VideoLabel.Height = 20
$VideoLabel.Font = $HeaderFont
$Tab1.Controls.Add($VideoLabel)

$CapCutLogo = New-Object System.Windows.Forms.PictureBox
$CapCutLogo.Width = 18
$CapCutLogo.Height = 18
$CapCutLogo.Location = New-Object System.Drawing.Size(980,230)
$CapCutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\CapCut.png"
$CapCutLogo.ImageLocation = $CapCutLogoFile
$CapCutLogo.BorderStyle = 0
$CapCutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($CapCutLogo)

$CapCutCheckbox = New-Object System.Windows.Forms.Checkbox 
$CapCutCheckbox.Location = New-Object System.Drawing.Size(960,230) 
$CapCutCheckbox.Text = "       CapCut"
$CapCutCheckbox.Width = 180
$CapCutCheckbox.Height = 20
$CapCutCheckbox.Font = $BodyFont
$Tab1.Controls.Add($CapCutCheckbox)

$HandbrakeLogo = New-Object System.Windows.Forms.PictureBox
$HandbrakeLogo.Width = 18
$HandbrakeLogo.Height = 18
$HandbrakeLogo.Location = New-Object System.Drawing.Size(980,250)
$HandbrakeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Handbrake.png"
$HandbrakeLogo.ImageLocation = $HandbrakeLogoFile
$HandbrakeLogo.BorderStyle = 0
$HandbrakeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($HandbrakeLogo)

$HandbrakeCheckbox = New-Object System.Windows.Forms.Checkbox 
$HandbrakeCheckbox.Location = New-Object System.Drawing.Size(960,250) 
$HandbrakeCheckbox.Text = "       Handbrake"
$HandbrakeCheckbox.Width = 180
$HandbrakeCheckbox.Height = 20
$HandbrakeCheckbox.Font = $BodyFont
$Tab1.Controls.Add($HandbrakeCheckbox)

$LightworksLogo = New-Object System.Windows.Forms.PictureBox
$LightworksLogo.Width = 18
$LightworksLogo.Height = 18
$LightworksLogo.Location = New-Object System.Drawing.Size(980,270)
$LightworksLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Lightworks.png"
$LightworksLogo.ImageLocation = $LightworksLogoFile
$LightworksLogo.BorderStyle = 0
$LightworksLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($LightworksLogo)

$LightworksCheckbox = New-Object System.Windows.Forms.Checkbox 
$LightworksCheckbox.Location = New-Object System.Drawing.Size(960,270) 
$LightworksCheckbox.Text = "       Lightworks"
$LightworksCheckbox.Width = 180
$LightworksCheckbox.Height = 20
$LightworksCheckbox.Font = $BodyFont
$Tab1.Controls.Add($LightworksCheckbox)

$OBSLogo = New-Object System.Windows.Forms.PictureBox
$OBSLogo.Width = 18
$OBSLogo.Height = 18
$OBSLogo.Location = New-Object System.Drawing.Size(980,290)
$OBSLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\OBS.png"
$OBSLogo.ImageLocation = $OBSLogoFile
$OBSLogo.BorderStyle = 0
$OBSLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab1.Controls.Add($OBSLogo)

$OBSCheckbox = New-Object System.Windows.Forms.Checkbox 
$OBSCheckbox.Location = New-Object System.Drawing.Size(960,290) 
$OBSCheckbox.Text = "       OBS Studio"
$OBSCheckbox.Width = 180
$OBSCheckbox.Height = 20
$OBSCheckbox.Font = $BodyFont
$Tab1.Controls.Add($OBSCheckbox)

# Tab 2 
$Tab2 = New-Object System.Windows.Forms.TabPage
$Tab2.Text = "Gaming"
$Tab2.Font = $TabFont
$Tab2.Autoscroll  = $True
$TabControl.Controls.Add($Tab2)

$EmulationLabel = New-Object System.Windows.Forms.Label
$EmulationLabel.Location = New-Object System.Drawing.Size(10,10)
$EmulationLabel.Text = "Emulation 1"
$EmulationLabel.Width = 180
$EmulationLabel.Height = 20
$EmulationLabel.Font = $HeaderFont
$Tab2.Controls.Add($EmulationLabel)

$BlueStacksLogo = New-Object System.Windows.Forms.PictureBox
$BlueStacksLogo.Width = 18
$BlueStacksLogo.Height = 18
$BlueStacksLogo.Location = New-Object System.Drawing.Size(30,30)
$BlueStacksLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\BlueStacks.png"
$BlueStacksLogo.ImageLocation = $BlueStacksLogoFile
$BlueStacksLogo.BorderStyle = 0
$BlueStacksLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BlueStacksLogo)

$BlueStacksCheckbox = New-Object System.Windows.Forms.Checkbox 
$BlueStacksCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$BlueStacksCheckbox.Text = "       BlueStacks"
$BlueStacksCheckbox.Width = 180
$BlueStacksCheckbox.Height = 20
$BlueStacksCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BlueStacksCheckbox)

$CemuLogo = New-Object System.Windows.Forms.PictureBox
$CemuLogo.Width = 18
$CemuLogo.Height = 18
$CemuLogo.Location = New-Object System.Drawing.Size(30,50)
$CemuLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Cemu.png"
$CemuLogo.ImageLocation = $CemuLogoFile
$CemuLogo.BorderStyle = 0
$CemuLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CemuLogo)

$CemuCheckbox = New-Object System.Windows.Forms.Checkbox 
$CemuCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$CemuCheckbox.Text = "       Cemu"
$CemuCheckbox.Width = 180
$CemuCheckbox.Height = 20
$CemuCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CemuCheckbox)

$CitraLogo = New-Object System.Windows.Forms.PictureBox
$CitraLogo.Width = 18
$CitraLogo.Height = 18
$CitraLogo.Location = New-Object System.Drawing.Size(30,70)
$CitraLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Citra.png"
$CitraLogo.ImageLocation = $CitraLogoFile
$CitraLogo.BorderStyle = 0
$CitraLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CitraLogo)

$CitraCheckbox = New-Object System.Windows.Forms.Checkbox 
$CitraCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$CitraCheckbox.Text = "       Citra"
$CitraCheckbox.Width = 180
$CitraCheckbox.Height = 20
$CitraCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CitraCheckbox)

$DeSmuMELogo = New-Object System.Windows.Forms.PictureBox
$DeSmuMELogo.Width = 18
$DeSmuMELogo.Height = 18
$DeSmuMELogo.Location = New-Object System.Drawing.Size(30,90)
$DeSmuMELogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DeSmuME.png"
$DeSmuMELogo.ImageLocation = $DeSmuMELogoFile
$DeSmuMELogo.BorderStyle = 0
$DeSmuMELogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DeSmuMELogo)

$DeSmuMECheckbox = New-Object System.Windows.Forms.Checkbox 
$DeSmuMECheckbox.Location = New-Object System.Drawing.Size(10,90) 
$DeSmuMECheckbox.Text = "       DeSmuME"
$DeSmuMECheckbox.Width = 180
$DeSmuMECheckbox.Height = 20
$DeSmuMECheckbox.Font = $BodyFont
$Tab2.Controls.Add($DeSmuMECheckbox)

$DolphinLogo = New-Object System.Windows.Forms.PictureBox
$DolphinLogo.Width = 18
$DolphinLogo.Height = 18
$DolphinLogo.Location = New-Object System.Drawing.Size(30,110)
$DolphinLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Dolphin.png"
$DolphinLogo.ImageLocation = $DolphinLogoFile
$DolphinLogo.BorderStyle = 0
$DolphinLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DolphinLogo)

$DolphinCheckbox = New-Object System.Windows.Forms.Checkbox 
$DolphinCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$DolphinCheckbox.Text = "       Dolphin"
$DolphinCheckbox.Width = 180
$DolphinCheckbox.Height = 20
$DolphinCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DolphinCheckbox)

$DOSBoxLogo = New-Object System.Windows.Forms.PictureBox
$DOSBoxLogo.Width = 18
$DOSBoxLogo.Height = 18
$DOSBoxLogo.Location = New-Object System.Drawing.Size(30,130)
$DOSBoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DOSBox.png"
$DOSBoxLogo.ImageLocation = $DOSBoxLogoFile
$DOSBoxLogo.BorderStyle = 0
$DOSBoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DOSBoxLogo)

$DOSBoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$DOSBoxCheckbox.Location = New-Object System.Drawing.Size(10,130) 
$DOSBoxCheckbox.Text = "       DOSBox"
$DOSBoxCheckbox.Width = 180
$DOSBoxCheckbox.Height = 20
$DOSBoxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DOSBoxCheckbox)

$ePSXeLogo = New-Object System.Windows.Forms.PictureBox
$ePSXeLogo.Width = 18
$ePSXeLogo.Height = 18
$ePSXeLogo.Location = New-Object System.Drawing.Size(30,150)
$ePSXeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\ePSXe.png"
$ePSXeLogo.ImageLocation = $ePSXeLogoFile
$ePSXeLogo.BorderStyle = 0
$ePSXeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($ePSXeLogo)

$ePSXeCheckbox = New-Object System.Windows.Forms.Checkbox 
$ePSXeCheckbox.Location = New-Object System.Drawing.Size(10,150) 
$ePSXeCheckbox.Text = "       ePSXe"
$ePSXeCheckbox.Width = 180
$ePSXeCheckbox.Height = 20
$ePSXeCheckbox.Font = $BodyFont
$Tab2.Controls.Add($ePSXeCheckbox)

$HiganLogo = New-Object System.Windows.Forms.PictureBox
$HiganLogo.Width = 18
$HiganLogo.Height = 18
$HiganLogo.Location = New-Object System.Drawing.Size(30,170)
$HiganLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Higan.png"
$HiganLogo.ImageLocation = $HiganLogoFile
$HiganLogo.BorderStyle = 0
$HiganLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($HiganLogo)

$HiganCheckbox = New-Object System.Windows.Forms.Checkbox 
$HiganCheckbox.Location = New-Object System.Drawing.Size(10,170) 
$HiganCheckbox.Text = "       Higan"
$HiganCheckbox.Width = 180
$HiganCheckbox.Height = 20
$HiganCheckbox.Font = $BodyFont
$Tab2.Controls.Add($HiganCheckbox)

$KegaFusionLogo = New-Object System.Windows.Forms.PictureBox
$KegaFusionLogo.Width = 18
$KegaFusionLogo.Height = 18
$KegaFusionLogo.Location = New-Object System.Drawing.Size(30,190)
$KegaFusionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\KegaFusion.png"
$KegaFusionLogo.ImageLocation = $KegaFusionLogoFile
$KegaFusionLogo.BorderStyle = 0
$KegaFusionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($KegaFusionLogo)

$KegaFusionCheckbox = New-Object System.Windows.Forms.Checkbox 
$KegaFusionCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$KegaFusionCheckbox.Text = "       Kega Fusion"
$KegaFusionCheckbox.Width = 180
$KegaFusionCheckbox.Height = 20
$KegaFusionCheckbox.Font = $BodyFont
$Tab2.Controls.Add($KegaFusionCheckbox)

$MAMELogo = New-Object System.Windows.Forms.PictureBox
$MAMELogo.Width = 18
$MAMELogo.Height = 18
$MAMELogo.Location = New-Object System.Drawing.Size(30,210)
$MAMELogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MAME.png"
$MAMELogo.ImageLocation = $MAMELogoFile
$MAMELogo.BorderStyle = 0
$MAMELogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MAMELogo)

$MAMECheckbox = New-Object System.Windows.Forms.Checkbox 
$MAMECheckbox.Location = New-Object System.Drawing.Size(10,210) 
$MAMECheckbox.Text = "       MAME"
$MAMECheckbox.Width = 180
$MAMECheckbox.Height = 20
$MAMECheckbox.Font = $BodyFont
$Tab2.Controls.Add($MAMECheckbox)

$NestopiaLogo = New-Object System.Windows.Forms.PictureBox
$NestopiaLogo.Width = 18
$NestopiaLogo.Height = 18
$NestopiaLogo.Location = New-Object System.Drawing.Size(30,230)
$NestopiaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Nestopia.png"
$NestopiaLogo.ImageLocation = $NestopiaLogoFile
$NestopiaLogo.BorderStyle = 0
$NestopiaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($NestopiaLogo)

$NestopiaCheckbox = New-Object System.Windows.Forms.Checkbox 
$NestopiaCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$NestopiaCheckbox.Text = "       Nestopia"
$NestopiaCheckbox.Width = 180
$NestopiaCheckbox.Height = 20
$NestopiaCheckbox.Font = $BodyFont
$Tab2.Controls.Add($NestopiaCheckbox)

$NoxPlayerLogo = New-Object System.Windows.Forms.PictureBox
$NoxPlayerLogo.Width = 18
$NoxPlayerLogo.Height = 18
$NoxPlayerLogo.Location = New-Object System.Drawing.Size(30,250)
$NoxPlayerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\NoxPlayer.png"
$NoxPlayerLogo.ImageLocation = $NoxPlayerLogoFile
$NoxPlayerLogo.BorderStyle = 0
$NoxPlayerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($NoxPlayerLogo)

$NoxPlayerCheckbox = New-Object System.Windows.Forms.Checkbox 
$NoxPlayerCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$NoxPlayerCheckbox.Text = "       NoxPlayer"
$NoxPlayerCheckbox.Width = 180
$NoxPlayerCheckbox.Height = 20
$NoxPlayerCheckbox.Font = $BodyFont
$Tab2.Controls.Add($NoxPlayerCheckbox)

$Emulation2Label = New-Object System.Windows.Forms.Label
$Emulation2Label.Location = New-Object System.Drawing.Size(200,10)
$Emulation2Label.Text = "Emulation 2"
$Emulation2Label.Width = 180
$Emulation2Label.Height = 20
$Emulation2Label.Font = $HeaderFont
$Tab2.Controls.Add($Emulation2Label)

$PCSX2Logo = New-Object System.Windows.Forms.PictureBox
$PCSX2Logo.Width = 18
$PCSX2Logo.Height = 18
$PCSX2Logo.Location = New-Object System.Drawing.Size(220,30)
$PCSX2LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\PCSX2.png"
$PCSX2Logo.ImageLocation = $PCSX2LogoFile
$PCSX2Logo.BorderStyle = 0
$PCSX2Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($PCSX2Logo)

$PCSX2Checkbox = New-Object System.Windows.Forms.Checkbox 
$PCSX2Checkbox.Location = New-Object System.Drawing.Size(200,30) 
$PCSX2Checkbox.Text = "       PCSX2"
$PCSX2Checkbox.Width = 180
$PCSX2Checkbox.Height = 20
$PCSX2Checkbox.Font = $BodyFont
$Tab2.Controls.Add($PCSX2Checkbox)

$PPSSPPLogo = New-Object System.Windows.Forms.PictureBox
$PPSSPPLogo.Width = 18
$PPSSPPLogo.Height = 18
$PPSSPPLogo.Location = New-Object System.Drawing.Size(220,50)
$PPSSPPLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\PPSSPP.png"
$PPSSPPLogo.ImageLocation = $PPSSPPLogoFile
$PPSSPPLogo.BorderStyle = 0
$PPSSPPLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($PPSSPPLogo)

$PPSSPPCheckbox = New-Object System.Windows.Forms.Checkbox 
$PPSSPPCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$PPSSPPCheckbox.Text = "       PPSSPP"
$PPSSPPCheckbox.Width = 180
$PPSSPPCheckbox.Height = 20
$PPSSPPCheckbox.Font = $BodyFont
$Tab2.Controls.Add($PPSSPPCheckbox)

$Project64Logo = New-Object System.Windows.Forms.PictureBox
$Project64Logo.Width = 18
$Project64Logo.Height = 18
$Project64Logo.Location = New-Object System.Drawing.Size(220,70)
$Project64LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Project64.png"
$Project64Logo.ImageLocation = $Project64LogoFile
$Project64Logo.BorderStyle = 0
$Project64Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($Project64Logo)

$Project64Checkbox = New-Object System.Windows.Forms.Checkbox 
$Project64Checkbox.Location = New-Object System.Drawing.Size(200,70) 
$Project64Checkbox.Text = "       Project64"
$Project64Checkbox.Width = 180
$Project64Checkbox.Height = 20
$Project64Checkbox.Font = $BodyFont
$Tab2.Controls.Add($Project64Checkbox)

$RedreamLogo = New-Object System.Windows.Forms.PictureBox
$RedreamLogo.Width = 18
$RedreamLogo.Height = 18
$RedreamLogo.Location = New-Object System.Drawing.Size(220,90)
$RedreamLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Redream.png"
$RedreamLogo.ImageLocation = $RedreamLogoFile
$RedreamLogo.BorderStyle = 0
$RedreamLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RedreamLogo)

$RedreamCheckbox = New-Object System.Windows.Forms.Checkbox 
$RedreamCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$RedreamCheckbox.Text = "       Redream"
$RedreamCheckbox.Width = 180
$RedreamCheckbox.Height = 20
$RedreamCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RedreamCheckbox)

$RetroArchLogo = New-Object System.Windows.Forms.PictureBox
$RetroArchLogo.Width = 18
$RetroArchLogo.Height = 18
$RetroArchLogo.Location = New-Object System.Drawing.Size(220,110)
$RetroArchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RetroArch.png"
$RetroArchLogo.ImageLocation = $RetroArchLogoFile
$RetroArchLogo.BorderStyle = 0
$RetroArchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RetroArchLogo)

$RetroArchCheckbox = New-Object System.Windows.Forms.Checkbox 
$RetroArchCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$RetroArchCheckbox.Text = "       RetroArch"
$RetroArchCheckbox.Width = 180
$RetroArchCheckbox.Height = 20
$RetroArchCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RetroArchCheckbox)

$RPCS3Logo = New-Object System.Windows.Forms.PictureBox
$RPCS3Logo.Width = 18
$RPCS3Logo.Height = 18
$RPCS3Logo.Location = New-Object System.Drawing.Size(220,130)
$RPCS3LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RPCS3.png"
$RPCS3Logo.ImageLocation = $RPCS3LogoFile
$RPCS3Logo.BorderStyle = 0
$RPCS3Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RPCS3Logo)

$RPCS3Checkbox = New-Object System.Windows.Forms.Checkbox 
$RPCS3Checkbox.Location = New-Object System.Drawing.Size(200,130) 
$RPCS3Checkbox.Text = "       RPCS3"
$RPCS3Checkbox.Width = 180
$RPCS3Checkbox.Height = 20
$RPCS3Checkbox.Font = $BodyFont
$Tab2.Controls.Add($RPCS3Checkbox)

$SuyuLogo = New-Object System.Windows.Forms.PictureBox
$SuyuLogo.Width = 18
$SuyuLogo.Height = 18
$SuyuLogo.Location = New-Object System.Drawing.Size(220,150)
$SuyuLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Suyu.png"
$SuyuLogo.ImageLocation = $SuyuLogoFile
$SuyuLogo.BorderStyle = 0
$SuyuLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($SuyuLogo)

$SuyuCheckbox = New-Object System.Windows.Forms.Checkbox 
$SuyuCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$SuyuCheckbox.Text = "       Suyu"
$SuyuCheckbox.Width = 180
$SuyuCheckbox.Height = 20
$SuyuCheckbox.Font = $BodyFont
$Tab2.Controls.Add($SuyuCheckbox)

$VirtualBoxLogo = New-Object System.Windows.Forms.PictureBox
$VirtualBoxLogo.Width = 18
$VirtualBoxLogo.Height = 18
$VirtualBoxLogo.Location = New-Object System.Drawing.Size(220,170)
$VirtualBoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\VirtualBox.png"
$VirtualBoxLogo.ImageLocation = $VirtualBoxLogoFile
$VirtualBoxLogo.BorderStyle = 0
$VirtualBoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($VirtualBoxLogo)

$VirtualBoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$VirtualBoxCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$VirtualBoxCheckbox.Text = "       VirtualBox"
$VirtualBoxCheckbox.Width = 180
$VirtualBoxCheckbox.Height = 20
$VirtualBoxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($VirtualBoxCheckbox)

$VisualBoyAdvanceLogo = New-Object System.Windows.Forms.PictureBox
$VisualBoyAdvanceLogo.Width = 18
$VisualBoyAdvanceLogo.Height = 18
$VisualBoyAdvanceLogo.Location = New-Object System.Drawing.Size(220,190)
$VisualBoyAdvanceLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\VisualBoyAdvance.png"
$VisualBoyAdvanceLogo.ImageLocation = $VisualBoyAdvanceLogoFile
$VisualBoyAdvanceLogo.BorderStyle = 0
$VisualBoyAdvanceLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($VisualBoyAdvanceLogo)

$VisualBoyAdvanceCheckbox = New-Object System.Windows.Forms.Checkbox 
$VisualBoyAdvanceCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$VisualBoyAdvanceCheckbox.Text = "       VisualBoyAdvance"
$VisualBoyAdvanceCheckbox.Width = 180
$VisualBoyAdvanceCheckbox.Height = 20
$VisualBoyAdvanceCheckbox.Font = $BodyFont
$Tab2.Controls.Add($VisualBoyAdvanceCheckbox)

$XemuLogo = New-Object System.Windows.Forms.PictureBox
$XemuLogo.Width = 18
$XemuLogo.Height = 18
$XemuLogo.Location = New-Object System.Drawing.Size(220,210)
$XemuLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Xemu.png"
$XemuLogo.ImageLocation = $XemuLogoFile
$XemuLogo.BorderStyle = 0
$XemuLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($XemuLogo)

$XemuCheckbox = New-Object System.Windows.Forms.Checkbox 
$XemuCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$XemuCheckbox.Text = "       Xemu"
$XemuCheckbox.Width = 180
$XemuCheckbox.Height = 20
$XemuCheckbox.Font = $BodyFont
$Tab2.Controls.Add($XemuCheckbox)

$XeniaLogo = New-Object System.Windows.Forms.PictureBox
$XeniaLogo.Width = 18
$XeniaLogo.Height = 18
$XeniaLogo.Location = New-Object System.Drawing.Size(220,230)
$XeniaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Xenia.png"
$XeniaLogo.ImageLocation = $XeniaLogoFile
$XeniaLogo.BorderStyle = 0
$XeniaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($XeniaLogo)

$XeniaCheckbox = New-Object System.Windows.Forms.Checkbox 
$XeniaCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$XeniaCheckbox.Text = "       Xenia"
$XeniaCheckbox.Width = 180
$XeniaCheckbox.Height = 20
$XeniaCheckbox.Font = $BodyFont
$Tab2.Controls.Add($XeniaCheckbox)

$YabauseLogo = New-Object System.Windows.Forms.PictureBox
$YabauseLogo.Width = 18
$YabauseLogo.Height = 18
$YabauseLogo.Location = New-Object System.Drawing.Size(220,250)
$YabauseLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Yabause.png"
$YabauseLogo.ImageLocation = $YabauseLogoFile
$YabauseLogo.BorderStyle = 0
$YabauseLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($YabauseLogo)

$YabauseCheckbox = New-Object System.Windows.Forms.Checkbox 
$YabauseCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$YabauseCheckbox.Text = "       Yabause"
$YabauseCheckbox.Width = 180
$YabauseCheckbox.Height = 20
$YabauseCheckbox.Font = $BodyFont
$Tab2.Controls.Add($YabauseCheckbox)

$FrontendLabel = New-Object System.Windows.Forms.Label
$FrontendLabel.Location = New-Object System.Drawing.Size(390,10)
$FrontendLabel.Text = "Frontend"
$FrontendLabel.Width = 180
$FrontendLabel.Height = 20
$FrontendLabel.Font = $HeaderFont
$Tab2.Controls.Add($FrontendLabel)

$EmulationStationLogo = New-Object System.Windows.Forms.PictureBox
$EmulationStationLogo.Width = 18
$EmulationStationLogo.Height = 18
$EmulationStationLogo.Location = New-Object System.Drawing.Size(410,30)
$EmulationStationLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\EmulationStation.png"
$EmulationStationLogo.ImageLocation = $EmulationStationLogoFile
$EmulationStationLogo.BorderStyle = 0
$EmulationStationLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EmulationStationLogo)

$EmulationStationCheckbox = New-Object System.Windows.Forms.Checkbox 
$EmulationStationCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$EmulationStationCheckbox.Text = "       Emulation Station"
$EmulationStationCheckbox.Width = 180
$EmulationStationCheckbox.Height = 20
$EmulationStationCheckbox.Font = $BodyFont
$Tab2.Controls.Add($EmulationStationCheckbox)

$LaunchBoxLogo = New-Object System.Windows.Forms.PictureBox
$LaunchBoxLogo.Width = 18
$LaunchBoxLogo.Height = 18
$LaunchBoxLogo.Location = New-Object System.Drawing.Size(410,50)
$LaunchBoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\LaunchBox.png"
$LaunchBoxLogo.ImageLocation = $LaunchBoxLogoFile
$LaunchBoxLogo.BorderStyle = 0
$LaunchBoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($LaunchBoxLogo)

$LaunchBoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$LaunchBoxCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$LaunchBoxCheckbox.Text = "       LaunchBox"
$LaunchBoxCheckbox.Width = 180
$LaunchBoxCheckbox.Height = 20
$LaunchBoxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($LaunchBoxCheckbox)

$PlayniteLogo = New-Object System.Windows.Forms.PictureBox
$PlayniteLogo.Width = 18
$PlayniteLogo.Height = 18
$PlayniteLogo.Location = New-Object System.Drawing.Size(410,70)
$PlayniteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Playnite.png"
$PlayniteLogo.ImageLocation = $PlayniteLogoFile
$PlayniteLogo.BorderStyle = 0
$PlayniteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($PlayniteLogo)

$PlayniteCheckbox = New-Object System.Windows.Forms.Checkbox 
$PlayniteCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$PlayniteCheckbox.Text = "       Playnite"
$PlayniteCheckbox.Width = 180
$PlayniteCheckbox.Height = 20
$PlayniteCheckbox.Font = $BodyFont
$Tab2.Controls.Add($PlayniteCheckbox)

$RetroArchLogo = New-Object System.Windows.Forms.PictureBox
$RetroArchLogo.Width = 18
$RetroArchLogo.Height = 18
$RetroArchLogo.Location = New-Object System.Drawing.Size(410,90)
$RetroArchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RetroArch.png"
$RetroArchLogo.ImageLocation = $RetroArchLogoFile
$RetroArchLogo.BorderStyle = 0
$RetroArchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RetroArchLogo)

$RetroArchCheckbox = New-Object System.Windows.Forms.Checkbox 
$RetroArchCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$RetroArchCheckbox.Text = "       RetroArch"
$RetroArchCheckbox.Width = 180
$RetroArchCheckbox.Height = 20
$RetroArchCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RetroArchCheckbox)

$GameBoosterLabel = New-Object System.Windows.Forms.Label
$GameBoosterLabel.Location = New-Object System.Drawing.Size(390,130)
$GameBoosterLabel.Text = "Game Booster"
$GameBoosterLabel.Width = 180
$GameBoosterLabel.Height = 20
$GameBoosterLabel.Font = $HeaderFont
$Tab2.Controls.Add($GameBoosterLabel)

$RazerCortexLogo = New-Object System.Windows.Forms.PictureBox
$RazerCortexLogo.Width = 18
$RazerCortexLogo.Height = 18
$RazerCortexLogo.Location = New-Object System.Drawing.Size(410,150)
$RazerCortexLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\RazerCortex.png"
$RazerCortexLogo.ImageLocation = $RazerCortexLogoFile
$RazerCortexLogo.BorderStyle = 0
$RazerCortexLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RazerCortexLogo)

$RazerCortexCheckbox = New-Object System.Windows.Forms.Checkbox 
$RazerCortexCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$RazerCortexCheckbox.Text = "       RazerCortex"
$RazerCortexCheckbox.Width = 180
$RazerCortexCheckbox.Height = 20
$RazerCortexCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RazerCortexCheckbox)

$WiseGameBoosterLogo = New-Object System.Windows.Forms.PictureBox
$WiseGameBoosterLogo.Width = 18
$WiseGameBoosterLogo.Height = 18
$WiseGameBoosterLogo.Location = New-Object System.Drawing.Size(410,170)
$WiseGameBoosterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\WiseGameBooster.png"
$WiseGameBoosterLogo.ImageLocation = $WiseGameBoosterLogoFile
$WiseGameBoosterLogo.BorderStyle = 0
$WiseGameBoosterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($WiseGameBoosterLogo)

$WiseGameBoosterCheckbox = New-Object System.Windows.Forms.Checkbox 
$WiseGameBoosterCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$WiseGameBoosterCheckbox.Text = "       WiseGameBooster"
$WiseGameBoosterCheckbox.Width = 180
$WiseGameBoosterCheckbox.Height = 20
$WiseGameBoosterCheckbox.Font = $BodyFont
$Tab2.Controls.Add($WiseGameBoosterCheckbox)

$GamesLabel = New-Object System.Windows.Forms.Label
$GamesLabel.Location = New-Object System.Drawing.Size(390,210)
$GamesLabel.Text = "Games"
$GamesLabel.Width = 180
$GamesLabel.Height = 20
$GamesLabel.Font = $HeaderFont
$Tab2.Controls.Add($GamesLabel)

$LoLLogo = New-Object System.Windows.Forms.PictureBox
$LoLLogo.Width = 18
$LoLLogo.Height = 18
$LoLLogo.Location = New-Object System.Drawing.Size(410,230)
$LoLLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\LoL.png"
$LoLLogo.ImageLocation = $LoLLogoFile
$LoLLogo.BorderStyle = 0
$LoLLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($LoLLogo)

$LoLCheckbox = New-Object System.Windows.Forms.Checkbox 
$LoLCheckbox.Location = New-Object System.Drawing.Size(390,230) 
$LoLCheckbox.Text = "       LoL"
$LoLCheckbox.Width = 180
$LoLCheckbox.Height = 20
$LoLCheckbox.Font = $BodyFont
$Tab2.Controls.Add($LoLCheckbox)

$MTGArenaLogo = New-Object System.Windows.Forms.PictureBox
$MTGArenaLogo.Width = 18
$MTGArenaLogo.Height = 18
$MTGArenaLogo.Location = New-Object System.Drawing.Size(410,250)
$MTGArenaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MTGArena.png"
$MTGArenaLogo.ImageLocation = $MTGArenaLogoFile
$MTGArenaLogo.BorderStyle = 0
$MTGArenaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MTGArenaLogo)

$MTGArenaCheckbox = New-Object System.Windows.Forms.Checkbox 
$MTGArenaCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$MTGArenaCheckbox.Text = "       MTG Arena"
$MTGArenaCheckbox.Width = 180
$MTGArenaCheckbox.Height = 20
$MTGArenaCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MTGArenaCheckbox)

$MTGOLogo = New-Object System.Windows.Forms.PictureBox
$MTGOLogo.Width = 18
$MTGOLogo.Height = 18
$MTGOLogo.Location = New-Object System.Drawing.Size(410,270)
$MTGOLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\MTGO.png"
$MTGOLogo.ImageLocation = $MTGOLogoFile
$MTGOLogo.BorderStyle = 0
$MTGOLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MTGOLogo)

$MTGOCheckbox = New-Object System.Windows.Forms.Checkbox 
$MTGOCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$MTGOCheckbox.Text = "       MTGO"
$MTGOCheckbox.Width = 180
$MTGOCheckbox.Height = 20
$MTGOCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MTGOCheckbox)

$RobloxLogo = New-Object System.Windows.Forms.PictureBox
$RobloxLogo.Width = 18
$RobloxLogo.Height = 18
$RobloxLogo.Location = New-Object System.Drawing.Size(410,290)
$RobloxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Roblox.png"
$RobloxLogo.ImageLocation = $RobloxLogoFile
$RobloxLogo.BorderStyle = 0
$RobloxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RobloxLogo)

$RobloxCheckbox = New-Object System.Windows.Forms.Checkbox 
$RobloxCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$RobloxCheckbox.Text = "       Roblox"
$RobloxCheckbox.Width = 180
$RobloxCheckbox.Height = 20
$RobloxCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RobloxCheckbox)

$ValorantLogo = New-Object System.Windows.Forms.PictureBox
$ValorantLogo.Width = 18
$ValorantLogo.Height = 18
$ValorantLogo.Location = New-Object System.Drawing.Size(410,310)
$ValorantLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Valorant.png"
$ValorantLogo.ImageLocation = $ValorantLogoFile
$ValorantLogo.BorderStyle = 0
$ValorantLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($ValorantLogo)

$ValorantCheckbox = New-Object System.Windows.Forms.Checkbox 
$ValorantCheckbox.Location = New-Object System.Drawing.Size(390,310) 
$ValorantCheckbox.Text = "       Valorant"
$ValorantCheckbox.Width = 180
$ValorantCheckbox.Height = 20
$ValorantCheckbox.Font = $BodyFont
$Tab2.Controls.Add($ValorantCheckbox)

$LauncherLabel = New-Object System.Windows.Forms.Label
$LauncherLabel.Location = New-Object System.Drawing.Size(580,10)
$LauncherLabel.Text = "Launcher"
$LauncherLabel.Width = 180
$LauncherLabel.Height = 20
$LauncherLabel.Font = $HeaderFont
$Tab2.Controls.Add($LauncherLabel)

$BattleLogo = New-Object System.Windows.Forms.PictureBox
$BattleLogo.Width = 18
$BattleLogo.Height = 18
$BattleLogo.Location = New-Object System.Drawing.Size(600,30)
$BattleLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Battle.png"
$BattleLogo.ImageLocation = $BattleLogoFile
$BattleLogo.BorderStyle = 0
$BattleLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BattleLogo)

$BattleCheckbox = New-Object System.Windows.Forms.Checkbox 
$BattleCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$BattleCheckbox.Text = "       Battle.net"
$BattleCheckbox.Width = 180
$BattleCheckbox.Height = 20
$BattleCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BattleCheckbox)

$EALogo = New-Object System.Windows.Forms.PictureBox
$EALogo.Width = 18
$EALogo.Height = 18
$EALogo.Location = New-Object System.Drawing.Size(600,50)
$EALogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\EA.png"
$EALogo.ImageLocation = $EALogoFile
$EALogo.BorderStyle = 0
$EALogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EALogo)

$EACheckbox = New-Object System.Windows.Forms.Checkbox 
$EACheckbox.Location = New-Object System.Drawing.Size(580,50) 
$EACheckbox.Text = "       EA Desktop"
$EACheckbox.Width = 180
$EACheckbox.Height = 20
$EACheckbox.Font = $BodyFont
$Tab2.Controls.Add($EACheckbox)

$EpicGamesLogo = New-Object System.Windows.Forms.PictureBox
$EpicGamesLogo.Width = 18
$EpicGamesLogo.Height = 18
$EpicGamesLogo.Location = New-Object System.Drawing.Size(600,70)
$EpicGamesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\EpicGames.png"
$EpicGamesLogo.ImageLocation = $EpicGamesLogoFile
$EpicGamesLogo.BorderStyle = 0
$EpicGamesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($EpicGamesLogo)

$EpicGamesCheckbox = New-Object System.Windows.Forms.Checkbox 
$EpicGamesCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$EpicGamesCheckbox.Text = "       Epic Games"
$EpicGamesCheckbox.Width = 180
$EpicGamesCheckbox.Height = 20
$EpicGamesCheckbox.Font = $BodyFont
$Tab2.Controls.Add($EpicGamesCheckbox)

$MinecraftLogo = New-Object System.Windows.Forms.PictureBox
$MinecraftLogo.Width = 18
$MinecraftLogo.Height = 18
$MinecraftLogo.Location = New-Object System.Drawing.Size(600,90)
$MinecraftLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Minecraft.png"
$MinecraftLogo.ImageLocation = $MinecraftLogoFile
$MinecraftLogo.BorderStyle = 0
$MinecraftLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($MinecraftLogo)

$MinecraftCheckbox = New-Object System.Windows.Forms.Checkbox 
$MinecraftCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$MinecraftCheckbox.Text = "       Minecraft"
$MinecraftCheckbox.Width = 180
$MinecraftCheckbox.Height = 20
$MinecraftCheckbox.Font = $BodyFont
$Tab2.Controls.Add($MinecraftCheckbox)

$RockstarLogo = New-Object System.Windows.Forms.PictureBox
$RockstarLogo.Width = 18
$RockstarLogo.Height = 18
$RockstarLogo.Location = New-Object System.Drawing.Size(600,110)
$RockstarLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Rockstar.png"
$RockstarLogo.ImageLocation = $RockstarLogoFile
$RockstarLogo.BorderStyle = 0
$RockstarLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RockstarLogo)

$RockstarCheckbox = New-Object System.Windows.Forms.Checkbox 
$RockstarCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$RockstarCheckbox.Text = "       Rockstar"
$RockstarCheckbox.Width = 180
$RockstarCheckbox.Height = 20
$RockstarCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RockstarCheckbox)

$SteamLogo = New-Object System.Windows.Forms.PictureBox
$SteamLogo.Width = 18
$SteamLogo.Height = 18
$SteamLogo.Location = New-Object System.Drawing.Size(600,130)
$SteamLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Steam.png"
$SteamLogo.ImageLocation = $SteamLogoFile
$SteamLogo.BorderStyle = 0
$SteamLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($SteamLogo)

$SteamCheckbox = New-Object System.Windows.Forms.Checkbox 
$SteamCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$SteamCheckbox.Text = "       Steam"
$SteamCheckbox.Width = 180
$SteamCheckbox.Height = 20
$SteamCheckbox.Font = $BodyFont
$Tab2.Controls.Add($SteamCheckbox)

$UbisoftConnectLogo = New-Object System.Windows.Forms.PictureBox
$UbisoftConnectLogo.Width = 18
$UbisoftConnectLogo.Height = 18
$UbisoftConnectLogo.Location = New-Object System.Drawing.Size(600,150)
$UbisoftConnectLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\UbisoftConnect.png"
$UbisoftConnectLogo.ImageLocation = $UbisoftConnectLogoFile
$UbisoftConnectLogo.BorderStyle = 0
$UbisoftConnectLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($UbisoftConnectLogo)

$UbisoftConnectCheckbox = New-Object System.Windows.Forms.Checkbox 
$UbisoftConnectCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$UbisoftConnectCheckbox.Text = "       Ubisoft Connect"
$UbisoftConnectCheckbox.Width = 180
$UbisoftConnectCheckbox.Height = 20
$UbisoftConnectCheckbox.Font = $BodyFont
$Tab2.Controls.Add($UbisoftConnectCheckbox)

$ModsLabel = New-Object System.Windows.Forms.Label
$ModsLabel.Location = New-Object System.Drawing.Size(770,10)
$ModsLabel.Text = "Mods"
$ModsLabel.Width = 180
$ModsLabel.Height = 20
$ModsLabel.Font = $HeaderFont
$Tab2.Controls.Add($ModsLabel)

$BakkesModLogo = New-Object System.Windows.Forms.PictureBox
$BakkesModLogo.Width = 18
$BakkesModLogo.Height = 18
$BakkesModLogo.Location = New-Object System.Drawing.Size(790,30)
$BakkesModLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\BakkesMod.png"
$BakkesModLogo.ImageLocation = $BakkesModLogoFile
$BakkesModLogo.BorderStyle = 0
$BakkesModLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BakkesModLogo)

$BakkesModCheckbox = New-Object System.Windows.Forms.Checkbox 
$BakkesModCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$BakkesModCheckbox.Text = "       BakkesMod"
$BakkesModCheckbox.Width = 180
$BakkesModCheckbox.Height = 20
$BakkesModCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BakkesModCheckbox)

$BrutalDoomLogo = New-Object System.Windows.Forms.PictureBox
$BrutalDoomLogo.Width = 18
$BrutalDoomLogo.Height = 18
$BrutalDoomLogo.Location = New-Object System.Drawing.Size(790,50)
$BrutalDoomLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\BrutalDoom.png"
$BrutalDoomLogo.ImageLocation = $BrutalDoomLogoFile
$BrutalDoomLogo.BorderStyle = 0
$BrutalDoomLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($BrutalDoomLogo)

$BrutalDoomCheckbox = New-Object System.Windows.Forms.Checkbox 
$BrutalDoomCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$BrutalDoomCheckbox.Text = "       Brutal Doom"
$BrutalDoomCheckbox.Width = 180
$BrutalDoomCheckbox.Height = 20
$BrutalDoomCheckbox.Font = $BodyFont
$Tab2.Controls.Add($BrutalDoomCheckbox)

$CheatEngineLogo = New-Object System.Windows.Forms.PictureBox
$CheatEngineLogo.Width = 18
$CheatEngineLogo.Height = 18
$CheatEngineLogo.Location = New-Object System.Drawing.Size(790,70)
$CheatEngineLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\CheatEngine.png"
$CheatEngineLogo.ImageLocation = $CheatEngineLogoFile
$CheatEngineLogo.BorderStyle = 0
$CheatEngineLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CheatEngineLogo)

$CheatEngineCheckbox = New-Object System.Windows.Forms.Checkbox 
$CheatEngineCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$CheatEngineCheckbox.Text = "       Cheat Engine"
$CheatEngineCheckbox.Width = 180
$CheatEngineCheckbox.Height = 20
$CheatEngineCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CheatEngineCheckbox)

$CurseForgeLogo = New-Object System.Windows.Forms.PictureBox
$CurseForgeLogo.Width = 18
$CurseForgeLogo.Height = 18
$CurseForgeLogo.Location = New-Object System.Drawing.Size(790,90)
$CurseForgeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\CurseForge.png"
$CurseForgeLogo.ImageLocation = $CurseForgeLogoFile
$CurseForgeLogo.BorderStyle = 0
$CurseForgeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($CurseForgeLogo)

$CurseForgeCheckbox = New-Object System.Windows.Forms.Checkbox 
$CurseForgeCheckbox.Location = New-Object System.Drawing.Size(770,90) 
$CurseForgeCheckbox.Text = "       CurseForge"
$CurseForgeCheckbox.Width = 180
$CurseForgeCheckbox.Height = 20
$CurseForgeCheckbox.Font = $BodyFont
$Tab2.Controls.Add($CurseForgeCheckbox)

$DoomInfiniteLogo = New-Object System.Windows.Forms.PictureBox
$DoomInfiniteLogo.Width = 18
$DoomInfiniteLogo.Height = 18
$DoomInfiniteLogo.Location = New-Object System.Drawing.Size(790,110)
$DoomInfiniteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DoomInfinite.png"
$DoomInfiniteLogo.ImageLocation = $DoomInfiniteLogoFile
$DoomInfiniteLogo.BorderStyle = 0
$DoomInfiniteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DoomInfiniteLogo)

$DoomInfiniteCheckbox = New-Object System.Windows.Forms.Checkbox 
$DoomInfiniteCheckbox.Location = New-Object System.Drawing.Size(770,110) 
$DoomInfiniteCheckbox.Text = "       Doom Infinite"
$DoomInfiniteCheckbox.Width = 180
$DoomInfiniteCheckbox.Height = 20
$DoomInfiniteCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DoomInfiniteCheckbox)

$FiveMLogo = New-Object System.Windows.Forms.PictureBox
$FiveMLogo.Width = 18
$FiveMLogo.Height = 18
$FiveMLogo.Location = New-Object System.Drawing.Size(790,130)
$FiveMLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\FiveM.png"
$FiveMLogo.ImageLocation = $FiveMLogoFile
$FiveMLogo.BorderStyle = 0
$FiveMLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($FiveMLogo)

$FiveMCheckbox = New-Object System.Windows.Forms.Checkbox 
$FiveMCheckbox.Location = New-Object System.Drawing.Size(770,130) 
$FiveMCheckbox.Text = "       FiveM"
$FiveMCheckbox.Width = 180
$FiveMCheckbox.Height = 20
$FiveMCheckbox.Font = $BodyFont
$Tab2.Controls.Add($FiveMCheckbox)

$TModLoaderLogo = New-Object System.Windows.Forms.PictureBox
$TModLoaderLogo.Width = 18
$TModLoaderLogo.Height = 18
$TModLoaderLogo.Location = New-Object System.Drawing.Size(790,150)
$TModLoaderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\TModLoader.png"
$TModLoaderLogo.ImageLocation = $TModLoaderLogoFile
$TModLoaderLogo.BorderStyle = 0
$TModLoaderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($TModLoaderLogo)

$TModLoaderCheckbox = New-Object System.Windows.Forms.Checkbox 
$TModLoaderCheckbox.Location = New-Object System.Drawing.Size(770,150) 
$TModLoaderCheckbox.Text = "       TModLoader"
$TModLoaderCheckbox.Width = 180
$TModLoaderCheckbox.Height = 20
$TModLoaderCheckbox.Font = $BodyFont
$Tab2.Controls.Add($TModLoaderCheckbox)

$RandomizersLogo = New-Object System.Windows.Forms.PictureBox
$RandomizersLogo.Width = 18
$RandomizersLogo.Height = 18
$RandomizersLogo.Location = New-Object System.Drawing.Size(790,170)
$RandomizersLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Randomizers.png"
$RandomizersLogo.ImageLocation = $RandomizersLogoFile
$RandomizersLogo.BorderStyle = 0
$RandomizersLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($RandomizersLogo)

$RandomizersCheckbox = New-Object System.Windows.Forms.Checkbox 
$RandomizersCheckbox.Location = New-Object System.Drawing.Size(770,170) 
$RandomizersCheckbox.Text = "       Randomizers"
$RandomizersCheckbox.Width = 180
$RandomizersCheckbox.Height = 20
$RandomizersCheckbox.Font = $BodyFont
$Tab2.Controls.Add($RandomizersCheckbox)

$VortexLogo = New-Object System.Windows.Forms.PictureBox
$VortexLogo.Width = 18
$VortexLogo.Height = 18
$VortexLogo.Location = New-Object System.Drawing.Size(790,190)
$VortexLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Vortex.png"
$VortexLogo.ImageLocation = $VortexLogoFile
$VortexLogo.BorderStyle = 0
$VortexLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($VortexLogo)

$VortexCheckbox = New-Object System.Windows.Forms.Checkbox 
$VortexCheckbox.Location = New-Object System.Drawing.Size(770,190) 
$VortexCheckbox.Text = "       Vortex"
$VortexCheckbox.Width = 180
$VortexCheckbox.Height = 20
$VortexCheckbox.Font = $BodyFont
$Tab2.Controls.Add($VortexCheckbox)

$WeModLogo = New-Object System.Windows.Forms.PictureBox
$WeModLogo.Width = 18
$WeModLogo.Height = 18
$WeModLogo.Location = New-Object System.Drawing.Size(790,210)
$WeModLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\WeMod.png"
$WeModLogo.ImageLocation = $WeModLogoFile
$WeModLogo.BorderStyle = 0
$WeModLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($WeModLogo)

$WeModCheckbox = New-Object System.Windows.Forms.Checkbox 
$WeModCheckbox.Location = New-Object System.Drawing.Size(770,210) 
$WeModCheckbox.Text = "       WeMod"
$WeModCheckbox.Width = 180
$WeModCheckbox.Height = 20
$WeModCheckbox.Font = $BodyFont
$Tab2.Controls.Add($WeModCheckbox)

$SpeedrunLabel = New-Object System.Windows.Forms.Label
$SpeedrunLabel.Location = New-Object System.Drawing.Size(960,10)
$SpeedrunLabel.Text = "Speedrun"
$SpeedrunLabel.Width = 180
$SpeedrunLabel.Height = 20
$SpeedrunLabel.Font = $HeaderFont
$Tab2.Controls.Add($SpeedrunLabel)

$LiveSplitLogo = New-Object System.Windows.Forms.PictureBox
$LiveSplitLogo.Width = 18
$LiveSplitLogo.Height = 18
$LiveSplitLogo.Location = New-Object System.Drawing.Size(980,30)
$LiveSplitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\LiveSplit.png"
$LiveSplitLogo.ImageLocation = $LiveSplitLogoFile
$LiveSplitLogo.BorderStyle = 0
$LiveSplitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($LiveSplitLogo)

$LiveSplitCheckbox = New-Object System.Windows.Forms.Checkbox 
$LiveSplitCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$LiveSplitCheckbox.Text = "       LiveSplit"
$LiveSplitCheckbox.Width = 180
$LiveSplitCheckbox.Height = 20
$LiveSplitCheckbox.Font = $BodyFont
$Tab2.Controls.Add($LiveSplitCheckbox)

$ToolsLabel = New-Object System.Windows.Forms.Label
$ToolsLabel.Location = New-Object System.Drawing.Size(960,70)
$ToolsLabel.Text = "Tools"
$ToolsLabel.Width = 180
$ToolsLabel.Height = 20
$ToolsLabel.Font = $HeaderFont
$Tab2.Controls.Add($ToolsLabel)

$AntiMicroXLogo = New-Object System.Windows.Forms.PictureBox
$AntiMicroXLogo.Width = 18
$AntiMicroXLogo.Height = 18
$AntiMicroXLogo.Location = New-Object System.Drawing.Size(980,90)
$AntiMicroXLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\AntiMicroX.png"
$AntiMicroXLogo.ImageLocation = $AntiMicroXLogoFile
$AntiMicroXLogo.BorderStyle = 0
$AntiMicroXLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($AntiMicroXLogo)

$AntiMicroXCheckbox = New-Object System.Windows.Forms.Checkbox 
$AntiMicroXCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$AntiMicroXCheckbox.Text = "       AntiMicroX"
$AntiMicroXCheckbox.Width = 180
$AntiMicroXCheckbox.Height = 20
$AntiMicroXCheckbox.Font = $BodyFont
$Tab2.Controls.Add($AntiMicroXCheckbox)

$DS4WindowsLogo = New-Object System.Windows.Forms.PictureBox
$DS4WindowsLogo.Width = 18
$DS4WindowsLogo.Height = 18
$DS4WindowsLogo.Location = New-Object System.Drawing.Size(980,110)
$DS4WindowsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\DS4Windows.png"
$DS4WindowsLogo.ImageLocation = $DS4WindowsLogoFile
$DS4WindowsLogo.BorderStyle = 0
$DS4WindowsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($DS4WindowsLogo)

$DS4WindowsCheckbox = New-Object System.Windows.Forms.Checkbox 
$DS4WindowsCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$DS4WindowsCheckbox.Text = "       DS4Windows"
$DS4WindowsCheckbox.Width = 180
$DS4WindowsCheckbox.Height = 20
$DS4WindowsCheckbox.Font = $BodyFont
$Tab2.Controls.Add($DS4WindowsCheckbox)

$SpecialKLogo = New-Object System.Windows.Forms.PictureBox
$SpecialKLogo.Width = 18
$SpecialKLogo.Height = 18
$SpecialKLogo.Location = New-Object System.Drawing.Size(980,130)
$SpecialKLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\SpecialK.png"
$SpecialKLogo.ImageLocation = $SpecialKLogoFile
$SpecialKLogo.BorderStyle = 0
$SpecialKLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($SpecialKLogo)

$SpecialKCheckbox = New-Object System.Windows.Forms.Checkbox 
$SpecialKCheckbox.Location = New-Object System.Drawing.Size(960,130) 
$SpecialKCheckbox.Text = "       Special K"
$SpecialKCheckbox.Width = 180
$SpecialKCheckbox.Height = 20
$SpecialKCheckbox.Font = $BodyFont
$Tab2.Controls.Add($SpecialKCheckbox)

$VirtualLANLabel = New-Object System.Windows.Forms.Label
$VirtualLANLabel.Location = New-Object System.Drawing.Size(960,170)
$VirtualLANLabel.Text = "Virtual LAN"
$VirtualLANLabel.Width = 180
$VirtualLANLabel.Height = 20
$VirtualLANLabel.Font = $HeaderFont
$Tab2.Controls.Add($VirtualLANLabel)

$HamachiLogo = New-Object System.Windows.Forms.PictureBox
$HamachiLogo.Width = 18
$HamachiLogo.Height = 18
$HamachiLogo.Location = New-Object System.Drawing.Size(980,190)
$HamachiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Gaming\Hamachi.png"
$HamachiLogo.ImageLocation = $HamachiLogoFile
$HamachiLogo.BorderStyle = 0
$HamachiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab2.Controls.Add($HamachiLogo)

$HamachiCheckbox = New-Object System.Windows.Forms.Checkbox 
$HamachiCheckbox.Location = New-Object System.Drawing.Size(960,190) 
$HamachiCheckbox.Text = "       Hamachi"
$HamachiCheckbox.Width = 180
$HamachiCheckbox.Height = 20
$HamachiCheckbox.Font = $BodyFont
$Tab2.Controls.Add($HamachiCheckbox)

# Tab 3 DEVELOPING
$Tab3 = New-Object System.Windows.Forms.TabPage
$Tab3.Text = "Developing"
$Tab3.Font = $TabFont
$Tab3.Autoscroll  = $True
$TabControl.Controls.Add($Tab3)

$DatabaseLabel = New-Object System.Windows.Forms.Label
$DatabaseLabel.Location = New-Object System.Drawing.Size(10,10)
$DatabaseLabel.Text = "Database"
$DatabaseLabel.Width = 180
$DatabaseLabel.Height = 20
$DatabaseLabel.Font = $HeaderFont
$Tab3.Controls.Add($DatabaseLabel)

$MongoDBLogo = New-Object System.Windows.Forms.PictureBox
$MongoDBLogo.Width = 18
$MongoDBLogo.Height = 18
$MongoDBLogo.Location = New-Object System.Drawing.Size(30,30)
$MongoDBLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\MongoDB.png"
$MongoDBLogo.ImageLocation = $MongoDBLogoFile
$MongoDBLogo.BorderStyle = 0
$MongoDBLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($MongoDBLogo)

$MongoDBCheckbox = New-Object System.Windows.Forms.Checkbox 
$MongoDBCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$MongoDBCheckbox.Text = "       MongoDB"
$MongoDBCheckbox.Width = 180
$MongoDBCheckbox.Height = 20
$MongoDBCheckbox.Font = $BodyFont
$Tab3.Controls.Add($MongoDBCheckbox)

$MySQLLogo = New-Object System.Windows.Forms.PictureBox
$MySQLLogo.Width = 18
$MySQLLogo.Height = 18
$MySQLLogo.Location = New-Object System.Drawing.Size(30,50)
$MySQLLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\MySQL.png"
$MySQLLogo.ImageLocation = $MySQLLogoFile
$MySQLLogo.BorderStyle = 0
$MySQLLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($MySQLLogo)

$MySQLCheckbox = New-Object System.Windows.Forms.Checkbox 
$MySQLCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$MySQLCheckbox.Text = "       MySQL"
$MySQLCheckbox.Width = 180
$MySQLCheckbox.Height = 20
$MySQLCheckbox.Font = $BodyFont
$Tab3.Controls.Add($MySQLCheckbox)

$PostgreSQLLogo = New-Object System.Windows.Forms.PictureBox
$PostgreSQLLogo.Width = 18
$PostgreSQLLogo.Height = 18
$PostgreSQLLogo.Location = New-Object System.Drawing.Size(30,70)
$PostgreSQLLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PostgreSQL.png"
$PostgreSQLLogo.ImageLocation = $PostgreSQLLogoFile
$PostgreSQLLogo.BorderStyle = 0
$PostgreSQLLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PostgreSQLLogo)

$PostgreSQLCheckbox = New-Object System.Windows.Forms.Checkbox 
$PostgreSQLCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$PostgreSQLCheckbox.Text = "       PostgreSQL"
$PostgreSQLCheckbox.Width = 180
$PostgreSQLCheckbox.Height = 20
$PostgreSQLCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PostgreSQLCheckbox)

$RedisLogo = New-Object System.Windows.Forms.PictureBox
$RedisLogo.Width = 18
$RedisLogo.Height = 18
$RedisLogo.Location = New-Object System.Drawing.Size(30,90)
$RedisLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Redis.png"
$RedisLogo.ImageLocation = $RedisLogoFile
$RedisLogo.BorderStyle = 0
$RedisLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RedisLogo)

$RedisCheckbox = New-Object System.Windows.Forms.Checkbox 
$RedisCheckbox.Location = New-Object System.Drawing.Size(10,90) 
$RedisCheckbox.Text = "       Redis Insite"
$RedisCheckbox.Width = 180
$RedisCheckbox.Height = 20
$RedisCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RedisCheckbox)

$SQLiteLogo = New-Object System.Windows.Forms.PictureBox
$SQLiteLogo.Width = 18
$SQLiteLogo.Height = 18
$SQLiteLogo.Location = New-Object System.Drawing.Size(30,110)
$SQLiteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\SQLite.png"
$SQLiteLogo.ImageLocation = $SQLiteLogoFile
$SQLiteLogo.BorderStyle = 0
$SQLiteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SQLiteLogo)

$SQLiteCheckbox = New-Object System.Windows.Forms.Checkbox 
$SQLiteCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$SQLiteCheckbox.Text = "       SQLite"
$SQLiteCheckbox.Width = 180
$SQLiteCheckbox.Height = 20
$SQLiteCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SQLiteCheckbox)

$GameEnginesLabel = New-Object System.Windows.Forms.Label
$GameEnginesLabel.Location = New-Object System.Drawing.Size(10,150)
$GameEnginesLabel.Text = "Game Engines"
$GameEnginesLabel.Width = 180
$GameEnginesLabel.Height = 20
$GameEnginesLabel.Font = $HeaderFont
$Tab3.Controls.Add($GameEnginesLabel)

$Construct3Logo = New-Object System.Windows.Forms.PictureBox
$Construct3Logo.Width = 18
$Construct3Logo.Height = 18
$Construct3Logo.Location = New-Object System.Drawing.Size(30,170)
$Construct3LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Construct3.png"
$Construct3Logo.ImageLocation = $Construct3LogoFile
$Construct3Logo.BorderStyle = 0
$Construct3Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($Construct3Logo)

$Construct3Checkbox = New-Object System.Windows.Forms.Checkbox 
$Construct3Checkbox.Location = New-Object System.Drawing.Size(10,170) 
$Construct3Checkbox.Text = "       Construct 3"
$Construct3Checkbox.Width = 180
$Construct3Checkbox.Height = 20
$Construct3Checkbox.Font = $BodyFont
$Tab3.Controls.Add($Construct3Checkbox)

$CryEngineLogo = New-Object System.Windows.Forms.PictureBox
$CryEngineLogo.Width = 18
$CryEngineLogo.Height = 18
$CryEngineLogo.Location = New-Object System.Drawing.Size(30,190)
$CryEngineLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\CryEngine.png"
$CryEngineLogo.ImageLocation = $CryEngineLogoFile
$CryEngineLogo.BorderStyle = 0
$CryEngineLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CryEngineLogo)

$CryEngineCheckbox = New-Object System.Windows.Forms.Checkbox 
$CryEngineCheckbox.Location = New-Object System.Drawing.Size(10,190) 
$CryEngineCheckbox.Text = "       CryEngine"
$CryEngineCheckbox.Width = 180
$CryEngineCheckbox.Height = 20
$CryEngineCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CryEngineCheckbox)

$GameMakerLogo = New-Object System.Windows.Forms.PictureBox
$GameMakerLogo.Width = 18
$GameMakerLogo.Height = 18
$GameMakerLogo.Location = New-Object System.Drawing.Size(30,210)
$GameMakerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GameMaker.png"
$GameMakerLogo.ImageLocation = $GameMakerLogoFile
$GameMakerLogo.BorderStyle = 0
$GameMakerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GameMakerLogo)

$GameMakerCheckbox = New-Object System.Windows.Forms.Checkbox 
$GameMakerCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$GameMakerCheckbox.Text = "       GameMaker"
$GameMakerCheckbox.Width = 180
$GameMakerCheckbox.Height = 20
$GameMakerCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GameMakerCheckbox)

$GodotLogo = New-Object System.Windows.Forms.PictureBox
$GodotLogo.Width = 18
$GodotLogo.Height = 18
$GodotLogo.Location = New-Object System.Drawing.Size(30,230)
$GodotLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Godot.png"
$GodotLogo.ImageLocation = $GodotLogoFile
$GodotLogo.BorderStyle = 0
$GodotLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GodotLogo)

$GodotCheckbox = New-Object System.Windows.Forms.Checkbox 
$GodotCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$GodotCheckbox.Text = "       Godot"
$GodotCheckbox.Width = 180
$GodotCheckbox.Height = 20
$GodotCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GodotCheckbox)

$UnityLogo = New-Object System.Windows.Forms.PictureBox
$UnityLogo.Width = 18
$UnityLogo.Height = 18
$UnityLogo.Location = New-Object System.Drawing.Size(30,250)
$UnityLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Unity.png"
$UnityLogo.ImageLocation = $UnityLogoFile
$UnityLogo.BorderStyle = 0
$UnityLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($UnityLogo)

$UnityCheckbox = New-Object System.Windows.Forms.Checkbox 
$UnityCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$UnityCheckbox.Text = "       Unity"
$UnityCheckbox.Width = 180
$UnityCheckbox.Height = 20
$UnityCheckbox.Font = $BodyFont
$Tab3.Controls.Add($UnityCheckbox)

$IDELabel = New-Object System.Windows.Forms.Label
$IDELabel.Location = New-Object System.Drawing.Size(200,10)
$IDELabel.Text = "IDE"
$IDELabel.Width = 180
$IDELabel.Height = 20
$IDELabel.Font = $HeaderFont
$Tab3.Controls.Add($IDELabel)

$AndroidStudioLogo = New-Object System.Windows.Forms.PictureBox
$AndroidStudioLogo.Width = 18
$AndroidStudioLogo.Height = 18
$AndroidStudioLogo.Location = New-Object System.Drawing.Size(220,30)
$AndroidStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\AndroidStudio.png"
$AndroidStudioLogo.ImageLocation = $AndroidStudioLogoFile
$AndroidStudioLogo.BorderStyle = 0
$AndroidStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($AndroidStudioLogo)

$AndroidStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$AndroidStudioCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$AndroidStudioCheckbox.Text = "       Android Studio"
$AndroidStudioCheckbox.Width = 180
$AndroidStudioCheckbox.Height = 20
$AndroidStudioCheckbox.Font = $BodyFont
$Tab3.Controls.Add($AndroidStudioCheckbox)

$CLionLogo = New-Object System.Windows.Forms.PictureBox
$CLionLogo.Width = 18
$CLionLogo.Height = 18
$CLionLogo.Location = New-Object System.Drawing.Size(220,50)
$CLionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\CLion.png"
$CLionLogo.ImageLocation = $CLionLogoFile
$CLionLogo.BorderStyle = 0
$CLionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CLionLogo)

$CLionCheckbox = New-Object System.Windows.Forms.Checkbox 
$CLionCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$CLionCheckbox.Text = "       CLion"
$CLionCheckbox.Width = 180
$CLionCheckbox.Height = 20
$CLionCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CLionCheckbox)

$DataGripLogo = New-Object System.Windows.Forms.PictureBox
$DataGripLogo.Width = 18
$DataGripLogo.Height = 18
$DataGripLogo.Location = New-Object System.Drawing.Size(220,70)
$DataGripLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\DataGrip.png"
$DataGripLogo.ImageLocation = $DataGripLogoFile
$DataGripLogo.BorderStyle = 0
$DataGripLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($DataGripLogo)

$DataGripCheckbox = New-Object System.Windows.Forms.Checkbox 
$DataGripCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$DataGripCheckbox.Text = "       DataGrip"
$DataGripCheckbox.Width = 180
$DataGripCheckbox.Height = 20
$DataGripCheckbox.Font = $BodyFont
$Tab3.Controls.Add($DataGripCheckbox)

$DataSpellLogo = New-Object System.Windows.Forms.PictureBox
$DataSpellLogo.Width = 18
$DataSpellLogo.Height = 18
$DataSpellLogo.Location = New-Object System.Drawing.Size(220,90)
$DataSpellLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\DataSpell.png"
$DataSpellLogo.ImageLocation = $DataSpellLogoFile
$DataSpellLogo.BorderStyle = 0
$DataSpellLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($DataSpellLogo)

$DataSpellCheckbox = New-Object System.Windows.Forms.Checkbox 
$DataSpellCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$DataSpellCheckbox.Text = "       DataSpell"
$DataSpellCheckbox.Width = 180
$DataSpellCheckbox.Height = 20
$DataSpellCheckbox.Font = $BodyFont
$Tab3.Controls.Add($DataSpellCheckbox)

$EclipseLogo = New-Object System.Windows.Forms.PictureBox
$EclipseLogo.Width = 18
$EclipseLogo.Height = 18
$EclipseLogo.Location = New-Object System.Drawing.Size(220,110)
$EclipseLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Eclipse.png"
$EclipseLogo.ImageLocation = $EclipseLogoFile
$EclipseLogo.BorderStyle = 0
$EclipseLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($EclipseLogo)

$EclipseCheckbox = New-Object System.Windows.Forms.Checkbox 
$EclipseCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$EclipseCheckbox.Text = "       Eclipse"
$EclipseCheckbox.Width = 180
$EclipseCheckbox.Height = 20
$EclipseCheckbox.Font = $BodyFont
$Tab3.Controls.Add($EclipseCheckbox)

$GoLandLogo = New-Object System.Windows.Forms.PictureBox
$GoLandLogo.Width = 18
$GoLandLogo.Height = 18
$GoLandLogo.Location = New-Object System.Drawing.Size(220,130)
$GoLandLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GoLand.png"
$GoLandLogo.ImageLocation = $GoLandLogoFile
$GoLandLogo.BorderStyle = 0
$GoLandLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GoLandLogo)

$GoLandCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoLandCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$GoLandCheckbox.Text = "       GoLand"
$GoLandCheckbox.Width = 180
$GoLandCheckbox.Height = 20
$GoLandCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GoLandCheckbox)

$IntelliJLogo = New-Object System.Windows.Forms.PictureBox
$IntelliJLogo.Width = 18
$IntelliJLogo.Height = 18
$IntelliJLogo.Location = New-Object System.Drawing.Size(220,150)
$IntelliJLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\IntelliJ.png"
$IntelliJLogo.ImageLocation = $IntelliJLogoFile
$IntelliJLogo.BorderStyle = 0
$IntelliJLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($IntelliJLogo)

$IntelliJCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelliJCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$IntelliJCheckbox.Text = "       IntelliJ"
$IntelliJCheckbox.Width = 180
$IntelliJCheckbox.Height = 20
$IntelliJCheckbox.Font = $BodyFont
$Tab3.Controls.Add($IntelliJCheckbox)

$JetBrainsToolboxLogo = New-Object System.Windows.Forms.PictureBox
$JetBrainsToolboxLogo.Width = 18
$JetBrainsToolboxLogo.Height = 18
$JetBrainsToolboxLogo.Location = New-Object System.Drawing.Size(220,170)
$JetBrainsToolboxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\JetBrainsToolbox.png"
$JetBrainsToolboxLogo.ImageLocation = $JetBrainsToolboxLogoFile
$JetBrainsToolboxLogo.BorderStyle = 0
$JetBrainsToolboxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JetBrainsToolboxLogo)

$JetBrainsToolboxCheckbox = New-Object System.Windows.Forms.Checkbox 
$JetBrainsToolboxCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$JetBrainsToolboxCheckbox.Text = "       JetBrains Toolbox"
$JetBrainsToolboxCheckbox.Width = 180
$JetBrainsToolboxCheckbox.Height = 20
$JetBrainsToolboxCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JetBrainsToolboxCheckbox)

$NotepadLogo = New-Object System.Windows.Forms.PictureBox
$NotepadLogo.Width = 18
$NotepadLogo.Height = 18
$NotepadLogo.Location = New-Object System.Drawing.Size(220,190)
$NotepadLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Notepad.png"
$NotepadLogo.ImageLocation = $NotepadLogoFile
$NotepadLogo.BorderStyle = 0
$NotepadLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($NotepadLogo)

$NotepadCheckbox = New-Object System.Windows.Forms.Checkbox 
$NotepadCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$NotepadCheckbox.Text = "       Notepad++"
$NotepadCheckbox.Width = 180
$NotepadCheckbox.Height = 20
$NotepadCheckbox.Font = $BodyFont
$Tab3.Controls.Add($NotepadCheckbox)

$PhpStormLogo = New-Object System.Windows.Forms.PictureBox
$PhpStormLogo.Width = 18
$PhpStormLogo.Height = 18
$PhpStormLogo.Location = New-Object System.Drawing.Size(220,210)
$PhpStormLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PhpStorm.png"
$PhpStormLogo.ImageLocation = $PhpStormLogoFile
$PhpStormLogo.BorderStyle = 0
$PhpStormLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PhpStormLogo)

$PhpStormCheckbox = New-Object System.Windows.Forms.Checkbox 
$PhpStormCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$PhpStormCheckbox.Text = "       PhpStorm"
$PhpStormCheckbox.Width = 180
$PhpStormCheckbox.Height = 20
$PhpStormCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PhpStormCheckbox)

$PyCharmLogo = New-Object System.Windows.Forms.PictureBox
$PyCharmLogo.Width = 18
$PyCharmLogo.Height = 18
$PyCharmLogo.Location = New-Object System.Drawing.Size(220,230)
$PyCharmLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PyCharm.png"
$PyCharmLogo.ImageLocation = $PyCharmLogoFile
$PyCharmLogo.BorderStyle = 0
$PyCharmLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PyCharmLogo)

$PyCharmCheckbox = New-Object System.Windows.Forms.Checkbox 
$PyCharmCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$PyCharmCheckbox.Text = "       PyCharm"
$PyCharmCheckbox.Width = 180
$PyCharmCheckbox.Height = 20
$PyCharmCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PyCharmCheckbox)

$RiderLogo = New-Object System.Windows.Forms.PictureBox
$RiderLogo.Width = 18
$RiderLogo.Height = 18
$RiderLogo.Location = New-Object System.Drawing.Size(220,250)
$RiderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Rider.png"
$RiderLogo.ImageLocation = $PyCharmLogoFile
$RiderLogo.BorderStyle = 0
$RiderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RiderLogo)

$RiderCheckbox = New-Object System.Windows.Forms.Checkbox 
$RiderCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$RiderCheckbox.Text = "       Rider"
$RiderCheckbox.Width = 180
$RiderCheckbox.Height = 20
$RiderCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RiderCheckbox)

$RubyMineLogo = New-Object System.Windows.Forms.PictureBox
$RubyMineLogo.Width = 18
$RubyMineLogo.Height = 18
$RubyMineLogo.Location = New-Object System.Drawing.Size(220,270)
$RubyMineLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\RubyMine.png"
$RubyMineLogo.ImageLocation = $RubyMineLogoFile
$RubyMineLogo.BorderStyle = 0
$RubyMineLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RubyMineLogo)

$RubyMineCheckbox = New-Object System.Windows.Forms.Checkbox 
$RubyMineCheckbox.Location = New-Object System.Drawing.Size(200,270) 
$RubyMineCheckbox.Text = "       RubyMine"
$RubyMineCheckbox.Width = 180
$RubyMineCheckbox.Height = 20
$RubyMineCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RubyMineCheckbox)

$SublimeTextLogo = New-Object System.Windows.Forms.PictureBox
$SublimeTextLogo.Width = 18
$SublimeTextLogo.Height = 18
$SublimeTextLogo.Location = New-Object System.Drawing.Size(220,290)
$SublimeTextLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\SublimeText.png"
$SublimeTextLogo.ImageLocation = $SublimeTextLogoFile
$SublimeTextLogo.BorderStyle = 0
$SublimeTextLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SublimeTextLogo)

$SublimeTextCheckbox = New-Object System.Windows.Forms.Checkbox 
$SublimeTextCheckbox.Location = New-Object System.Drawing.Size(200,290) 
$SublimeTextCheckbox.Text = "       Sublime Text"
$SublimeTextCheckbox.Width = 180
$SublimeTextCheckbox.Height = 20
$SublimeTextCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SublimeTextCheckbox)

$VisualStudioLogo = New-Object System.Windows.Forms.PictureBox
$VisualStudioLogo.Width = 18
$VisualStudioLogo.Height = 18
$VisualStudioLogo.Location = New-Object System.Drawing.Size(220,310)
$VisualStudioLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\VisualStudio.png"
$VisualStudioLogo.ImageLocation = $VisualStudioLogoFile
$VisualStudioLogo.BorderStyle = 0
$VisualStudioLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($VisualStudioLogo)

$VisualStudioCheckbox = New-Object System.Windows.Forms.Checkbox 
$VisualStudioCheckbox.Location = New-Object System.Drawing.Size(200,310) 
$VisualStudioCheckbox.Text = "       Visual Studio"
$VisualStudioCheckbox.Width = 180
$VisualStudioCheckbox.Height = 20
$VisualStudioCheckbox.Font = $BodyFont
$Tab3.Controls.Add($VisualStudioCheckbox)

$WebStormLogo = New-Object System.Windows.Forms.PictureBox
$WebStormLogo.Width = 18
$WebStormLogo.Height = 18
$WebStormLogo.Location = New-Object System.Drawing.Size(220,330)
$WebStormLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\WebStorm.png"
$WebStormLogo.ImageLocation = $WebStormLogoFile
$WebStormLogo.BorderStyle = 0
$WebStormLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($WebStormLogo)

$WebStormCheckbox = New-Object System.Windows.Forms.Checkbox 
$WebStormCheckbox.Location = New-Object System.Drawing.Size(200,330) 
$WebStormCheckbox.Text = "       WebStorm"
$WebStormCheckbox.Width = 180
$WebStormCheckbox.Height = 20
$WebStormCheckbox.Font = $BodyFont
$Tab3.Controls.Add($WebStormCheckbox)

$LanguageLabel = New-Object System.Windows.Forms.Label
$LanguageLabel.Location = New-Object System.Drawing.Size(390,10)
$LanguageLabel.Text = "Language"
$LanguageLabel.Width = 180
$LanguageLabel.Height = 20
$LanguageLabel.Font = $HeaderFont
$Tab3.Controls.Add($LanguageLabel)

$GoLogo = New-Object System.Windows.Forms.PictureBox
$GoLogo.Width = 18
$GoLogo.Height = 18
$GoLogo.Location = New-Object System.Drawing.Size(410,30)
$GoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Go.png"
$GoLogo.ImageLocation = $GoLogoFile
$GoLogo.BorderStyle = 0
$GoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GoLogo)

$GoCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$GoCheckbox.Text = "       Go"
$GoCheckbox.Width = 180
$GoCheckbox.Height = 20
$GoCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GoCheckbox)

$JavaJDKLogo = New-Object System.Windows.Forms.PictureBox
$JavaJDKLogo.Width = 18
$JavaJDKLogo.Height = 18
$JavaJDKLogo.Location = New-Object System.Drawing.Size(410,50)
$JavaJDKLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Java.png"
$JavaJDKLogo.ImageLocation = $JavaJDKLogoFile
$JavaJDKLogo.BorderStyle = 0
$JavaJDKLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JavaJDKLogo)

$JavaJDKCheckbox = New-Object System.Windows.Forms.Checkbox 
$JavaJDKCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$JavaJDKCheckbox.Text = "       Java JDK"
$JavaJDKCheckbox.Width = 180
$JavaJDKCheckbox.Height = 20
$JavaJDKCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JavaJDKCheckbox)

$Python3Logo = New-Object System.Windows.Forms.PictureBox
$Python3Logo.Width = 18
$Python3Logo.Height = 18
$Python3Logo.Location = New-Object System.Drawing.Size(410,70)
$Python3LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Python3.png"
$Python3Logo.ImageLocation = $Python3LogoFile
$Python3Logo.BorderStyle = 0
$Python3Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($Python3Logo)

$Python3Checkbox = New-Object System.Windows.Forms.Checkbox 
$Python3Checkbox.Location = New-Object System.Drawing.Size(390,70) 
$Python3Checkbox.Text = "       Python3"
$Python3Checkbox.Width = 180
$Python3Checkbox.Height = 20
$Python3Checkbox.Font = $BodyFont
$Tab3.Controls.Add($Python3Checkbox)

$RLogo = New-Object System.Windows.Forms.PictureBox
$RLogo.Width = 18
$RLogo.Height = 18
$RLogo.Location = New-Object System.Drawing.Size(410,90)
$RLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\R.png"
$RLogo.ImageLocation = $RLogoFile
$RLogo.BorderStyle = 0
$RLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RLogo)

$RCheckbox = New-Object System.Windows.Forms.Checkbox 
$RCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$RCheckbox.Text = "       R"
$RCheckbox.Width = 180
$RCheckbox.Height = 20
$RCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RCheckbox)

$RubyLogo = New-Object System.Windows.Forms.PictureBox
$RubyLogo.Width = 18
$RubyLogo.Height = 18
$RubyLogo.Location = New-Object System.Drawing.Size(410,110)
$RubyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Ruby.png"
$RubyLogo.ImageLocation = $RubyLogoFile
$RubyLogo.BorderStyle = 0
$RubyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RubyLogo)

$RubyCheckbox = New-Object System.Windows.Forms.Checkbox 
$RubyCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$RubyCheckbox.Text = "       Ruby"
$RubyCheckbox.Width = 180
$RubyCheckbox.Height = 20
$RubyCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RubyCheckbox)

$RustupLogo = New-Object System.Windows.Forms.PictureBox
$RustupLogo.Width = 18
$RustupLogo.Height = 18
$RustupLogo.Location = New-Object System.Drawing.Size(410,130)
$RustupLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Rustup.png"
$RustupLogo.ImageLocation = $RustupLogoFile
$RustupLogo.BorderStyle = 0
$RustupLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($RustupLogo)

$RustupCheckbox = New-Object System.Windows.Forms.Checkbox 
$RustupCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$RustupCheckbox.Text = "       Rustup"
$RustupCheckbox.Width = 180
$RustupCheckbox.Height = 20
$RustupCheckbox.Font = $BodyFont
$Tab3.Controls.Add($RustupCheckbox)

$StrawberryPerlLogo = New-Object System.Windows.Forms.PictureBox
$StrawberryPerlLogo.Width = 18
$StrawberryPerlLogo.Height = 18
$StrawberryPerlLogo.Location = New-Object System.Drawing.Size(410,150)
$StrawberryPerlLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\StrawberryPerl.png"
$StrawberryPerlLogo.ImageLocation = $StrawberryPerlLogoFile
$StrawberryPerlLogo.BorderStyle = 0
$StrawberryPerlLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($StrawberryPerlLogo)

$StrawberryPerlCheckbox = New-Object System.Windows.Forms.Checkbox 
$StrawberryPerlCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$StrawberryPerlCheckbox.Text = "       Strawberry Perl"
$StrawberryPerlCheckbox.Width = 180
$StrawberryPerlCheckbox.Height = 20
$StrawberryPerlCheckbox.Font = $BodyFont
$Tab3.Controls.Add($StrawberryPerlCheckbox)

$SwiftLogo = New-Object System.Windows.Forms.PictureBox
$SwiftLogo.Width = 18
$SwiftLogo.Height = 18
$SwiftLogo.Location = New-Object System.Drawing.Size(410,170)
$SwiftLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Swift.png"
$SwiftLogo.ImageLocation = $SwiftLogoFile
$SwiftLogo.BorderStyle = 0
$SwiftLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SwiftLogo)

$SwiftCheckbox = New-Object System.Windows.Forms.Checkbox 
$SwiftCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$SwiftCheckbox.Text = "       Swift"
$SwiftCheckbox.Width = 180
$SwiftCheckbox.Height = 20
$SwiftCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SwiftCheckbox)

$PlanningLabel = New-Object System.Windows.Forms.Label
$PlanningLabel.Location = New-Object System.Drawing.Size(390,110)
$PlanningLabel.Text = "Planning"
$PlanningLabel.Width = 180
$PlanningLabel.Height = 20
$PlanningLabel.Font = $HeaderFont
$Tab3.Controls.Add($PlanningLabel)

$ClickUpLogo = New-Object System.Windows.Forms.PictureBox
$ClickUpLogo.Width = 18
$ClickUpLogo.Height = 18
$ClickUpLogo.Location = New-Object System.Drawing.Size(410,130)
$ClickUpLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\ClickUp.png"
$ClickUpLogo.ImageLocation = $ClickUpLogoFile
$ClickUpLogo.BorderStyle = 0
$ClickUpLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($ClickUpLogo)

$ClickUpCheckbox = New-Object System.Windows.Forms.Checkbox 
$ClickUpCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$ClickUpCheckbox.Text = "       ClickUp"
$ClickUpCheckbox.Width = 180
$ClickUpCheckbox.Height = 20
$ClickUpCheckbox.Font = $BodyFont
$Tab3.Controls.Add($ClickUpCheckbox)

$CodecksLogo = New-Object System.Windows.Forms.PictureBox
$CodecksLogo.Width = 18
$CodecksLogo.Height = 18
$CodecksLogo.Location = New-Object System.Drawing.Size(410,150)
$CodecksLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Codecks.png"
$CodecksLogo.ImageLocation = $CodecksLogoFile
$CodecksLogo.BorderStyle = 0
$CodecksLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CodecksLogo)

$CodecksCheckbox = New-Object System.Windows.Forms.Checkbox 
$CodecksCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$CodecksCheckbox.Text = "       Codecks"
$CodecksCheckbox.Width = 180
$CodecksCheckbox.Height = 20
$CodecksCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CodecksCheckbox)

$HacknPlanLogo = New-Object System.Windows.Forms.PictureBox
$HacknPlanLogo.Width = 18
$HacknPlanLogo.Height = 18
$HacknPlanLogo.Location = New-Object System.Drawing.Size(410,170)
$HacknPlanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\HacknPlan.png"
$HacknPlanLogo.ImageLocation = $HacknPlanLogoFile
$HacknPlanLogo.BorderStyle = 0
$HacknPlanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($HacknPlanLogo)

$HacknPlanCheckbox = New-Object System.Windows.Forms.Checkbox 
$HacknPlanCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$HacknPlanCheckbox.Text = "       HacknPlan"
$HacknPlanCheckbox.Width = 180
$HacknPlanCheckbox.Height = 20
$HacknPlanCheckbox.Font = $BodyFont
$Tab3.Controls.Add($HacknPlanCheckbox)

$RuntimesLabel = New-Object System.Windows.Forms.Label
$RuntimesLabel.Location = New-Object System.Drawing.Size(580,10)
$RuntimesLabel.Text = "Runtimes"
$RuntimesLabel.Width = 180
$RuntimesLabel.Height = 20
$RuntimesLabel.Font = $HeaderFont
$Tab3.Controls.Add($RuntimesLabel)

$NetLogo = New-Object System.Windows.Forms.PictureBox
$NetLogo.Width = 18
$NetLogo.Height = 18
$NetLogo.Location = New-Object System.Drawing.Size(600,30)
$NetLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Net.png"
$NetLogo.ImageLocation = $NetLogoFile
$NetLogo.BorderStyle = 0
$NetLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($NetLogo)

$NetCheckbox = New-Object System.Windows.Forms.Checkbox 
$NetCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$NetCheckbox.Text = "       .NET 4.8"
$NetCheckbox.Width = 180
$NetCheckbox.Height = 20
$NetCheckbox.Font = $BodyFont
$Tab3.Controls.Add($NetCheckbox)

$JavaLogo = New-Object System.Windows.Forms.PictureBox
$JavaLogo.Width = 18
$JavaLogo.Height = 18
$JavaLogo.Location = New-Object System.Drawing.Size(600,50)
$JavaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Java.png"
$JavaLogo.ImageLocation = $JavaLogoFile
$JavaLogo.BorderStyle = 0
$JavaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JavaLogo)

$JavaCheckbox = New-Object System.Windows.Forms.Checkbox 
$JavaCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$JavaCheckbox.Text = "       Java"
$JavaCheckbox.Width = 180
$JavaCheckbox.Height = 20
$JavaCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JavaCheckbox)

$NodejsLogo = New-Object System.Windows.Forms.PictureBox
$NodejsLogo.Width = 18
$NodejsLogo.Height = 18
$NodejsLogo.Location = New-Object System.Drawing.Size(600,70)
$NodejsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Nodejs.png"
$NodejsLogo.ImageLocation = $NodejsLogoFile
$NodejsLogo.BorderStyle = 0
$NodejsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($NodejsLogo)

$NodejsCheckbox = New-Object System.Windows.Forms.Checkbox 
$NodejsCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$NodejsCheckbox.Text = "       Node.js"
$NodejsCheckbox.Width = 180
$NodejsCheckbox.Height = 20
$NodejsCheckbox.Font = $BodyFont
$Tab3.Controls.Add($NodejsCheckbox)

$VisualLogo = New-Object System.Windows.Forms.PictureBox
$VisualLogo.Width = 18
$VisualLogo.Height = 18
$VisualLogo.Location = New-Object System.Drawing.Size(600,90)
$VisualLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Visual.png"
$VisualLogo.ImageLocation = $VisualLogoFile
$VisualLogo.BorderStyle = 0
$VisualLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($VisualLogo)

$VisualCheckbox = New-Object System.Windows.Forms.Checkbox 
$VisualCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$VisualCheckbox.Text = "       Visual C++"
$VisualCheckbox.Width = 180
$VisualCheckbox.Height = 20
$VisualCheckbox.Font = $BodyFont
$Tab3.Controls.Add($VisualCheckbox)

$TerminalLabel = New-Object System.Windows.Forms.Label
$TerminalLabel.Location = New-Object System.Drawing.Size(580,130)
$TerminalLabel.Text = "Terminal"
$TerminalLabel.Width = 180
$TerminalLabel.Height = 20
$TerminalLabel.Font = $HeaderFont
$Tab3.Controls.Add($TerminalLabel)

$CmderLogo = New-Object System.Windows.Forms.PictureBox
$CmderLogo.Width = 18
$CmderLogo.Height = 18
$CmderLogo.Location = New-Object System.Drawing.Size(600,150)
$CmderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Cmder.png"
$CmderLogo.ImageLocation = $CmderLogoFile
$CmderLogo.BorderStyle = 0
$CmderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($CmderLogo)

$CmderCheckbox = New-Object System.Windows.Forms.Checkbox 
$CmderCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$CmderCheckbox.Text = "       Cmder"
$CmderCheckbox.Width = 180
$CmderCheckbox.Height = 20
$CmderCheckbox.Font = $BodyFont
$Tab3.Controls.Add($CmderCheckbox)

$HyperLogo = New-Object System.Windows.Forms.PictureBox
$HyperLogo.Width = 18
$HyperLogo.Height = 18
$HyperLogo.Location = New-Object System.Drawing.Size(600,170)
$HyperLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Hyper.png"
$HyperLogo.ImageLocation = $HyperLogoFile
$HyperLogo.BorderStyle = 0
$HyperLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($HyperLogo)

$HyperCheckbox = New-Object System.Windows.Forms.Checkbox 
$HyperCheckbox.Location = New-Object System.Drawing.Size(580,170) 
$HyperCheckbox.Text = "       Hyper"
$HyperCheckbox.Width = 180
$HyperCheckbox.Height = 20
$HyperCheckbox.Font = $BodyFont
$Tab3.Controls.Add($HyperCheckbox)

$PuTTYLogo = New-Object System.Windows.Forms.PictureBox
$PuTTYLogo.Width = 18
$PuTTYLogo.Height = 18
$PuTTYLogo.Location = New-Object System.Drawing.Size(600,190)
$PuTTYLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\PuTTY.png"
$PuTTYLogo.ImageLocation = $PuTTYLogoFile
$PuTTYLogo.BorderStyle = 0
$PuTTYLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PuTTYLogo)

$PuTTYCheckbox = New-Object System.Windows.Forms.Checkbox 
$PuTTYCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$PuTTYCheckbox.Text = "       PuTTY"
$PuTTYCheckbox.Width = 180
$PuTTYCheckbox.Height = 20
$PuTTYCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PuTTYCheckbox)

$TestingLabel = New-Object System.Windows.Forms.Label
$TestingLabel.Location = New-Object System.Drawing.Size(770,10)
$TestingLabel.Text = "Testing"
$TestingLabel.Width = 180
$TestingLabel.Height = 20
$TestingLabel.Font = $HeaderFont
$Tab3.Controls.Add($TestingLabel)

$BurpSuiteLogo = New-Object System.Windows.Forms.PictureBox
$BurpSuiteLogo.Width = 18
$BurpSuiteLogo.Height = 18
$BurpSuiteLogo.Location = New-Object System.Drawing.Size(790,30)
$BurpSuiteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\BurpSuite.png"
$BurpSuiteLogo.ImageLocation = $BurpSuiteLogoFile
$BurpSuiteLogo.BorderStyle = 0
$BurpSuiteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($BurpSuiteLogo)

$BurpSuiteCheckbox = New-Object System.Windows.Forms.Checkbox 
$BurpSuiteCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$BurpSuiteCheckbox.Text = "       BurpSuite"
$BurpSuiteCheckbox.Width = 180
$BurpSuiteCheckbox.Height = 20
$BurpSuiteCheckbox.Font = $BodyFont
$Tab3.Controls.Add($BurpSuiteCheckbox)

$JMeterLogo = New-Object System.Windows.Forms.PictureBox
$JMeterLogo.Width = 18
$JMeterLogo.Height = 18
$JMeterLogo.Location = New-Object System.Drawing.Size(790,50)
$JMeterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\JMeter.png"
$JMeterLogo.ImageLocation = $JMeterLogoFile
$JMeterLogo.BorderStyle = 0
$JMeterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($JMeterLogo)

$JMeterCheckbox = New-Object System.Windows.Forms.Checkbox 
$JMeterCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$JMeterCheckbox.Text = "       JMeter"
$JMeterCheckbox.Width = 180
$JMeterCheckbox.Height = 20
$JMeterCheckbox.Font = $BodyFont
$Tab3.Controls.Add($JMeterCheckbox)

$PostmanLogo = New-Object System.Windows.Forms.PictureBox
$PostmanLogo.Width = 18
$PostmanLogo.Height = 18
$PostmanLogo.Location = New-Object System.Drawing.Size(790,70)
$PostmanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Postman.png"
$PostmanLogo.ImageLocation = $PostmanLogoFile
$PostmanLogo.BorderStyle = 0
$PostmanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($PostmanLogo)

$PostmanCheckbox = New-Object System.Windows.Forms.Checkbox 
$PostmanCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$PostmanCheckbox.Text = "       Postman"
$PostmanCheckbox.Width = 180
$PostmanCheckbox.Height = 20
$PostmanCheckbox.Font = $BodyFont
$Tab3.Controls.Add($PostmanCheckbox)

$SoapUILogo = New-Object System.Windows.Forms.PictureBox
$SoapUILogo.Width = 18
$SoapUILogo.Height = 18
$SoapUILogo.Location = New-Object System.Drawing.Size(790,90)
$SoapUILogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\SoapUI.png"
$SoapUILogo.ImageLocation = $SoapUILogoFile
$SoapUILogo.BorderStyle = 0
$SoapUILogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SoapUILogo)

$SoapUICheckbox = New-Object System.Windows.Forms.Checkbox 
$SoapUICheckbox.Location = New-Object System.Drawing.Size(770,90) 
$SoapUICheckbox.Text = "       SoapUI"
$SoapUICheckbox.Width = 180
$SoapUICheckbox.Height = 20
$SoapUICheckbox.Font = $BodyFont
$Tab3.Controls.Add($SoapUICheckbox)

$ZAPLogo = New-Object System.Windows.Forms.PictureBox
$ZAPLogo.Width = 18
$ZAPLogo.Height = 18
$ZAPLogo.Location = New-Object System.Drawing.Size(790,110)
$ZAPLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\ZAP.png"
$ZAPLogo.ImageLocation = $ZAPLogoFile
$ZAPLogo.BorderStyle = 0
$ZAPLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($ZAPLogo)

$ZAPCheckbox = New-Object System.Windows.Forms.Checkbox 
$ZAPCheckbox.Location = New-Object System.Drawing.Size(770,110) 
$ZAPCheckbox.Text = "       ZAP"
$ZAPCheckbox.Width = 180
$ZAPCheckbox.Height = 20
$ZAPCheckbox.Font = $BodyFont
$Tab3.Controls.Add($ZAPCheckbox)

$VCSLabel = New-Object System.Windows.Forms.Label
$VCSLabel.Location = New-Object System.Drawing.Size(960,10)
$VCSLabel.Text = "VCS"
$VCSLabel.Width = 180
$VCSLabel.Height = 20
$VCSLabel.Font = $HeaderFont
$Tab3.Controls.Add($VCSLabel)

$GitLogo = New-Object System.Windows.Forms.PictureBox
$GitLogo.Width = 18
$GitLogo.Height = 18
$GitLogo.Location = New-Object System.Drawing.Size(980,30)
$GitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Git.png"
$GitLogo.ImageLocation = $GitLogoFile
$GitLogo.BorderStyle = 0
$GitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GitLogo)

$GitCheckbox = New-Object System.Windows.Forms.Checkbox 
$GitCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$GitCheckbox.Text = "       Git"
$GitCheckbox.Width = 180
$GitCheckbox.Height = 20
$GitCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GitCheckbox)

$GitLFSLogo = New-Object System.Windows.Forms.PictureBox
$GitLFSLogo.Width = 18
$GitLFSLogo.Height = 18
$GitLFSLogo.Location = New-Object System.Drawing.Size(980,50)
$GitLFSLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GitLFS.png"
$GitLFSLogo.ImageLocation = $GitLFSLogoFile
$GitLFSLogo.BorderStyle = 0
$GitLFSLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GitLFSLogo)

$GitLFSCheckbox = New-Object System.Windows.Forms.Checkbox 
$GitLFSCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$GitLFSCheckbox.Text = "       Git LFS"
$GitLFSCheckbox.Width = 180
$GitLFSCheckbox.Height = 20
$GitLFSCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GitLFSCheckbox)

$GitHubDesktopLogo = New-Object System.Windows.Forms.PictureBox
$GitHubDesktopLogo.Width = 18
$GitHubDesktopLogo.Height = 18
$GitHubDesktopLogo.Location = New-Object System.Drawing.Size(980,70)
$GitHubDesktopLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\GitHubDesktop.png"
$GitHubDesktopLogo.ImageLocation = $GitHubDesktopLogoFile
$GitHubDesktopLogo.BorderStyle = 0
$GitHubDesktopLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($GitHubDesktopLogo)

$GitHubDesktopCheckbox = New-Object System.Windows.Forms.Checkbox 
$GitHubDesktopCheckbox.Location = New-Object System.Drawing.Size(960,70) 
$GitHubDesktopCheckbox.Text = "       GitHub Desktop"
$GitHubDesktopCheckbox.Width = 180
$GitHubDesktopCheckbox.Height = 20
$GitHubDesktopCheckbox.Font = $BodyFont
$Tab3.Controls.Add($GitHubDesktopCheckbox)

$SourcetreeLogo = New-Object System.Windows.Forms.PictureBox
$SourcetreeLogo.Width = 18
$SourcetreeLogo.Height = 18
$SourcetreeLogo.Location = New-Object System.Drawing.Size(980,90)
$SourcetreeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\Sourcetree.png"
$SourcetreeLogo.ImageLocation = $SourcetreeLogoFile
$SourcetreeLogo.BorderStyle = 0
$SourcetreeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($SourcetreeLogo)

$SourcetreeCheckbox = New-Object System.Windows.Forms.Checkbox 
$SourcetreeCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$SourcetreeCheckbox.Text = "       Sourcetree"
$SourcetreeCheckbox.Width = 180
$SourcetreeCheckbox.Height = 20
$SourcetreeCheckbox.Font = $BodyFont
$Tab3.Controls.Add($SourcetreeCheckbox)

$TortoiseGitLogo = New-Object System.Windows.Forms.PictureBox
$TortoiseGitLogo.Width = 18
$TortoiseGitLogo.Height = 18
$TortoiseGitLogo.Location = New-Object System.Drawing.Size(980,110)
$TortoiseGitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Developing\TortoiseGit.png"
$TortoiseGitLogo.ImageLocation = $TortoiseGitLogoFile
$TortoiseGitLogo.BorderStyle = 0
$TortoiseGitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab3.Controls.Add($TortoiseGitLogo)

$TortoiseGitCheckbox = New-Object System.Windows.Forms.Checkbox 
$TortoiseGitCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$TortoiseGitCheckbox.Text = "       TortoiseGit"
$TortoiseGitCheckbox.Width = 180
$TortoiseGitCheckbox.Height = 20
$TortoiseGitCheckbox.Font = $BodyFont
$Tab3.Controls.Add($TortoiseGitCheckbox)

# Tab 4 DIAGNOSTIC
$Tab4 = New-Object System.Windows.Forms.TabPage
$Tab4.Text = "Diagnostic"
$Tab4.Font = $TabFont
$Tab4.Autoscroll  = $True
$TabControl.Controls.Add($Tab4)

$Audio2Label = New-Object System.Windows.Forms.Label
$Audio2Label.Location = New-Object System.Drawing.Size(10,10)
$Audio2Label.Text = "Audio"
$Audio2Label.Width = 180
$Audio2Label.Height = 20
$Audio2Label.Font = $HeaderFont
$Tab4.Controls.Add($Audio2Label)

$DPCLatCheckerLogo = New-Object System.Windows.Forms.PictureBox
$DPCLatCheckerLogo.Width = 18
$DPCLatCheckerLogo.Height = 18
$DPCLatCheckerLogo.Location = New-Object System.Drawing.Size(30,30)
$DPCLatCheckerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\DPCLatChecker.png"
$DPCLatCheckerLogo.ImageLocation = $DPCLatCheckerLogoFile
$DPCLatCheckerLogo.BorderStyle = 0
$DPCLatCheckerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($DPCLatCheckerLogo)

$DPCLatCheckerCheckbox = New-Object System.Windows.Forms.Checkbox
$DPCLatCheckerCheckbox.Location = New-Object System.Drawing.Size(10,30)
$DPCLatCheckerCheckbox.Text = "       DPC Lat Checker"
$DPCLatCheckerCheckbox.Width = 180
$DPCLatCheckerCheckbox.Height = 20
$DPCLatCheckerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($DPCLatCheckerCheckbox)

$EqualizerAPOLogo = New-Object System.Windows.Forms.PictureBox
$EqualizerAPOLogo.Width = 18
$EqualizerAPOLogo.Height = 18
$EqualizerAPOLogo.Location = New-Object System.Drawing.Size(30,50)
$EqualizerAPOLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\EqualizerAPO.png"
$EqualizerAPOLogo.ImageLocation = $EqualizerAPOLogoFile
$EqualizerAPOLogo.BorderStyle = 0
$EqualizerAPOLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($EqualizerAPOLogo)

$EqualizerAPOCheckbox = New-Object System.Windows.Forms.Checkbox
$EqualizerAPOCheckbox.Location = New-Object System.Drawing.Size(10,50)
$EqualizerAPOCheckbox.Text = "       Equalizer APO"
$EqualizerAPOCheckbox.Width = 180
$EqualizerAPOCheckbox.Height = 20
$EqualizerAPOCheckbox.Font = $BodyFont
$Tab4.Controls.Add($EqualizerAPOCheckbox)

$LatencyMonLogo = New-Object System.Windows.Forms.PictureBox
$LatencyMonLogo.Width = 18
$LatencyMonLogo.Height = 18
$LatencyMonLogo.Location = New-Object System.Drawing.Size(30,70)
$LatencyMonLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\LatencyMon.png"
$LatencyMonLogo.ImageLocation = $LatencyMonLogoFile
$LatencyMonLogo.BorderStyle = 0
$LatencyMonLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($LatencyMonLogo)

$LatencyMonCheckbox = New-Object System.Windows.Forms.Checkbox
$LatencyMonCheckbox.Location = New-Object System.Drawing.Size(10,70)
$LatencyMonCheckbox.Text = "       Latency Mon"
$LatencyMonCheckbox.Width = 180
$LatencyMonCheckbox.Height = 20
$LatencyMonCheckbox.Font = $BodyFont
$Tab4.Controls.Add($LatencyMonCheckbox)

$BatteryLabel = New-Object System.Windows.Forms.Label
$BatteryLabel.Location = New-Object System.Drawing.Size(10,110)
$BatteryLabel.Text = "Battery"
$BatteryLabel.Width = 180
$BatteryLabel.Height = 20
$BatteryLabel.Font = $HeaderFont
$Tab4.Controls.Add($BatteryLabel)

$BatteryInfoViewLogo = New-Object System.Windows.Forms.PictureBox
$BatteryInfoViewLogo.Width = 18
$BatteryInfoViewLogo.Height = 18
$BatteryInfoViewLogo.Location = New-Object System.Drawing.Size(30,130)
$BatteryInfoViewLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BatteryInfoView.png"
$BatteryInfoViewLogo.ImageLocation = $BatteryInfoViewLogoFile
$BatteryInfoViewLogo.BorderStyle = 0
$BatteryInfoViewLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BatteryInfoViewLogo)

$BatteryInfoViewCheckbox = New-Object System.Windows.Forms.Checkbox
$BatteryInfoViewCheckbox.Location = New-Object System.Drawing.Size(10,130)
$BatteryInfoViewCheckbox.Text = "       BatteryInfoView"
$BatteryInfoViewCheckbox.Width = 180
$BatteryInfoViewCheckbox.Height = 20
$BatteryInfoViewCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BatteryInfoViewCheckbox)

$BatteryMonLogo = New-Object System.Windows.Forms.PictureBox
$BatteryMonLogo.Width = 18
$BatteryMonLogo.Height = 18
$BatteryMonLogo.Location = New-Object System.Drawing.Size(30,150)
$BatteryMonLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BatteryMon.png"
$BatteryMonLogo.ImageLocation = $BatteryMonLogoFile
$BatteryMonLogo.BorderStyle = 0
$BatteryMonLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BatteryMonLogo)

$BatteryMonCheckbox = New-Object System.Windows.Forms.Checkbox
$BatteryMonCheckbox.Location = New-Object System.Drawing.Size(10,150)
$BatteryMonCheckbox.Text = "       BatteryMon"
$BatteryMonCheckbox.Width = 180
$BatteryMonCheckbox.Height = 20
$BatteryMonCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BatteryMonCheckbox)

$BenchmarkLabel = New-Object System.Windows.Forms.Label
$BenchmarkLabel.Location = New-Object System.Drawing.Size(10,190)
$BenchmarkLabel.Text = "Benchmark"
$BenchmarkLabel.Width = 180
$BenchmarkLabel.Height = 20
$BenchmarkLabel.Font = $HeaderFont
$Tab4.Controls.Add($BenchmarkLabel)

$3DMarkLogo = New-Object System.Windows.Forms.PictureBox
$3DMarkLogo.Width = 18
$3DMarkLogo.Height = 18
$3DMarkLogo.Location = New-Object System.Drawing.Size(30,210)
$3DMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\3DMark.png"
$3DMarkLogo.ImageLocation = $3DMarkLogoFile
$3DMarkLogo.BorderStyle = 0
$3DMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($3DMarkLogo)

$3DMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$3DMarkCheckbox.Location = New-Object System.Drawing.Size(10,210) 
$3DMarkCheckbox.Text = "       3DMark"
$3DMarkCheckbox.Width = 180
$3DMarkCheckbox.Height = 20
$3DMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($3DMarkCheckbox)

$BlenderBenchmarkLogo = New-Object System.Windows.Forms.PictureBox
$BlenderBenchmarkLogo.Width = 18
$BlenderBenchmarkLogo.Height = 18
$BlenderBenchmarkLogo.Location = New-Object System.Drawing.Size(30,230)
$BlenderBenchmarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BlenderBenchmark.png"
$BlenderBenchmarkLogo.ImageLocation = $BlenderBenchmarkLogoFile
$BlenderBenchmarkLogo.BorderStyle = 0
$BlenderBenchmarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BlenderBenchmarkLogo)

$BlenderBenchmarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$BlenderBenchmarkCheckbox.Location = New-Object System.Drawing.Size(10,230) 
$BlenderBenchmarkCheckbox.Text = "       Blender Benchmark"
$BlenderBenchmarkCheckbox.Width = 180
$BlenderBenchmarkCheckbox.Height = 20
$BlenderBenchmarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BlenderBenchmarkCheckbox)

$CinebenchLogo = New-Object System.Windows.Forms.PictureBox
$CinebenchLogo.Width = 18
$CinebenchLogo.Height = 18
$CinebenchLogo.Location = New-Object System.Drawing.Size(30,250)
$CinebenchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Cinebench.png"
$CinebenchLogo.ImageLocation = $CinebenchLogoFile
$CinebenchLogo.BorderStyle = 0
$CinebenchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CinebenchLogo)

$CinebenchCheckbox = New-Object System.Windows.Forms.Checkbox 
$CinebenchCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$CinebenchCheckbox.Text = "       Cinebench"
$CinebenchCheckbox.Width = 180
$CinebenchCheckbox.Height = 20
$CinebenchCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CinebenchCheckbox)

$CrystalDiskMarkLogo = New-Object System.Windows.Forms.PictureBox
$CrystalDiskMarkLogo.Width = 18
$CrystalDiskMarkLogo.Height = 18
$CrystalDiskMarkLogo.Location = New-Object System.Drawing.Size(30,270)
$CrystalDiskMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CrystalDiskMark.png"
$CrystalDiskMarkLogo.ImageLocation = $CrystalDiskMarkLogoFile
$CrystalDiskMarkLogo.BorderStyle = 0
$CrystalDiskMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CrystalDiskMarkLogo)

$CrystalDiskMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$CrystalDiskMarkCheckbox.Location = New-Object System.Drawing.Size(10,270) 
$CrystalDiskMarkCheckbox.Text = "       CrystalDiskMark"
$CrystalDiskMarkCheckbox.Width = 180
$CrystalDiskMarkCheckbox.Height = 20
$CrystalDiskMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CrystalDiskMarkCheckbox)

$GeekbenchLogo = New-Object System.Windows.Forms.PictureBox
$GeekbenchLogo.Width = 18
$GeekbenchLogo.Height = 18
$GeekbenchLogo.Location = New-Object System.Drawing.Size(30,290)
$GeekbenchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Geekbench.png"
$GeekbenchLogo.ImageLocation = $GeekbenchLogoFile
$GeekbenchLogo.BorderStyle = 0
$GeekbenchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GeekbenchLogo)

$GeekbenchCheckbox = New-Object System.Windows.Forms.Checkbox 
$GeekbenchCheckbox.Location = New-Object System.Drawing.Size(10,290) 
$GeekbenchCheckbox.Text = "       Geekbench"
$GeekbenchCheckbox.Width = 180
$GeekbenchCheckbox.Height = 20
$GeekbenchCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GeekbenchCheckbox)

$NovabenchLogo = New-Object System.Windows.Forms.PictureBox
$NovabenchLogo.Width = 18
$NovabenchLogo.Height = 18
$NovabenchLogo.Location = New-Object System.Drawing.Size(30,310)
$NovabenchLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Novabench.png"
$NovabenchLogo.ImageLocation = $NovabenchLogoFile
$NovabenchLogo.BorderStyle = 0
$NovabenchLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($NovabenchLogo)

$NovabenchCheckbox = New-Object System.Windows.Forms.Checkbox 
$NovabenchCheckbox.Location = New-Object System.Drawing.Size(10,310) 
$NovabenchCheckbox.Text = "       Novabench"
$NovabenchCheckbox.Width = 180
$NovabenchCheckbox.Height = 20
$NovabenchCheckbox.Font = $BodyFont
$Tab4.Controls.Add($NovabenchCheckbox)

$PCMarkLogo = New-Object System.Windows.Forms.PictureBox
$PCMarkLogo.Width = 18
$PCMarkLogo.Height = 18
$PCMarkLogo.Location = New-Object System.Drawing.Size(30,330)
$PCMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\PCMark.png"
$PCMarkLogo.ImageLocation = $PCMarkLogoFile
$PCMarkLogo.BorderStyle = 0
$PCMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($PCMarkLogo)

$PCMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$PCMarkCheckbox.Location = New-Object System.Drawing.Size(10,330) 
$PCMarkCheckbox.Text = "       PCMark"
$PCMarkCheckbox.Width = 180
$PCMarkCheckbox.Height = 20
$PCMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($PCMarkCheckbox)

$PerformanceTESTLogo = New-Object System.Windows.Forms.PictureBox
$PerformanceTESTLogo.Width = 18
$PerformanceTESTLogo.Height = 18
$PerformanceTESTLogo.Location = New-Object System.Drawing.Size(30,350)
$PerformanceTESTLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\PerformanceTEST.png"
$PerformanceTESTLogo.ImageLocation = $PerformanceTESTLogoFile
$PerformanceTESTLogo.BorderStyle = 0
$PerformanceTESTLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($PerformanceTESTLogo)

$PerformanceTESTCheckbox = New-Object System.Windows.Forms.Checkbox 
$PerformanceTESTCheckbox.Location = New-Object System.Drawing.Size(10,350) 
$PerformanceTESTCheckbox.Text = "       PerformanceTEST"
$PerformanceTESTCheckbox.Width = 180
$PerformanceTESTCheckbox.Height = 20
$PerformanceTESTCheckbox.Font = $BodyFont
$Tab4.Controls.Add($PerformanceTESTCheckbox)

$SuperpositionLogo = New-Object System.Windows.Forms.PictureBox
$SuperpositionLogo.Width = 18
$SuperpositionLogo.Height = 18
$SuperpositionLogo.Location = New-Object System.Drawing.Size(30,370)
$SuperpositionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Superposition.png"
$SuperpositionLogo.ImageLocation = $SuperpositionLogoFile
$SuperpositionLogo.BorderStyle = 0
$SuperpositionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SuperpositionLogo)

$SuperpositionCheckbox = New-Object System.Windows.Forms.Checkbox 
$SuperpositionCheckbox.Location = New-Object System.Drawing.Size(10,370) 
$SuperpositionCheckbox.Text = "       Superposition"
$SuperpositionCheckbox.Width = 180
$SuperpositionCheckbox.Height = 20
$SuperpositionCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SuperpositionCheckbox)

$UserBenchmarkLogo = New-Object System.Windows.Forms.PictureBox
$UserBenchmarkLogo.Width = 18
$UserBenchmarkLogo.Height = 18
$UserBenchmarkLogo.Location = New-Object System.Drawing.Size(30,390)
$UserBenchmarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\UserBenchmark.png"
$UserBenchmarkLogo.ImageLocation = $UserBenchmarkLogoFile
$UserBenchmarkLogo.BorderStyle = 0
$UserBenchmarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($UserBenchmarkLogo)

$UserBenchmarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$UserBenchmarkCheckbox.Location = New-Object System.Drawing.Size(10,390) 
$UserBenchmarkCheckbox.Text = "       UserBenchmark"
$UserBenchmarkCheckbox.Width = 180
$UserBenchmarkCheckbox.Height = 20
$UserBenchmarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($UserBenchmarkCheckbox)

$CPULabel = New-Object System.Windows.Forms.Label
$CPULabel.Location = New-Object System.Drawing.Size(200,10)
$CPULabel.Text = "CPU"
$CPULabel.Width = 180
$CPULabel.Height = 20
$CPULabel.Font = $HeaderFont
$Tab4.Controls.Add($CPULabel)

$IntelDiagLogo = New-Object System.Windows.Forms.PictureBox
$IntelDiagLogo.Width = 18
$IntelDiagLogo.Height = 18
$IntelDiagLogo.Location = New-Object System.Drawing.Size(220,30)
$IntelDiagLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\IntelDiag.png"
$IntelDiagLogo.ImageLocation = $IntelDiagLogoFile
$IntelDiagLogo.BorderStyle = 0
$IntelDiagLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($IntelDiagLogo)

$IntelDiagCheckbox = New-Object System.Windows.Forms.Checkbox 
$IntelDiagCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$IntelDiagCheckbox.Text = "       Intel Diag"
$IntelDiagCheckbox.Width = 180
$IntelDiagCheckbox.Height = 20
$IntelDiagCheckbox.Font = $BodyFont
$Tab4.Controls.Add($IntelDiagCheckbox)

$Prime95Logo = New-Object System.Windows.Forms.PictureBox
$Prime95Logo.Width = 18
$Prime95Logo.Height = 18
$Prime95Logo.Location = New-Object System.Drawing.Size(220,50)
$Prime95LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Prime95.png"
$Prime95Logo.ImageLocation = $Prime95LogoFile
$Prime95Logo.BorderStyle = 0
$Prime95Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($Prime95Logo)

$Prime95Checkbox = New-Object System.Windows.Forms.Checkbox 
$Prime95Checkbox.Location = New-Object System.Drawing.Size(200,50) 
$Prime95Checkbox.Text = "       Prime95"
$Prime95Checkbox.Width = 180
$Prime95Checkbox.Height = 20
$Prime95Checkbox.Font = $BodyFont
$Tab4.Controls.Add($Prime95Checkbox)

$DataRecoveryLabel = New-Object System.Windows.Forms.Label
$DataRecoveryLabel.Location = New-Object System.Drawing.Size(200,90)
$DataRecoveryLabel.Text = "Data Recovery"
$DataRecoveryLabel.Width = 180
$DataRecoveryLabel.Height = 20
$DataRecoveryLabel.Font = $HeaderFont
$Tab4.Controls.Add($DataRecoveryLabel)

$EaseUSDataRecoveryLogo = New-Object System.Windows.Forms.PictureBox
$EaseUSDataRecoveryLogo.Width = 18
$EaseUSDataRecoveryLogo.Height = 18
$EaseUSDataRecoveryLogo.Location = New-Object System.Drawing.Size(220,110)
$EaseUSDataRecoveryLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\EaseUSDataRecovery.png"
$EaseUSDataRecoveryLogo.ImageLocation = $EaseUSDataRecoveryLogoFile
$EaseUSDataRecoveryLogo.BorderStyle = 0
$EaseUSDataRecoveryLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($EaseUSDataRecoveryLogo)

$EaseUSDataRecoveryCheckbox = New-Object System.Windows.Forms.Checkbox 
$EaseUSDataRecoveryCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$EaseUSDataRecoveryCheckbox.Text = "       EaseUS"
$EaseUSDataRecoveryCheckbox.Width = 180
$EaseUSDataRecoveryCheckbox.Height = 20
$EaseUSDataRecoveryCheckbox.Font = $BodyFont
$Tab4.Controls.Add($EaseUSDataRecoveryCheckbox)

$RecuvaLogo = New-Object System.Windows.Forms.PictureBox
$RecuvaLogo.Width = 18
$RecuvaLogo.Height = 18
$RecuvaLogo.Location = New-Object System.Drawing.Size(220,130)
$RecuvaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Recuva.png"
$RecuvaLogo.ImageLocation = $RecuvaLogoFile
$RecuvaLogo.BorderStyle = 0
$RecuvaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RecuvaLogo)

$RecuvaCheckbox = New-Object System.Windows.Forms.Checkbox 
$RecuvaCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$RecuvaCheckbox.Text = "       Recuva"
$RecuvaCheckbox.Width = 180
$RecuvaCheckbox.Height = 20
$RecuvaCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RecuvaCheckbox)

$StellarLogo = New-Object System.Windows.Forms.PictureBox
$StellarLogo.Width = 18
$StellarLogo.Height = 18
$StellarLogo.Location = New-Object System.Drawing.Size(220,150)
$StellarLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Stellar.png"
$StellarLogo.ImageLocation = $StellarLogoFile
$StellarLogo.BorderStyle = 0
$StellarLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($StellarLogo)

$StellarCheckbox = New-Object System.Windows.Forms.Checkbox 
$StellarCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$StellarCheckbox.Text = "       Stellar"
$StellarCheckbox.Width = 180
$StellarCheckbox.Height = 20
$StellarCheckbox.Font = $BodyFont
$Tab4.Controls.Add($StellarCheckbox)

$DirectoryLabel = New-Object System.Windows.Forms.Label
$DirectoryLabel.Location = New-Object System.Drawing.Size(200,190)
$DirectoryLabel.Text = "Directory"
$DirectoryLabel.Width = 180
$DirectoryLabel.Height = 20
$DirectoryLabel.Font = $HeaderFont
$Tab4.Controls.Add($DirectoryLabel)

$CaptainNemoLogo = New-Object System.Windows.Forms.PictureBox
$CaptainNemoLogo.Width = 18
$CaptainNemoLogo.Height = 18
$CaptainNemoLogo.Location = New-Object System.Drawing.Size(220,210)
$CaptainNemoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CaptainNemo.png"
$CaptainNemoLogo.ImageLocation = $CaptainNemoLogoFile
$CaptainNemoLogo.BorderStyle = 0
$CaptainNemoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CaptainNemoLogo)

$CaptainNemoCheckbox = New-Object System.Windows.Forms.Checkbox 
$CaptainNemoCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$CaptainNemoCheckbox.Text = "       Captain Nemo"
$CaptainNemoCheckbox.Width = 180
$CaptainNemoCheckbox.Height = 20
$CaptainNemoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CaptainNemoCheckbox)

$EverythingLogo = New-Object System.Windows.Forms.PictureBox
$EverythingLogo.Width = 18
$EverythingLogo.Height = 18
$EverythingLogo.Location = New-Object System.Drawing.Size(220,230)
$EverythingLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Everything.png"
$EverythingLogo.ImageLocation = $EverythingLogoFile
$EverythingLogo.BorderStyle = 0
$EverythingLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($EverythingLogo)

$EverythingCheckbox = New-Object System.Windows.Forms.Checkbox 
$EverythingCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$EverythingCheckbox.Text = "       Everything"
$EverythingCheckbox.Width = 180
$EverythingCheckbox.Height = 20
$EverythingCheckbox.Font = $BodyFont
$Tab4.Controls.Add($EverythingCheckbox)

$TreeSizeLogo = New-Object System.Windows.Forms.PictureBox
$TreeSizeLogo.Width = 18
$TreeSizeLogo.Height = 18
$TreeSizeLogo.Location = New-Object System.Drawing.Size(220,250)
$TreeSizeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\TreeSize.png"
$TreeSizeLogo.ImageLocation = $TreeSizeLogoFile
$TreeSizeLogo.BorderStyle = 0
$TreeSizeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($TreeSizeLogo)

$TreeSizeCheckbox = New-Object System.Windows.Forms.Checkbox 
$TreeSizeCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$TreeSizeCheckbox.Text = "       TreeSize"
$TreeSizeCheckbox.Width = 180
$TreeSizeCheckbox.Height = 20
$TreeSizeCheckbox.Font = $BodyFont
$Tab4.Controls.Add($TreeSizeCheckbox)

$WinDirStatLogo = New-Object System.Windows.Forms.PictureBox
$WinDirStatLogo.Width = 18
$WinDirStatLogo.Height = 18
$WinDirStatLogo.Location = New-Object System.Drawing.Size(220,270)
$WinDirStatLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WinDirStat.png"
$WinDirStatLogo.ImageLocation = $WinDirStatLogoFile
$WinDirStatLogo.BorderStyle = 0
$WinDirStatLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WinDirStatLogo)

$WinDirStatCheckbox = New-Object System.Windows.Forms.Checkbox 
$WinDirStatCheckbox.Location = New-Object System.Drawing.Size(200,270) 
$WinDirStatCheckbox.Text = "       WinDirStat"
$WinDirStatCheckbox.Width = 180
$WinDirStatCheckbox.Height = 20
$WinDirStatCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WinDirStatCheckbox)

$WizTreeLogo = New-Object System.Windows.Forms.PictureBox
$WizTreeLogo.Width = 18
$WizTreeLogo.Height = 18
$WizTreeLogo.Location = New-Object System.Drawing.Size(220,290)
$WizTreeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WizTree.png"
$WizTreeLogo.ImageLocation = $WizTreeLogoFile
$WizTreeLogo.BorderStyle = 0
$WizTreeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WizTreeLogo)

$WizTreeCheckbox = New-Object System.Windows.Forms.Checkbox 
$WizTreeCheckbox.Location = New-Object System.Drawing.Size(200,290) 
$WizTreeCheckbox.Text = "       WizTree"
$WizTreeCheckbox.Width = 180
$WizTreeCheckbox.Height = 20
$WizTreeCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WizTreeCheckbox)

$GPULabel = New-Object System.Windows.Forms.Label
$GPULabel.Location = New-Object System.Drawing.Size(390,10)
$GPULabel.Text = "GPU"
$GPULabel.Width = 180
$GPULabel.Height = 20
$GPULabel.Font = $HeaderFont
$Tab4.Controls.Add($GPULabel)

$FurMarkLogo = New-Object System.Windows.Forms.PictureBox
$FurMarkLogo.Width = 18
$FurMarkLogo.Height = 18
$FurMarkLogo.Location = New-Object System.Drawing.Size(410,30)
$FurMarkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\FurMark.png"
$FurMarkLogo.ImageLocation = $FurMarkLogoFile
$FurMarkLogo.BorderStyle = 0
$FurMarkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($FurMarkLogo)

$FurMarkCheckbox = New-Object System.Windows.Forms.Checkbox 
$FurMarkCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$FurMarkCheckbox.Text = "       FurMark"
$FurMarkCheckbox.Width = 180
$FurMarkCheckbox.Height = 20
$FurMarkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($FurMarkCheckbox)

$HeavenLogo = New-Object System.Windows.Forms.PictureBox
$HeavenLogo.Width = 18
$HeavenLogo.Height = 18
$HeavenLogo.Location = New-Object System.Drawing.Size(410,50)
$HeavenLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Heaven.png"
$HeavenLogo.ImageLocation = $HeavenLogoFile
$HeavenLogo.BorderStyle = 0
$HeavenLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HeavenLogo)

$HeavenCheckbox = New-Object System.Windows.Forms.Checkbox 
$HeavenCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$HeavenCheckbox.Text = "       Heaven"
$HeavenCheckbox.Width = 180
$HeavenCheckbox.Height = 20
$HeavenCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HeavenCheckbox)

$KombustorLogo = New-Object System.Windows.Forms.PictureBox
$KombustorLogo.Width = 18
$KombustorLogo.Height = 18
$KombustorLogo.Location = New-Object System.Drawing.Size(410,70)
$KombustorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Kombustor.png"
$KombustorLogo.ImageLocation = $KombustorLogoFile
$KombustorLogo.BorderStyle = 0
$KombustorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($KombustorLogo)

$KombustorCheckbox = New-Object System.Windows.Forms.Checkbox 
$KombustorCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$KombustorCheckbox.Text = "       Kombustor"
$KombustorCheckbox.Width = 180
$KombustorCheckbox.Height = 20
$KombustorCheckbox.Font = $BodyFont
$Tab4.Controls.Add($KombustorCheckbox)

$HDDLabel = New-Object System.Windows.Forms.Label
$HDDLabel.Location = New-Object System.Drawing.Size(390,110)
$HDDLabel.Text = "HDD"
$HDDLabel.Width = 180
$HDDLabel.Height = 20
$HDDLabel.Font = $HeaderFont
$Tab4.Controls.Add($HDDLabel)

$AcronisLogo = New-Object System.Windows.Forms.PictureBox
$AcronisLogo.Width = 18
$AcronisLogo.Height = 18
$AcronisLogo.Location = New-Object System.Drawing.Size(410,130)
$AcronisLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Acronis.png"
$AcronisLogo.ImageLocation = $AcronisLogoFile
$AcronisLogo.BorderStyle = 0
$AcronisLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AcronisLogo)

$AcronisCheckbox = New-Object System.Windows.Forms.Checkbox 
$AcronisCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$AcronisCheckbox.Text = "       Acronis"
$AcronisCheckbox.Width = 180
$AcronisCheckbox.Height = 20
$AcronisCheckbox.Font = $BodyFont
$Tab4.Controls.Add($AcronisCheckbox)

$AOMEILogo = New-Object System.Windows.Forms.PictureBox
$AOMEILogo.Width = 18
$AOMEILogo.Height = 18
$AOMEILogo.Location = New-Object System.Drawing.Size(410,150)
$AOMEILogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\AOMEI.png"
$AOMEILogo.ImageLocation = $AOMEILogoFile
$AOMEILogo.BorderStyle = 0
$AOMEILogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AOMEILogo)

$AOMEICheckbox = New-Object System.Windows.Forms.Checkbox 
$AOMEICheckbox.Location = New-Object System.Drawing.Size(390,150) 
$AOMEICheckbox.Text = "       AOMEI"
$AOMEICheckbox.Width = 180
$AOMEICheckbox.Height = 20
$AOMEICheckbox.Font = $BodyFont
$Tab4.Controls.Add($AOMEICheckbox)

$CheckDiskGUILogo = New-Object System.Windows.Forms.PictureBox
$CheckDiskGUILogo.Width = 18
$CheckDiskGUILogo.Height = 18
$CheckDiskGUILogo.Location = New-Object System.Drawing.Size(410,170)
$CheckDiskGUILogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CheckDiskGUI.png"
$CheckDiskGUILogo.ImageLocation = $CheckDiskGUILogoFile
$CheckDiskGUILogo.BorderStyle = 0
$CheckDiskGUILogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CheckDiskGUILogo)

$CheckDiskGUICheckbox = New-Object System.Windows.Forms.Checkbox 
$CheckDiskGUICheckbox.Location = New-Object System.Drawing.Size(390,170) 
$CheckDiskGUICheckbox.Text = "       CheckDiskGUI"
$CheckDiskGUICheckbox.Width = 180
$CheckDiskGUICheckbox.Height = 20
$CheckDiskGUICheckbox.Font = $BodyFont
$Tab4.Controls.Add($CheckDiskGUICheckbox)

$CrystalDiskInfoLogo = New-Object System.Windows.Forms.PictureBox
$CrystalDiskInfoLogo.Width = 18
$CrystalDiskInfoLogo.Height = 18
$CrystalDiskInfoLogo.Location = New-Object System.Drawing.Size(410,190)
$CrystalDiskInfoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CrystalDiskInfo.png"
$CrystalDiskInfoLogo.ImageLocation = $CrystalDiskInfoLogoFile
$CrystalDiskInfoLogo.BorderStyle = 0
$CrystalDiskInfoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CrystalDiskInfoLogo)

$CrystalDiskInfoCheckbox = New-Object System.Windows.Forms.Checkbox 
$CrystalDiskInfoCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$CrystalDiskInfoCheckbox.Text = "       CrystalDiskInfo"
$CrystalDiskInfoCheckbox.Width = 180
$CrystalDiskInfoCheckbox.Height = 20
$CrystalDiskInfoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CrystalDiskInfoCheckbox)

$GSmartControlLogo = New-Object System.Windows.Forms.PictureBox
$GSmartControlLogo.Width = 18
$GSmartControlLogo.Height = 18
$GSmartControlLogo.Location = New-Object System.Drawing.Size(410,210)
$GSmartControlLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\GSmartControl.png"
$GSmartControlLogo.ImageLocation = $GSmartControlLogoFile
$GSmartControlLogo.BorderStyle = 0
$GSmartControlLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GSmartControlLogo)

$GSmartControlCheckbox = New-Object System.Windows.Forms.Checkbox 
$GSmartControlCheckbox.Location = New-Object System.Drawing.Size(390,210) 
$GSmartControlCheckbox.Text = "       GSmartControl"
$GSmartControlCheckbox.Width = 180
$GSmartControlCheckbox.Height = 20
$GSmartControlCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GSmartControlCheckbox)

$HDDScanLogo = New-Object System.Windows.Forms.PictureBox
$HDDScanLogo.Width = 18
$HDDScanLogo.Height = 18
$HDDScanLogo.Location = New-Object System.Drawing.Size(410,230)
$HDDScanLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HDDScan.png"
$HDDScanLogo.ImageLocation = $HDDScanLogoFile
$HDDScanLogo.BorderStyle = 0
$HDDScanLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HDDScanLogo)

$HDDScanCheckbox = New-Object System.Windows.Forms.Checkbox 
$HDDScanCheckbox.Location = New-Object System.Drawing.Size(390,230) 
$HDDScanCheckbox.Text = "       HDDScan"
$HDDScanCheckbox.Width = 180
$HDDScanCheckbox.Height = 20
$HDDScanCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HDDScanCheckbox)

$HDTuneProLogo = New-Object System.Windows.Forms.PictureBox
$HDTuneProLogo.Width = 18
$HDTuneProLogo.Height = 18
$HDTuneProLogo.Location = New-Object System.Drawing.Size(410,250)
$HDTuneProLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HDTunePro.png"
$HDTuneProLogo.ImageLocation = $HDTuneProLogoFile
$HDTuneProLogo.BorderStyle = 0
$HDTuneProLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HDTuneProLogo)

$HDTuneProCheckbox = New-Object System.Windows.Forms.Checkbox 
$HDTuneProCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$HDTuneProCheckbox.Text = "       HDTunePro"
$HDTuneProCheckbox.Width = 180
$HDTuneProCheckbox.Height = 20
$HDTuneProCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HDTuneProCheckbox)

$SamsungMagicianLogo = New-Object System.Windows.Forms.PictureBox
$SamsungMagicianLogo.Width = 18
$SamsungMagicianLogo.Height = 18
$SamsungMagicianLogo.Location = New-Object System.Drawing.Size(410,270)
$SamsungMagicianLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SamsungMagician.png"
$SamsungMagicianLogo.ImageLocation = $SamsungMagicianLogoFile
$SamsungMagicianLogo.BorderStyle = 0
$SamsungMagicianLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SamsungMagicianLogo)

$SamsungMagicianCheckbox = New-Object System.Windows.Forms.Checkbox 
$SamsungMagicianCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$SamsungMagicianCheckbox.Text = "       Samsung Magician"
$SamsungMagicianCheckbox.Width = 180
$SamsungMagicianCheckbox.Height = 20
$SamsungMagicianCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SamsungMagicianCheckbox)

$SeagateSeaToolsLogo = New-Object System.Windows.Forms.PictureBox
$SeagateSeaToolsLogo.Width = 18
$SeagateSeaToolsLogo.Height = 18
$SeagateSeaToolsLogo.Location = New-Object System.Drawing.Size(410,290)
$SeagateSeaToolsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SeagateSeaTools.png"
$SeagateSeaToolsLogo.ImageLocation = $SeagateSeaToolsLogoFile
$SeagateSeaToolsLogo.BorderStyle = 0
$SeagateSeaToolsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SeagateSeaToolsLogo)

$SeagateSeaToolsCheckbox = New-Object System.Windows.Forms.Checkbox 
$SeagateSeaToolsCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$SeagateSeaToolsCheckbox.Text = "       Seagate SeaTools"
$SeagateSeaToolsCheckbox.Width = 180
$SeagateSeaToolsCheckbox.Height = 20
$SeagateSeaToolsCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SeagateSeaToolsCheckbox)

$VictoriaLogo = New-Object System.Windows.Forms.PictureBox
$VictoriaLogo.Width = 18
$VictoriaLogo.Height = 18
$VictoriaLogo.Location = New-Object System.Drawing.Size(410,310)
$VictoriaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Victoria.png"
$VictoriaLogo.ImageLocation = $VictoriaLogoFile
$VictoriaLogo.BorderStyle = 0
$VictoriaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($VictoriaLogo)

$VictoriaCheckbox = New-Object System.Windows.Forms.Checkbox 
$VictoriaCheckbox.Location = New-Object System.Drawing.Size(390,310) 
$VictoriaCheckbox.Text = "       Victoria"
$VictoriaCheckbox.Width = 180
$VictoriaCheckbox.Height = 20
$VictoriaCheckbox.Font = $BodyFont
$Tab4.Controls.Add($VictoriaCheckbox)

$WDKitfoxLogo = New-Object System.Windows.Forms.PictureBox
$WDKitfoxLogo.Width = 18
$WDKitfoxLogo.Height = 18
$WDKitfoxLogo.Location = New-Object System.Drawing.Size(410,330)
$WDKitfoxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WDKitfox.png"
$WDKitfoxLogo.ImageLocation = $WDKitfoxLogoFile
$WDKitfoxLogo.BorderStyle = 0
$WDKitfoxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WDKitfoxLogo)

$WDKitfoxCheckbox = New-Object System.Windows.Forms.Checkbox 
$WDKitfoxCheckbox.Location = New-Object System.Drawing.Size(390,330) 
$WDKitfoxCheckbox.Text = "       WD Kitfox"
$WDKitfoxCheckbox.Width = 180
$WDKitfoxCheckbox.Height = 20
$WDKitfoxCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WDKitfoxCheckbox)

$MonitoringLabel = New-Object System.Windows.Forms.Label
$MonitoringLabel.Location = New-Object System.Drawing.Size(580,10)
$MonitoringLabel.Text = "Monitoring"
$MonitoringLabel.Width = 180
$MonitoringLabel.Height = 20
$MonitoringLabel.Font = $HeaderFont
$Tab4.Controls.Add($MonitoringLabel)

$AfterburnerLogo = New-Object System.Windows.Forms.PictureBox
$AfterburnerLogo.Width = 18
$AfterburnerLogo.Height = 18
$AfterburnerLogo.Location = New-Object System.Drawing.Size(600,30)
$AfterburnerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Afterburner.png"
$AfterburnerLogo.ImageLocation = $AfterburnerLogoFile
$AfterburnerLogo.BorderStyle = 0
$AfterburnerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AfterburnerLogo)

$AfterburnerCheckbox = New-Object System.Windows.Forms.Checkbox 
$AfterburnerCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$AfterburnerCheckbox.Text = "       Afterburner"
$AfterburnerCheckbox.Width = 180
$AfterburnerCheckbox.Height = 20
$AfterburnerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($AfterburnerCheckbox)

$AIDA64Logo = New-Object System.Windows.Forms.PictureBox
$AIDA64Logo.Width = 18
$AIDA64Logo.Height = 18
$AIDA64Logo.Location = New-Object System.Drawing.Size(600,50)
$AIDA64LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\AIDA64.png"
$AIDA64Logo.ImageLocation = $AIDA64LogoFile
$AIDA64Logo.BorderStyle = 0
$AIDA64Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AIDA64Logo)

$AIDA64Checkbox = New-Object System.Windows.Forms.Checkbox 
$AIDA64Checkbox.Location = New-Object System.Drawing.Size(580,50) 
$AIDA64Checkbox.Text = "       AIDA64"
$AIDA64Checkbox.Width = 180
$AIDA64Checkbox.Height = 20
$AIDA64Checkbox.Font = $BodyFont
$Tab4.Controls.Add($AIDA64Checkbox)

$CoreTempLogo = New-Object System.Windows.Forms.PictureBox
$CoreTempLogo.Width = 18
$CoreTempLogo.Height = 18
$CoreTempLogo.Location = New-Object System.Drawing.Size(600,70)
$CoreTempLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CoreTemp.png"
$CoreTempLogo.ImageLocation = $CoreTempLogoFile
$CoreTempLogo.BorderStyle = 0
$CoreTempLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CoreTempLogo)

$CoreTempCheckbox = New-Object System.Windows.Forms.Checkbox 
$CoreTempCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$CoreTempCheckbox.Text = "       Core Temp"
$CoreTempCheckbox.Width = 180
$CoreTempCheckbox.Height = 20
$CoreTempCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CoreTempCheckbox)

$CPUZLogo = New-Object System.Windows.Forms.PictureBox
$CPUZLogo.Width = 18
$CPUZLogo.Height = 18
$CPUZLogo.Location = New-Object System.Drawing.Size(600,90)
$CPUZLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CPUZ.png"
$CPUZLogo.ImageLocation = $CPUZLogoFile
$CPUZLogo.BorderStyle = 0
$CPUZLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CPUZLogo)

$CPUZCheckbox = New-Object System.Windows.Forms.Checkbox 
$CPUZCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$CPUZCheckbox.Text = "       CPU-Z"
$CPUZCheckbox.Width = 180
$CPUZCheckbox.Height = 20
$CPUZCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CPUZCheckbox)

$GPUZLogo = New-Object System.Windows.Forms.PictureBox
$GPUZLogo.Width = 18
$GPUZLogo.Height = 18
$GPUZLogo.Location = New-Object System.Drawing.Size(600,110)
$GPUZLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\GPUZ.png"
$GPUZLogo.ImageLocation = $GPUZLogoFile
$GPUZLogo.BorderStyle = 0
$GPUZLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GPUZLogo)

$GPUZCheckbox = New-Object System.Windows.Forms.Checkbox 
$GPUZCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$GPUZCheckbox.Text = "       GPU-Z"
$GPUZCheckbox.Width = 180
$GPUZCheckbox.Height = 20
$GPUZCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GPUZCheckbox)

$HWinfoLogo = New-Object System.Windows.Forms.PictureBox
$HWinfoLogo.Width = 18
$HWinfoLogo.Height = 18
$HWinfoLogo.Location = New-Object System.Drawing.Size(600,130)
$HWinfoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HWinfo.png"
$HWinfoLogo.ImageLocation = $HWinfoLogoFile
$HWinfoLogo.BorderStyle = 0
$HWinfoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HWinfoLogo)

$HWinfoCheckbox = New-Object System.Windows.Forms.Checkbox 
$HWinfoCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$HWinfoCheckbox.Text = "       HWinfo"
$HWinfoCheckbox.Width = 180
$HWinfoCheckbox.Height = 20
$HWinfoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HWinfoCheckbox)

$HWMonitorLogo = New-Object System.Windows.Forms.PictureBox
$HWMonitorLogo.Width = 18
$HWMonitorLogo.Height = 18
$HWMonitorLogo.Location = New-Object System.Drawing.Size(600,150)
$HWMonitorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HWMonitor.png"
$HWMonitorLogo.ImageLocation = $HWMonitorLogoFile
$HWMonitorLogo.BorderStyle = 0
$HWMonitorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HWMonitorLogo)

$HWMonitorCheckbox = New-Object System.Windows.Forms.Checkbox 
$HWMonitorCheckbox.Location = New-Object System.Drawing.Size(580,150) 
$HWMonitorCheckbox.Text = "       HWMonitor"
$HWMonitorCheckbox.Width = 180
$HWMonitorCheckbox.Height = 20
$HWMonitorCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HWMonitorCheckbox)

$OpenHardwareLogo = New-Object System.Windows.Forms.PictureBox
$OpenHardwareLogo.Width = 18
$OpenHardwareLogo.Height = 18
$OpenHardwareLogo.Location = New-Object System.Drawing.Size(600,170)
$OpenHardwareLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\OpenHardware.png"
$OpenHardwareLogo.ImageLocation = $OpenHardwareLogoFile
$OpenHardwareLogo.BorderStyle = 0
$OpenHardwareLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($OpenHardwareLogo)

$OpenHardwareCheckbox = New-Object System.Windows.Forms.Checkbox 
$OpenHardwareCheckbox.Location = New-Object System.Drawing.Size(580,170) 
$OpenHardwareCheckbox.Text = "       Open Hardware"
$OpenHardwareCheckbox.Width = 180
$OpenHardwareCheckbox.Height = 20
$OpenHardwareCheckbox.Font = $BodyFont
$Tab4.Controls.Add($OpenHardwareCheckbox)

$RainmeterLogo = New-Object System.Windows.Forms.PictureBox
$RainmeterLogo.Width = 18
$RainmeterLogo.Height = 18
$RainmeterLogo.Location = New-Object System.Drawing.Size(600,190)
$RainmeterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\General\Rainmeter.png"
$RainmeterLogo.ImageLocation = $RainmeterLogoFile
$RainmeterLogo.BorderStyle = 0
$RainmeterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RainmeterLogo)

$RainmeterCheckbox = New-Object System.Windows.Forms.Checkbox 
$RainmeterCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$RainmeterCheckbox.Text = "       Rainmeter"
$RainmeterCheckbox.Width = 180
$RainmeterCheckbox.Height = 20
$RainmeterCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RainmeterCheckbox)

$RyzenMasterLogo = New-Object System.Windows.Forms.PictureBox
$RyzenMasterLogo.Width = 18
$RyzenMasterLogo.Height = 18
$RyzenMasterLogo.Location = New-Object System.Drawing.Size(600,210)
$RyzenMasterLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\RyzenMaster.png"
$RyzenMasterLogo.ImageLocation = $RyzenMasterLogoFile
$RyzenMasterLogo.BorderStyle = 0
$RyzenMasterLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RyzenMasterLogo)

$RyzenMasterCheckbox = New-Object System.Windows.Forms.Checkbox 
$RyzenMasterCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$RyzenMasterCheckbox.Text = "       Ryzen Master"
$RyzenMasterCheckbox.Width = 180
$RyzenMasterCheckbox.Height = 20
$RyzenMasterCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RyzenMasterCheckbox)

$SpeccyLogo = New-Object System.Windows.Forms.PictureBox
$SpeccyLogo.Width = 18
$SpeccyLogo.Height = 18
$SpeccyLogo.Location = New-Object System.Drawing.Size(600,230)
$SpeccyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Speccy.png"
$SpeccyLogo.ImageLocation = $SpeccyLogoFile
$SpeccyLogo.BorderStyle = 0
$SpeccyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SpeccyLogo)

$SpeccyCheckbox = New-Object System.Windows.Forms.Checkbox 
$SpeccyCheckbox.Location = New-Object System.Drawing.Size(580,230) 
$SpeccyCheckbox.Text = "       Speccy"
$SpeccyCheckbox.Width = 180
$SpeccyCheckbox.Height = 20
$SpeccyCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SpeccyCheckbox)

$WhySoSlowLogo = New-Object System.Windows.Forms.PictureBox
$WhySoSlowLogo.Width = 18
$WhySoSlowLogo.Height = 18
$WhySoSlowLogo.Location = New-Object System.Drawing.Size(600,250)
$WhySoSlowLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WhySoSlow.png"
$WhySoSlowLogo.ImageLocation = $WhySoSlowLogoFile
$WhySoSlowLogo.BorderStyle = 0
$WhySoSlowLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WhySoSlowLogo)

$WhySoSlowCheckbox = New-Object System.Windows.Forms.Checkbox 
$WhySoSlowCheckbox.Location = New-Object System.Drawing.Size(580,250) 
$WhySoSlowCheckbox.Text = "       WhySoSlow"
$WhySoSlowCheckbox.Width = 180
$WhySoSlowCheckbox.Height = 20
$WhySoSlowCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WhySoSlowCheckbox)

$NetworkLabel = New-Object System.Windows.Forms.Label
$NetworkLabel.Location = New-Object System.Drawing.Size(770,10)
$NetworkLabel.Text = "Network"
$NetworkLabel.Width = 180
$NetworkLabel.Height = 20
$NetworkLabel.Font = $HeaderFont
$Tab4.Controls.Add($NetworkLabel)

$WifiAnalyzerLogo = New-Object System.Windows.Forms.PictureBox
$WifiAnalyzerLogo.Width = 18
$WifiAnalyzerLogo.Height = 18
$WifiAnalyzerLogo.Location = New-Object System.Drawing.Size(790,30)
$WifiAnalyzerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WifiAnalyzer.png"
$WifiAnalyzerLogo.ImageLocation = $WifiAnalyzerLogoFile
$WifiAnalyzerLogo.BorderStyle = 0
$WifiAnalyzerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WifiAnalyzerLogo)

$WifiAnalyzerCheckbox = New-Object System.Windows.Forms.Checkbox 
$WifiAnalyzerCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$WifiAnalyzerCheckbox.Text = "       Wifi Analyzer"
$WifiAnalyzerCheckbox.Width = 180
$WifiAnalyzerCheckbox.Height = 20
$WifiAnalyzerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WifiAnalyzerCheckbox)

$WiresharkLogo = New-Object System.Windows.Forms.PictureBox
$WiresharkLogo.Width = 18
$WiresharkLogo.Height = 18
$WiresharkLogo.Location = New-Object System.Drawing.Size(790,50)
$WiresharkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Wireshark.png"
$WiresharkLogo.ImageLocation = $WiresharkLogoFile
$WiresharkLogo.BorderStyle = 0
$WiresharkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WiresharkLogo)

$WiresharkCheckbox = New-Object System.Windows.Forms.Checkbox 
$WiresharkCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$WiresharkCheckbox.Text = "       Wireshark"
$WiresharkCheckbox.Width = 180
$WiresharkCheckbox.Height = 20
$WiresharkCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WiresharkCheckbox)

$RAMLabel = New-Object System.Windows.Forms.Label
$RAMLabel.Location = New-Object System.Drawing.Size(770,90)
$RAMLabel.Text = "RAM"
$RAMLabel.Width = 180
$RAMLabel.Height = 20
$RAMLabel.Font = $HeaderFont
$Tab4.Controls.Add($RAMLabel)

$MemTest86Logo = New-Object System.Windows.Forms.PictureBox
$MemTest86Logo.Width = 18
$MemTest86Logo.Height = 18
$MemTest86Logo.Location = New-Object System.Drawing.Size(790,110)
$MemTest86LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\MemTest86.png"
$MemTest86Logo.ImageLocation = $MemTest86LogoFile
$MemTest86Logo.BorderStyle = 0
$MemTest86Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($MemTest86Logo)

$MemTest86Checkbox = New-Object System.Windows.Forms.Checkbox 
$MemTest86Checkbox.Location = New-Object System.Drawing.Size(770,110) 
$MemTest86Checkbox.Text = "       MemTest86"
$MemTest86Checkbox.Width = 180
$MemTest86Checkbox.Height = 20
$MemTest86Checkbox.Font = $BodyFont
$Tab4.Controls.Add($MemTest86Checkbox)

$WinMemoryDiagLogo = New-Object System.Windows.Forms.PictureBox
$WinMemoryDiagLogo.Width = 18
$WinMemoryDiagLogo.Height = 18
$WinMemoryDiagLogo.Location = New-Object System.Drawing.Size(790,130)
$WinMemoryDiagLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WinMemoryDiag.png"
$WinMemoryDiagLogo.ImageLocation = $WinMemoryDiagLogoFile
$WinMemoryDiagLogo.BorderStyle = 0
$WinMemoryDiagLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WinMemoryDiagLogo)

$WinMemoryDiagCheckbox = New-Object System.Windows.Forms.Checkbox 
$WinMemoryDiagCheckbox.Location = New-Object System.Drawing.Size(770,130) 
$WinMemoryDiagCheckbox.Text = "       Win Memory Diag"
$WinMemoryDiagCheckbox.Width = 180
$WinMemoryDiagCheckbox.Height = 20
$WinMemoryDiagCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WinMemoryDiagCheckbox)

$SystemLabel = New-Object System.Windows.Forms.Label
$SystemLabel.Location = New-Object System.Drawing.Size(770,170)
$SystemLabel.Text = "System Diag"
$SystemLabel.Width = 180
$SystemLabel.Height = 20
$SystemLabel.Font = $HeaderFont
$Tab4.Controls.Add($SystemLabel)

$ESETSysinspectorLogo = New-Object System.Windows.Forms.PictureBox
$ESETSysinspectorLogo.Width = 18
$ESETSysinspectorLogo.Height = 18
$ESETSysinspectorLogo.Location = New-Object System.Drawing.Size(790,190)
$ESETSysinspectorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\ESET.png"
$ESETSysinspectorLogo.ImageLocation = $ESETSysinspectorLogoFile
$ESETSysinspectorLogo.BorderStyle = 0
$ESETSysinspectorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($ESETSysinspectorLogo)

$ESETSysinspectorCheckbox = New-Object System.Windows.Forms.Checkbox 
$ESETSysinspectorCheckbox.Location = New-Object System.Drawing.Size(770,190) 
$ESETSysinspectorCheckbox.Text = "       ESET Sysinspector"
$ESETSysinspectorCheckbox.Width = 180
$ESETSysinspectorCheckbox.Height = 20
$ESETSysinspectorCheckbox.Font = $BodyFont
$Tab4.Controls.Add($ESETSysinspectorCheckbox)

$HeavyLoadLogo = New-Object System.Windows.Forms.PictureBox
$HeavyLoadLogo.Width = 18
$HeavyLoadLogo.Height = 18
$HeavyLoadLogo.Location = New-Object System.Drawing.Size(790,210)
$HeavyLoadLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HeavyLoad.png"
$HeavyLoadLogo.ImageLocation = $HeavyLoadLogoFile
$HeavyLoadLogo.BorderStyle = 0
$HeavyLoadLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HeavyLoadLogo)

$HeavyLoadCheckbox = New-Object System.Windows.Forms.Checkbox 
$HeavyLoadCheckbox.Location = New-Object System.Drawing.Size(770,210) 
$HeavyLoadCheckbox.Text = "       HeavyLoad"
$HeavyLoadCheckbox.Width = 180
$HeavyLoadCheckbox.Height = 20
$HeavyLoadCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HeavyLoadCheckbox)

$HPDiagLogo = New-Object System.Windows.Forms.PictureBox
$HPDiagLogo.Width = 18
$HPDiagLogo.Height = 18
$HPDiagLogo.Location = New-Object System.Drawing.Size(790,230)
$HPDiagLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\HPDiag.png"
$HPDiagLogo.ImageLocation = $HPDiagLogoFile
$HPDiagLogo.BorderStyle = 0
$HPDiagLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($HPDiagLogo)

$HPDiagCheckbox = New-Object System.Windows.Forms.Checkbox 
$HPDiagCheckbox.Location = New-Object System.Drawing.Size(770,230) 
$HPDiagCheckbox.Text = "       HP Diag"
$HPDiagCheckbox.Width = 180
$HPDiagCheckbox.Height = 20
$HPDiagCheckbox.Font = $BodyFont
$Tab4.Controls.Add($HPDiagCheckbox)

$OCCTLogo = New-Object System.Windows.Forms.PictureBox
$OCCTLogo.Width = 18
$OCCTLogo.Height = 18
$OCCTLogo.Location = New-Object System.Drawing.Size(790,250)
$OCCTLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\OCCT.png"
$OCCTLogo.ImageLocation = $OCCTLogoFile
$OCCTLogo.BorderStyle = 0
$OCCTLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($OCCTLogo)

$OCCTCheckbox = New-Object System.Windows.Forms.Checkbox 
$OCCTCheckbox.Location = New-Object System.Drawing.Size(770,250) 
$OCCTCheckbox.Text = "       OCCT"
$OCCTCheckbox.Width = 180
$OCCTCheckbox.Height = 20
$OCCTCheckbox.Font = $BodyFont
$Tab4.Controls.Add($OCCTCheckbox)

$UninstallerLabel = New-Object System.Windows.Forms.Label
$UninstallerLabel.Location = New-Object System.Drawing.Size(960,10)
$UninstallerLabel.Text = "Uninstaller"
$UninstallerLabel.Width = 180
$UninstallerLabel.Height = 20
$UninstallerLabel.Font = $HeaderFont
$Tab4.Controls.Add($UninstallerLabel)

$GeekUninstallerLogo = New-Object System.Windows.Forms.PictureBox
$GeekUninstallerLogo.Width = 18
$GeekUninstallerLogo.Height = 18
$GeekUninstallerLogo.Location = New-Object System.Drawing.Size(980,30)
$GeekUninstallerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\GeekUninstaller.png"
$GeekUninstallerLogo.ImageLocation = $GeekUninstallerLogoFile
$GeekUninstallerLogo.BorderStyle = 0
$GeekUninstallerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GeekUninstallerLogo)

$GeekUninstallerCheckbox = New-Object System.Windows.Forms.Checkbox 
$GeekUninstallerCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$GeekUninstallerCheckbox.Text = "       Geek Uninstaller"
$GeekUninstallerCheckbox.Width = 180
$GeekUninstallerCheckbox.Height = 20
$GeekUninstallerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GeekUninstallerCheckbox)

$RevoLogo = New-Object System.Windows.Forms.PictureBox
$RevoLogo.Width = 18
$RevoLogo.Height = 18
$RevoLogo.Location = New-Object System.Drawing.Size(980,50)
$RevoLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Revo.png"
$RevoLogo.ImageLocation = $RevoLogoFile
$RevoLogo.BorderStyle = 0
$RevoLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($RevoLogo)

$RevoCheckbox = New-Object System.Windows.Forms.Checkbox 
$RevoCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$RevoCheckbox.Text = "       Revo Uninstaller"
$RevoCheckbox.Width = 180
$RevoCheckbox.Height = 20
$RevoCheckbox.Font = $BodyFont
$Tab4.Controls.Add($RevoCheckbox)

$Utilities2Label = New-Object System.Windows.Forms.Label
$Utilities2Label.Location = New-Object System.Drawing.Size(960,90) 
$Utilities2Label.Text = "Utilities"
$Utilities2Label.Width = 180
$Utilities2Label.Height = 20
$Utilities2Label.Font = $HeaderFont
$Tab4.Controls.Add($Utilities2Label)

$AutorunsLogo = New-Object System.Windows.Forms.PictureBox
$AutorunsLogo.Width = 18
$AutorunsLogo.Height = 18
$AutorunsLogo.Location = New-Object System.Drawing.Size(980,110)
$AutorunsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Autoruns.png"
$AutorunsLogo.ImageLocation = $AutorunsLogoFile
$AutorunsLogo.BorderStyle = 0
$AutorunsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($AutorunsLogo)

$AutorunsCheckbox = New-Object System.Windows.Forms.Checkbox 
$AutorunsCheckbox.Location = New-Object System.Drawing.Size(960,110) 
$AutorunsCheckbox.Text = "       Autoruns"
$AutorunsCheckbox.Width = 180
$AutorunsCheckbox.Height = 20
$AutorunsCheckbox.Font = $BodyFont
$Tab4.Controls.Add($AutorunsCheckbox)

$BlueScreenViewLogo = New-Object System.Windows.Forms.PictureBox
$BlueScreenViewLogo.Width = 18
$BlueScreenViewLogo.Height = 18
$BlueScreenViewLogo.Location = New-Object System.Drawing.Size(980,130)
$BlueScreenViewLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\BlueScreenView.png"
$BlueScreenViewLogo.ImageLocation = $BlueScreenViewLogoFile
$BlueScreenViewLogo.BorderStyle = 0
$BlueScreenViewLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($BlueScreenViewLogo)

$BlueScreenViewCheckbox = New-Object System.Windows.Forms.Checkbox 
$BlueScreenViewCheckbox.Location = New-Object System.Drawing.Size(960,130) 
$BlueScreenViewCheckbox.Text = "       BlueScreenView"
$BlueScreenViewCheckbox.Width = 180
$BlueScreenViewCheckbox.Height = 20
$BlueScreenViewCheckbox.Font = $BodyFont
$Tab4.Controls.Add($BlueScreenViewCheckbox)

$CCleanerLogo = New-Object System.Windows.Forms.PictureBox
$CCleanerLogo.Width = 18
$CCleanerLogo.Height = 18
$CCleanerLogo.Location = New-Object System.Drawing.Size(980,150)
$CCleanerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\CCleaner.png"
$CCleanerLogo.ImageLocation = $CCleanerLogoFile
$CCleanerLogo.BorderStyle = 0
$CCleanerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($CCleanerLogo)

$CCleanerCheckbox = New-Object System.Windows.Forms.Checkbox 
$CCleanerCheckbox.Location = New-Object System.Drawing.Size(960,150) 
$CCleanerCheckbox.Text = "       CCleaner"
$CCleanerCheckbox.Width = 180
$CCleanerCheckbox.Height = 20
$CCleanerCheckbox.Font = $BodyFont
$Tab4.Controls.Add($CCleanerCheckbox)

$GlaryLogo = New-Object System.Windows.Forms.PictureBox
$GlaryLogo.Width = 18
$GlaryLogo.Height = 18
$GlaryLogo.Location = New-Object System.Drawing.Size(980,170)
$GlaryLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\Glary.png"
$GlaryLogo.ImageLocation = $GlaryLogoFile
$GlaryLogo.BorderStyle = 0
$GlaryLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($GlaryLogo)

$GlaryCheckbox = New-Object System.Windows.Forms.Checkbox 
$GlaryCheckbox.Location = New-Object System.Drawing.Size(960,170) 
$GlaryCheckbox.Text = "       Glary Utilities"
$GlaryCheckbox.Width = 180
$GlaryCheckbox.Height = 20
$GlaryCheckbox.Font = $BodyFont
$Tab4.Controls.Add($GlaryCheckbox)

$SysinternalsSuiteLogo = New-Object System.Windows.Forms.PictureBox
$SysinternalsSuiteLogo.Width = 18
$SysinternalsSuiteLogo.Height = 18
$SysinternalsSuiteLogo.Location = New-Object System.Drawing.Size(980,190)
$SysinternalsSuiteLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\SysinternalsSuite.png"
$SysinternalsSuiteLogo.ImageLocation = $SysinternalsSuiteLogoFile
$SysinternalsSuiteLogo.BorderStyle = 0
$SysinternalsSuiteLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($SysinternalsSuiteLogo)

$SysinternalsSuiteCheckbox = New-Object System.Windows.Forms.Checkbox 
$SysinternalsSuiteCheckbox.Location = New-Object System.Drawing.Size(960,190) 
$SysinternalsSuiteCheckbox.Text = "       Sysinternals Suite"
$SysinternalsSuiteCheckbox.Width = 180
$SysinternalsSuiteCheckbox.Height = 20
$SysinternalsSuiteCheckbox.Font = $BodyFont
$Tab4.Controls.Add($SysinternalsSuiteCheckbox)

$WhoCrashedLogo = New-Object System.Windows.Forms.PictureBox
$WhoCrashedLogo.Width = 18
$WhoCrashedLogo.Height = 18
$WhoCrashedLogo.Location = New-Object System.Drawing.Size(980,210)
$WhoCrashedLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Diagnostic\WhoCrashed.png"
$WhoCrashedLogo.ImageLocation = $WhoCrashedLogoFile
$WhoCrashedLogo.BorderStyle = 0
$WhoCrashedLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab4.Controls.Add($WhoCrashedLogo)

$WhoCrashedCheckbox = New-Object System.Windows.Forms.Checkbox 
$WhoCrashedCheckbox.Location = New-Object System.Drawing.Size(960,210) 
$WhoCrashedCheckbox.Text = "       WhoCrashed"
$WhoCrashedCheckbox.Width = 180
$WhoCrashedCheckbox.Height = 20
$WhoCrashedCheckbox.Font = $BodyFont
$Tab4.Controls.Add($WhoCrashedCheckbox)

# Tab 5 SECURITY

$Tab5 = New-Object System.Windows.Forms.TabPage
$Tab5.Text = "Security"
$Tab5.Font = $TabFont
$Tab5.Autoscroll  = $True
$TabControl.Controls.Add($Tab5)

$AntiMalwareLabel = New-Object System.Windows.Forms.Label
$AntiMalwareLabel.Location = New-Object System.Drawing.Size(10,10)
$AntiMalwareLabel.Text = "Anti-Malware"
$AntiMalwareLabel.Width = 180
$AntiMalwareLabel.Height = 20
$AntiMalwareLabel.Font = $HeaderFont
$Tab5.Controls.Add($AntiMalwareLabel)

$AdwCleanerLogo = New-Object System.Windows.Forms.PictureBox
$AdwCleanerLogo.Width = 18
$AdwCleanerLogo.Height = 18
$AdwCleanerLogo.Location = New-Object System.Drawing.Size(30,30)
$AdwCleanerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\AdwCleaner.png"
$AdwCleanerLogo.ImageLocation = $AdwCleanerLogoFile
$AdwCleanerLogo.BorderStyle = 0
$AdwCleanerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AdwCleanerLogo)

$AdwCleanerCheckbox = New-Object System.Windows.Forms.Checkbox 
$AdwCleanerCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$AdwCleanerCheckbox.Text = "       AdwCleaner"
$AdwCleanerCheckbox.Width = 180
$AdwCleanerCheckbox.Height = 20
$AdwCleanerCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AdwCleanerCheckbox)

$MalwareBytesLogo = New-Object System.Windows.Forms.PictureBox
$MalwareBytesLogo.Width = 18
$MalwareBytesLogo.Height = 18
$MalwareBytesLogo.Location = New-Object System.Drawing.Size(30,50)
$MalwareBytesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\MalwareBytes.png"
$MalwareBytesLogo.ImageLocation = $MalwareBytesLogoFile
$MalwareBytesLogo.BorderStyle = 0
$MalwareBytesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($MalwareBytesLogo)

$MalwareBytesCheckbox = New-Object System.Windows.Forms.Checkbox 
$MalwareBytesCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$MalwareBytesCheckbox.Text = "       MalwareBytes"
$MalwareBytesCheckbox.Width = 180
$MalwareBytesCheckbox.Height = 20
$MalwareBytesCheckbox.Font = $BodyFont
$Tab5.Controls.Add($MalwareBytesCheckbox)

$OSArmorLogo = New-Object System.Windows.Forms.PictureBox
$OSArmorLogo.Width = 18
$OSArmorLogo.Height = 18
$OSArmorLogo.Location = New-Object System.Drawing.Size(30,70)
$OSArmorLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\OSArmor.png"
$OSArmorLogo.ImageLocation = $OSArmorLogoFile
$OSArmorLogo.BorderStyle = 0
$OSArmorLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($OSArmorLogo)

$OSArmorCheckbox = New-Object System.Windows.Forms.Checkbox 
$OSArmorCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$OSArmorCheckbox.Text = "       OSArmor"
$OSArmorCheckbox.Width = 180
$OSArmorCheckbox.Height = 20
$OSArmorCheckbox.Font = $BodyFont
$Tab5.Controls.Add($OSArmorCheckbox)

$AntivirusLabel = New-Object System.Windows.Forms.Label
$AntivirusLabel.Location = New-Object System.Drawing.Size(200,10)
$AntivirusLabel.Text = "Antivirus"
$AntivirusLabel.Width = 180
$AntivirusLabel.Height = 20
$AntivirusLabel.Font = $HeaderFont
$Tab5.Controls.Add($AntivirusLabel)

$AvastLogo = New-Object System.Windows.Forms.PictureBox
$AvastLogo.Width = 18
$AvastLogo.Height = 18
$AvastLogo.Location = New-Object System.Drawing.Size(220,30)
$AvastLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Avast.png"
$AvastLogo.ImageLocation = $AvastLogoFile
$AvastLogo.BorderStyle = 0
$AvastLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AvastLogo)

$AvastCheckbox = New-Object System.Windows.Forms.Checkbox
$AvastCheckbox.Location = New-Object System.Drawing.Size(200,30)
$AvastCheckbox.Text = "       Avast"
$AvastCheckbox.Width = 180
$AvastCheckbox.Height = 20
$AvastCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AvastCheckbox)

$AVGLogo = New-Object System.Windows.Forms.PictureBox
$AVGLogo.Width = 18
$AVGLogo.Height = 18
$AVGLogo.Location = New-Object System.Drawing.Size(220,50)
$AVGLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\AVG.png"
$AVGLogo.ImageLocation = $AVGLogoFile
$AVGLogo.BorderStyle = 0
$AVGLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AVGLogo)

$AVGCheckbox = New-Object System.Windows.Forms.Checkbox 
$AVGCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$AVGCheckbox.Text = "       AVG"
$AVGCheckbox.Width = 180
$AVGCheckbox.Height = 20
$AVGCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AVGCheckbox)

$AviraLogo = New-Object System.Windows.Forms.PictureBox
$AviraLogo.Width = 18
$AviraLogo.Height = 18
$AviraLogo.Location = New-Object System.Drawing.Size(220,70)
$AviraLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Avira.png"
$AviraLogo.ImageLocation = $AviraLogoFile
$AviraLogo.BorderStyle = 0
$AviraLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AviraLogo)

$AviraCheckbox = New-Object System.Windows.Forms.Checkbox 
$AviraCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$AviraCheckbox.Text = "       Avira"
$AviraCheckbox.Width = 180
$AviraCheckbox.Height = 20
$AviraCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AviraCheckbox)

$BitdefenderLogo = New-Object System.Windows.Forms.PictureBox
$BitdefenderLogo.Width = 18
$BitdefenderLogo.Height = 18
$BitdefenderLogo.Location = New-Object System.Drawing.Size(220,90)
$BitdefenderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Bitdefender.png"
$BitdefenderLogo.ImageLocation = $BitdefenderLogoFile
$BitdefenderLogo.BorderStyle = 0
$BitdefenderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($BitdefenderLogo)

$BitdefenderCheckbox = New-Object System.Windows.Forms.Checkbox 
$BitdefenderCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$BitdefenderCheckbox.Text = "       Bitdefender"
$BitdefenderCheckbox.Width = 180
$BitdefenderCheckbox.Height = 20
$BitdefenderCheckbox.Font = $BodyFont
$Tab5.Controls.Add($BitdefenderCheckbox)

$ESETNod32Logo = New-Object System.Windows.Forms.PictureBox
$ESETNod32Logo.Width = 18
$ESETNod32Logo.Height = 18
$ESETNod32Logo.Location = New-Object System.Drawing.Size(220,110)
$ESETNod32LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\ESET.png"
$ESETNod32Logo.ImageLocation = $ESETNod32LogoFile
$ESETNod32Logo.BorderStyle = 0
$ESETNod32Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($ESETNod32Logo)

$ESETNod32Checkbox = New-Object System.Windows.Forms.Checkbox 
$ESETNod32Checkbox.Location = New-Object System.Drawing.Size(200,110) 
$ESETNod32Checkbox.Text = "       ESET Nod32"
$ESETNod32Checkbox.Width = 180
$ESETNod32Checkbox.Height = 20
$ESETNod32Checkbox.Font = $BodyFont
$Tab5.Controls.Add($ESETNod32Checkbox)

$Norton360Logo = New-Object System.Windows.Forms.PictureBox
$Norton360Logo.Width = 18
$Norton360Logo.Height = 18
$Norton360Logo.Location = New-Object System.Drawing.Size(220,130)
$Norton360LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Norton360.png"
$Norton360Logo.ImageLocation = $Norton360LogoFile
$Norton360Logo.BorderStyle = 0
$Norton360Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($Norton360Logo)

$Norton360Checkbox = New-Object System.Windows.Forms.Checkbox 
$Norton360Checkbox.Location = New-Object System.Drawing.Size(200,130) 
$Norton360Checkbox.Text = "       Norton360"
$Norton360Checkbox.Width = 180
$Norton360Checkbox.Height = 20
$Norton360Checkbox.Font = $BodyFont
$Tab5.Controls.Add($Norton360Checkbox)

$PandaLogo = New-Object System.Windows.Forms.PictureBox
$PandaLogo.Width = 18
$PandaLogo.Height = 18
$PandaLogo.Location = New-Object System.Drawing.Size(220,150)
$PandaLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Panda.png"
$PandaLogo.ImageLocation = $PandaLogoFile
$PandaLogo.BorderStyle = 0
$PandaLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($PandaLogo)

$PandaCheckbox = New-Object System.Windows.Forms.Checkbox 
$PandaCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$PandaCheckbox.Text = "       Panda"
$PandaCheckbox.Width = 180
$PandaCheckbox.Height = 20
$PandaCheckbox.Font = $BodyFont
$Tab5.Controls.Add($PandaCheckbox)

$TotalAVLogo = New-Object System.Windows.Forms.PictureBox
$TotalAVLogo.Width = 18
$TotalAVLogo.Height = 18
$TotalAVLogo.Location = New-Object System.Drawing.Size(220,170)
$TotalAVLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\TotalAV.png"
$TotalAVLogo.ImageLocation = $TotalAVLogoFile
$TotalAVLogo.BorderStyle = 0
$TotalAVLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($TotalAVLogo)

$TotalAVCheckbox = New-Object System.Windows.Forms.Checkbox 
$TotalAVCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$TotalAVCheckbox.Text = "       TotalAV"
$TotalAVCheckbox.Width = 180
$TotalAVCheckbox.Height = 20
$TotalAVCheckbox.Font = $BodyFont
$Tab5.Controls.Add($TotalAVCheckbox)

$TrendMicroLogo = New-Object System.Windows.Forms.PictureBox
$TrendMicroLogo.Width = 18
$TrendMicroLogo.Height = 18
$TrendMicroLogo.Location = New-Object System.Drawing.Size(220,190)
$TrendMicroLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\TrendMicro.png"
$TrendMicroLogo.ImageLocation = $TrendMicroLogoFile
$TrendMicroLogo.BorderStyle = 0
$TrendMicroLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($TrendMicroLogo)

$TrendMicroCheckbox = New-Object System.Windows.Forms.Checkbox 
$TrendMicroCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$TrendMicroCheckbox.Text = "       TrendMicro"
$TrendMicroCheckbox.Width = 180
$TrendMicroCheckbox.Height = 20
$TrendMicroCheckbox.Font = $BodyFont
$Tab5.Controls.Add($TrendMicroCheckbox)

$WebrootLogo = New-Object System.Windows.Forms.PictureBox
$WebrootLogo.Width = 18
$WebrootLogo.Height = 18
$WebrootLogo.Location = New-Object System.Drawing.Size(220,210)
$WebrootLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Webroot.png"
$WebrootLogo.ImageLocation = $WebrootLogoFile
$WebrootLogo.BorderStyle = 0
$WebrootLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($WebrootLogo)

$WebrootCheckbox = New-Object System.Windows.Forms.Checkbox 
$WebrootCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$WebrootCheckbox.Text = "       Webroot"
$WebrootCheckbox.Width = 180
$WebrootCheckbox.Height = 20
$WebrootCheckbox.Font = $BodyFont
$Tab5.Controls.Add($WebrootCheckbox)

$BackupLabel = New-Object System.Windows.Forms.Label
$BackupLabel.Location = New-Object System.Drawing.Size(390,10)
$BackupLabel.Text = "Backup"
$BackupLabel.Width = 180
$BackupLabel.Height = 20
$BackupLabel.Font = $HeaderFont
$Tab5.Controls.Add($BackupLabel)

$CitrixLogo = New-Object System.Windows.Forms.PictureBox
$CitrixLogo.Width = 18
$CitrixLogo.Height = 18
$CitrixLogo.Location = New-Object System.Drawing.Size(410,30)
$CitrixLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Citrix.png"
$CitrixLogo.ImageLocation = $CitrixLogoFile
$CitrixLogo.BorderStyle = 0
$CitrixLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($CitrixLogo)

$CitrixCheckbox = New-Object System.Windows.Forms.Checkbox 
$CitrixCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$CitrixCheckbox.Text = "       Citrix"
$CitrixCheckbox.Width = 180
$CitrixCheckbox.Height = 20
$CitrixCheckbox.Font = $BodyFont
$Tab5.Controls.Add($CitrixCheckbox)

$DropboxLogo = New-Object System.Windows.Forms.PictureBox
$DropboxLogo.Width = 18
$DropboxLogo.Height = 18
$DropboxLogo.Location = New-Object System.Drawing.Size(410,50)
$DropboxLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Dropbox.png"
$DropboxLogo.ImageLocation = $DropboxLogoFile
$DropboxLogo.BorderStyle = 0
$DropboxLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DropboxLogo)

$DropboxCheckbox = New-Object System.Windows.Forms.Checkbox 
$DropboxCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$DropboxCheckbox.Text = "       Dropbox"
$DropboxCheckbox.Width = 180
$DropboxCheckbox.Height = 20
$DropboxCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DropboxCheckbox)

$GoogleDriveLogo = New-Object System.Windows.Forms.PictureBox
$GoogleDriveLogo.Width = 18
$GoogleDriveLogo.Height = 18
$GoogleDriveLogo.Location = New-Object System.Drawing.Size(410,70)
$GoogleDriveLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\GoogleDrive.png"
$GoogleDriveLogo.ImageLocation = $GoogleDriveLogoFile
$GoogleDriveLogo.BorderStyle = 0
$GoogleDriveLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($GoogleDriveLogo)

$GoogleDriveCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoogleDriveCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$GoogleDriveCheckbox.Text = "       Google Drive"
$GoogleDriveCheckbox.Width = 180
$GoogleDriveCheckbox.Height = 20
$GoogleDriveCheckbox.Font = $BodyFont
$Tab5.Controls.Add($GoogleDriveCheckbox)

$iCloudLogo = New-Object System.Windows.Forms.PictureBox
$iCloudLogo.Width = 18
$iCloudLogo.Height = 18
$iCloudLogo.Location = New-Object System.Drawing.Size(410,90)
$iCloudLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\iCloud.png"
$iCloudLogo.ImageLocation = $iCloudLogoFile
$iCloudLogo.BorderStyle = 0
$iCloudLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($iCloudLogo)

$iCloudCheckbox = New-Object System.Windows.Forms.Checkbox 
$iCloudCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$iCloudCheckbox.Text = "       iCloud"
$iCloudCheckbox.Width = 180
$iCloudCheckbox.Height = 20
$iCloudCheckbox.Font = $BodyFont
$Tab5.Controls.Add($iCloudCheckbox)

$DuplicatiLogo = New-Object System.Windows.Forms.PictureBox
$DuplicatiLogo.Width = 18
$DuplicatiLogo.Height = 18
$DuplicatiLogo.Location = New-Object System.Drawing.Size(410,110)
$DuplicatiLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Duplicati.png"
$DuplicatiLogo.ImageLocation = $DuplicatiLogoFile
$DuplicatiLogo.BorderStyle = 0
$DuplicatiLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DuplicatiLogo)

$DuplicatiCheckbox = New-Object System.Windows.Forms.Checkbox 
$DuplicatiCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$DuplicatiCheckbox.Text = "       Duplicati"
$DuplicatiCheckbox.Width = 180
$DuplicatiCheckbox.Height = 20
$DuplicatiCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DuplicatiCheckbox)

$TodoBackupLogo = New-Object System.Windows.Forms.PictureBox
$TodoBackupLogo.Width = 18
$TodoBackupLogo.Height = 18
$TodoBackupLogo.Location = New-Object System.Drawing.Size(410,130)
$TodoBackupLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\TodoBackup.png"
$TodoBackupLogo.ImageLocation = $TodoBackupLogoFile
$TodoBackupLogo.BorderStyle = 0
$TodoBackupLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($TodoBackupLogo)

$TodoBackupCheckbox = New-Object System.Windows.Forms.Checkbox 
$TodoBackupCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$TodoBackupCheckbox.Text = "       Todo Backup"
$TodoBackupCheckbox.Width = 180
$TodoBackupCheckbox.Height = 20
$TodoBackupCheckbox.Font = $BodyFont
$Tab5.Controls.Add($TodoBackupCheckbox)

$DashboardLabel = New-Object System.Windows.Forms.Label
$DashboardLabel.Location = New-Object System.Drawing.Size(390,170)
$DashboardLabel.Text = "Dashboard"
$DashboardLabel.Width = 180
$DashboardLabel.Height = 20
$DashboardLabel.Font = $HeaderFont
$Tab5.Controls.Add($DashboardLabel)

$DefenderLogo = New-Object System.Windows.Forms.PictureBox
$DefenderLogo.Width = 18
$DefenderLogo.Height = 18
$DefenderLogo.Location = New-Object System.Drawing.Size(410,190)
$DefenderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Defender.png"
$DefenderLogo.ImageLocation = $DefenderLogoFile
$DefenderLogo.BorderStyle = 0
$DefenderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($DefenderLogo)

$DefenderCheckbox = New-Object System.Windows.Forms.Checkbox 
$DefenderCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$DefenderCheckbox.Text = "       Defender"
$DefenderCheckbox.Width = 180
$DefenderCheckbox.Height = 20
$DefenderCheckbox.Font = $BodyFont
$Tab5.Controls.Add($DefenderCheckbox)

$EncryptDeleteLabel = New-Object System.Windows.Forms.Label
$EncryptDeleteLabel.Location = New-Object System.Drawing.Size(390,230)
$EncryptDeleteLabel.Text = "Encrypt/Delete"
$EncryptDeleteLabel.Width = 180
$EncryptDeleteLabel.Height = 20
$EncryptDeleteLabel.Font = $HeaderFont
$Tab5.Controls.Add($EncryptDeleteLabel)

$CipherShedLogo = New-Object System.Windows.Forms.PictureBox
$CipherShedLogo.Width = 18
$CipherShedLogo.Height = 18
$CipherShedLogo.Location = New-Object System.Drawing.Size(410,250)
$CipherShedLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\CipherShed.png"
$CipherShedLogo.ImageLocation = $CipherShedLogoFile
$CipherShedLogo.BorderStyle = 0
$CipherShedLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($CipherShedLogo)

$CipherShedCheckbox = New-Object System.Windows.Forms.Checkbox 
$CipherShedCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$CipherShedCheckbox.Text = "       CipherShed"
$CipherShedCheckbox.Width = 180
$CipherShedCheckbox.Height = 20
$CipherShedCheckbox.Font = $BodyFont
$Tab5.Controls.Add($CipherShedCheckbox)

$EraserLogo = New-Object System.Windows.Forms.PictureBox
$EraserLogo.Width = 18
$EraserLogo.Height = 18
$EraserLogo.Location = New-Object System.Drawing.Size(410,270)
$EraserLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Eraser.png"
$EraserLogo.ImageLocation = $EraserLogoFile
$EraserLogo.BorderStyle = 0
$EraserLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($EraserLogo)

$EraserCheckbox = New-Object System.Windows.Forms.Checkbox 
$EraserCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$EraserCheckbox.Text = "       Eraser"
$EraserCheckbox.Width = 180
$EraserCheckbox.Height = 20
$EraserCheckbox.Font = $BodyFont
$Tab5.Controls.Add($EraserCheckbox)

$VeraCryptLogo = New-Object System.Windows.Forms.PictureBox
$VeraCryptLogo.Width = 18
$VeraCryptLogo.Height = 18
$VeraCryptLogo.Location = New-Object System.Drawing.Size(410,290)
$VeraCryptLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\VeraCrypt.png"
$VeraCryptLogo.ImageLocation = $VeraCryptLogoFile
$VeraCryptLogo.BorderStyle = 0
$VeraCryptLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($VeraCryptLogo)

$VeraCryptCheckbox = New-Object System.Windows.Forms.Checkbox 
$VeraCryptCheckbox.Location = New-Object System.Drawing.Size(390,290) 
$VeraCryptCheckbox.Text = "       VeraCrypt"
$VeraCryptCheckbox.Width = 180
$VeraCryptCheckbox.Height = 20
$VeraCryptCheckbox.Font = $BodyFont
$Tab5.Controls.Add($VeraCryptCheckbox)

$FirewallLabel = New-Object System.Windows.Forms.Label
$FirewallLabel.Location = New-Object System.Drawing.Size(580,10)
$FirewallLabel.Text = "Firewall"
$FirewallLabel.Width = 180
$FirewallLabel.Height = 20
$FirewallLabel.Font = $HeaderFont
$Tab5.Controls.Add($FirewallLabel)

$GlassWireLogo = New-Object System.Windows.Forms.PictureBox
$GlassWireLogo.Width = 18
$GlassWireLogo.Height = 18
$GlassWireLogo.Location = New-Object System.Drawing.Size(600,30)
$GlassWireLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\GlassWire.png"
$GlassWireLogo.ImageLocation = $GlassWireLogoFile
$GlassWireLogo.BorderStyle = 0
$GlassWireLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($GlassWireLogo)

$GlassWireCheckbox = New-Object System.Windows.Forms.Checkbox 
$GlassWireCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$GlassWireCheckbox.Text = "       GlassWire"
$GlassWireCheckbox.Width = 180
$GlassWireCheckbox.Height = 20
$GlassWireCheckbox.Font = $BodyFont
$Tab5.Controls.Add($GlassWireCheckbox)

$SimpleWallLogo = New-Object System.Windows.Forms.PictureBox
$SimpleWallLogo.Width = 18
$SimpleWallLogo.Height = 18
$SimpleWallLogo.Location = New-Object System.Drawing.Size(600,50)
$SimpleWallLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\SimpleWall.png"
$SimpleWallLogo.ImageLocation = $SimpleWallLogoFile
$SimpleWallLogo.BorderStyle = 0
$SimpleWallLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SimpleWallLogo)

$SimpleWallCheckbox = New-Object System.Windows.Forms.Checkbox 
$SimpleWallCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$SimpleWallCheckbox.Text = "       SimpleWall"
$SimpleWallCheckbox.Width = 180
$SimpleWallCheckbox.Height = 20
$SimpleWallCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SimpleWallCheckbox)

$PWManagerLabel = New-Object System.Windows.Forms.Label
$PWManagerLabel.Location = New-Object System.Drawing.Size(580,90)
$PWManagerLabel.Text = "PW Manager"
$PWManagerLabel.Width = 180
$PWManagerLabel.Height = 20
$PWManagerLabel.Font = $HeaderFont
$Tab5.Controls.Add($PWManagerLabel)

$LastPassAppLogo = New-Object System.Windows.Forms.PictureBox
$LastPassAppLogo.Width = 18
$LastPassAppLogo.Height = 18
$LastPassAppLogo.Location = New-Object System.Drawing.Size(600,110)
$LastPassAppLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\LastPass.png"
$LastPassAppLogo.ImageLocation = $LastPassAppLogoFile
$LastPassAppLogo.BorderStyle = 0
$LastPassAppLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($LastPassAppLogo)

$LastPassAppCheckbox = New-Object System.Windows.Forms.Checkbox 
$LastPassAppCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$LastPassAppCheckbox.Text = "       LastPass"
$LastPassAppCheckbox.Width = 180
$LastPassAppCheckbox.Height = 20
$LastPassAppCheckbox.Font = $BodyFont
$Tab5.Controls.Add($LastPassAppCheckbox)

$NordPassLogo = New-Object System.Windows.Forms.PictureBox
$NordPassLogo.Width = 18
$NordPassLogo.Height = 18
$NordPassLogo.Location = New-Object System.Drawing.Size(600,130)
$NordPassLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\NordPass.png"
$NordPassLogo.ImageLocation = $NordPassLogoFile
$NordPassLogo.BorderStyle = 0
$NordPassLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($NordPassLogo)

$NordPassCheckbox = New-Object System.Windows.Forms.Checkbox 
$NordPassCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$NordPassCheckbox.Text = "       NordPass"
$NordPassCheckbox.Width = 180
$NordPassCheckbox.Height = 20
$NordPassCheckbox.Font = $BodyFont
$Tab5.Controls.Add($NordPassCheckbox)

$PrivacyLabel = New-Object System.Windows.Forms.Label
$PrivacyLabel.Location = New-Object System.Drawing.Size(580,170)
$PrivacyLabel.Text = "Privacy"
$PrivacyLabel.Width = 180
$PrivacyLabel.Height = 20
$PrivacyLabel.Font = $HeaderFont
$Tab5.Controls.Add($PrivacyLabel)

$AntiBeaconLogo = New-Object System.Windows.Forms.PictureBox
$AntiBeaconLogo.Width = 18
$AntiBeaconLogo.Height = 18
$AntiBeaconLogo.Location = New-Object System.Drawing.Size(600,190)
$AntiBeaconLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\AntiBeacon.png"
$AntiBeaconLogo.ImageLocation = $AntiBeaconLogoFile
$AntiBeaconLogo.BorderStyle = 0
$AntiBeaconLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($AntiBeaconLogo)

$AntiBeaconCheckbox = New-Object System.Windows.Forms.Checkbox 
$AntiBeaconCheckbox.Location = New-Object System.Drawing.Size(580,190) 
$AntiBeaconCheckbox.Text = "       Anti-Beacon"
$AntiBeaconCheckbox.Width = 180
$AntiBeaconCheckbox.Height = 20
$AntiBeaconCheckbox.Font = $BodyFont
$Tab5.Controls.Add($AntiBeaconCheckbox)

$OOShutUp10Logo = New-Object System.Windows.Forms.PictureBox
$OOShutUp10Logo.Width = 18
$OOShutUp10Logo.Height = 18
$OOShutUp10Logo.Location = New-Object System.Drawing.Size(600,210)
$OOShutUp10LogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\OOShutUp10.png"
$OOShutUp10Logo.ImageLocation = $OOShutUp10LogoFile
$OOShutUp10Logo.BorderStyle = 0
$OOShutUp10Logo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($OOShutUp10Logo)

$OOShutUp10Checkbox = New-Object System.Windows.Forms.Checkbox 
$OOShutUp10Checkbox.Location = New-Object System.Drawing.Size(580,210) 
$OOShutUp10Checkbox.Text = "       O&&OShutUp10++"
$OOShutUp10Checkbox.Width = 180
$OOShutUp10Checkbox.Height = 20
$OOShutUp10Checkbox.Font = $BodyFont
$Tab5.Controls.Add($OOShutUp10Checkbox)

$SecondOpinionLabel = New-Object System.Windows.Forms.Label
$SecondOpinionLabel.Location = New-Object System.Drawing.Size(770,10)
$SecondOpinionLabel.Text = "Second Opinion"
$SecondOpinionLabel.Width = 180
$SecondOpinionLabel.Height = 20
$SecondOpinionLabel.Font = $HeaderFont
$Tab5.Controls.Add($SecondOpinionLabel)

$ESETScannerLogo = New-Object System.Windows.Forms.PictureBox
$ESETScannerLogo.Width = 18
$ESETScannerLogo.Height = 18
$ESETScannerLogo.Location = New-Object System.Drawing.Size(790,30)
$ESETScannerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\ESET.png"
$ESETScannerLogo.ImageLocation = $ESETScannerLogoFile
$ESETScannerLogo.BorderStyle = 0
$ESETScannerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($ESETScannerLogo)

$ESETScannerCheckbox = New-Object System.Windows.Forms.Checkbox 
$ESETScannerCheckbox.Location = New-Object System.Drawing.Size(770,30) 
$ESETScannerCheckbox.Text = "       ESET Scanner"
$ESETScannerCheckbox.Width = 180
$ESETScannerCheckbox.Height = 20
$ESETScannerCheckbox.Font = $BodyFont
$Tab5.Controls.Add($ESETScannerCheckbox)

$EmergencyKitLogo = New-Object System.Windows.Forms.PictureBox
$EmergencyKitLogo.Width = 18
$EmergencyKitLogo.Height = 18
$EmergencyKitLogo.Location = New-Object System.Drawing.Size(790,50)
$EmergencyKitLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\EmergencyKit.png"
$EmergencyKitLogo.ImageLocation = $EmergencyKitLogoFile
$EmergencyKitLogo.BorderStyle = 0
$EmergencyKitLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($EmergencyKitLogo)

$EmergencyKitCheckbox = New-Object System.Windows.Forms.Checkbox 
$EmergencyKitCheckbox.Location = New-Object System.Drawing.Size(770,50) 
$EmergencyKitCheckbox.Text = "       Emergency Kit"
$EmergencyKitCheckbox.Width = 180
$EmergencyKitCheckbox.Height = 20
$EmergencyKitCheckbox.Font = $BodyFont
$Tab5.Controls.Add($EmergencyKitCheckbox)

$HitmanProLogo = New-Object System.Windows.Forms.PictureBox
$HitmanProLogo.Width = 18
$HitmanProLogo.Height = 18
$HitmanProLogo.Location = New-Object System.Drawing.Size(790,70)
$HitmanProLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\HitmanPro.png"
$HitmanProLogo.ImageLocation = $HitmanProLogoFile
$HitmanProLogo.BorderStyle = 0
$HitmanProLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($HitmanProLogo)

$HitmanProCheckbox = New-Object System.Windows.Forms.Checkbox 
$HitmanProCheckbox.Location = New-Object System.Drawing.Size(770,70) 
$HitmanProCheckbox.Text = "       HitmanPro"
$HitmanProCheckbox.Width = 180
$HitmanProCheckbox.Height = 20
$HitmanProCheckbox.Font = $BodyFont
$Tab5.Controls.Add($HitmanProCheckbox)

$SophosSCLogo = New-Object System.Windows.Forms.PictureBox
$SophosSCLogo.Width = 18
$SophosSCLogo.Height = 18
$SophosSCLogo.Location = New-Object System.Drawing.Size(790,90)
$SophosSCLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Sophos.png"
$SophosSCLogo.ImageLocation = $SophosSCLogoFile
$SophosSCLogo.BorderStyle = 0
$SophosSCLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SophosSCLogo)

$SophosSCCheckbox = New-Object System.Windows.Forms.Checkbox 
$SophosSCCheckbox.Location = New-Object System.Drawing.Size(770,90) 
$SophosSCCheckbox.Text = "       Sophos S&&C"
$SophosSCCheckbox.Width = 180
$SophosSCCheckbox.Height = 20
$SophosSCCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SophosSCCheckbox)

$VPNLabel = New-Object System.Windows.Forms.Label
$VPNLabel.Location = New-Object System.Drawing.Size(960,10)
$VPNLabel.Text = "VPN"
$VPNLabel.Width = 180
$VPNLabel.Height = 20
$VPNLabel.Font = $HeaderFont
$Tab5.Controls.Add($VPNLabel)

$IPVanishLogo = New-Object System.Windows.Forms.PictureBox
$IPVanishLogo.Width = 18
$IPVanishLogo.Height = 18
$IPVanishLogo.Location = New-Object System.Drawing.Size(980,30)
$IPVanishLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\IPVanish.png"
$IPVanishLogo.ImageLocation = $IPVanishLogoFile
$IPVanishLogo.BorderStyle = 0
$IPVanishLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($IPVanishLogo)

$IPVanishCheckbox = New-Object System.Windows.Forms.Checkbox 
$IPVanishCheckbox.Location = New-Object System.Drawing.Size(960,30) 
$IPVanishCheckbox.Text = "       IPVanish"
$IPVanishCheckbox.Width = 180
$IPVanishCheckbox.Height = 20
$IPVanishCheckbox.Font = $BodyFont
$Tab5.Controls.Add($IPVanishCheckbox)

$NordVPNLogo = New-Object System.Windows.Forms.PictureBox
$NordVPNLogo.Width = 18
$NordVPNLogo.Height = 18
$NordVPNLogo.Location = New-Object System.Drawing.Size(980,50)
$NordVPNLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\NordVPN.png"
$NordVPNLogo.ImageLocation = $NordVPNLogoFile
$NordVPNLogo.BorderStyle = 0
$NordVPNLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($NordVPNLogo)

$NordVPNCheckbox = New-Object System.Windows.Forms.Checkbox 
$NordVPNCheckbox.Location = New-Object System.Drawing.Size(960,50) 
$NordVPNCheckbox.Text = "       NordVPN"
$NordVPNCheckbox.Width = 180
$NordVPNCheckbox.Height = 20
$NordVPNCheckbox.Font = $BodyFont
$Tab5.Controls.Add($NordVPNCheckbox)

$ProtonVPNLogo = New-Object System.Windows.Forms.PictureBox
$ProtonVPNLogo.Width = 18
$ProtonVPNLogo.Height = 18
$ProtonVPNLogo.Location = New-Object System.Drawing.Size(980,70)
$ProtonVPNLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\ProtonVPN.png"
$ProtonVPNLogo.ImageLocation = $ProtonVPNLogoFile
$ProtonVPNLogo.BorderStyle = 0
$ProtonVPNLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($ProtonVPNLogo)

$ProtonVPNCheckbox = New-Object System.Windows.Forms.Checkbox 
$ProtonVPNCheckbox.Location = New-Object System.Drawing.Size(960,70) 
$ProtonVPNCheckbox.Text = "       ProtonVPN"
$ProtonVPNCheckbox.Width = 180
$ProtonVPNCheckbox.Height = 20
$ProtonVPNCheckbox.Font = $BodyFont
$Tab5.Controls.Add($ProtonVPNCheckbox)

$SurfsharkLogo = New-Object System.Windows.Forms.PictureBox
$SurfsharkLogo.Width = 18
$SurfsharkLogo.Height = 18
$SurfsharkLogo.Location = New-Object System.Drawing.Size(980,90)
$SurfsharkLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Security\Surfshark.png"
$SurfsharkLogo.ImageLocation = $SurfsharkLogoFile
$SurfsharkLogo.BorderStyle = 0
$SurfsharkLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab5.Controls.Add($SurfsharkLogo)

$SurfsharkCheckbox = New-Object System.Windows.Forms.Checkbox 
$SurfsharkCheckbox.Location = New-Object System.Drawing.Size(960,90) 
$SurfsharkCheckbox.Text = "       Surfshark"
$SurfsharkCheckbox.Width = 180
$SurfsharkCheckbox.Height = 20
$SurfsharkCheckbox.Font = $BodyFont
$Tab5.Controls.Add($SurfsharkCheckbox)

# Tab 6 SEARCH
$Tab6 = New-Object System.Windows.Forms.TabPage
$Tab6.Text = "Search"
$Tab6.Font = $TabFont
$Tab6.Autoscroll  = $True
$TabControl.Controls.Add($Tab6)

$searchBox = New-Object System.Windows.Forms.TextBox
$searchBox.Location = New-Object System.Drawing.Point(10, 10)
$searchBox.Width = 500
$searchBox.Font = $BodyFont
# Attach Enter key handler to searchBox
$searchBox.Add_KeyDown({
    if ($_.KeyCode -eq "Enter") {
        $_.Handled = $true
        $_.SuppressKeyPress = $true
        $searchButton.PerformClick()
    }
})
$Tab6.Controls.Add($searchBox)

$searchButton = New-Object System.Windows.Forms.Button
$searchButton.Location = New-Object System.Drawing.Point(530, 10)
$searchButton.Size = New-Object System.Drawing.Size(100,30)
$searchButton.Text = "Search"
$searchButton.Font = $ButtonFont
$Tab6.Controls.Add($searchButton)

$searchInstalledButton = New-Object System.Windows.Forms.Button
$searchInstalledButton.Location = New-Object System.Drawing.Point(680, 10)
$searchInstalledButton.Size = New-Object System.Drawing.Size(150,30)
$searchInstalledButton.Text = "Search Installed"
$searchInstalledButton.Font = $ButtonFont
$Tab6.Controls.Add($searchInstalledButton)

$listInstalledButton = New-Object System.Windows.Forms.Button
$listInstalledButton.Location = New-Object System.Drawing.Point(880, 10)
$listInstalledButton.Size = New-Object System.Drawing.Size(150,30)
$listInstalledButton.Text = "List Installed"
$listInstalledButton.Font = $ButtonFont
$Tab6.Controls.Add($listInstalledButton)

$installButton = New-Object System.Windows.Forms.Button
$installButton.Location = New-Object System.Drawing.Point(10, 540)
$installButton.Size = New-Object System.Drawing.Size(100,30)
$installButton.Text = "Install"
$installButton.Font = $ButtonFont
$Tab6.Controls.Add($installButton)

$uninstallButton = New-Object System.Windows.Forms.Button
$uninstallButton.Location = New-Object System.Drawing.Point(1064, 540)
$uninstallButton.Size = New-Object System.Drawing.Size(100,30)
$uninstallButton.Text = "Uninstall"
$uninstallButton.Font = $ButtonFont
$Tab6.Controls.Add($uninstallButton)

$listBox = New-Object System.Windows.Forms.ListBox
$listBox.Location = New-Object System.Drawing.Point(10, 50)
$listBox.Width = 1154
$listBox.Height = 470
$listBox.HorizontalScrollbar = $true
$listBox.Font = $ListBoxFont
$listBox.Items.Clear()
$Tab6.Controls.Add($listBox)

# Tab 7 TASKS
$Tab7 = New-Object System.Windows.Forms.TabPage
$Tab7.Text = "Tasks"
$Tab7.Font = $TabFont
$Tab7.Autoscroll  = $True
$TabControl.Controls.Add($Tab7)

$DisableLabel = New-Object System.Windows.Forms.Label
$DisableLabel.Location = New-Object System.Drawing.Size(10,10)
$DisableLabel.Text = "Disable"
$DisableLabel.Width = 180
$DisableLabel.Height = 20
$DisableLabel.Font = $HeaderFont
$Tab7.Controls.Add($DisableLabel)

$EncryptionLogo = New-Object System.Windows.Forms.PictureBox
$EncryptionLogo.Width = 18
$EncryptionLogo.Height = 18
$EncryptionLogo.Location = New-Object System.Drawing.Size(30,30)
$EncryptionLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Encryption.png"
$EncryptionLogo.ImageLocation = $EncryptionLogoFile
$EncryptionLogo.BorderStyle = 0
$EncryptionLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($EncryptionLogo)

$EncryptionCheckbox = New-Object System.Windows.Forms.Checkbox 
$EncryptionCheckbox.Location = New-Object System.Drawing.Size(10,30) 
$EncryptionCheckbox.Text = "       Encryption"
$EncryptionCheckbox.Width = 180
$EncryptionCheckbox.Height = 20
$EncryptionCheckbox.Font = $BodyFont
$Tab7.Controls.Add($EncryptionCheckbox)

$GameBarDVRLogo = New-Object System.Windows.Forms.PictureBox
$GameBarDVRLogo.Width = 18
$GameBarDVRLogo.Height = 18
$GameBarDVRLogo.Location = New-Object System.Drawing.Size(30,50)
$GameBarDVRLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\GameBarDVR.png"
$GameBarDVRLogo.ImageLocation = $GameBarDVRLogoFile
$GameBarDVRLogo.BorderStyle = 0
$GameBarDVRLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($GameBarDVRLogo)

$GameBarDVRCheckbox = New-Object System.Windows.Forms.Checkbox 
$GameBarDVRCheckbox.Location = New-Object System.Drawing.Size(10,50) 
$GameBarDVRCheckbox.Text = "       Game Bar && DVR"
$GameBarDVRCheckbox.Width = 180
$GameBarDVRCheckbox.Height = 20
$GameBarDVRCheckbox.Font = $BodyFont
$Tab7.Controls.Add($GameBarDVRCheckbox)

$HighlightsLogo = New-Object System.Windows.Forms.PictureBox
$HighlightsLogo.Width = 18
$HighlightsLogo.Height = 18
$HighlightsLogo.Location = New-Object System.Drawing.Size(30,70)
$HighlightsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Highlights.png"
$HighlightsLogo.ImageLocation = $HighlightsLogoFile
$HighlightsLogo.BorderStyle = 0
$HighlightsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($HighlightsLogo)

$HighlightsCheckbox = New-Object System.Windows.Forms.Checkbox 
$HighlightsCheckbox.Location = New-Object System.Drawing.Size(10,70) 
$HighlightsCheckbox.Text = "       Highlights"
$HighlightsCheckbox.Width = 180
$HighlightsCheckbox.Height = 20
$HighlightsCheckbox.Font = $BodyFont
$Tab7.Controls.Add($HighlightsCheckbox)

$SleepLogo = New-Object System.Windows.Forms.PictureBox
$SleepLogo.Width = 18
$SleepLogo.Height = 18
$SleepLogo.Location = New-Object System.Drawing.Size(30,90)
$SleepLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Sleep.png"
$SleepLogo.ImageLocation = $SleepLogoFile
$SleepLogo.BorderStyle = 0
$SleepLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($SleepLogo)

$SleepCheckbox = New-Object System.Windows.Forms.Checkbox 
$SleepCheckbox.Location = New-Object System.Drawing.Size(10,90) 
$SleepCheckbox.Text = "       Sleep"
$SleepCheckbox.Width = 180
$SleepCheckbox.Height = 20
$SleepCheckbox.Font = $BodyFont
$Tab7.Controls.Add($SleepCheckbox)

$SuggestionsLogo = New-Object System.Windows.Forms.PictureBox
$SuggestionsLogo.Width = 18
$SuggestionsLogo.Height = 18
$SuggestionsLogo.Location = New-Object System.Drawing.Size(30,110)
$SuggestionsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Suggestions.png"
$SuggestionsLogo.ImageLocation = $SuggestionsLogoFile
$SuggestionsLogo.BorderStyle = 0
$SuggestionsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($SuggestionsLogo)

$SuggestionsCheckbox = New-Object System.Windows.Forms.Checkbox 
$SuggestionsCheckbox.Location = New-Object System.Drawing.Size(10,110) 
$SuggestionsCheckbox.Text = "       Suggestions"
$SuggestionsCheckbox.Width = 180
$SuggestionsCheckbox.Height = 20
$SuggestionsCheckbox.Font = $BodyFont
$Tab7.Controls.Add($SuggestionsCheckbox)

$TaskViewLogo = New-Object System.Windows.Forms.PictureBox
$TaskViewLogo.Width = 18
$TaskViewLogo.Height = 18
$TaskViewLogo.Location = New-Object System.Drawing.Size(30,130)
$TaskViewLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\TaskView.png"
$TaskViewLogo.ImageLocation = $TaskViewLogoFile
$TaskViewLogo.BorderStyle = 0
$TaskViewLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($TaskViewLogo)

$TaskViewCheckbox = New-Object System.Windows.Forms.Checkbox 
$TaskViewCheckbox.Location = New-Object System.Drawing.Size(10,130) 
$TaskViewCheckbox.Text = "       TaskView Icon"
$TaskViewCheckbox.Width = 180
$TaskViewCheckbox.Height = 20
$TaskViewCheckbox.Font = $BodyFont
$Tab7.Controls.Add($TaskViewCheckbox)

$TrackingLogo = New-Object System.Windows.Forms.PictureBox
$TrackingLogo.Width = 18
$TrackingLogo.Height = 18
$TrackingLogo.Location = New-Object System.Drawing.Size(30,150)
$TrackingLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Tracking.png"
$TrackingLogo.ImageLocation = $TrackingLogoFile
$TrackingLogo.BorderStyle = 0
$TrackingLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($TrackingLogo)

$TrackingCheckbox = New-Object System.Windows.Forms.Checkbox 
$TrackingCheckbox.Location = New-Object System.Drawing.Size(10,150) 
$TrackingCheckbox.Text = "       Tracking"
$TrackingCheckbox.Width = 180
$TrackingCheckbox.Height = 20
$TrackingCheckbox.Font = $BodyFont
$Tab7.Controls.Add($TrackingCheckbox)

$WidgetsLogo = New-Object System.Windows.Forms.PictureBox
$WidgetsLogo.Width = 18
$WidgetsLogo.Height = 18
$WidgetsLogo.Location = New-Object System.Drawing.Size(30,170)
$WidgetsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Widgets.png"
$WidgetsLogo.ImageLocation = $WidgetsLogoFile
$WidgetsLogo.BorderStyle = 0
$WidgetsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($WidgetsLogo)

$WidgetsCheckbox = New-Object System.Windows.Forms.Checkbox 
$WidgetsCheckbox.Location = New-Object System.Drawing.Size(10,170) 
$WidgetsCheckbox.Text = "       Widgets Icon"
$WidgetsCheckbox.Width = 180
$WidgetsCheckbox.Height = 20
$WidgetsCheckbox.Font = $BodyFont
$Tab7.Controls.Add($WidgetsCheckbox)

# Logo for "Select All" Disable
$DisableAllLogo = New-Object System.Windows.Forms.PictureBox
$DisableAllLogo.Width = 18
$DisableAllLogo.Height = 18
$DisableAllLogo.Location = New-Object System.Drawing.Size(30, 190)
$DisableAllLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SelectAll.png"
$DisableAllLogo.ImageLocation = $DisableAllLogoFile
$DisableAllLogo.BorderStyle = 0
$DisableAllLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$Tab7.Controls.Add($DisableAllLogo)

# Checkbox for "Select All" Disable
$DisableAllCheckbox = New-Object System.Windows.Forms.CheckBox
$DisableAllCheckbox.Location = New-Object System.Drawing.Size(10, 190)
$DisableAllCheckbox.Text = "       Select All"
$DisableAllCheckbox.Width = 180
$DisableAllCheckbox.Height = 20
$DisableAllCheckbox.Font = $BodyFont
$Tab7.Controls.Add($DisableAllCheckbox)

# Array of Disable checkboxes
$DisableAllCheckboxes = @($EncryptionCheckbox, $GameBarDVRCheckbox, $HighlightsCheckbox, $SleepCheckbox, $SuggestionsCheckbox, $TaskviewCheckbox, $TrackingCheckbox, $WidgetsCheckbox)

# Event: Toggle all Disable checkboxes when "Select All" is clicked
$DisableAllCheckbox.Add_CheckedChanged({
    foreach ($cb in $DisableAllCheckboxes) {
        $cb.Checked = $DisableAllCheckbox.Checked
    }
})

$EnableLabel = New-Object System.Windows.Forms.Label
$EnableLabel.Location = New-Object System.Drawing.Size(10,230)
$EnableLabel.Text = "Enable"
$EnableLabel.Width = 180
$EnableLabel.Height = 20
$EnableLabel.Font = $HeaderFont
$Tab7.Controls.Add($EnableLabel)

$DarkModeLogo = New-Object System.Windows.Forms.PictureBox
$DarkModeLogo.Width = 18
$DarkModeLogo.Height = 18
$DarkModeLogo.Location = New-Object System.Drawing.Size(30,250)
$DarkModeLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\DarkMode.png"
$DarkModeLogo.ImageLocation = $DarkModeLogoFile
$DarkModeLogo.BorderStyle = 0
$DarkModeLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($DarkModeLogo)

$DarkModeCheckbox = New-Object System.Windows.Forms.Checkbox 
$DarkModeCheckbox.Location = New-Object System.Drawing.Size(10,250) 
$DarkModeCheckbox.Text = "       Dark Mode"
$DarkModeCheckbox.Width = 180
$DarkModeCheckbox.Height = 20
$DarkModeCheckbox.Font = $BodyFont
$Tab7.Controls.Add($DarkModeCheckbox)

$FileExtensionsLogo = New-Object System.Windows.Forms.PictureBox
$FileExtensionsLogo.Width = 18
$FileExtensionsLogo.Height = 18
$FileExtensionsLogo.Location = New-Object System.Drawing.Size(30,270)
$FileExtensionsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\FileExtensions.png"
$FileExtensionsLogo.ImageLocation = $FileExtensionsLogoFile
$FileExtensionsLogo.BorderStyle = 0
$FileExtensionsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($FileExtensionsLogo)

$FileExtensionsCheckbox = New-Object System.Windows.Forms.Checkbox 
$FileExtensionsCheckbox.Location = New-Object System.Drawing.Size(10,270) 
$FileExtensionsCheckbox.Text = "       File Extensions"
$FileExtensionsCheckbox.Width = 180
$FileExtensionsCheckbox.Height = 20
$FileExtensionsCheckbox.Font = $BodyFont
$Tab7.Controls.Add($FileExtensionsCheckbox)

$HiddenFilesLogo = New-Object System.Windows.Forms.PictureBox
$HiddenFilesLogo.Width = 18
$HiddenFilesLogo.Height = 18
$HiddenFilesLogo.Location = New-Object System.Drawing.Size(30,290)
$HiddenFilesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\HiddenFiles.png"
$HiddenFilesLogo.ImageLocation = $HiddenFilesLogoFile
$HiddenFilesLogo.BorderStyle = 0
$HiddenFilesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($HiddenFilesLogo)

$HiddenFilesCheckbox = New-Object System.Windows.Forms.Checkbox 
$HiddenFilesCheckbox.Location = New-Object System.Drawing.Size(10,290) 
$HiddenFilesCheckbox.Text = "       Hidden Files"
$HiddenFilesCheckbox.Width = 180
$HiddenFilesCheckbox.Height = 20
$HiddenFilesCheckbox.Font = $BodyFont
$Tab7.Controls.Add($HiddenFilesCheckbox)

$LeftTaskbarLogo = New-Object System.Windows.Forms.PictureBox
$LeftTaskbarLogo.Width = 18
$LeftTaskbarLogo.Height = 18
$LeftTaskbarLogo.Location = New-Object System.Drawing.Size(30,310)
$LeftTaskbarLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\LeftTaskbar.png"
$LeftTaskbarLogo.ImageLocation = $LeftTaskbarLogoFile
$LeftTaskbarLogo.BorderStyle = 0
$LeftTaskbarLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($LeftTaskbarLogo)

$LeftTaskbarCheckbox = New-Object System.Windows.Forms.Checkbox 
$LeftTaskbarCheckbox.Location = New-Object System.Drawing.Size(10,310) 
$LeftTaskbarCheckbox.Text = "       Left Taskbar"
$LeftTaskbarCheckbox.Width = 180
$LeftTaskbarCheckbox.Height = 20
$LeftTaskbarCheckbox.Font = $BodyFont
$Tab7.Controls.Add($LeftTaskbarCheckbox)

$NightLightLogo = New-Object System.Windows.Forms.PictureBox
$NightLightLogo.Width = 18
$NightLightLogo.Height = 18
$NightLightLogo.Location = New-Object System.Drawing.Size(30,330)
$NightLightLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\NightLight.png"
$NightLightLogo.ImageLocation = $NightLightLogoFile
$NightLightLogo.BorderStyle = 0
$NightLightLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($NightLightLogo)

$NightLightCheckbox = New-Object System.Windows.Forms.Checkbox 
$NightLightCheckbox.Location = New-Object System.Drawing.Size(10,330) 
$NightLightCheckbox.Text = "       Night Light"
$NightLightCheckbox.Width = 180
$NightLightCheckbox.Height = 20
$NightLightCheckbox.Font = $BodyFont
$Tab7.Controls.Add($NightLightCheckbox)

# Logo for "Select All" Enable
$EnableAllLogo = New-Object System.Windows.Forms.PictureBox
$EnableAllLogo.Width = 18
$EnableAllLogo.Height = 18
$EnableAllLogo.Location = New-Object System.Drawing.Size(30, 350)
$EnableAllLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SelectAll.png"
$EnableAllLogo.ImageLocation = $EnableAllLogoFile
$EnableAllLogo.BorderStyle = 0
$EnableAllLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$Tab7.Controls.Add($EnableAllLogo)

# Checkbox for "Select All" Enable
$EnableAllCheckbox = New-Object System.Windows.Forms.CheckBox
$EnableAllCheckbox.Location = New-Object System.Drawing.Size(10, 350)
$EnableAllCheckbox.Text = "       Select All"
$EnableAllCheckbox.Width = 180
$EnableAllCheckbox.Height = 20
$EnableAllCheckbox.Font = $BodyFont
$Tab7.Controls.Add($EnableAllCheckbox)

# Array of Enable checkboxes
$EnableAllCheckboxes = @($DarkModeCheckbox, $FileExtensionsCheckbox, $HiddenFilesCheckbox, $LeftTaskbarCheckbox, $NightLightCheckbox)

# Event: Toggle all Enable checkboxes when "Select All" is clicked
$EnableAllCheckbox.Add_CheckedChanged({
    foreach ($cb in $EnableAllCheckboxes) {
        $cb.Checked = $EnableAllCheckbox.Checked
    }
})

$ExtensionsLabel = New-Object System.Windows.Forms.Label
$ExtensionsLabel.Location = New-Object System.Drawing.Size(200,10)
$ExtensionsLabel.Text = "Extensions"
$ExtensionsLabel.Width = 180
$ExtensionsLabel.Height = 20
$ExtensionsLabel.Font = $HeaderFont
$Tab7.Controls.Add($ExtensionsLabel)

$1PasswordLogo = New-Object System.Windows.Forms.PictureBox
$1PasswordLogo.Width = 18
$1PasswordLogo.Height = 18
$1PasswordLogo.Location = New-Object System.Drawing.Size(220,30)
$1PasswordLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\1Password.png"
$1PasswordLogo.ImageLocation = $1PasswordLogoFile
$1PasswordLogo.BorderStyle = 0
$1PasswordLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($1PasswordLogo)

$1PasswordCheckbox = New-Object System.Windows.Forms.Checkbox 
$1PasswordCheckbox.Location = New-Object System.Drawing.Size(200,30) 
$1PasswordCheckbox.Text = "       1Password"
$1PasswordCheckbox.Width = 180
$1PasswordCheckbox.Height = 20
$1PasswordCheckbox.Font = $BodyFont
$Tab7.Controls.Add($1PasswordCheckbox)

$BitwardenLogo = New-Object System.Windows.Forms.PictureBox
$BitwardenLogo.Width = 18
$BitwardenLogo.Height = 18
$BitwardenLogo.Location = New-Object System.Drawing.Size(220,50)
$BitwardenLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Bitwarden.png"
$BitwardenLogo.ImageLocation = $BitwardenLogoFile
$BitwardenLogo.BorderStyle = 0
$BitwardenLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($BitwardenLogo)

$BitwardenCheckbox = New-Object System.Windows.Forms.Checkbox 
$BitwardenCheckbox.Location = New-Object System.Drawing.Size(200,50) 
$BitwardenCheckbox.Text = "       Bitwarden"
$BitwardenCheckbox.Width = 180
$BitwardenCheckbox.Height = 20
$BitwardenCheckbox.Font = $BodyFont
$Tab7.Controls.Add($BitwardenCheckbox)

$DarkReaderLogo = New-Object System.Windows.Forms.PictureBox
$DarkReaderLogo.Width = 18
$DarkReaderLogo.Height = 18
$DarkReaderLogo.Location = New-Object System.Drawing.Size(220,70)
$DarkReaderLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\DarkReader.png"
$DarkReaderLogo.ImageLocation = $DarkReaderLogoFile
$DarkReaderLogo.BorderStyle = 0
$DarkReaderLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($DarkReaderLogo)

$DarkReaderCheckbox = New-Object System.Windows.Forms.Checkbox 
$DarkReaderCheckbox.Location = New-Object System.Drawing.Size(200,70) 
$DarkReaderCheckbox.Text = "       Dark Reader"
$DarkReaderCheckbox.Width = 180
$DarkReaderCheckbox.Height = 20
$DarkReaderCheckbox.Font = $BodyFont
$Tab7.Controls.Add($DarkReaderCheckbox)

$GrammarlyLogo = New-Object System.Windows.Forms.PictureBox
$GrammarlyLogo.Width = 18
$GrammarlyLogo.Height = 18
$GrammarlyLogo.Location = New-Object System.Drawing.Size(220,90)
$GrammarlyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Grammarly.png"
$GrammarlyLogo.ImageLocation = $GrammarlyLogoFile
$GrammarlyLogo.BorderStyle = 0
$GrammarlyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($GrammarlyLogo)

$GrammarlyCheckbox = New-Object System.Windows.Forms.Checkbox 
$GrammarlyCheckbox.Location = New-Object System.Drawing.Size(200,90) 
$GrammarlyCheckbox.Text = "       Grammarly"
$GrammarlyCheckbox.Width = 180
$GrammarlyCheckbox.Height = 20
$GrammarlyCheckbox.Font = $BodyFont
$Tab7.Controls.Add($GrammarlyCheckbox)

$LastPassLogo = New-Object System.Windows.Forms.PictureBox
$LastPassLogo.Width = 18
$LastPassLogo.Height = 18
$LastPassLogo.Location = New-Object System.Drawing.Size(220,110)
$LastPassLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\LastPass.png"
$LastPassLogo.ImageLocation = $LastPassLogoFile
$LastPassLogo.BorderStyle = 0
$LastPassLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($LastPassLogo)

$LastPassCheckbox = New-Object System.Windows.Forms.Checkbox 
$LastPassCheckbox.Location = New-Object System.Drawing.Size(200,110) 
$LastPassCheckbox.Text = "       LastPass"
$LastPassCheckbox.Width = 180
$LastPassCheckbox.Height = 20
$LastPassCheckbox.Font = $BodyFont
$Tab7.Controls.Add($LastPassCheckbox)

$MomentumLogo = New-Object System.Windows.Forms.PictureBox
$MomentumLogo.Width = 18
$MomentumLogo.Height = 18
$MomentumLogo.Location = New-Object System.Drawing.Size(220,130)
$MomentumLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Momentum.png"
$MomentumLogo.ImageLocation = $MomentumLogoFile
$MomentumLogo.BorderStyle = 0
$MomentumLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($MomentumLogo)

$MomentumCheckbox = New-Object System.Windows.Forms.Checkbox 
$MomentumCheckbox.Location = New-Object System.Drawing.Size(200,130) 
$MomentumCheckbox.Text = "       Momentum"
$MomentumCheckbox.Width = 180
$MomentumCheckbox.Height = 20
$MomentumCheckbox.Font = $BodyFont
$Tab7.Controls.Add($MomentumCheckbox)

$PrivacyBadgerLogo = New-Object System.Windows.Forms.PictureBox
$PrivacyBadgerLogo.Width = 18
$PrivacyBadgerLogo.Height = 18
$PrivacyBadgerLogo.Location = New-Object System.Drawing.Size(220,150)
$PrivacyBadgerLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\PrivacyBadger.png"
$PrivacyBadgerLogo.ImageLocation = $PrivacyBadgerLogoFile
$PrivacyBadgerLogo.BorderStyle = 0
$PrivacyBadgerLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($PrivacyBadgerLogo)

$PrivacyBadgerCheckbox = New-Object System.Windows.Forms.Checkbox 
$PrivacyBadgerCheckbox.Location = New-Object System.Drawing.Size(200,150) 
$PrivacyBadgerCheckbox.Text = "       Privacy Badger"
$PrivacyBadgerCheckbox.Width = 180
$PrivacyBadgerCheckbox.Height = 20
$PrivacyBadgerCheckbox.Font = $BodyFont
$Tab7.Controls.Add($PrivacyBadgerCheckbox)

$SponsorBlockLogo = New-Object System.Windows.Forms.PictureBox
$SponsorBlockLogo.Width = 18
$SponsorBlockLogo.Height = 18
$SponsorBlockLogo.Location = New-Object System.Drawing.Size(220,170)
$SponsorBlockLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SponsorBlock.png"
$SponsorBlockLogo.ImageLocation = $SponsorBlockLogoFile
$SponsorBlockLogo.BorderStyle = 0
$SponsorBlockLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($SponsorBlockLogo)

$SponsorBlockCheckbox = New-Object System.Windows.Forms.Checkbox 
$SponsorBlockCheckbox.Location = New-Object System.Drawing.Size(200,170) 
$SponsorBlockCheckbox.Text = "       SponsorBlock"
$SponsorBlockCheckbox.Width = 180
$SponsorBlockCheckbox.Height = 20
$SponsorBlockCheckbox.Font = $BodyFont
$Tab7.Controls.Add($SponsorBlockCheckbox)

$TodoistLogo = New-Object System.Windows.Forms.PictureBox
$TodoistLogo.Width = 18
$TodoistLogo.Height = 18
$TodoistLogo.Location = New-Object System.Drawing.Size(220,190)
$TodoistLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Todoist.png"
$TodoistLogo.ImageLocation = $TodoistLogoFile
$TodoistLogo.BorderStyle = 0
$TodoistLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($TodoistLogo)

$TodoistCheckbox = New-Object System.Windows.Forms.Checkbox 
$TodoistCheckbox.Location = New-Object System.Drawing.Size(200,190) 
$TodoistCheckbox.Text = "       Todoist"
$TodoistCheckbox.Width = 180
$TodoistCheckbox.Height = 20
$TodoistCheckbox.Font = $BodyFont
$Tab7.Controls.Add($TodoistCheckbox)

$uBlockOriginLogo = New-Object System.Windows.Forms.PictureBox
$uBlockOriginLogo.Width = 18
$uBlockOriginLogo.Height = 18
$uBlockOriginLogo.Location = New-Object System.Drawing.Size(220,210)
$uBlockOriginLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\uBlockOrigin.png"
$uBlockOriginLogo.ImageLocation = $uBlockOriginLogoFile
$uBlockOriginLogo.BorderStyle = 0
$uBlockOriginLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($uBlockOriginLogo)

$uBlockOriginCheckbox = New-Object System.Windows.Forms.Checkbox 
$uBlockOriginCheckbox.Location = New-Object System.Drawing.Size(200,210) 
$uBlockOriginCheckbox.Text = "       uBlockOrigin"
$uBlockOriginCheckbox.Width = 180
$uBlockOriginCheckbox.Height = 20
$uBlockOriginCheckbox.Font = $BodyFont
$Tab7.Controls.Add($uBlockOriginCheckbox)

$ViolentMonkeyLogo = New-Object System.Windows.Forms.PictureBox
$ViolentMonkeyLogo.Width = 18
$ViolentMonkeyLogo.Height = 18
$ViolentMonkeyLogo.Location = New-Object System.Drawing.Size(220,230)
$ViolentMonkeyLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\ViolentMonkey.png"
$ViolentMonkeyLogo.ImageLocation = $ViolentMonkeyLogoFile
$ViolentMonkeyLogo.BorderStyle = 0
$ViolentMonkeyLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($ViolentMonkeyLogo)

$ViolentMonkeyCheckbox = New-Object System.Windows.Forms.Checkbox 
$ViolentMonkeyCheckbox.Location = New-Object System.Drawing.Size(200,230) 
$ViolentMonkeyCheckbox.Text = "       ViolentMonkey"
$ViolentMonkeyCheckbox.Width = 180
$ViolentMonkeyCheckbox.Height = 20
$ViolentMonkeyCheckbox.Font = $BodyFont
$Tab7.Controls.Add($ViolentMonkeyCheckbox)

$YouTubeNonstopLogo = New-Object System.Windows.Forms.PictureBox
$YouTubeNonstopLogo.Width = 18
$YouTubeNonstopLogo.Height = 18
$YouTubeNonstopLogo.Location = New-Object System.Drawing.Size(220,250)
$YouTubeNonstopLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YouTubeNonstop.png"
$YouTubeNonstopLogo.ImageLocation = $YouTubeNonstopLogoFile
$YouTubeNonstopLogo.BorderStyle = 0
$YouTubeNonstopLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($YouTubeNonstopLogo)

$YouTubeNonstopCheckbox = New-Object System.Windows.Forms.Checkbox 
$YouTubeNonstopCheckbox.Location = New-Object System.Drawing.Size(200,250) 
$YouTubeNonstopCheckbox.Text = "       YouTubeNonstop"
$YouTubeNonstopCheckbox.Width = 180
$YouTubeNonstopCheckbox.Height = 20
$YouTubeNonstopCheckbox.Font = $BodyFont
$Tab7.Controls.Add($YouTubeNonstopCheckbox)

$ShortcutsLabel = New-Object System.Windows.Forms.Label
$ShortcutsLabel.Location = New-Object System.Drawing.Size(390,10)
$ShortcutsLabel.Text = "Shortcuts"
$ShortcutsLabel.Width = 180
$ShortcutsLabel.Height = 20
$ShortcutsLabel.Font = $HeaderFont
$Tab7.Controls.Add($ShortcutsLabel)

$AmazonShortcutLogo = New-Object System.Windows.Forms.PictureBox
$AmazonShortcutLogo.Width = 18
$AmazonShortcutLogo.Height = 18
$AmazonShortcutLogo.Location = New-Object System.Drawing.Size(410,30)
$AmazonShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AmazonShortcut.png"
$AmazonShortcutLogo.ImageLocation = $AmazonShortcutLogoFile
$AmazonShortcutLogo.BorderStyle = 0
$AmazonShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($AmazonShortcutLogo)

$AmazonShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$AmazonShortcutCheckbox.Location = New-Object System.Drawing.Size(390,30) 
$AmazonShortcutCheckbox.Text = "       Amazon"
$AmazonShortcutCheckbox.Width = 180
$AmazonShortcutCheckbox.Height = 20
$AmazonShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($AmazonShortcutCheckbox)

$AOLShortcutLogo = New-Object System.Windows.Forms.PictureBox
$AOLShortcutLogo.Width = 18
$AOLShortcutLogo.Height = 18
$AOLShortcutLogo.Location = New-Object System.Drawing.Size(410,50)
$AOLShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AOLShortcut.png"
$AOLShortcutLogo.ImageLocation = $AOLShortcutLogoFile
$AOLShortcutLogo.BorderStyle = 0
$AOLShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($AOLShortcutLogo)

$AOLShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$AOLShortcutCheckbox.Location = New-Object System.Drawing.Size(390,50) 
$AOLShortcutCheckbox.Text = "       AOL"
$AOLShortcutCheckbox.Width = 180
$AOLShortcutCheckbox.Height = 20
$AOLShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($AOLShortcutCheckbox)

$AOLMailShortcutLogo = New-Object System.Windows.Forms.PictureBox
$AOLMailShortcutLogo.Width = 18
$AOLMailShortcutLogo.Height = 18
$AOLMailShortcutLogo.Location = New-Object System.Drawing.Size(410,70)
$AOLMailShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AOLMailShortcut.png"
$AOLMailShortcutLogo.ImageLocation = $AOLMailShortcutLogoFile
$AOLMailShortcutLogo.BorderStyle = 0
$AOLMailShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($AOLMailShortcutLogo)

$AOLMailShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$AOLMailShortcutCheckbox.Location = New-Object System.Drawing.Size(390,70) 
$AOLMailShortcutCheckbox.Text = "       AOL Mail"
$AOLMailShortcutCheckbox.Width = 180
$AOLMailShortcutCheckbox.Height = 20
$AOLMailShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($AOLMailShortcutCheckbox)

$BestBuyShortcutLogo = New-Object System.Windows.Forms.PictureBox
$BestBuyShortcutLogo.Width = 18
$BestBuyShortcutLogo.Height = 18
$BestBuyShortcutLogo.Location = New-Object System.Drawing.Size(410,90)
$BestBuyShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\BestBuyShortcut.png"
$BestBuyShortcutLogo.ImageLocation = $BestBuyShortcutLogoFile
$BestBuyShortcutLogo.BorderStyle = 0
$BestBuyShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($BestBuyShortcutLogo)

$BestBuyShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$BestBuyShortcutCheckbox.Location = New-Object System.Drawing.Size(390,90) 
$BestBuyShortcutCheckbox.Text = "       Best Buy"
$BestBuyShortcutCheckbox.Width = 180
$BestBuyShortcutCheckbox.Height = 20
$BestBuyShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($BestBuyShortcutCheckbox)

$FacebookShortcutLogo = New-Object System.Windows.Forms.PictureBox
$FacebookShortcutLogo.Width = 18
$FacebookShortcutLogo.Height = 18
$FacebookShortcutLogo.Location = New-Object System.Drawing.Size(410,110)
$FacebookShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\FacebookShortcut.png"
$FacebookShortcutLogo.ImageLocation = $FacebookShortcutLogoFile
$FacebookShortcutLogo.BorderStyle = 0
$FacebookShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($FacebookShortcutLogo)

$FacebookShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$FacebookShortcutCheckbox.Location = New-Object System.Drawing.Size(390,110) 
$FacebookShortcutCheckbox.Text = "       Facebook"
$FacebookShortcutCheckbox.Width = 180
$FacebookShortcutCheckbox.Height = 20
$FacebookShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($FacebookShortcutCheckbox)

$GmailShortcutLogo = New-Object System.Windows.Forms.PictureBox
$GmailShortcutLogo.Width = 18
$GmailShortcutLogo.Height = 18
$GmailShortcutLogo.Location = New-Object System.Drawing.Size(410,130)
$GmailShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\GmailShortcut.png"
$GmailShortcutLogo.ImageLocation = $GmailShortcutLogoFile
$GmailShortcutLogo.BorderStyle = 0
$GmailShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($GmailShortcutLogo)

$GmailShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$GmailShortcutCheckbox.Location = New-Object System.Drawing.Size(390,130) 
$GmailShortcutCheckbox.Text = "       Gmail"
$GmailShortcutCheckbox.Width = 180
$GmailShortcutCheckbox.Height = 20
$GmailShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($GmailShortcutCheckbox)

$GoogleShortcutLogo = New-Object System.Windows.Forms.PictureBox
$GoogleShortcutLogo.Width = 18
$GoogleShortcutLogo.Height = 18
$GoogleShortcutLogo.Location = New-Object System.Drawing.Size(410,150)
$GoogleShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\GoogleShortcut.png"
$GoogleShortcutLogo.ImageLocation = $GoogleShortcutLogoFile
$GoogleShortcutLogo.BorderStyle = 0
$GoogleShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($GoogleShortcutLogo)

$GoogleShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$GoogleShortcutCheckbox.Location = New-Object System.Drawing.Size(390,150) 
$GoogleShortcutCheckbox.Text = "       Google"
$GoogleShortcutCheckbox.Width = 180
$GoogleShortcutCheckbox.Height = 20
$GoogleShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($GoogleShortcutCheckbox)

$OfficeShortcutsLogo = New-Object System.Windows.Forms.PictureBox
$OfficeShortcutsLogo.Width = 18
$OfficeShortcutsLogo.Height = 18
$OfficeShortcutsLogo.Location = New-Object System.Drawing.Size(410,170)
$OfficeShortcutsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\OfficeShortcuts.png"
$OfficeShortcutsLogo.ImageLocation = $OfficeShortcutsLogoFile
$OfficeShortcutsLogo.BorderStyle = 0
$OfficeShortcutsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($OfficeShortcutsLogo)

$OfficeShortcutsCheckbox = New-Object System.Windows.Forms.Checkbox 
$OfficeShortcutsCheckbox.Location = New-Object System.Drawing.Size(390,170) 
$OfficeShortcutsCheckbox.Text = "       Office"
$OfficeShortcutsCheckbox.Width = 180
$OfficeShortcutsCheckbox.Height = 20
$OfficeShortcutsCheckbox.Font = $BodyFont
$Tab7.Controls.Add($OfficeShortcutsCheckbox)

$RedditShortcutLogo = New-Object System.Windows.Forms.PictureBox
$RedditShortcutLogo.Width = 18
$RedditShortcutLogo.Height = 18
$RedditShortcutLogo.Location = New-Object System.Drawing.Size(410,190)
$RedditShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\RedditShortcut.png"
$RedditShortcutLogo.ImageLocation = $RedditShortcutLogoFile
$RedditShortcutLogo.BorderStyle = 0
$RedditShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($RedditShortcutLogo)

$RedditShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$RedditShortcutCheckbox.Location = New-Object System.Drawing.Size(390,190) 
$RedditShortcutCheckbox.Text = "       Reddit"
$RedditShortcutCheckbox.Width = 180
$RedditShortcutCheckbox.Height = 20
$RedditShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($RedditShortcutCheckbox)

$TwitterShortcutLogo = New-Object System.Windows.Forms.PictureBox
$TwitterShortcutLogo.Width = 18
$TwitterShortcutLogo.Height = 18
$TwitterShortcutLogo.Location = New-Object System.Drawing.Size(410,210)
$TwitterShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\TwitterShortcut.png"
$TwitterShortcutLogo.ImageLocation = $TwitterShortcutLogoFile
$TwitterShortcutLogo.BorderStyle = 0
$TwitterShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($TwitterShortcutLogo)

$TwitterShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$TwitterShortcutCheckbox.Location = New-Object System.Drawing.Size(390,210) 
$TwitterShortcutCheckbox.Text = "       Twitter"
$TwitterShortcutCheckbox.Width = 180
$TwitterShortcutCheckbox.Height = 20
$TwitterShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($TwitterShortcutCheckbox)

$YahooShortcutLogo = New-Object System.Windows.Forms.PictureBox
$YahooShortcutLogo.Width = 18
$YahooShortcutLogo.Height = 18
$YahooShortcutLogo.Location = New-Object System.Drawing.Size(410,230)
$YahooShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YahooShortcut.png"
$YahooShortcutLogo.ImageLocation = $YahooShortcutLogoFile
$YahooShortcutLogo.BorderStyle = 0
$YahooShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($YahooShortcutLogo)

$YahooShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$YahooShortcutCheckbox.Location = New-Object System.Drawing.Size(390,230) 
$YahooShortcutCheckbox.Text = "       Yahoo"
$YahooShortcutCheckbox.Width = 180
$YahooShortcutCheckbox.Height = 20
$YahooShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($YahooShortcutCheckbox)

$YahooMailShortcutLogo = New-Object System.Windows.Forms.PictureBox
$YahooMailShortcutLogo.Width = 18
$YahooMailShortcutLogo.Height = 18
$YahooMailShortcutLogo.Location = New-Object System.Drawing.Size(410,250)
$YahooMailShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YahooMailShortcut.png"
$YahooMailShortcutLogo.ImageLocation = $YahooMailShortcutLogoFile
$YahooMailShortcutLogo.BorderStyle = 0
$YahooMailShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($YahooMailShortcutLogo)

$YahooMailShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$YahooMailShortcutCheckbox.Location = New-Object System.Drawing.Size(390,250) 
$YahooMailShortcutCheckbox.Text = "       Yahoo Mail"
$YahooMailShortcutCheckbox.Width = 180
$YahooMailShortcutCheckbox.Height = 20
$YahooMailShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($YahooMailShortcutCheckbox)

$YouTubeShortcutLogo = New-Object System.Windows.Forms.PictureBox
$YouTubeShortcutLogo.Width = 18
$YouTubeShortcutLogo.Height = 18
$YouTubeShortcutLogo.Location = New-Object System.Drawing.Size(410,270)
$YouTubeShortcutLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\YouTubeShortcut.png"
$YouTubeShortcutLogo.ImageLocation = $YouTubeShortcutLogoFile
$YouTubeShortcutLogo.BorderStyle = 0
$YouTubeShortcutLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($YouTubeShortcutLogo)

$YouTubeShortcutCheckbox = New-Object System.Windows.Forms.Checkbox 
$YouTubeShortcutCheckbox.Location = New-Object System.Drawing.Size(390,270) 
$YouTubeShortcutCheckbox.Text = "       YouTube"
$YouTubeShortcutCheckbox.Width = 180
$YouTubeShortcutCheckbox.Height = 20
$YouTubeShortcutCheckbox.Font = $BodyFont
$Tab7.Controls.Add($YouTubeShortcutCheckbox)

$SystemPrepLabel = New-Object System.Windows.Forms.Label
$SystemPrepLabel.Location = New-Object System.Drawing.Size(580,10)
$SystemPrepLabel.Text = "System Prep"
$SystemPrepLabel.Width = 180
$SystemPrepLabel.Height = 20
$SystemPrepLabel.Font = $HeaderFont
$Tab7.Controls.Add($SystemPrepLabel)

$AppUpdatesLogo = New-Object System.Windows.Forms.PictureBox
$AppUpdatesLogo.Width = 18
$AppUpdatesLogo.Height = 18
$AppUpdatesLogo.Location = New-Object System.Drawing.Size(600,30)
$AppUpdatesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AppUpdates.png"
$AppUpdatesLogo.ImageLocation = $AppUpdatesLogoFile
$AppUpdatesLogo.BorderStyle = 0
$AppUpdatesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($AppUpdatesLogo)

$AppUpdatesCheckbox = New-Object System.Windows.Forms.Checkbox 
$AppUpdatesCheckbox.Location = New-Object System.Drawing.Size(580,30) 
$AppUpdatesCheckbox.Text = "       App Updates"
$AppUpdatesCheckbox.Width = 180
$AppUpdatesCheckbox.Height = 20
$AppUpdatesCheckbox.Font = $BodyFont
$Tab7.Controls.Add($AppUpdatesCheckbox)

$AutoRestartLogo = New-Object System.Windows.Forms.PictureBox
$AutoRestartLogo.Width = 18
$AutoRestartLogo.Height = 18
$AutoRestartLogo.Location = New-Object System.Drawing.Size(600,50)
$AutoRestartLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AutoRestart.png"
$AutoRestartLogo.ImageLocation = $AutoRestartLogoFile
$AutoRestartLogo.BorderStyle = 0
$AutoRestartLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($AutoRestartLogo)

$AutoRestartCheckbox = New-Object System.Windows.Forms.Checkbox 
$AutoRestartCheckbox.Location = New-Object System.Drawing.Size(580,50) 
$AutoRestartCheckbox.Text = "       Auto Restart"
$AutoRestartCheckbox.Width = 180
$AutoRestartCheckbox.Height = 20
$AutoRestartCheckbox.Font = $BodyFont
$Tab7.Controls.Add($AutoRestartCheckbox)

$AutoTimeZoneLogo = New-Object System.Windows.Forms.PictureBox
$AutoTimeZoneLogo.Width = 18
$AutoTimeZoneLogo.Height = 18
$AutoTimeZoneLogo.Location = New-Object System.Drawing.Size(600,70)
$AutoTimeZoneLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\AutoTimeZone.png"
$AutoTimeZoneLogo.ImageLocation = $AutoTimeZoneLogoFile
$AutoTimeZoneLogo.BorderStyle = 0
$AutoTimeZoneLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($AutoTimeZoneLogo)

$AutoTimeZoneCheckbox = New-Object System.Windows.Forms.Checkbox 
$AutoTimeZoneCheckbox.Location = New-Object System.Drawing.Size(580,70) 
$AutoTimeZoneCheckbox.Text = "       Auto Time Zone"
$AutoTimeZoneCheckbox.Width = 180
$AutoTimeZoneCheckbox.Height = 20
$AutoTimeZoneCheckbox.Font = $BodyFont
$Tab7.Controls.Add($AutoTimeZoneCheckbox)

$CleanupLogo = New-Object System.Windows.Forms.PictureBox
$CleanupLogo.Width = 18
$CleanupLogo.Height = 18
$CleanupLogo.Location = New-Object System.Drawing.Size(600,90)
$CleanupLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Cleanup.png"
$CleanupLogo.ImageLocation = $CleanupLogoFile
$CleanupLogo.BorderStyle = 0
$CleanupLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($CleanupLogo)

$CleanupCheckbox = New-Object System.Windows.Forms.Checkbox 
$CleanupCheckbox.Location = New-Object System.Drawing.Size(580,90) 
$CleanupCheckbox.Text = "       Cleanup"
$CleanupCheckbox.Width = 180
$CleanupCheckbox.Height = 20
$CleanupCheckbox.Font = $BodyFont
$Tab7.Controls.Add($CleanupCheckbox)

$RestorePointLogo = New-Object System.Windows.Forms.PictureBox
$RestorePointLogo.Width = 18
$RestorePointLogo.Height = 18
$RestorePointLogo.Location = New-Object System.Drawing.Size(600,110)
$RestorePointLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\RestorePoint.png"
$RestorePointLogo.ImageLocation = $RestorePointLogoFile
$RestorePointLogo.BorderStyle = 0
$RestorePointLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($RestorePointLogo)

$RestorePointCheckbox = New-Object System.Windows.Forms.Checkbox 
$RestorePointCheckbox.Location = New-Object System.Drawing.Size(580,110) 
$RestorePointCheckbox.Text = "       Restore Point"
$RestorePointCheckbox.Width = 180
$RestorePointCheckbox.Height = 20
$RestorePointCheckbox.Font = $BodyFont
$Tab7.Controls.Add($RestorePointCheckbox)

$WindowsUpdatesLogo = New-Object System.Windows.Forms.PictureBox
$WindowsUpdatesLogo.Width = 18
$WindowsUpdatesLogo.Height = 18
$WindowsUpdatesLogo.Location = New-Object System.Drawing.Size(600,130)
$WindowsUpdatesLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\WindowsUpdates.png"
$WindowsUpdatesLogo.ImageLocation = $WindowsUpdatesLogoFile
$WindowsUpdatesLogo.BorderStyle = 0
$WindowsUpdatesLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($WindowsUpdatesLogo)

$WindowsUpdatesCheckbox = New-Object System.Windows.Forms.Checkbox 
$WindowsUpdatesCheckbox.Location = New-Object System.Drawing.Size(580,130) 
$WindowsUpdatesCheckbox.Text = "       Windows Updates"
$WindowsUpdatesCheckbox.Width = 180
$WindowsUpdatesCheckbox.Height = 20
$WindowsUpdatesCheckbox.Font = $BodyFont
$Tab7.Controls.Add($WindowsUpdatesCheckbox)

# Logo for "Select All" System Prep
$SystemPrepAllLogo = New-Object System.Windows.Forms.PictureBox
$SystemPrepAllLogo.Width = 18
$SystemPrepAllLogo.Height = 18
$SystemPrepAllLogo.Location = New-Object System.Drawing.Size(600,150)
$SystemPrepAllLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\SelectAll.png"
$SystemPrepAllLogo.ImageLocation = $SystemPrepAllLogoFile
$SystemPrepAllLogo.BorderStyle = 0
$SystemPrepAllLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$Tab7.Controls.Add($SystemPrepAllLogo)

# Checkbox for "Select All" System Prep
$SystemPrepAllCheckbox = New-Object System.Windows.Forms.CheckBox
$SystemPrepAllCheckbox.Location = New-Object System.Drawing.Size(580,150)
$SystemPrepAllCheckbox.Text = "       Select All"
$SystemPrepAllCheckbox.Width = 180
$SystemPrepAllCheckbox.Height = 20
$SystemPrepAllCheckbox.Font = $BodyFont
$Tab7.Controls.Add($SystemPrepAllCheckbox)

# Array of System Prep checkboxes
$SystemPrepCheckboxes = @($AppUpdatesCheckbox, $AutoRestartCheckbox, $AutoTimeZoneCheckbox, $CleanupCheckbox, $RestorePointCheckbox, $WindowsUpdatesCheckbox)

# Event: Toggle all System Prep checkboxes when "Select All" is clicked
$SystemPrepAllCheckbox.Add_CheckedChanged({
    foreach ($cb in $SystemPrepCheckboxes) {
        $cb.Checked = $SystemPrepAllCheckbox.Checked
    }
})

$UninstallLabel = New-Object System.Windows.Forms.Label
$UninstallLabel.Location = New-Object System.Drawing.Size(580,190)
$UninstallLabel.Text = "Uninstall"
$UninstallLabel.Width = 180
$UninstallLabel.Height = 20
$UninstallLabel.Font = $HeaderFont
$Tab7.Controls.Add($UninstallLabel)

$BloatwareLogo = New-Object System.Windows.Forms.PictureBox
$BloatwareLogo.Width = 18
$BloatwareLogo.Height = 18
$BloatwareLogo.Location = New-Object System.Drawing.Size(600,210)
$BloatwareLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\Bloatware.png"
$BloatwareLogo.ImageLocation = $BloatwareLogoFile
$BloatwareLogo.BorderStyle = 0
$BloatwareLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($BloatwareLogo)

$BloatwareCheckbox = New-Object System.Windows.Forms.Checkbox 
$BloatwareCheckbox.Location = New-Object System.Drawing.Size(580,210) 
$BloatwareCheckbox.Text = "       Bloatware"
$BloatwareCheckbox.Width = 180
$BloatwareCheckbox.Height = 20
$BloatwareCheckbox.Font = $BodyFont
$Tab7.Controls.Add($BloatwareCheckbox)

$UninstallExtensionsLogo = New-Object System.Windows.Forms.PictureBox
$UninstallExtensionsLogo.Width = 18
$UninstallExtensionsLogo.Height = 18
$UninstallExtensionsLogo.Location = New-Object System.Drawing.Size(600,230)
$UninstallExtensionsLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\UninstallExtensions.png"
$UninstallExtensionsLogo.ImageLocation = $UninstallExtensionsLogoFile
$UninstallExtensionsLogo.BorderStyle = 0
$UninstallExtensionsLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($UninstallExtensionsLogo)

$UninstallExtensionsCheckbox = New-Object System.Windows.Forms.Checkbox 
$UninstallExtensionsCheckbox.Location = New-Object System.Drawing.Size(580,230) 
$UninstallExtensionsCheckbox.Text = "       Extensions"
$UninstallExtensionsCheckbox.Width = 180
$UninstallExtensionsCheckbox.Height = 20
$UninstallExtensionsCheckbox.Font = $BodyFont
$Tab7.Controls.Add($UninstallExtensionsCheckbox)

$MCPRLogo = New-Object System.Windows.Forms.PictureBox
$MCPRLogo.Width = 18
$MCPRLogo.Height = 18
$MCPRLogo.Location = New-Object System.Drawing.Size(600,250)
$MCPRLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\MCPR.png"
$MCPRLogo.ImageLocation = $MCPRLogoFile
$MCPRLogo.BorderStyle = 0
$MCPRLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($MCPRLogo)

$MCPRCheckbox = New-Object System.Windows.Forms.Checkbox 
$MCPRCheckbox.Location = New-Object System.Drawing.Size(580,250) 
$MCPRCheckbox.Text = "       McAfee"
$MCPRCheckbox.Width = 180
$MCPRCheckbox.Height = 20
$MCPRCheckbox.Font = $BodyFont
$Tab7.Controls.Add($MCPRCheckbox)

$OneDriveLogo = New-Object System.Windows.Forms.PictureBox
$OneDriveLogo.Width = 18
$OneDriveLogo.Height = 18
$OneDriveLogo.Location = New-Object System.Drawing.Size(600,270)
$OneDriveLogoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\OneDrive.png"
$OneDriveLogo.ImageLocation = $OneDriveLogoFile
$OneDriveLogo.BorderStyle = 0
$OneDriveLogo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($OneDriveLogo)

$OneDriveCheckbox = New-Object System.Windows.Forms.Checkbox 
$OneDriveCheckbox.Location = New-Object System.Drawing.Size(580,270) 
$OneDriveCheckbox.Text = "       OneDrive"
$OneDriveCheckbox.Width = 180
$OneDriveCheckbox.Height = 20
$OneDriveCheckbox.Font = $BodyFont
$Tab7.Controls.Add($OneDriveCheckbox)

$RUNButton = New-Object System.Windows.Forms.Button
$RUNButton.Location = New-Object System.Drawing.Size(975,100)
$RUNButton.Size = New-Object System.Drawing.Size(150,50)
$RUNButton.Text = "RUN"
$RUNButton.Font = $RunFont
$Tab7.Controls.Add($RUNButton)

$ZeroTwo = New-Object System.Windows.Forms.PictureBox
$ZeroTwo.Width = 400
$ZeroTwo.Height = 488
$ZeroTwo.Location = New-Object System.Drawing.Size(775,90)
$ZeroTwoFile = (Split-Path -Parent $PSCommandPath) + "\Images\Tasks\ZeroTwo.png"
$ZeroTwo.ImageLocation = $ZeroTwoFile
$ZeroTwo.BorderStyle = 0
$ZeroTwo.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$Tab7.Controls.Add($ZeroTwo)

#---------------------------------------------------------------------------------------------
# Event Handlers

function Execute {

$form.ShowInTaskbar = $False
$form.Hide()
Clear
Show-Console | Out-Null

# Sets the Desktop Path
$desktopPath = [Environment]::GetFolderPath("Desktop")

# Shell 
$shell = New-Object -ComObject WScript.Shell

# Edge path for icon shortcuts
$edgeExePath = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

# Disable Sleep
$schemeGuid = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67' 
$schemeName = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'
function assert-ok { if ($LASTEXITCODE -ne 0) { throw } }
$prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
assert-ok
try {
	powercfg -setactive $schemeGuid 2>$null
	if ($LASTEXITCODE -ne 0) { 
    	$null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
    	assert-ok
    	$null = powercfg -changename $schemeGuid $schemeName $schemeDescr
    	$null = powercfg -setactive $schemeGuid
    	assert-ok
    	$settings = 'monitor-timeout-ac', 'monitor-timeout-dc', 'disk-timeout-ac', 'disk-timeout-dc', 'standby-timeout-ac', 'standby-timeout-dc', 'hibernate-timeout-ac', 'hibernate-timeout-dc'
    	foreach ($setting in $settings) {
      	powercfg -change $setting 0 # 0 == Never
      	assert-ok
    }
}

# Settings
# Disable
if ($Encryption.Checked) { 
    Write-Host "Disable Device Encryption" -ForegroundColor Cyan
    try {
        $bitlocker = Get-BitLockerVolume -MountPoint "C:" -ErrorAction Stop
    } catch {
        Write-Host "[WARNING] Unable to query BitLocker status. Device Encryption state unknown`n" -ForegroundColor Yellow
        return
    }
    if ($bitlocker.VolumeStatus -eq "FullyEncrypted" -or $bitlocker.VolumeStatus -eq "EncryptionInProgress") {
        try {
            Disable-BitLocker -MountPoint "C:" -ErrorAction Stop
            Write-Host "[DONE] Disable Device Encryption completed and decrypting in the background`n" -ForegroundColor Green
        } catch {
            Write-Host "[ERROR] Unable to disable Device Encryption: $($_.Exception.Message)`n" -ForegroundColor Red
        }
    } else {
        Write-Host "[DONE] Device Encryption is already disabled`n" -ForegroundColor Green
    }
}

if ($AppUpdatesCheckbox.Checked) {
	Write-Host "Manual App Updates" -ForegroundColor Cyan
	Start-Process ms-windows-store://downloadsandupdates
	Write-Host "[DONE] App Updates`n" -ForegroundColor Green
}

if ($TrackingCheckbox.Checked) {
    Write-Host "Disable Tracking" -ForegroundColor Cyan

    # Location Tracking
    try {
        if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location") {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" -Name "Value" -Value "Deny" -ErrorAction Stop
            Write-Host "Location Tracking disabled"
        }
    } catch { Write-Host "[ERROR] Location Tracking: $($_.Exception.Message)" -ForegroundColor Red }

    # Advertising ID
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -Name "Enabled" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "Advertising ID disabled"
    } catch { Write-Host "[ERROR] Advertising ID: $($_.Exception.Message)" -ForegroundColor Red }

    # Tailored Experiences
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -Name "TailoredExperiencesWithDiagnosticDataEnabled" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "Tailored Experiences disabled"
    } catch { Write-Host "[ERROR] Tailored Experiences: $($_.Exception.Message)" -ForegroundColor Red }

    # Feedback Frequency (Win10 + Win11)
    try {
        # Policy key (Win11 + Win10)
        $dcPol = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
        if (!(Test-Path $dcPol)) {
            New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows" -Name "DataCollection" -Force | Out-Null
        }
        Set-ItemProperty -Path $dcPol -Name "DoNotShowFeedbackNotifications" -Type DWord -Value 1 -ErrorAction Stop
        Write-Host "Feedback notifications disabled"

        # Legacy Win10 fallback
        $siuf = "HKCU:\Software\Microsoft\Siuf\Rules"
        if (!(Test-Path $siuf)) {
            New-Item -Path "HKCU:\Software\Microsoft\Siuf" -Name "Rules" -Force | Out-Null
        }
        Set-ItemProperty -Path $siuf -Name "NumberOfSIUFInPeriod" -Type DWord -Value 0 -ErrorAction Stop
        New-ItemProperty -Path $siuf -Name "PeriodInNanoSeconds" -PropertyType QWord -Value 0 -Force | Out-Null
        Write-Host "Feedback frequency set to 'Never' (legacy)"
    } catch { Write-Host "[ERROR] Feedback Frequency: $($_.Exception.Message)" -ForegroundColor Red }

    # Typing and Inking Data
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\InputPersonalization" -Name "RestrictImplicitTextCollection" -Type DWord -Value 1 -ErrorAction Stop
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\InputPersonalization" -Name "RestrictImplicitInkCollection" -Type DWord -Value 1 -ErrorAction Stop
        Write-Host "Typing and Inking Data disabled"
    } catch { Write-Host "[ERROR] Typing and Inking: $($_.Exception.Message)" -ForegroundColor Red }

    # Activity History
    try {
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableActivityFeed" -Type DWord -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "PublishUserActivities" -Type DWord -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "UploadUserActivities" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "Activity History disabled"
    } catch { Write-Host "[ERROR] Activity History: $($_.Exception.Message)" -ForegroundColor Red }

    # App Launch Tracking
    try {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Start_TrackProgs" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "App Launch Tracking disabled"
    } catch { Write-Host "[ERROR] App Launch Tracking: $($_.Exception.Message)" -ForegroundColor Red }

    # Find My Device
    try {
        if (Test-Path "HKLM:\SOFTWARE\Microsoft\Settings\FindMyDevice") {
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Settings\FindMyDevice" -Name "LocationSyncEnabled" -Type DWord -Value 0 -ErrorAction Stop
            Write-Host "Find My Device disabled"
        }
    } catch { Write-Host "[ERROR] Find My Device: $($_.Exception.Message)" -ForegroundColor Red }

    # Diagnostic Data (basic telemetry)
    try {
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Type DWord -Value 1 -ErrorAction Stop
        Write-Host "Optional Diagnostic Data disabled"
    } catch { Write-Host "[ERROR] Diagnostic Data: $($_.Exception.Message)" -ForegroundColor Red }

    Write-Host "[DONE] Disable Tracking completed`n" -ForegroundColor Green
}

if ($SuggestionsCheckbox.Checked) {
    Write-Host "Disabling Suggestions, Tips, and Recommendations" -ForegroundColor Cyan

    try {
        # Disable Start Menu Suggestions
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338393Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338389Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable Suggestions for Apps in Start (like "Suggested apps")
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338388Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable "Finish Setting Up Your Device" prompts
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" -Name "ScoobeSystemSettingEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable "Get tips, tricks, and suggestions" notifications
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SoftLandingEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable "Suggested Apps" notifications
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-310093Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable Windows Welcome Experience
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SubscribedContent-338387Enabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        # Disable Automatic Installation of Suggested Apps
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "ContentDeliveryAllowed" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "OemPreInstalledAppsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "PreInstalledAppsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "PreInstalledAppsEverEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SilentInstalledAppsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" -Name "SystemPaneSuggestionsEnabled" -Type DWord -Value 0 -ErrorAction SilentlyContinue

        Write-Host "[DONE] Suggestions and tips disabled.`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to disable suggestions and tips: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Disable Task View (Win11)
if ($TaskViewCheckbox.Checked) {
    Write-Host "Disable Task View Button" -ForegroundColor Cyan

    $taskbarKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    if (Test-Path $taskbarKey) {
        try {
            Set-ItemProperty -Path $taskbarKey -Name "ShowTaskViewButton" -Type DWord -Value 0 -ErrorAction Stop
            Write-Host "[DONE] Disable Task View button completed`n" -ForegroundColor Green
        } catch {
            Write-Host "Failed to disable Task View: $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Write-Host "For Windows 11 only`n" -ForegroundColor Red
    }
}

# Disable Widgets (Win11)
if ($Widgets.Checked) {
    Write-Host "Disabling Widgets Button" -ForegroundColor Cyan
    $taskbarKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
    if (Test-Path $taskbarKey) {
        try {
            Set-ItemProperty -Path $taskbarKey -Name "TaskbarDa" -Type DWord -Value 0 -ErrorAction Stop
            Write-Host "[DONE] Disabling Widgets Button completed`n" -ForegroundColor Green
        } catch {
            Write-Host "Failed to disable Widgets: $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Write-Host "For Windows 11 only`n" -ForegroundColor Red
    }
}

# Disable Search Highlights (Win10 + Win11 support)
if ($HighlightsCheckbox.Checked) {
    Write-Host "Disable Search Highlights" -ForegroundColor Cyan
    try {
        # Win11 toggle
        if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings") {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings" -Name "IsDynamicSearchBoxEnabled" -Type DWord -Value 0 -ErrorAction Stop
        }
        # Win10 fallback
        if (Test-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search") {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "EnableDynamicContentInWSB" -Type DWord -Value 0 -ErrorAction Stop
        }
        Write-Host "[DONE] Search Highlights disabled`n" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Failed to disable Search Highlights: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

# Disable Game Bar + enforce policy
if ($GameBarDVRCheckbox.Checked) { 
    Write-Host "Disable Game Bar and Game DVR" -ForegroundColor Cyan
    try {
        Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\GameBar" -Name "ShowStartupPanel" -Type DWord -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\GameBar" -Name "Enabled" -Type DWord -Value 0 -ErrorAction Stop
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_Enabled" -Type DWord -Value 0 -ErrorAction Stop
        # Enforce via Group Policy (prevents re-enabling after updates)
        if (!(Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR")) {
            New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows" -Name "GameDVR" -Force | Out-Null
        }
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR" -Name "AllowGameDVR" -Type DWord -Value 0 -ErrorAction Stop
        Write-Host "[DONE] Game Bar and Game DVR disabled`n" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] Failed to disable Game Bar/Game DVR: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

# Enable
if ($DarkModeCheckbox.Checked) { 
    Write-Host "Enable Dark Mode" -ForegroundColor Cyan
	Set-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -Value 0
    Write-Host "[DONE] Enable Dark Mode completed`n" -ForegroundColor Green
}

if ($HiddenFilesCheckbox.Checked) {
    Write-Host "Enable Show Hidden Files" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "Hidden" -Type DWord -Value 1
    Write-Host "[DONE] Enable Show Hidden Files enabled`n"
}

if ($FileExtensionsCheckbox.Checked) {
    Write-Host "Enable File Extensions" -ForegroundColor Cyan
    Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "HideFileExt" -Type DWord -Value 0
    Write-Host "[DONE] Enable File Extensions`n"
}

if ($NightLightCheckbox.Checked) {
    Write-Host "Enable Night Light with custom schedule" -ForegroundColor Cyan

    try {
        # === CONFIGURATION ===
        # Start / End times are in minutes since midnight (0 - 1439)
        $StartTimeMinutes = 1140   # 19:00 (7:00 PM)
        $EndTimeMinutes   = 420    # 07:00 (7:00 AM)
        $StrengthValue    = 128    # 0-255 (0 = cool, 255 = very warm)

        # Registry path for Night Light settings
        $nightLightPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\CloudStore\Store\DefaultAccount\Current\default$windows.data.bluelightreduction.settings"

        # Build binary data structure:
        # DWORDs in order: Version, Enabled, ScheduleMode, Start, End, Strength
        $version      = [BitConverter]::GetBytes(2) # Schema version
        $enabled      = [BitConverter]::GetBytes(1) # Enable Night Light
        $scheduleMode = [BitConverter]::GetBytes(2) # 2 = Custom Schedule
        $startMinutes = [BitConverter]::GetBytes($StartTimeMinutes)
        $endMinutes   = [BitConverter]::GetBytes($EndTimeMinutes)
        $strength     = [BitConverter]::GetBytes($StrengthValue)

        $data = $version + $enabled + $scheduleMode + $startMinutes + $endMinutes + $strength

        # Write to registry
        Set-ItemProperty -Path $nightLightPath -Name Data -Value $data -ErrorAction Stop

        Write-Host "[DONE] Enable Night Light with custom schedule $($StartTimeMinutes/60):$("{0:D2}" -f ($StartTimeMinutes%60)) - $($EndTimeMinutes/60):$("{0:D2}" -f ($EndTimeMinutes%60)), Strength: $StrengthValue (0-255) completed`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to configure Night Light schedule: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Taskbar alignment with OS version check
if ($LeftTaskbarCheckbox.Checked) {
    Write-Host "Enable Left Taskbar Alignment" -ForegroundColor Cyan
    $osBuild = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").CurrentBuildNumber
    if ([int]$osBuild -ge 22000) {
        try {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" -Name "TaskbarAl" -Type DWord -Value 0 -ErrorAction Stop
            Write-Host "[DONE] Taskbar Left Alignment completed`n" -ForegroundColor Green
        } catch {
            Write-Host "[ERROR] Failed to set Taskbar Alignment: $($_.Exception.Message)`n" -ForegroundColor Red
        }
    } else {
        Write-Host "[INFO] Taskbar alignment option is only available on Windows 11`n" -ForegroundColor Yellow
    }
}

if ($AutoTimeZoneCheckbox.Checked) {
    Write-Host "Set Automatic Time Zone" -ForegroundColor Cyan

    try {
        # Enable Location Service (required for auto time zone)
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration" `
                         -Name "Status" -Type DWord -Value 1 -ErrorAction SilentlyContinue
        Write-Host "Location Service enabled"

        # Enable "Set time zone automatically"
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\tzautoupdate" `
                         -Name "Start" -Type DWord -Value 3 -ErrorAction SilentlyContinue
        Start-Service -Name tzautoupdate -ErrorAction SilentlyContinue
        Write-Host "Set Time Zone Automatically enabled"

    } catch {
        Write-Host "[ERROR] Failed to enable automatic time zone: $($_.Exception.Message)`n" -ForegroundColor Red
    }

    Write-Host "[DONE] Automatic Time Zone completed`n" -ForegroundColor Green
}

if($MCPRCheckbox.Checked) {  
	write-Host "McAfee Consumer Product Removal" -ForegroundColor Cyan 
	$urlMCPR = "https://github.com/andrew-s-taylor/public/raw/main/De-Bloat/mcafeeclean.zip"
	$destMCPR = "$env:TEMP\MCPR.zip"
	Invoke-WebRequest -Uri $urlMCPR -OutFile $destMCPR -verbose
	Expand-Archive $destMCPR -DestinationPath "$env:TEMP\MCPR" -Force
    Start-Process "$env:TEMP\MCPR\Mccleanup.exe" -ArgumentList "-p StopServices,MFSY,PEF,MXD,CSP,Sustainability,MOCP,MFP,APPSTATS,Auth,EMproxy,FWdiver,HW,MAS,MAT,MBK,MCPR,McProxy,McSvcHost,VUL,MHN,MNA,MOBK,MPFP,MPFPCU,MPS,SHRED,MPSCU,MQC,MQCCU,MSAD,MSHR,MSK,MSKCU,MWL,NMC,RedirSvc,VS,REMEDIATION,MSC,YAP,TRUEKEY,LAM,PCB,Symlink,SafeConnect,MGS,WMIRemover,RESIDUE -v -s" 
	write-Host "Removing McAfee products" -ForegroundColor Cyan 
	Start-Sleep 300
	write-Host "[DONE] McAfee Consumer Product Removal completed`n" -ForegroundColor Green 
}

if($TrendMicroCheckbox.Checked) { 
	write-Host "Installing TrendMicro" -ForegroundColor Cyan 
	$urlTrendMicro = "https://files.trendmicro.com/products/Titanium/17.8/BBY/07302024/TrendMicro_17.8_MR_64bit.exe"
	$destTrendMicro = "$env:TEMP\TrendMicro.exe" 
	Invoke-WebRequest -Uri $urlTrendMicro -OutFile $destTrendMicro -verbose
	start-process $destTrendMicro -verb runas -verbose
	start-sleep -Seconds 180
	write-Host "[DONE] Installing TrendMicro completed`n" -ForegroundColor Green 
}

if($NvidiaCheckbox.Checked) { 
	write-Host "Installing Nvidia App" -ForegroundColor Cyan 
	$urlNvidia = "https://us.download.nvidia.com/nvapp/client/11.0.3.241/NVIDIA_app_v11.0.3.241.exe"
	$destNvidia = "$env:TEMP\Nvidia.exe" 
	Invoke-WebRequest -Uri $urlNvidia -OutFile $destNvidia -verbose
	start-process $destNvidia /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Nvidia App completed`n" -ForegroundColor Green 
}

if($EpsonConnectCheckbox.Checked) { 
	write-Host "Installing Epson Connect" -ForegroundColor Cyan 
	$urlEpsonConnect = "https://ftp.epson.com/drivers/ECPSU_143.exe"
	$destEpsonConnect = "$env:TEMP\ECPSU.exe" 
	Invoke-WebRequest -Uri $urlEpsonConnect -OutFile $destEpsonConnect -verbose
	start-process $destEpsonConnect /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Epson Connect completed`n" -ForegroundColor Green 
}

if($NoxPlayerCheckbox.Checked) { 
	write-Host "Installing NoxPlayer" -ForegroundColor Cyan 
	$urlNoxPlayer = "https://www.bignox.com/en/download/fullPackage?formal"
	$destNoxPlayer = "$env:TEMP\NoxPlayer.exe" 
	Invoke-WebRequest -Uri $urlNoxPlayer -OutFile $destNoxPlayer -verbose
	start-process $destNoxPlayer -verb runas -verbose -wait
	write-Host "[DONE] Installing NoxPlayer completed`n" -ForegroundColor Green 
}

if($MTGOCheckbox.Checked) { 
    write-Host "Installing MTGO" -ForegroundColor Cyan 
	$urlMTGO = "https://mtgo.patch.daybreakgames.com/patch/mtg/live/client/setup.exe?v=9"
	$destMTGO = "$env:TEMP\MTGO.exe" 
	Invoke-WebRequest -Uri $urlMTGO -OutFile $destMTGO -verbose
	start-process $destMTGO -verb runas -verbose 
	start-sleep 240
	write-Host "[DONE] Installing MTGO completed`n" -ForegroundColor Green        	   				
}

if($Project64Checkbox.Checked) { 
	write-Host "Installing Project64" -ForegroundColor Cyan 
	$urlProject64 = "https://www.pj64-emu.com/file/setup-project64-3-0-1-5664-2df3434/"
	$destProject64 = "$env:TEMP\Project64.exe" 
	Invoke-WebRequest -Uri $urlProject64 -OutFile $destProject64 -verbose
	start-process $destProject64 -verb runas -verbose -wait
	write-Host "[DONE] Installing Project64 completed`n" -ForegroundColor Green        	   				
}

if ($MTGArenaCheckbox.Checked) {
    Install-Game -GameName "MTG Arena" -WingetId "WizardsoftheCoast.MTGALauncher" -SubFolder "MTG\Arena"
}

if ($SteamCheckbox.Checked) {
    Install-Game -GameName "Steam" -WingetId "Valve.Steam" -SubFolder "Steam"
}

if ($EpicGamesCheckbox.Checked) {
    Install-Game -GameName "Epic Games" -WingetId "EpicGames.EpicGamesLauncher" -SubFolder "Epic Games"
}

if ($BattleCheckbox.Checked) {
    Install-Game -GameName "Battle.net" -WingetId "Blizzard.BattleNet" -SubFolder "Battle.net"
}

if ($EACheckbox.Checked) {
    Install-Game -GameName "EA Desktop" -WingetId "ElectronicArts.EADesktop" -SubFolder "Electronic Arts\EA Desktop"
}

if ($MinecraftCheckbox.Checked) {
    Install-Game -GameName "Minecraft" -WingetId "Mojang.MinecraftLauncher" -SubFolder "Minecraft"
}

if ($UbisoftConnectCheckbox.Checked) {
    Install-Game -GameName "Ubisoft Connect" -WingetId "Ubisoft.Connect" -SubFolder "Ubisoft"
}
	
if ($LoLCheckbox.Checked) {
    Install-Game -GameName "League of Legends" -WingetId "RiotGames.LeagueOfLegends.NA" -SubFolder "Riot Games\League of Legends"
}
	
if ($ValorantCheckbox.Checked) {
    Install-Game -GameName "Valorant" -WingetId "RiotGames.Valorant.NA" -SubFolder "Riot Games\Valorant"
}

if ($VortexCheckbox.Checked) {
    Install-Game -GameName "Nexus Mods Vortex" -WingetId "NexusMods.Vortex" -SubFolder "Mods\NexusMods"
}

if ($CurseForgeCheckbox.Checked) {
    Install-Game -GameName "CurseForge" -WingetId "Overwolf.CurseForge" -SubFolder "Mods\CurseForge"
}

if ($WeModCheckbox.Checked) {
    Install-Game -GameName "WeMod" -WingetId "WeMod.WeMod" -SubFolder "Mods\WeMod"
}

if ($DolphinCheckbox.Checked) {
    Install-Game -GameName "Dolphin Emulator" -WingetId "DolphinEmulator.Dolphin" -SubFolder "Emulators\GC Wii\Dolphin"
}

if ($CemuCheckbox.Checked) {
    Install-Game -GameName "Cemu Emulator" -WingetId "Cemu.Cemu" -SubFolder "Emulators\Wii U\Cemu"
}

if ($DeSmuMECheckbox.Checked) {
    Install-Game -GameName "DeSmuME Emulator" -WingetId "TASVideos.Desmume" -SubFolder "Emulators\DS\DeSmuME"
}

if ($DOSBoxCheckbox.Checked) {
    Install-Game -GameName "DOSBox" -WingetId "DOSBox.DOSBox" -SubFolder "Emulators\DOS\DOSBox"
}

if ($PPSSPPCheckbox.Checked) {
    Install-Game -GameName "PPSSPP Emulator" -WingetId "PPSSPPTeam.PPSSPP" -SubFolder "Emulators\PSP\PPSSPP"
}

if ($RedreamCheckbox.Checked) {
    Install-Game -GameName "Redream Emulator" -WingetId "redream.redream" -SubFolder "Emulators\Dreamcast\Redream"
}

if ($VisualBoyAdvanceCheckbox.Checked) {
    Install-Game -GameName "VisualBoyAdvance-M" -WingetId "VisualBoyAdvance-M.VisualBoyAdvance-M" -SubFolder "Emulators\GBA\VisualBoyAdvance"
}

if ($XemuCheckbox.Checked) {
    Install-Game -GameName "Xemu Emulator" -WingetId "xemu-project.xemu" -SubFolder "Emulators\XBox\Xemu"
}

if ($XeniaCheckbox.Checked) {
    Install-Game -GameName "Xenia Emulator" -WingetId "xenia-project.xenia" -SubFolder "Emulators\XBox360\Xenia"
}

if ($RetroArchCheckbox.Checked) {
    Install-Game -GameName "RetroArch" -WingetId "Libretro.RetroArch" -SubFolder "Emulators\RetroArch"
}

# Symlink
if ($RobloxCheckbox.Checked) {
    $gamesDrive = Get-GamesDrive -EligibleDriveLetters ((Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 3 }).DeviceID | ForEach-Object { $_.TrimEnd(':') })
    $targetFolder = "${gamesDrive}:\Roblox"
    $defaultFolder = "C:\Program Files (x86)\Roblox"
    $installerPath = "$env:TEMP\RobloxPlayerInstaller.exe"

    Write-Host "Downloading Roblox installer" -ForegroundColor Cyan
    Invoke-WebRequest -Uri "https://setup.rbxcdn.com/RobloxPlayerInstaller.exe" -OutFile $installerPath

    Write-Host "Running Roblox installer" -ForegroundColor Cyan
    $proc = Start-Process -FilePath $installerPath -PassThru

    # Wait for installer to exit (so it finishes writing files)
    Write-Host "Waiting for installer to finish" -ForegroundColor Yellow
    $proc.WaitForExit()

    # Wait until Roblox auto-launches (a sign install is complete)
    Write-Host "Waiting for Roblox client to auto-launch" -ForegroundColor Yellow
    while (-not (Get-Process "RobloxPlayerBeta" -ErrorAction SilentlyContinue)) {
        Start-Sleep -Seconds 2
    }

    # Kill auto-launched client so script can continue
    Write-Host "Closing Roblox client" -ForegroundColor Yellow
    Get-Process "RobloxPlayerBeta" -ErrorAction SilentlyContinue | Stop-Process -Force

    # Move installation to chosen drive
    Write-Host "Moving Roblox to $targetFolder" -ForegroundColor Cyan
    if (Test-Path $targetFolder) { Remove-Item $targetFolder -Recurse -Force }
    Move-Item $defaultFolder $targetFolder -Force

    # Create symlink back at C:\
    cmd /c mklink /D "$defaultFolder" "$targetFolder" | Out-Null

    Write-Host "[DONE] Roblox installation completed on $gamesDrive" -ForegroundColor Green
}

if($RockstarCheckbox.Checked) {  
	write-Host "Installing Rockstar Launcher" -ForegroundColor Cyan 
	$urlRockstar = "https://gamedownloads.rockstargames.com/public/installer/Rockstar-Games-Launcher.exe"
	$destRockstar = "$env:TEMP\Rockstar.exe"
	Invoke-WebRequest -Uri $urlRockstar -OutFile $destRockstar -verbose
	start-process $destRockstar -verbose -wait
	write-Host "[DONE] Installing Rockstar Launcher completed"`n -ForegroundColor Green 
	}	

if($MAMECheckbox.Checked) {  
	write-Host "Installing MAME" -ForegroundColor Cyan 
	$urlMAME = "https://github.com/mamedev/mame/releases/download/mame0261/mame0261b_64bit.exe"
	$destMAME = "$env:TEMP\MAME.exe"
	Invoke-WebRequest -Uri $urlMAME -OutFile $destMAME -verbose
	start-process $destMAME -verbose -wait
	write-Host "[DONE] Installing MAME completed"`n -ForegroundColor Green 
	}

if($BakkesModCheckbox.Checked) {  
	write-Host "Installing BakkesMod" -ForegroundColor Cyan 
	$urlBakkesMod = "https://github.com/bakkesmodorg/BakkesModInjectorCpp/releases/latest/download/BakkesModSetup.zip"
	$destBakkesMod = "$env:TEMP\BakkesMod.zip"
	Invoke-WebRequest -Uri $urlBakkesMod -OutFile $destBakkesMod -verbose
	Expand-Archive $destBakkesMod -DestinationPath "$env:TEMP\BakkesMod" -Force 
	start-process "$env:Temp\BakkesMod\BakkesModSetup.exe" -verb runas -verbose -wait
	write-Host "[DONE] Installing BakkesMod completed"`n -ForegroundColor Green 
	}

if($FiveMCheckbox.Checked) { 
	write-Host "Installing FiveM" -ForegroundColor Cyan 
	$urlFiveM = "https://runtime.fivem.net/client/FiveM.exe"
	$destFiveM = "$env:TEMP\FiveM.exe" 
	Invoke-WebRequest -Uri $urlFiveM -OutFile $destFiveM -verbose
	start-process $destFiveM -verb runas -verbose -wait
	write-Host "[DONE] Installing FiveM completed"`n -ForegroundColor Green 
	}
	
if($SuyuCheckbox.Checked) {       
	write-Host "Installing Suyu" -ForegroundColor Cyan   
	$urlSuyu = "https://git.suyu.dev/suyu/suyu/releases/download/v0.0.3/Suyu-Windows_x86_64.tar.xz"
	$destSuyu = "$desktopPath\Suyu.tar.xz"
	Invoke-WebRequest -Uri $urlSuyu -OutFile $destSuyu -verbose     	
    write-Host "[DONE] Installing Suyu completed"`n -ForegroundColor Green   
	}

if($CryEngineCheckbox.Checked) { 
	write-Host "Installing CryEngine" -ForegroundColor Cyan 
	$urlCryEngine = "https://content.cryengine.com/cryengine-launcher/CRYENGINE_Launcher.exe"
	$destCryEngine = "$env:TEMP\CryEngine.exe" 
	Invoke-WebRequest -Uri $urlCryEngine -OutFile $destCryEngine -verbose
	start-process $destCryEngine -verb runas -verbose -wait
	write-Host "[DONE] Installing CryEngine completed"`n -ForegroundColor Green 
	}
	
if ($CheatEngineCheckbox.Checked) {
    Write-Host "Opening Cheat Engine download page" -ForegroundColor Cyan
    
    Start-Process "https://www.cheatengine.org/downloads.php"

    Write-Host "Please download and install Cheat Engine manually from the opened page." -ForegroundColor Yellow
    Write-Host "Press Enter once you're done to continue..."
    [void][System.Console]::ReadLine()

    Write-Host "[DONE] Installing Cheat Engine complete`n" -ForegroundColor Green
}

if($RyzenMasterCheckbox.Checked) {  
	write-Host "Installing Ryzen Master" -ForegroundColor Cyan 
	$urlRyzen = "https://download.amd.com/Desktop/amd-ryzen-master.exe"
	$destRyzen = "$env:TEMP\RyzenMaster.exe" 
	Invoke-WebRequest -Uri $urlRyzen -OutFile $destRyzen -verbose
	start-process $destRyzen /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Ryzen Master completed"`n -ForegroundColor Green 
	}

if($HPSupportCheckbox.Checked) {  
	write-Host "Installing HP Support Assistant" -ForegroundColor Cyan 
	$urlHPSA = "https://ftp.hp.com/pub/softpaq/sp114001-114500/sp114036.exe"
	$destHPSA = "$env:TEMP\HPSA.exe" 
	Invoke-WebRequest -Uri $urlHPSA -OutFile $destHPSA -verbose
	start-process $destHPSA /s -verb runas -verbose -wait
	write-Host "[DONE] Installing HP Support Assistant completed"`n -ForegroundColor Green 
	}

if($DellSupportCheckbox.Checked) {  
	write-Host "Installing Dell SupportAssist" -ForegroundColor Cyan 
	$urlDellSA = "https://downloads.dell.com/serviceability/catalog/SupportAssistInstaller.exe"
	$destDellSA = "$env:TEMP\DellSA.exe" 
	Invoke-WebRequest -Uri $urlDellSA -OutFile $destDellSA -verbose
	start-process $destDellSA /s -verb runas -verbose -wait
	write-Host "[DONE] Installing Dell SupportAssist completed"`n -ForegroundColor Green 
	}

if($RazerSynapseCheckbox.Checked) {  
	write-Host "Installing Razer Synapse" -ForegroundColor Cyan 
	$urlRazerSynapse = "https://rzr.to/synapse-pc-download"
	$destRazerSynapse = "$env:TEMP\RazerSynapse.exe" 
	Invoke-WebRequest -Uri $urlRazerSynapse -OutFile $destRazerSynapse -verbose
	start-process $destRazerSynapse -verb runas -verbose -wait
	write-Host "[DONE] Installing Razer Synapse completed"`n -ForegroundColor Green 
	}

if($AMDSoftwareCheckbox.Checked) {
	write-Host "Installing AMD Software" -ForegroundColor Cyan 
	$urlAMDSoftware = "https://www.mediafire.com/file/iw6t5pi0ws5r5me/amd-software-adrenalin-edition-22.4.1-win10-win11-april5-VideoCardz.com.exe"
	$destAMDSoftware = "$env:TEMP\AMDSoftware.exe" 
	Invoke-WebRequest -Uri $urlAMDSoftware -OutFile $destAMDSoftware -verbose
	start-process $destAMDSoftware -verb runas -verbose -wait
	write-Host "[DONE] Installing AMD Software completed"`n -ForegroundColor Green 
	}

if($BitTorrentCheckbox.Checked) {
	write-Host "Installing BitTorrent" -ForegroundColor Cyan 
	$urlBitTorrent = "https://download-new.utorrent.com/endpoint/bittorrent/os/windows/track/stable/"
	$destBitTorrent = "$env:TEMP\BitTorrent.exe" 
	Invoke-WebRequest -Uri $urlBitTorrent -OutFile $destBitTorrent -verbose
	start-process $destBitTorrent -verb runas -verbose -wait
	write-Host "[DONE] Installing BitTorrent completed"`n -ForegroundColor Green 
	}

if($uTorrentCheckbox.Checked) {
	write-Host "Installing uTorrent" -ForegroundColor Cyan 
	$urluTorrent = "https://download-hr.utorrent.com/track/stable/endpoint/utorrent/os/windows"
	$destuTorrent = "$env:TEMP\uTorrent.exe" 
	Invoke-WebRequest -Uri $urluTorrent -OutFile $destuTorrent -verbose
	start-process $destuTorrent -verb runas -verbose -wait
	write-Host "[DONE] Installing uTorrent completed"`n -ForegroundColor Green 
	}

if($StellarCheckbox.Checked) {  
	write-Host "Installing Stellar Data Recovery" -ForegroundColor Cyan 
	$urlStellar = "https://cloud.stellarinfo.com/StellarDataRecovery-H.exe"
	$destStellar = "$env:TEMP\Stellar.exe"
	Invoke-WebRequest -Uri $urlStellar -OutFile $destStellar -verbose
	start-process $destStellar -verb runas -verbose -wait
	write-Host "[DONE] Installing Stellar Data Recovery completed"`n -ForegroundColor Green 
	}

if($CaptainNemoCheckbox.Checked) {  
	write-Host "Installing Captain Nemo Pro" -ForegroundColor Cyan 
	$urlCaptainNemo = "https://dl.dropboxusercontent.com/s/5i93kadp5p3z0gr/nemopro.zip"
	$destCaptainNemo = "$env:TEMP\CaptainNemo.zip"
	Invoke-WebRequest -Uri $urlCaptainNemo -OutFile $destCaptainNemo -verbose
	Expand-Archive $destCaptainNemo -DestinationPath "$env:TEMP\CaptainNemo" -Force
	start-process "$env:Temp\CaptainNemo\CaptainNemo.exe" -verbose -wait
	write-Host "[DONE] Installing Captain Nemo Pro completed"`n -ForegroundColor Green 
	}

if($CheckDiskGUICheckbox.Checked) {  
	write-Host "Installing CheckDiskGUI" -ForegroundColor Cyan 
	$urlCheckDiskGUI = "https://www.filecroco.com/download-file/download-checkdiskgui/117/108/"
	$destCheckDiskGUI = "$desktopPath\CheckDiskGUI.exe"
	Invoke-WebRequest -Uri $urlCheckDiskGUI -OutFile $destCheckDiskGUI -verbose
	write-Host "[DONE] Installing CheckDiskGUI completed"`n -ForegroundColor Green 
	}

if($ESETSysinspectorCheckbox.Checked) {  
	write-Host "Installing ESETSysinspector" -ForegroundColor Cyan 
	$urlESETSysinspector = "https://download.eset.com/com/eset/tools/diagnosis/sysinspector/latest/sysinspector_nt64_enu.exe"
	$destESETSysinspector = "$desktopPath\ESETSysinspector.exe"
	Invoke-WebRequest -Uri $urlESETSysinspector -OutFile $destESETSysinspector -verbose
	write-Host "[DONE] Installing ESETSysinspector completed"`n -ForegroundColor Green 
	}

if($BlenderBenchmarkCheckbox.Checked) {  
	write-Host "Installing Blender Benchmark" -ForegroundColor Cyan 
	$urlBlenderBenchmark = "https://download.blender.org/release/BlenderBenchmark2.0/launcher/benchmark-launcher-3.1.0-windows.zip"
	$destBlenderBenchmark = "$env:TEMP\BlenderBenchmark.zip"
	$extractedPath = "$env:TEMP\BlenderBenchmark"
	Invoke-WebRequest -Uri $urlBlenderBenchmark -OutFile $destBlenderBenchmark -verbose
	Expand-Archive $destBlenderBenchmark -DestinationPath $extractedPath -Force
	$exePath = Join-Path -Path $extractedPath -ChildPath "benchmark-launcher.exe"
	Move-Item -Path $exePath -Destination $desktopPath -Force
	write-Host "[DONE] Installing Blender Benchmark completed"`n -ForegroundColor Green
	}

if($CipherShedCheckbox.Checked) {  
	write-Host "Installing CipherShed" -ForegroundColor Cyan 
	$urlCipherShed = "https://github.com/CipherShed/CipherShedBuilds/raw/v0.7.4.0-20151231/builds/be4dc698ffdc8d4414dbde838c2ddc7143c9dac2/pyeron%2Cjason/1451581628/src/Release/Setup%20Files/CipherShed-Setup-0.7.4.0.exe"
	$destCipherShed = "$desktopPath\CipherShed.exe"
	Invoke-WebRequest -Uri $urlCipherShed -OutFile $destCipherShed -verbose
	write-Host "[DONE] Installing CipherShed completed"`n -ForegroundColor Green 
	}

if($ESETScannerCheckbox.Checked) {  
	write-Host "Installing ESETScanner" -ForegroundColor Cyan 
	$urlESETScanner = "https://download.eset.com/com/eset/tools/online_scanner/latest/esetonlinescanner.exe"
	$destESETScanner = "$desktopPath\ESETScanner.exe"
	Invoke-WebRequest -Uri $urlESETScanner -OutFile $destESETScanner -verbose
	write-Host "[DONE] Installing ESETScanner completed"`n -ForegroundColor Green 
	}

if($EmergencyKitCheckbox.Checked) {  
	write-Host "Installing Emsisoft EmergencyKit" -ForegroundColor Cyan 
	$urlEmergencyKit = "https://dl.emsisoft.com/EmsisoftEmergencyKit.exe"
	$destEmergencyKit = "$desktopPath\EmergencyKit.exe"
	Invoke-WebRequest -Uri $urlEmergencyKit -OutFile $destEmergencyKit -verbose
	write-Host "[DONE] Installing Emsisoft EmergencyKit completed"`n -ForegroundColor Green 
	}

if($HitmanProCheckbox.Checked) {  
	write-Host "Installing HitmanPro" -ForegroundColor Cyan 
	$urlHitmanPro = "https://download.sophos.com/endpoint/clients/HitmanPro_x64.exe"
	$destHitmanPro = "$desktopPath\HitmanPro.exe"
	Invoke-WebRequest -Uri $urlHitmanPro -OutFile $destHitmanPro -verbose
	write-Host "[DONE] Installing HitmanPro completed"`n -ForegroundColor Green 
	}

if($SophosSCCheckbox.Checked) {  
	write-Host "Installing Sophos Scan & Clean" -ForegroundColor Cyan 
	$urlSophosSC = "https://download.sophos.com/tools/SophosScanAndClean_x64.exe"
	$destSophosSC = "$desktopPath\SophosSC.exe"
	Invoke-WebRequest -Uri $urlSophosSC -OutFile $destSophosSC -verbose
	write-Host "[DONE] Installing Sophos Scan & Clean completed"`n -ForegroundColor Green 
	}

if($NovabenchCheckbox.Checked) {  
	write-Host "Installing Novebench" -ForegroundColor Cyan 
	$urlNovabench = "https://novabench.com/files/novabench.msi"
	$destNovabench = "$env:TEMP\Novabench.msi"
	Invoke-WebRequest -Uri $urlNovabench -OutFile $destNovabench -verbose
	start-process msiexec -ArgumentList "/i $env:Temp\Novabench.msi /qn" -verbose -wait
	write-Host "[DONE] Installing Novabench completed"`n -ForegroundColor Green 
	}

if($IntelDiagCheckbox.Checked) {
	write-Host "Installing Intel Processor Diagnostic Tool" -ForegroundColor Cyan 
	$urlIntelDiag = "https://downloadmirror.intel.com/19792/IPDT_Installer_4.1.9.41_64bit.msi"
	$destIntelDiag = "$env:TEMP\IntelDiag.msi"
	Invoke-WebRequest -Uri $urlIntelDiag -OutFile $destIntelDiag -verbose
	start-process msiexec -ArgumentList "/i $env:Temp\IntelDiag.msi /qn" -verbose -wait
	write-Host "[DONE] Installing Intel Processor Diagnostic Tool completed"`n -ForegroundColor Green 
	}

if($UserBenchmarkCheckbox.Checked) {  
	write-Host "Installing UserBenchmark" -ForegroundColor Cyan 
	$urlUserBenchmark = "https://www.userbenchmark.com/resources/download/UserBenchmarkInstaller.exe"
	$destUserBenchmark = "$env:TEMP\UserBenchmark.exe"
	Invoke-WebRequest -Uri $urlUserBenchmark -OutFile $destUserBenchmark -verbose
	start-process $destUserBenchmark  -verb runas -verbose -wait
	write-Host "[DONE] Installing UserBenchmark completed"`n -ForegroundColor Green 
	}

if($DPCLatCheckerCheckbox.Checked) {
	Write-Host "Downloading DPCLatChecker" -ForegroundColor Cyan 
	$urlDPCLatChecker = "https://www.wagnardsoft.com/dpclatency/dpclatency%20v1.0.0.7.exe"
	$destDPCLatChecker = "$env:TEMP\DPCLatChecker.exe"
	Invoke-WebRequest -Uri $urlDPCLatChecker -OutFile $destDPCLatChecker -Verbose
	start-process $destDPCLatChecker -verb runas -verbose -wait
	Write-Host "[DONE] DPCLatChecker completed"`n -ForegroundColor Green 
	}
	
if($PandaCheckbox.Checked) {
	Write-Host "Downloading Panda Antivirus" -ForegroundColor Cyan 
	$urlPanda = "https://repository.pandasecurity.com/Panda/FREEAV/193309/PANDAFREEAV.exe"
	$destPanda = "$env:TEMP\Panda.exe"
	Invoke-WebRequest -Uri $urlPanda -OutFile $destPanda -Verbose
	start-process $destPanda -verb runas -verbose -wait
	Write-Host "[DONE] Installing Panda Antivirus completed"`n -ForegroundColor Green 
	}

if($WinMemoryDiagCheckbox.Checked) {
	write-Host "Opening Windows Memory Diagnostic Tool" -ForegroundColor Cyan
	write-Host "CHOOSE Check for problems the next time I start my computer" -ForegroundColor Cyan
	Start-Process -FilePath mdsched
	$processWinMemDiag = Get-Process | Where-Object { $_.ProcessName -eq "MdSched" }
	while ($processWinMemDiag -ne $null) {
    		Start-Sleep -Seconds 5  # Wait for 5 seconds
    		$processWinMemDiag = Get-Process | Where-Object { $_.ProcessName -eq "MdSched" }
		}
	write-Host "[DONE] Closed Windows Memory Diagnostic Tool completed"`n -ForegroundColor Green
	}

if($TTRGBPlusCheckbox.Checked) {  
	Write-Host "Downloading TT RGB Plus" -ForegroundColor Cyan
	$urlTTRGBPlus = "https://bit.ly/TTRGBPlusV215"
	$destTTRGBPlus = "$env:TEMP\TTRGBPlus.zip"
	Invoke-WebRequest -Uri $urlTTRGBPlus -OutFile $destTTRGBPlus -Verbose
	Expand-Archive -Path $destTTRGBPlus -DestinationPath $desktopPath/TTRGBPlus -Force
	Write-Host "[DONE] Downloading TT RGB Plus completed`n" -ForegroundColor Green
	}

if($ePSXeCheckbox.Checked) {  
	write-Host "Installing ePSXe" -ForegroundColor Cyan 
	$urlePSXe = "http://www.epsxe.com/files/ePSXe205.zip"
	$destePSXe = "$env:TEMP\ePSXe.zip"
	Invoke-WebRequest -Uri $urlePSXe -OutFile $destePSXe -verbose
	Expand-Archive $destePSXe -DestinationPath "$desktopPath\ePSXe" -Force 
	write-Host "[DONE] Installing ePSXe completed"`n -ForegroundColor Green 
	}

if($HiganCheckbox.Checked) {  
	write-Host "Installing Higan" -ForegroundColor Cyan 
	$urlHigan = "https://github.com/higan-emu/higan/releases/download/v110/higan-v110-windows-x86_64.zip"
	$destHigan = "$env:TEMP\Higan.zip"
	Invoke-WebRequest -Uri $urlHigan -OutFile $destHigan -verbose
	Expand-Archive $destHigan -DestinationPath "$desktopPath\Higan" -Force 
	write-Host "[DONE] Installing Higan completed"`n -ForegroundColor Green 
	}

if($KegaFusionCheckbox.Checked) {  
	write-Host "Installing Kega Fusion" -ForegroundColor Cyan 
	$urlKegaFusion = "https://dl.emulator-zone.com/download.php/emulators/genesis/fusion/Fusion364.zip"
	$destKegaFusion = "$env:TEMP\KegaFusion.zip"
	Invoke-WebRequest -Uri $urlKegaFusion -OutFile $destKegaFusion -verbose
	Expand-Archive $destKegaFusion -DestinationPath "$desktopPath\Kega Fusion" -Force 
	write-Host "[DONE] Installing Kega Fusion completed"`n -ForegroundColor Green 
	}

if($NestopiaCheckbox.Checked) {  
	write-Host "Installing Nestopia" -ForegroundColor Cyan 
	$urlNestopia = "https://dl.emulator-zone.com/download.php/emulators/nes/nestopia/nestopia_1.52.0-win32.zip"
	$destNestopia = "$env:TEMP\Nestopia.zip"
	Invoke-WebRequest -Uri $urlNestopia -OutFile $destNestopia -verbose
	Expand-Archive $destNestopia -DestinationPath "$desktopPath\Nestopia" -Force 
	write-Host "[DONE] Installing Nestopia completed"`n -ForegroundColor Green 
	}
	
if($CitraCheckbox.Checked) { 
	write-Host "Installing Citra" -ForegroundColor Cyan  
	$urlCitra = "https://github.com/PabloMK7/citra/releases/download/r8433057/citra-windows-msys2-20240307-8433057.zip"
	$destCitra = "$env:TEMP\Citra.zip"
	Invoke-WebRequest -Uri $urlCitra -OutFile $destCitra -verbose
	Expand-Archive $destCitra -DestinationPath "$desktopPath\Citra" -Force
   	write-Host "[DONE] Installing Citra completed"`n -ForegroundColor Green 	
	}

if($RPCS3Checkbox.Checked) {  
	write-Host "Installing RPCS3" -ForegroundColor Cyan 
	$urlRPCS3 = "https://github.com/RPCS3/rpcs3-binaries-win/releases/download/build-69238bfc23444cc12ba8a2a3c73e5ee7ffde3262/rpcs3-v0.0.29-15840-69238bfc_win64.7z"
	$destRPCS3 = "$desktopPath\RPCS3.7z"
	Invoke-WebRequest -Uri $urlRPCS3 -OutFile $destRPCS3 -verbose
	write-Host "[DONE] Installing RPCS3 completed"`n -ForegroundColor Green 
	}

if($YabauseCheckbox.Checked) {  
	write-Host "Installing Yabause" -ForegroundColor Cyan 
	$urlYabause = "https://download.tuxfamily.org/yabause/releases/travis-ci/yabause-latest-win64.zip"
	$destYabause = "$env:TEMP\Yabause.zip"
	Invoke-WebRequest -Uri $urlYabause -OutFile $destYabause -verbose
	Expand-Archive $destYabause -DestinationPath "$desktopPath\Yabause" -Force
	write-Host "[DONE] Installing Yabause completed"`n -ForegroundColor Green 
	}

if($OpenHardwareCheckbox.Checked) {  
	write-Host "Installing Open Hardware Monitor" -ForegroundColor Cyan 
	$urlOpenHardware = "https://openhardwaremonitor.org/files/openhardwaremonitor-v0.9.6.zip"
	$destOpenHardware = "$env:TEMP\OpenHardware.zip"
	Invoke-WebRequest -Uri $urlOpenHardware -OutFile $destOpenHardware -verbose
	Expand-Archive $destOpenHardware -DestinationPath "$desktopPath\Open Hardware" -Force 
	write-Host "[DONE] Installing Open Hardware Monitor completed"`n -ForegroundColor Green 
	}

if($Prime95Checkbox.Checked) {  
	write-Host "Installing Prime95" -ForegroundColor Cyan 
	$urlPrime95 = "https://www.mersenne.org/download/software/v30/30.8/p95v308b17.win64.zip"
	$destPrime95 = "$env:TEMP\Prime95.zip"
	Invoke-WebRequest -Uri $urlPrime95 -OutFile $destPrime95 -verbose
	Expand-Archive $destPrime95 -DestinationPath "$desktopPath\Prime95" -Force 
	write-Host "[DONE] Installing Prime95 completed"`n -ForegroundColor Green 
	}

if($MemTest86Checkbox.Checked) {  
	write-Host "Installing MemTest86" -ForegroundColor Cyan 
	$urlMemTest86 = "https://www.memtest86.com/downloads/memtest86-usb.zip"
	$destMemTest86 = "$env:TEMP\MemTest86.zip"
	Invoke-WebRequest -Uri $urlMemTest86 -OutFile $destMemTest86 -verbose
	Expand-Archive $destMemTest86 -DestinationPath "$desktopPath\MemTest86" -Force 
	write-Host "[DONE] Installing MemTest86 completed"`n -ForegroundColor Green 
	}

if($HDDScanCheckbox.Checked) {  
	write-Host "Installing HDDScan" -ForegroundColor Cyan 
	$urlHDDScan = "https://hddscan.com/download/HDDScan.zip"
	$destHDDScan = "$env:TEMP\HDDScan.zip"
	Invoke-WebRequest -Uri $urlHDDScan -OutFile $destHDDScan -verbose
	Expand-Archive $destHDDScan -DestinationPath "$desktopPath\HDDScan" -Force 
	write-Host "[DONE] Installing HDDScan completed"`n -ForegroundColor Green 
	}

if($BatteryInfoViewCheckbox.Checked) {
	Write-Host "Running BatteryInfoView" -ForegroundColor Cyan 
	$urlBattery = "https://www.nirsoft.net/utils/batteryinfoview.zip"
	$destBattery = "$env:TEMP\batteryinfoview.zip"
	Invoke-WebRequest -Uri $urlBattery -OutFile $destBattery -Verbose
	Expand-Archive $destBattery -DestinationPath "$desktopPath\Battery Info View" -Force
	Write-Host "[DONE] BatteryInfoView completed"`n -ForegroundColor Green 
	}

if($CmderCheckbox.Checked) {
	Write-Host "Running Cmder" -ForegroundColor Cyan 
	$urlCmder = "https://github.com/cmderdev/cmder/releases/download/v1.3.24/cmder.zip"
	$destCmder = "$env:TEMP\Cmder.zip"
	Invoke-WebRequest -Uri $urlCmder -OutFile $destCmder -Verbose
	Expand-Archive $destCmder -DestinationPath "$desktopPath\Cmder" -Force
	Write-Host "[DONE] Cmder completed"`n -ForegroundColor Green 
	}

if($BrutalDoomCheckbox.Checked) {
	Write-Host "Downloading BrutalDoom" -ForegroundColor Cyan 
	$urlBrutalDoom = "https://www.moddb.com/downloads/mirror/95667/121/70a7daaea4e3d956e2efc67743527461/?referer=https%3A%2F%2Fwww.moddb.com%2Fmods%2Fbrutal-doom%2Fdownloads"
	$destBrutalDoom = "$desktopPath\BrutalDoom.rar"
	Invoke-WebRequest -Uri $urlBrutalDoom -OutFile $destBrutalDoom -Verbose
	Write-Host "[DONE] BrutalDoom completed"`n -ForegroundColor Green 
	}

if($DoomInfiniteCheckbox.Checked) {
	Write-Host "Downloading Doom Infinite" -ForegroundColor Cyan 
	$urlDoomInfinite = "https://www.moddb.com/downloads/mirror/257498/124/315cf4faf064e2f024016a33fa0997b0"
	$destDoomInfinite = "$env:TEMP\DoomInfinite.zip"
	Invoke-WebRequest -Uri $urlDoomInfinite -OutFile $destDoomInfinite -Verbose
	Expand-Archive $destDoomInfinite -DestinationPath "$desktopPath\Doom Infinite" -Force
	Write-Host "[DONE] DoomInfinite completed"`n -ForegroundColor Green 
	}

if($LiveSplitCheckbox.Checked) {
	Write-Host "Downloading LiveSplit" -ForegroundColor Cyan 
	$urlLiveSplit = "https://github.com/LiveSplit/LiveSplit/releases/download/1.8.26/LiveSplit_1.8.26.zip"
	$destLiveSplit = "$env:TEMP\LiveSplit.zip"
	Invoke-WebRequest -Uri $urlLiveSplit -OutFile $destLiveSplit -Verbose
	Expand-Archive $destLiveSplit -DestinationPath "$desktopPath\LiveSplit" -Force
	Write-Host "[DONE] LiveSplit completed"`n -ForegroundColor Green 
	}

if($BlueScreenViewCheckbox.Checked) {
	Write-Host "Downloading BlueScreenView" -ForegroundColor Cyan 
	$urlBlueScreenView = "https://www.nirsoft.net/utils/bluescreenview.zip"
	$destBlueScreenView = "$env:TEMP\BlueScreenView.zip"
	Invoke-WebRequest -Uri $urlBlueScreenView -OutFile $destBlueScreenView -Verbose
	Expand-Archive $destBlueScreenView -DestinationPath "$desktopPath\Blue Screen View" -Force
	Write-Host "[DONE] BlueScreenView completed"`n -ForegroundColor Green 
	}

if($EqualizerAPOCheckbox.Checked) {
	Write-Host "Downloading EqualizerAPO" -ForegroundColor Cyan 
	$urlEqualizerAPO = "https://equalizerapo.com/EqualizerAPO64-1.2.1.zip"
	$destEqualizerAPO = "$env:TEMP\EqualizerAPO.zip"
	Invoke-WebRequest -Uri $urlEqualizerAPO -OutFile $destEqualizerAPO -Verbose
	Expand-Archive $destBlueScreenView -DestinationPath "$desktopPath\EqualizerAPO" -Force
	Write-Host "[DONE] EqualizerAPO completed"`n -ForegroundColor Green 
	}

if($Office365Checkbox.Checked) { 
	write-Host "Installing Office365" -ForegroundColor Cyan 
	winget install 9WZDNCRD29V9 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Office365 completed"`n -ForegroundColor Green 
	}

if($SuperF4Checkbox.Checked) {  
	write-Host "Installing SuperF4" -ForegroundColor Cyan 
	winget install StefanSundin.Superf4 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SuperF4 completed"`n -ForegroundColor Green 
	}

if($BlenderCheckbox.Checked) {  
	write-Host "Installing Blender" -ForegroundColor Cyan 
	winget install BlenderFoundation.Blender --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Blender completed"`n -ForegroundColor Green 
	}

if($HPSmartCheckbox.Checked) {  
	write-Host "Installing HP Smart" -ForegroundColor Cyan 
	winget install 9WZDNCRFHWLH --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing HP Smart completed"`n -ForegroundColor Green 
	}

if($CanonPrintCheckbox.Checked) {  
	write-Host "Installing Canon Print" -ForegroundColor Cyan 
	winget install 9PMK584KQVC2 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Canon Print completed"`n -ForegroundColor Green 
	}	

if($IntelSupportAssistantCheckbox.Checked) {  
	write-Host "Installing Intel Driver and Support Assistant" -ForegroundColor Cyan 
	winget install Intel.IntelDriverAndSupportAssistant --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Intel Driver and Support Assistant completed"`n -ForegroundColor Green 
	}

if($QuickenCheckbox.Checked) {  
	write-Host "Installing Quicken" -ForegroundColor Cyan 
	winget install Quicken.Quicken --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Quicken completed"`n -ForegroundColor Green 
	}

if($ChromeCheckbox.Checked) {  
	write-Host "Install Google Chrome" -ForegroundColor Cyan 
	winget install Google.Chrome --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Install Google Chrome completed"`n -ForegroundColor Green 
	}

if($FirefoxCheckbox.Checked) {
	write-Host "Install Firefox" -ForegroundColor Cyan 
	winget install Mozilla.Firefox --accept-source-agreements --accept-package-agreements 
	write-Host "[DONE] Install Firefox completed"`n -ForegroundColor Green 
	}

if($AcrobatReaderCheckbox.Checked) {  
	write-Host "Installing Acrobat Reader" -ForegroundColor Cyan 
	winget install Adobe.Acrobat.Reader.64-bit  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Acrobat Reader completed"`n -ForegroundColor Green 
	}

if($ZoomCheckbox.Checked) {  
	write-Host "Install Zoom" -ForegroundColor Cyan 
	winget install Zoom.Zoom --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Install Zoom completed"`n -ForegroundColor Green 
	}

if($iTunesCheckbox.Checked) { 
    write-Host "Installing iTunes" -ForegroundColor Cyan 
    winget install Apple.iTunes --accept-source-agreements --accept-package-agreements
    write-Host "[DONE] Installing iTunes completed"`n -ForegroundColor Green 
    $iTunesPath = "C:\Program Files\WindowsApps\AppleInc.iTunes_12132.3.2017.0_x64__nzyj5cx40ttqa\iTunes.exe"
    if (Test-Path $iTunesPath) {
        $shortcutiTunes = $shell.CreateShortcut("$desktopPath\iTunes.lnk")
        $shortcutiTunes.TargetPath = $iTunesPath
        $shortcutiTunes.IconLocation = $iTunesPath
        $shortcutiTunes.Save()
    }
}

if($DropboxCheckbox.Checked) {  
	write-Host "Installing Dropbox" -ForegroundColor Cyan 
	winget install Dropbox.Dropbox --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Dropbox completed"`n -ForegroundColor Green 
	}

if($VLCCheckbox.Checked) {  
	write-Host "Installing VLC Player" -ForegroundColor Cyan 
	winget install VideoLAN.VLC --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing VLC Player completed"`n -ForegroundColor Green 
	}

if($7ZipCheckbox.Checked) {
	write-Host "Installing 7-Zip" -ForegroundColor Cyan 
	winget install 7zip.7zip --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing 7-Zip completed"`n -ForegroundColor Green 
	}

if($WinRARCheckbox.Checked) {
	write-Host "Installing WinRAR" -ForegroundColor Cyan 
	winget install RARLab.WinRAR --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WinRAR completed"`n -ForegroundColor Green 
	}

if($SpotifyCheckbox.Checked) {
	write-Host "Installing Spotify" -ForegroundColor Cyan 
	winget install Spotify.Spotify --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Spotify completed"`n -ForegroundColor Green 
	}
	
if($WDKitfoxCheckbox.Checked) { 
	write-Host "Installing WD Kitfox" -ForegroundColor Cyan 
	winget install WesternDigital.Kitfox --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WD Kitfox completed"`n -ForegroundColor Green 
	}

if($GeekUninstallerCheckbox.Checked) { 
	write-Host "Installing Geek Uninstaller" -ForegroundColor Cyan 
	winget install GeekUninstaller.GeekUninstaller --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Geek Uninstaller completed"`n -ForegroundColor Green 
	}

if($SysinternalsSuiteCheckbox.Checked) { 
	write-Host "Installing Sysinternals Suite" -ForegroundColor Cyan 
	winget install Microsoft.Sysinternals.Suite --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Sysinternals Suite completed"`n -ForegroundColor Green 
	}

if($WhoCrashedCheckbox.Checked) { 
	write-Host "Installing WhoCrashed" -ForegroundColor Cyan 
	winget install Resplendence.WhoCrashed --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WhoCrashed completed"`n -ForegroundColor Green 
	}

if($WhySoSlowCheckbox.Checked) { 
	write-Host "Installing WhySoSlow" -ForegroundColor Cyan 
	winget install Resplendence.WhySoSlow --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WhySoSlow completed"`n -ForegroundColor Green 
	}

if($DiscordCheckbox.Checked) {
	write-Host "Installing Discord" -ForegroundColor Cyan 
	winget install Discord.Discord --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Discord completed"`n -ForegroundColor Green 
	}

if($SkypeCheckbox.Checked) {  
    write-Host "Installing Skype" -ForegroundColor Cyan 
    winget install 9WZDNCRFJ364 --accept-source-agreements --accept-package-agreements
    write-Host "[DONE] Installing Skype completed"`n -ForegroundColor Green 
    $skypePath = "C:\Program Files\WindowsApps\Microsoft.SkypeApp_15.127.3200.0_x64__kzf8qxf38zg5c\Skype\Skype.exe"
    if (Test-Path $skypePath) {
        $shortcutSkype = $shell.CreateShortcut("$desktopPath\Skype.lnk")
        $shortcutSkype.TargetPath = $skypePath
        $shortcutSkype.IconLocation = $skypePath
        $shortcutSkype.Save()
    }
}

if($TeamsCheckbox.Checked) {
	write-Host "Installing Teams" -ForegroundColor Cyan 
	winget install XP8BT8DW290MPQ --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Teams completed"`n -ForegroundColor Green 
	}

if($NotepadCheckbox.Checked) {
	write-Host "Installing Notepad++" -ForegroundColor Cyan 
	winget install Notepad++.Notepad++ --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Notepad++ completed"`n -ForegroundColor Green 
	}

if($PlexCheckbox.Checked) {
	write-Host "Installing Plex" -ForegroundColor Cyan 
	winget install Plex.PlexMediaServer --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Plex completed"`n -ForegroundColor Green 
	}

if($TeamViewerCheckbox.Checked) {
	write-Host "Installing TeamViewer" -ForegroundColor Cyan 
	winget install TeamViewer.TeamViewer --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing TeamViewer completed"`n -ForegroundColor Green 
	}

if($JavaCheckbox.Checked) {
	write-Host "Installing Java" -ForegroundColor Cyan 
	winget install Oracle.JavaRuntimeEnvironment --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Java completed"`n -ForegroundColor Green 
	}

if($VisualCheckbox.Checked) {
	write-Host "Installing C++ Redistributable X64" -ForegroundColor Cyan 
	winget install Microsoft.VC++2015-2022Redist-x64 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing C++ Redistributable X64 completed"`n -ForegroundColor Green 
	}

if($OBSCheckbox.Checked) {
	write-Host "Installing OBS Studio" -ForegroundColor Cyan 
	winget install OBSProject.OBSStudio --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing OBS Studio completed"`n -ForegroundColor Green 
	}

if($MalwareBytesCheckbox.Checked) {
	write-Host "Installing MalwareBytes" -ForegroundColor Cyan 
	winget install Malwarebytes.Malwarebytes --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing MalwareBytes completed"`n -ForegroundColor Green 
	}

if($CCleanerCheckbox.Checked) {
	write-Host "Installing CCleaner" -ForegroundColor Cyan 
	winget install Piriform.CCleaner --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing CCleaner completed"`n -ForegroundColor Green 
	}

if($BlueStacksCheckbox.Checked) {
	write-Host "Installing BlueStacks" -ForegroundColor Cyan 
	winget install BlueStack.BlueStacks --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing BlueStacks completed"`n -ForegroundColor Green 
	}

if($qBittorrentCheckbox.Checked) {
	write-Host "Installing qBittorrent" -ForegroundColor Cyan 
	winget install qBittorrent.qBittorrent --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing qBittorrent completed"`n -ForegroundColor Green 
	}

if($VirtualBoxCheckbox.Checked) {
	write-Host "Installing VirtualBox" -ForegroundColor Cyan 
	winget install Oracle.VirtualBox --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing VirtualBox completed"`n -ForegroundColor Green 
	}

if($GoogleDriveCheckbox.Checked) {
	write-Host "Installing GoogleDrive" -ForegroundColor Cyan 
	winget install Google.GoogleDrive --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GoogleDrive completed"`n -ForegroundColor Green 
	}

if($CitrixCheckbox.Checked) {
	write-Host "Installing Citrix" -ForegroundColor Cyan 
	winget install Citrix.Workspace --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Citrix completed"`n -ForegroundColor Green 
	}

if($LibreOfficeCheckbox.Checked) {
	write-Host "Installing Libre Office" -ForegroundColor Cyan 
	winget install TheDocumentFoundation.LibreOffice --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Libre Office completed"`n -ForegroundColor Green 
	}

if($OperaCheckbox.Checked) {
	write-Host "Installing Opera" -ForegroundColor Cyan 
	winget install Opera.Opera --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Libre Office completed"`n -ForegroundColor Green 
	}

if($BraveCheckbox.Checked) {
	write-Host "Installing Brave" -ForegroundColor Cyan 
	winget install XP8C9QZMS2PC1T --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Brave completed"`n -ForegroundColor Green 
	}

if($NetflixCheckbox.Checked) {  
	write-Host "Installing Netflix" -ForegroundColor Cyan 
	winget install 9WZDNCRFJ3TJ --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Netflix completed"`n -ForegroundColor Green 
	}

if($AmazonMusicCheckbox.Checked) {  
	write-Host "Installing Amazon Prime Music" -ForegroundColor Cyan 
	winget install Amazon.Music --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Amazon Prime Music completed"`n -ForegroundColor Green 
	}

if($NordVPNCheckbox.Checked) {  
	write-Host "Installing NordVPN" -ForegroundColor Cyan 
	winget install NordSecurity.NordVPN --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing NordVPN completed"`n -ForegroundColor Green
	}

if($ThunderbirdCheckbox.Checked) {
	write-Host "Installing Thunderbird" -ForegroundColor Cyan 
	winget install Mozilla.Thunderbird --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Thunderbird completed"`n -ForegroundColor Green 
	}

if($RevoCheckbox.Checked) {
	write-Host "Installing Revo Uninstaller" -ForegroundColor Cyan 
	winget install RevoUninstaller.RevoUninstaller --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Revo Uninstaller completed"`n -ForegroundColor Green
	}

if($VisualStudioCheckbox.Checked) {
	write-Host "Installing Visual Studio Code" -ForegroundColor Cyan 
	winget install Microsoft.VisualStudio.2022.Community --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Visual Studio Code completed"`n -ForegroundColor Green 
	}

if($EvernoteCheckbox.Checked) {
	write-Host "Installing Evernote" -ForegroundColor Cyan 
	winget install 9WZDNCRFJ3MB --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Evernote completed"`n -ForegroundColor Green 
	}

if($KodiCheckbox.Checked) {
	write-Host "Installing Kodi" -ForegroundColor Cyan
	winget install XBMCFoundation.Kodi --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Kodi completed"`n -ForegroundColor Green 
	}

if($WhatsAppCheckbox.Checked) {  
	write-Host "Installing WhatsApp" -ForegroundColor Cyan 
	winget install WhatsApp.WhatsApp --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WhatsApp completed"`n -ForegroundColor Green 
	}

if($EmulationStationCheckbox.Checked) {  
	write-Host "Installing Emulation Station" -ForegroundColor Cyan 
	winget install ES-DE.EmulationStation-DE --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Emulation Station completed"`n -ForegroundColor Green 
	}

if($PlayniteCheckbox.Checked) {  
	write-Host "Installing Playnite" -ForegroundColor Cyan 
	winget install Playnite.Playnite --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Playnite completed"`n -ForegroundColor Green 
	}

if($GoogleEarthProCheckbox.Checked) {
	write-Host "Installing Google Earth Pro" -ForegroundColor Cyan 
	winget install Google.EarthPro --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Google Earth Pro completed"`n -ForegroundColor Green 
	}

if($CPUZCheckbox.Checked) {
	write-Host "Installing CPU-Z" -ForegroundColor Cyan 
	winget install CPUID.CPU-Z --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing CPU-Z completed"`n -ForegroundColor Green 
	}

if($RufusCheckbox.Checked) {
	write-Host "Installing Rufus" -ForegroundColor Cyan 
	winget install Rufus.Rufus --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Rufus completed"`n -ForegroundColor Green 
	}

if($EverythingCheckbox.Checked) {
	write-Host "Installing Everything" -ForegroundColor Cyan 
	winget install voidtools.Everything --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Everything completed"`n -ForegroundColor Green 
	}

if($CrystalDiskInfoCheckbox.Checked) {
	write-Host "Installing CrystalDiskInfo" -ForegroundColor Cyan 
	winget install XP8K4RGX25G3GM --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing CrystalDiskInfo completed"`n -ForegroundColor Green 
	}

if($OCCTCheckbox.Checked) {
	write-Host "Installing OCCT" -ForegroundColor Cyan 
	winget install OCBase.OCCT.Personal --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing OCCT completed"`n -ForegroundColor Green 
	}

if($CoreTempCheckbox.Checked) {
	write-Host "Installing Core Temp" -ForegroundColor Cyan 
	winget install ALCPU.CoreTemp --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Core Temp completed"`n -ForegroundColor Green 
	}

if($GrammarlyAppCheckbox.Checked) {
	write-Host "Installing Grammarly" -ForegroundColor Cyan 
	winget install Grammarly.Grammarly --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Grammarly completed"`n -ForegroundColor Green 
	}
	
if($OperaGXCheckbox.Checked) {
	write-Host "Installing Opera GX" -ForegroundColor Cyan 
	winget install Opera.OperaGX --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Opera GX completed"`n -ForegroundColor Green 
	}
	
if($TorCheckbox.Checked) {
	write-Host "Installing Tor" -ForegroundColor Cyan 
	winget install TorProject.TorBrowser --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Tor completed"`n -ForegroundColor Green 
	}

if($DefenderCheckbox.Checked) {
	write-Host "Installing Microsoft Defender" -ForegroundColor Cyan 
	winget install 9P6PMZTM93LR --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Microsoft Defender completed"`n -ForegroundColor Green 
	}

if($WinDirStatCheckbox.Checked) {
	write-Host "Installing WinDirStat" -ForegroundColor Cyan 
	winget install WinDirStat.WinDirStat --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WinDirStat completed"`n -ForegroundColor Green 
	}

if($TreeSizeCheckbox.Checked) {
	write-Host "Installing TreeSize" -ForegroundColor Cyan 
	winget install JAMSoftware.TreeSize.Free --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing TreeSize completed"`n -ForegroundColor Green 
	}

if($NetCheckbox.Checked) {
	write-Host "Installing .NET 4.8" -ForegroundColor Cyan 
	winget install Microsoft.DotNet.Framework.DeveloperPack_4 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing .NET 4.8 completed"`n -ForegroundColor Green 
	}

if($NZXTCamCheckbox.Checked) {
	write-Host "Installing NZXT Cam" -ForegroundColor Cyan 
	winget install NZXT.CAM --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing NZXT Cam completed"`n -ForegroundColor Green 
	}

if($NordPassCheckbox.Checked) {
	write-Host "Installing NordPass" -ForegroundColor Cyan 
	winget install NordSecurity.NordPass --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing NordPass completed"`n -ForegroundColor Green 
	}

if($PaintNETCheckbox.Checked) {
	write-Host "Installing Paint.NET" -ForegroundColor Cyan 
	winget install dotPDNLLC.paintdotnet --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Paint.NET completed"`n -ForegroundColor Green 
	}

if($ShareXCheckbox.Checked) {
	write-Host "Installing ShareX" -ForegroundColor Cyan 
	winget install ShareX.ShareX --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing ShareX completed"`n -ForegroundColor Green 
	}

if($Paint3DCheckbox.Checked) {
	write-Host "Installing Paint3D" -ForegroundColor Cyan 
	winget install 9NBLGGH5FV99 --accept-source-agreements --accept-package-agreements 
	write-Host "[DONE] Installing Paint3D completed"`n -ForegroundColor Green 
	}

if($PowerToysCheckbox.Checked) {
	write-Host "Installing PowerToys" -ForegroundColor Cyan 
	winget install XP89DCGQ3K6VLD --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing PowerToys completed"`n -ForegroundColor Green 
	}

if($iCloudCheckbox.Checked) {
	write-Host "Installing iCloud" -ForegroundColor Cyan 
	winget install 9PKTQ5699M62 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing iCloud completed"`n -ForegroundColor Green 
	}

if($GPUZCheckbox.Checked) {
	write-Host "Installing GPU-Z" -ForegroundColor Cyan 
	winget install TechPowerUp.GPU-Z --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GPU-Z completed"`n -ForegroundColor Green 
	}

if($HWinfoCheckbox.Checked) {
	write-Host "Installing HWinfo" -ForegroundColor Cyan 
	winget install REALiX.HWiNFO --accept-source-agreements --accept-package-agreements
	try {
	stop-process -Name "HWiNFO64"
	}
	catch {
    		write-Host "An error occurred: $_" -ForegroundColor Red
		}
	write-Host "[DONE] Installing HWinfo completed"`n -ForegroundColor Green 
	}

if($HWMonitorCheckbox.Checked) {
	write-Host "Installing HWMonitor" -ForegroundColor Cyan 
	winget install CPUID.HWMonitor --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing HWMonitor completed"`n -ForegroundColor Green 
	}

if($AfterburnerCheckbox.Checked) {
	write-Host "Installing Afterburner" -ForegroundColor Cyan 
	winget install Guru3D.Afterburner --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Afterburner completed"`n -ForegroundColor Green 
	}

if($SpeccyCheckbox.Checked) {
	write-Host "Installing Speccy" -ForegroundColor Cyan
	winget install Piriform.Speccy --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Speccy completed"`n -ForegroundColor Green 
	}

if($FluxCheckbox.Checked) {
	write-Host "Installing F.lux" -ForegroundColor Cyan 
	winget install flux.flux --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing F.lux completed"`n -ForegroundColor Green 
	}

if($GimpCheckbox.Checked) {
	write-Host "Installing Gimp" -ForegroundColor Cyan 
	winget install GIMP.GIMP --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Gimp completed"`n -ForegroundColor Green 
	}

if($GreenshotCheckbox.Checked) {
	write-Host "Installing Greenshot" -ForegroundColor Cyan 
	winget install Greenshot.Greenshot --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Greenshot completed"`n -ForegroundColor Green 
	}

if($AudacityCheckbox.Checked) {
	write-Host "Installing Audacity" -ForegroundColor Cyan 
	winget install Audacity.Audacity --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Audacity completed"`n -ForegroundColor Green 
	}

if($FLStudioCheckbox.Checked) {
	write-Host "Installing FL Studio" -ForegroundColor Cyan 
	winget install ImageLine.FLStudio --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing FL Studio completed"`n -ForegroundColor Green 
	}

if($SlackCheckbox.Checked) {
	write-Host "Installing Slack" -ForegroundColor Cyan 
	winget install SlackTechnologies.Slack --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Slack completed"`n -ForegroundColor Green 
	}

if($TelegramCheckbox.Checked) {
	write-Host "Installing Telegram" -ForegroundColor Cyan 
	winget install Telegram.TelegramDesktop --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Telegram completed"`n -ForegroundColor Green 
	}

if($SublimeTextCheckbox.Checked) {
	write-Host "Installing Sublime Text" -ForegroundColor Cyan 
	winget install SublimeHQ.SublimeText.4 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Sublime Text completed"`n -ForegroundColor Green 
	}

if($ObsidianCheckbox.Checked) {
	write-Host "Installing Obsidian" -ForegroundColor Cyan 
	winget install Obsidian.Obsidian --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Obsidian completed"`n -ForegroundColor Green 
	}

if($CLionCheckbox.Checked) {
	write-Host "Installing CLion" -ForegroundColor Cyan 
	winget install JetBrains.CLion.EAP --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing CLion completed"`n -ForegroundColor Green 
	}

if($IntelliJCheckbox.Checked) {
	write-Host "Installing IntelliJ" -ForegroundColor Cyan 
	winget install JetBrains.IntelliJIDEA.Community.EAP  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing IntelliJ completed"`n -ForegroundColor Green 
	}

if($PyCharmCheckbox.Checked) {
	write-Host "Installing PyCharm" -ForegroundColor Cyan 
	winget install JetBrains.PyCharm.Community.EAP  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing PyCharm completed"`n -ForegroundColor Green 
	}

if($WebStormCheckbox.Checked) {
	write-Host "Installing WebStorm" -ForegroundColor Cyan 
	winget install JetBrains.WebStorm.EAP  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WebStorm completed"`n -ForegroundColor Green 
	}

if($WizTreeCheckbox.Checked) {
	write-Host "Installing WizTree" -ForegroundColor Cyan
	winget install AntibodySoftware.WizTree  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WizTree completed"`n -ForegroundColor Green 
	}

if($LastPassAppCheckbox.Checked) {
	write-Host "Installing LastPass" -ForegroundColor Cyan
	winget install -e --id LogMeIn.LastPass  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing LastPass completed"`n -ForegroundColor Green 
	}

if($GlaryCheckbox.Checked) {
	write-Host "Installing Glary Utilities" -ForegroundColor Cyan
	winget install Glarysoft.GlaryUtilities  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Glary Utilities completed"`n -ForegroundColor Green 
	}
	
if($LatencyMonCheckbox.Checked) {
	write-Host "Installing LatencyMon" -ForegroundColor Cyan
	winget install Resplendence.LatencyMon  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing LatencyMon completed"`n -ForegroundColor Green 
	}

if($RainmeterCheckbox.Checked) {
	write-Host "Installing Rainmeter" -ForegroundColor Cyan 
	winget install Rainmeter.Rainmeter  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Rainmeter completed"`n -ForegroundColor Green 
	}

if($OpenOfficeCheckbox.Checked) {
	write-Host "Installing OpenOffice" -ForegroundColor Cyan 
	winget install Apache.OpenOffice  --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing OpenOffice completed"`n -ForegroundColor Green 
	}

if($AIDA64Checkbox.Checked) {  
	write-Host "Installing AIDA64" -ForegroundColor Cyan 
	winget install FinalWire.AIDA64.Extreme --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AIDA64 completed"`n -ForegroundColor Green 
	}

if($CorsairiCueCheckbox.Checked) {
	write-Host "Installing Corsair iCue" -ForegroundColor Cyan 
	winget install Corsair.iCUE.4 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Corsair iCue completed"`n -ForegroundColor Green 
	}

if($LogitechGHubCheckbox.Checked) {
	write-Host "Installing Logitech G Hub" -ForegroundColor Cyan 
	winget install Logitech.GHUB --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Logitech G Hub completed"`n -ForegroundColor Green 
	}

if($OpenRGBCheckbox.Checked) {
	write-Host "Installing Open RGB" -ForegroundColor Cyan 
	winget install CalcProgrammer1.OpenRGB --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Open RGB completed"`n -ForegroundColor Green 
	}

if($RazerChromaCheckbox.Checked) {
	write-Host "Installing Razer Chroma" -ForegroundColor Cyan 
	winget install 9PG8DNKL06M6 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Razer Chroma completed"`n -ForegroundColor Green 
	}

if($AvastCheckbox.Checked) {
	write-Host "Installing Avast" -ForegroundColor Cyan 
	winget install XPDNZJFNCR1B07 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Avast completed"`n -ForegroundColor Green 
	}

if($AVGCheckbox.Checked) {
	write-Host "Installing AVG" -ForegroundColor Cyan 
	winget install XP8BX2DWV7TF50 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AVG completed"`n -ForegroundColor Green 
	}

if($AviraCheckbox.Checked) {
	write-Host "Installing Avira" -ForegroundColor Cyan 
	winget install XPFD23M0L795KD --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Avira completed"`n -ForegroundColor Green 
	}

if($BitdefenderCheckbox.Checked) {
	write-Host "Installing Bitdefender" -ForegroundColor Cyan 
	winget install Bitdefender.Bitdefender --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Bitdefender completed"`n -ForegroundColor Green 
	}

if($ESETNod32Checkbox.Checked) {
	write-Host "Installing ESETNod32" -ForegroundColor Cyan 
	winget install ESET.Nod32 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing ESETNod32 completed"`n -ForegroundColor Green 
	}

if($Norton360Checkbox.Checked) {
	write-Host "Installing Norton360" -ForegroundColor Cyan 
	winget install XPFNZKWN35KD6Z --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Norton360 completed"`n -ForegroundColor Green 
	}

if($ArmouryCrateCheckbox.Checked) {
	write-Host "Installing Asus Armoury Crate" -ForegroundColor Cyan 
	winget install Asus.ArmouryCrate --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Asus Armoury Crate completed"`n -ForegroundColor Green 
	}

if($ExodusCheckbox.Checked) {
	write-Host "Installing Exodus" -ForegroundColor Cyan 
	winget install ExodusMovement.Exodus --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Exodus completed"`n -ForegroundColor Green 
	}

if($RiderCheckbox.Checked) {
	write-Host "Installing Rider" -ForegroundColor Cyan 
	winget install JetBrains.Rider --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Rider completed"`n -ForegroundColor Green 
	}

if($EaseUSDataRecoveryCheckbox.Checked) {
	write-Host "Installing EaseUS Data Recovery" -ForegroundColor Cyan 
	winget install EaseUS.DataRecovery --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing EaseUS Data Recovery completed"`n -ForegroundColor Green 
	}

if($RecuvaCheckbox.Checked) {
	write-Host "Installing Recuva" -ForegroundColor Cyan 
	winget install Piriform.Recuva --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Recuva completed"`n -ForegroundColor Green 
	}

if($HeavenCheckbox.Checked) {
	write-Host "Installing Heaven" -ForegroundColor Cyan 
	winget install Unigine.HeavenBenchmark --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Heaven completed"`n -ForegroundColor Green 
	}

if($MSIKombustorCheckbox.Checked) {
	write-Host "Installing MSI Kombustor" -ForegroundColor Cyan 
	winget install MSI.Kombustor.4 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing MSI Kombustor completed"`n -ForegroundColor Green 
	}

if($AcronisCheckbox.Checked) {
	write-Host "Installing Acronis Cyber Protect Home Office" -ForegroundColor Cyan 
	winget install Acronis.CyberProtectHomeOffice --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Acronis Cyber Protect Home Office completed"`n -ForegroundColor Green 
	}

if($AOMEICheckbox.Checked) {
	write-Host "Installing AOMEI Partition Assistant" -ForegroundColor Cyan 
	winget install AOMEI.PartitionAssistant --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AOMEI Partition Assistant completed"`n -ForegroundColor Green 
	}

if($GSmartControlCheckbox.Checked) {
	write-Host "Installing GSmartControl" -ForegroundColor Cyan 
	winget install GSmartControl.GSmartControl --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GSmartControl completed"`n -ForegroundColor Green 
	}

if($HDTuneProCheckbox.Checked) {
	write-Host "Installing HD Tune Pro" -ForegroundColor Cyan 
	winget install EFDSoftware.HDTunePro --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing HD Tune Pro completed"`n -ForegroundColor Green 
	}

if($WifiAnalyzerCheckbox.Checked) {
	write-Host "Installing WifiAnalyzer" -ForegroundColor Cyan 
	winget install 9NBLGGH33N0N --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing WifiAnalyzer completed"`n -ForegroundColor Green 
	}

if($HeavyLoadCheckbox.Checked) {
	write-Host "Installing HeavyLoad" -ForegroundColor Cyan 
	winget install JAMSoftware.HeavyLoad --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing HeavyLoad completed"`n -ForegroundColor Green 
	}

if($CinebenchCheckbox.Checked) {
	write-Host "Installing Cinebench" -ForegroundColor Cyan 
	winget install 9PGZKJC81Q7J --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Cinebench completed"`n -ForegroundColor Green 
	}

if($CrystalDiskMarkCheckbox.Checked) {
	write-Host "Installing CrystalDiskMark" -ForegroundColor Cyan 
	winget install CrystalDewWorld.CrystalDiskMark --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing CrystalDiskMark completed"`n -ForegroundColor Green 
	}

if($GeekbenchCheckbox.Checked) {
	write-Host "Installing Geekbench" -ForegroundColor Cyan 
	winget install PrimateLabs.Geekbench.6 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Geekbench completed"`n -ForegroundColor Green 
	}

if($PerformanceTESTCheckbox.Checked) {
	write-Host "Installing PerformanceTEST" -ForegroundColor Cyan 
	winget install 9NX2VQG25JXJ --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing PerformanceTEST completed"`n -ForegroundColor Green 
	}

if($SuperpositionCheckbox.Checked) {
	write-Host "Installing Superposition Benchmark" -ForegroundColor Cyan 
	winget install Unigine.SuperpositionBenchmark --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Superposition Benchmark completed"`n -ForegroundColor Green 
	}

if($SignalRGBCheckbox.Checked) {
	write-Host "Installing SignalRGB" -ForegroundColor Cyan 
	winget install WhirlwindFX.SignalRgb --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SignalRGB completed"`n -ForegroundColor Green 
	}

if($DuolingoCheckbox.Checked) {
	write-Host "Installing Duolingo" -ForegroundColor Cyan 
	winget install 9WZDNCRCV5XN --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Duolingo completed"`n -ForegroundColor Green 
	}

if($HandbrakeCheckbox.Checked) {
	write-Host "Installing Handbrake" -ForegroundColor Cyan 
	winget install HandBrake.HandBrake --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Handbrake completed"`n -ForegroundColor Green 
	}

if($LightworksCheckbox.Checked) {
	write-Host "Installing Lightworks" -ForegroundColor Cyan 
	winget install LWKS.lightworks --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Lightworks completed"`n -ForegroundColor Green 
	}

if($Construct3Checkbox.Checked) {
	write-Host "Installing Construct 3" -ForegroundColor Cyan 
	winget install 9NBZ6CP2P37P --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Construct 3 completed"`n -ForegroundColor Green 
	}

if($GameMakerCheckbox.Checked) {
	write-Host "Installing GameMaker" -ForegroundColor Cyan 
	winget install YoYoGames.GameMaker.Studio.2 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GameMaker completed"`n -ForegroundColor Green 
	}

if($GodotCheckbox.Checked) {
	write-Host "Installing Godot" -ForegroundColor Cyan 
	winget install GodotEngine.GodotEngine --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Godot completed"`n -ForegroundColor Green 
	}

if($UnityCheckbox.Checked) {
	write-Host "Installing Unity" -ForegroundColor Cyan 
	winget install Unity.Unity.2022 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Unity completed"`n -ForegroundColor Green 
	}

if($AVGCheckbox.Checked) {
	write-Host "Installing AVG" -ForegroundColor Cyan 
	winget install XP8BX2DWV7TF50 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AVG completed"`n -ForegroundColor Green 
	}

if($AviraCheckbox.Checked) {
	write-Host "Installing Avira" -ForegroundColor Cyan 
	winget install XPFD23M0L795KD --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Avira completed"`n -ForegroundColor Green 
	}

if($BitdefenderCheckbox.Checked) {
	write-Host "Installing Bitdefender" -ForegroundColor Cyan 
	winget install Bitdefender.Bitdefender --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Bitdefender completed"`n -ForegroundColor Green 
	}

if($ESETNod32Checkbox.Checked) {
	write-Host "Installing ESETNod32" -ForegroundColor Cyan 
	winget install ESET.Nod32 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing ESETNod32 completed"`n -ForegroundColor Green 
	}

if($MalwareBytesCheckbox.Checked) {
	write-Host "Installing MalwareBytes" -ForegroundColor Cyan 
	winget install Malwarebytes.Malwarebytes --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing MalwareBytes completed"`n -ForegroundColor Green 
	}

if($AdwCleanerCheckbox.Checked) {
	write-Host "Installing AdwCleaner" -ForegroundColor Cyan 
	winget install Malwarebytes.AdwCleaner --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AdwCleaner completed"`n -ForegroundColor Green 
	}

if($OSArmorCheckbox.Checked) {
	write-Host "Installing OSArmor" -ForegroundColor Cyan 
	winget install NoVirusThanks.OSArmor.Personal --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing OSArmor completed"`n -ForegroundColor Green 
	}

if($Norton360Checkbox.Checked) {
	write-Host "Installing Norton360" -ForegroundColor Cyan 
	winget install XPFNZKWN35KD6Z --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Norton360 completed"`n -ForegroundColor Green 
	}

if($TotalAV.Checked) {
	write-Host "Installing TotalAV" -ForegroundColor Cyan 
	winget install XPDNTPM3BG8CV1 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing TotalAV completed"`n -ForegroundColor Green 
	}

if($WebrootCheckbox.Checked) {  
	write-Host "Installing Webroot" -ForegroundColor Cyan 
	winget install Webroot.SecureAnywhere --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Webroot completed"`n -ForegroundColor Green 
	}

if($AutorunsCheckbox.Checked) {  
	write-Host "Installing Autoruns" -ForegroundColor Cyan 
	winget install Microsoft.Sysinternals.Autoruns --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Autoruns completed"`n -ForegroundColor Green 
	}

if($ClickUpCheckbox.Checked) {  
	write-Host "Installing ClickUp" -ForegroundColor Cyan 
	winget install ClickUp.ClickUp --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing ClickUp completed"`n -ForegroundColor Green 
	}

if($KombustorCheckbox.Checked) {  
	write-Host "Installing Kombustor" -ForegroundColor Cyan 
	winget install MSI.Kombustor.4 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Kombustor completed"`n -ForegroundColor Green 
	}

if($HPDiagCheckbox.Checked) {  
	write-Host "Installing HP Diagnostics" -ForegroundColor Cyan 
	winget install 9P4PNDG7L782 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing HP Diagnostics completed"`n -ForegroundColor Green 
	}

if($Python3Checkbox.Checked) {  
	write-Host "Installing Python3" -ForegroundColor Cyan 
	winget install Python.Python.3.13 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Python3 completed"`n -ForegroundColor Green 
	}

if($JetBrainsToolboxCheckbox.Checked) {  
	write-Host "Installing JetBrainsToolbox" -ForegroundColor Cyan 
	winget install JetBrains.Toolbox --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing JetBrainsToolbox completed"`n -ForegroundColor Green 
	}

if($GoLandCheckbox.Checked) {  
	write-Host "Installing GoLand" -ForegroundColor Cyan 
	winget install JetBrains.GoLand --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GoLand completed"`n -ForegroundColor Green 
	}

if($RubyMineCheckbox.Checked) {  
	write-Host "Installing RubyMine" -ForegroundColor Cyan 
	winget install JetBrains.RubyMine --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing RubyMine completed"`n -ForegroundColor Green 
	}

if($PhpStormCheckbox.Checked) {  
	write-Host "Installing PhpStorm" -ForegroundColor Cyan 
	winget install JetBrains.PHPStorm --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing PhpStorm completed"`n -ForegroundColor Green 
	}

if($DataGripCheckbox.Checked) {  
	write-Host "Installing DataGrip" -ForegroundColor Cyan 
	winget install JetBrains.DataGrip --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing DataGrip completed"`n -ForegroundColor Green 
	}

if($DataSpellCheckbox.Checked) {  
	write-Host "Installing DataSpell" -ForegroundColor Cyan 
	winget install JetBrains.DataSpell --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing DataSpell completed"`n -ForegroundColor Green 
	}

if($HamachiCheckbox.Checked) {  
	write-Host "Installing Hamachi" -ForegroundColor Cyan 
	winget install LogMeIn.Hamachi --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Hamachi completed"`n -ForegroundColor Green 
	}

if($RazerCortexCheckbox.Checked) {  
	write-Host "Installing Razer Cortex" -ForegroundColor Cyan 
	winget install 9PK9W5QV2PKX --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Razer Cortex completed"`n -ForegroundColor Green 
	}

if($WiseGameBoosterCheckbox.Checked) {  
	write-Host "Installing Wise Game Booster" -ForegroundColor Cyan 
	winget install WiseCleaner.WiseGameBooster --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Wise Game Booster completed"`n -ForegroundColor Green 
	}

if($RubyCheckbox.Checked) {  
	write-Host "Installing Wise Game Booster" -ForegroundColor Cyan 
	winget install RubyInstallerTeam.Ruby.3.2 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Wise Game Booster completed"`n -ForegroundColor Green 
	}	

if($GarminCheckbox.Checked) {  
	write-Host "Installing Garmin Express" -ForegroundColor Cyan 
	winget install Garmin.Express --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Garmin Express completed"`n -ForegroundColor Green 
	}

if($HyperCheckbox.Checked) {
	write-Host "Installing Hyper" -ForegroundColor Cyan 
	winget install Vercel.Hyper --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Hyper completed"`n -ForegroundColor Green 
	}

if($PuTTYCheckbox.Checked) {
	write-Host "Installing PuTTY" -ForegroundColor Cyan 
	winget install PuTTY.PuTTY --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing PuTTY completed"`n -ForegroundColor Green 
	}

if($GitCheckbox.Checked) {
	write-Host "Installing Git" -ForegroundColor Cyan 
	winget install Git.Git --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Git completed"`n -ForegroundColor Green 
	}

if($GitLFSCheckbox.Checked) {
	write-Host "Installing Git LFS" -ForegroundColor Cyan 
	winget install GitHub.GitLFS --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Git LFS completed"`n -ForegroundColor Green 
	}

if($GitHubDesktopCheckbox.Checked) {
	write-Host "Installing GitHub Desktop" -ForegroundColor Cyan 
	winget install GitHub.GitHubDesktop --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GitHub Desktop completed"`n -ForegroundColor Green 
	}

if($DuckDuckGoCheckbox.Checked) {
	write-Host "Installing DuckDuckGo" -ForegroundColor Cyan 
	winget install DuckDuckGo.DesktopBrowser --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing DuckDuckGo completed"`n -ForegroundColor Green 
	}
	
if($MongoDBCheckbox.Checked) {
	write-Host "Installing MongoDB" -ForegroundColor Cyan 
	winget install MongoDB.Server --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing MongoDB completed"`n -ForegroundColor Green 
	}	
	
if($MySQLCheckbox.Checked) {
	write-Host "Installing MySQL" -ForegroundColor Cyan 
	winget install Oracle.MySQL --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing MySQL completed"`n -ForegroundColor Green 
	}	
	
if($PostgreSQLCheckbox.Checked) {
	write-Host "Installing PostgreSQL" -ForegroundColor Cyan 
	winget install PostgreSQL.PostgreSQL --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing PostgreSQL completed"`n -ForegroundColor Green 
	}

if($RedisCheckbox.Checked) {
	write-Host "Installing Redis Insite" -ForegroundColor Cyan 
	winget install XP8K1GHCB0F1R2 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Redis Insite completed"`n -ForegroundColor Green 
	}

if($AndroidStudioCheckbox.Checked) {
	write-Host "Installing Android Studio" -ForegroundColor Cyan 
	winget install Google.AndroidStudio.Beta --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Android Studio completed"`n -ForegroundColor Green 
	}

if($EclipseCheckbox.Checked) {
	write-Host "Installing Eclipse" -ForegroundColor Cyan 
	winget install EclipseAdoptium.Temurin.21.JDK --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Eclipse completed"`n -ForegroundColor Green 
	}

if($SwiftCheckbox.Checked) {
	write-Host "Installing Swift" -ForegroundColor Cyan 
	winget install Swift.Toolchain --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Swift completed"`n -ForegroundColor Green 
	}

if($NodejsCheckbox.Checked) {
	write-Host "Installing Node.js" -ForegroundColor Cyan 
	winget install OpenJS.NodeJS --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Node.js completed"`n -ForegroundColor Green 
	}

if($BurpSuiteCheckbox.Checked) {
	write-Host "Installing Burp Suite" -ForegroundColor Cyan 
	winget install PortSwigger.BurpSuite.Community --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Burp Suite completed"`n -ForegroundColor Green 
	}

if($JMeterCheckbox.Checked) {
	write-Host "Installing JMeter" -ForegroundColor Cyan 
	winget install JMeter DEVCOM.JMeter --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing JMeter completed"`n -ForegroundColor Green 
	}

if($ZapCheckbox.Checked) {
	write-Host "Installing Zap" -ForegroundColor Cyan 
	winget install Zap.Zap --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Zap completed"`n -ForegroundColor Green 
	}

if($PostmanCheckbox.Checked) {
	write-Host "Installing Postman" -ForegroundColor Cyan 
	winget install Postman.Postman --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Postman completed"`n -ForegroundColor Green 
	}
	
if($SoapUICheckbox.Checked) {
	write-Host "Installing SoapUI" -ForegroundColor Cyan 
	winget install SmartBear.SoapUI --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SoapUI completed"`n -ForegroundColor Green 
	}

if($SQLiteCheckbox.Checked) {
	write-Host "Installing SQLite" -ForegroundColor Cyan 
	winget install SQLite.SQLite --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SQLite completed"`n -ForegroundColor Green 
	}

if($SourcetreeCheckbox.Checked) {
	write-Host "Installing Sourcetree" -ForegroundColor Cyan 
	winget install Atlassian.Sourcetree --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Sourcetree completed"`n -ForegroundColor Green 
	}

if($TortoiseGitCheckbox.Checked) {
	write-Host "Installing TortoiseGit" -ForegroundColor Cyan 
	winget install TortoiseGit.TortoiseGit --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing TortoiseGit completed"`n -ForegroundColor Green 
	}

if($AnkiCheckbox.Checked) {
	write-Host "Installing Anki" -ForegroundColor Cyan 
	winget install Anki.Anki --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Anki completed"`n -ForegroundColor Green 
	}
	
if($MendeleyCheckbox.Checked) {
	write-Host "Installing Mendeley" -ForegroundColor Cyan 
	winget install Elsevier.MendeleyReferenceManager --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Mendeley completed"`n -ForegroundColor Green 
	}

if($GoCheckbox.Checked) {
	write-Host "Installing Go" -ForegroundColor Cyan 
	winget install GoLang.Go --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Go completed"`n -ForegroundColor Green 
	}

if($RustupCheckbox.Checked) {
	write-Host "Installing Rustup" -ForegroundColor Cyan 
	winget install Rustlang.Rustup --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Rustup completed"`n -ForegroundColor Green 
	}

if($RCheckbox.Checked) {
	write-Host "Installing R" -ForegroundColor Cyan 
	winget install RProject.R --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing R completed"`n -ForegroundColor Green 
	}

if($StrawberryPerlCheckbox.Checked) {
	write-Host "Installing StrawberryPerl" -ForegroundColor Cyan 
	winget install StrawberryPerl.StrawberryPerl --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing StrawberryPerl completed"`n -ForegroundColor Green 
	}
	
if($JavaJDKCheckbox.Checked) {
	write-Host "Installing Java SE Development Kit 22" -ForegroundColor Cyan 
	winget install Oracle.JDK.22 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Java SE Development Kit 22 completed"`n -ForegroundColor Green 
	}

if($CapCutCheckbox.Checked) {
	write-Host "Installing CapCut" -ForegroundColor Cyan 
	winget install ByteDance.CapCut --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing CapCut completed"`n -ForegroundColor Green 
	}

if($BatteryMonCheckbox.Checked) {
	write-Host "Installing BatteryMon" -ForegroundColor Cyan 
	winget install PassmarkSoftware.BatteryMon --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing BatteryMon completed"`n -ForegroundColor Green 
	}

if($WiresharkCheckbox.Checked) {
	write-Host "Installing Wireshark" -ForegroundColor Cyan 
	winget install WiresharkFoundation.Wireshark --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Wireshark completed"`n -ForegroundColor Green 
	}

if($DS4WindowsCheckbox.Checked) {
	write-Host "Installing DS4Windows" -ForegroundColor Cyan 
	winget install Ryochan7.DS4Windows --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing DS4Windows completed"`n -ForegroundColor Green 
	}

if($SpecialKCheckbox.Checked) {
	write-Host "Installing Special K" -ForegroundColor Cyan 
	winget install SpecialK.SpecialK --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Special K completed"`n -ForegroundColor Green 
	}

if($AntiMicroXCheckbox.Checked) {
	write-Host "Installing AntiMicroX" -ForegroundColor Cyan 
	winget install AntiMicroX.antimicrox --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AntiMicroX completed"`n -ForegroundColor Green 
	}

if($SamsungMagicianCheckbox.Checked) {
	write-Host "Installing SamsungMagician" -ForegroundColor Cyan 
	winget install XPDDT99J9GKB5C --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SamsungMagician completed"`n -ForegroundColor Green 
	}

if($SeagateSeaToolsCheckbox.Checked) {
	write-Host "Installing SeagateSeaTools" -ForegroundColor Cyan 
	winget install Seagate.SeaTools --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SeagateSeaTools completed"`n -ForegroundColor Green 
	}
	
if($VictoriaCheckbox.Checked) {
	write-Host "Installing Victoria" -ForegroundColor Cyan 
	winget install Victoria.Victoria --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Victoria completed"`n -ForegroundColor Green 
	}

if($EraserCheckbox.Checked) {
	write-Host "Installing Eraser" -ForegroundColor Cyan 
	winget install Eraser.Eraser --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Eraser completed"`n -ForegroundColor Green 
	}	

if($VeraCryptCheckbox.Checked) {
	write-Host "Installing VeraCrypt" -ForegroundColor Cyan 
	winget install IDRIX.VeraCrypt --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing VeraCrypt completed"`n -ForegroundColor Green 
	}	
	
if($GlassWireCheckbox.Checked) {
	write-Host "Installing GlassWire" -ForegroundColor Cyan 
	winget install GlassWire.GlassWire --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing GlassWire completed"`n -ForegroundColor Green 
	}	

if($SimpleWallCheckbox.Checked) {
	write-Host "Installing SimpleWall" -ForegroundColor Cyan 
	winget install Henry++.simplewall --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing SimpleWall completed"`n -ForegroundColor Green 
	}	

if($AntiBeaconCheckbox.Checked) {
	write-Host "Installing Spybot Anti-Beacon" -ForegroundColor Cyan 
	winget install SaferNetworking.SpybotAntiBeacon --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Spybot Anti-Beacon completed"`n -ForegroundColor Green 
	}		

if($OOShutUp10Checkbox.Checked) {
	write-Host "Installing O&OShutUp10++" -ForegroundColor Cyan 
	winget install OO-Software.ShutUp10 --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing O&OShutUp10++ completed"`n -ForegroundColor Green 
	}	

if($AdwCleanerCheckbox.Checked) {
	write-Host "Installing AdwCleaner" -ForegroundColor Cyan 
	winget install Malwarebytes.AdwCleaner --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing AdwCleaner completed"`n -ForegroundColor Green 
	}	

if($MalwarebytesCheckbox.Checked) {
	write-Host "Installing Malwarebytes" -ForegroundColor Cyan 
	winget install Malwarebytes.Malwarebytes --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Malwarebytes completed"`n -ForegroundColor Green 
	}	

if($OSArmorCheckbox.Checked) {
	write-Host "Installing OSArmor" -ForegroundColor Cyan 
	winget install NoVirusThanks.OSArmor.Personal --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing OSArmor completed"`n -ForegroundColor Green 
	}

if($DuplicatiCheckbox.Checked) {
	write-Host "Installing Duplicati" -ForegroundColor Cyan 
	winget install Duplicati.Duplicati --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Duplicati completed"`n -ForegroundColor Green 
	}

if($TodoBackupCheckbox.Checked) {
	write-Host "Installing TodoBackup" -ForegroundColor Cyan 
	winget install EaseUS.TodoBackup --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing TodoBackup completed"`n -ForegroundColor Green 
	}

if($IPVanishCheckbox.Checked) {
	write-Host "Installing IPVanish" -ForegroundColor Cyan 
	winget install IPVanish.IPVanish --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing IPVanish completed"`n -ForegroundColor Green 
	}

if($ProtonVPNCheckbox.Checked) {
	write-Host "Installing ProtonVPN" -ForegroundColor Cyan 
	winget install Proton.ProtonVPN --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing ProtonVPN completed"`n -ForegroundColor Green 
	}

if($SurfsharkCheckbox.Checked) {
	write-Host "Installing Surfshark" -ForegroundColor Cyan 
	winget install Surfshark.Surfshark --accept-source-agreements --accept-package-agreements
	write-Host "[DONE] Installing Surfshark completed"`n -ForegroundColor Green 
	}


# ==============================
# Extensions
# ==============================

# 1Password
if (${1PasswordCheckbox}.Checked) {
    Install-Extension "1Password"
}

# Bitwarden
if ($BitwardenCheckbox.Checked) {
    Install-Extension "Bitwarden"
}

# Dark Reader
if ($DarkReaderCheckbox.Checked) {
    Install-Extension "Dark Reader"
}

# Grammarly
if ($GrammarlyCheckbox.Checked) {
    Install-Extension "Grammarly"
}

# LastPass
if ($LastPassCheckbox.Checked) {
    Install-Extension "LastPass"
}

# Momentum
if ($MomentumCheckbox.Checked) {
    Install-Extension "Momentum"
}

# Privacy Badger
if ($PrivacyBadgerCheckbox.Checked) {
    Install-Extension "Privacy Badger"
}

# SponsorBlock
if ($SponsorBlockCheckbox.Checked) {
    Install-Extension "SponsorBlock"
}

# Todoist
if ($TodoistCheckbox.Checked) {
    Install-Extension "Todoist"
}

# uBlock Origin
if ($uBlockOriginCheckbox.Checked) {
    Install-Extension "uBlock Origin"
}

# ViolentMonkey
if ($ViolentMonkeyCheckbox.Checked) {
    Install-Extension "ViolentMonkey"
}

# YouTube Nonstop
if ($YouTubeNonstopCheckbox.Checked) {
    Install-Extension "YouTube Nonstop"
}


if($BloatwareCheckbox.Checked) {
	$AppsList = @(
	'ACGMediaPlayer',
	'ActiproSoftwareLLC',
	'AdobeSystemsIncorporated.AdobePhotoshopExpress',
	'Amazon.com.Amazon',
	'AmazonVideo.PrimeVideo',
	'Asphalt8Airborne',
	'AutodeskSketchBook',
	'C27EB4BA.DropboxOEM',
	'CaesarsSlotsFreeCasino',
	'Clipchamp.Clipchamp',
	'COOKINGFEVER',
	'CyberLinkMediaSuiteEssentials',
	'Disney',
	'DisneyMagicKingdoms',
	'Dolby',
	'DrawboardPDF',
	'Duolingo-LearnLanguagesforFree',
	'EclipseManager',
	'Facebook',
	'FarmVille2CountryEscape',
	'fitbit',
	'Flipboard',
	'HiddenCity',
	'HULULLC.HULUPLUS',
	'iHeartRadio',
	'Instagram',
	'king.com.BubbleWitch3Saga',
	'king.com.CandyCrushSaga',
	'king.com.CandyCrushSodaSaga',
	'Kodi',
	'LinkedInforWindows',
	'MarchofEmpires',
	'Microsoft.3DBuilder',
	'Microsoft.549981C3F5F10',
	'Microsoft.BingFinance',
	'Microsoft.BingFoodAndDrink',
	'Microsoft.BingHealthAndFitness',
	'Microsoft.BingNews',
	'Microsoft.BingSearch',
	'Microsoft.BingSports',
	'Microsoft.BingTranslator',
	'Microsoft.BingTravel',
	'Microsoft.BingWeather',
	'Microsoft.Copilot',
	'Microsoft.GamingApp',
	'Microsoft.GetHelp',
	'Microsoft.Getstarted',
	'Microsoft.Messaging',
	'Microsoft.Microsoft3DViewer',
	'Microsoft.MicrosoftJournal',
	'Microsoft.MicrosoftOfficeHub',
	'Microsoft.MicrosoftPowerBIForWindows',
	'Microsoft.MicrosoftSolitaireCollection',
	'Microsoft.MicrosoftStickyNotes',
	'Microsoft.MixedReality.Portal',
	'Microsoft.Music.Preview',
	'Microsoft.NetworkSpeedTest',
	'Microsoft.News',
	'Microsoft.Office.OneNote',
	'Microsoft.Office.Sway',
	'Microsoft.OneConnect',
	'Microsoft.OutlookForWindows',
	'Microsoft.People',
	'Microsoft.PowerAutomateDesktop',
	'Microsoft.Print3D',
	'Microsoft.RemoteDesktop',
	'Microsoft.ScreenSketch',
	'Microsoft.SkypeApp',
	'Microsoft.Todos',
	'Microsoft.Whiteboard',
	'Microsoft.Windows.DevHome',
	'Microsoft.WindowsAlarms',
	'Microsoft.WindowsCalculator',
	'Microsoft.WindowsCamera',
	'Microsoft.windowscommunicationsapps',
	'Microsoft.WindowsFeedbackHub',
	'Microsoft.WindowsMaps',
	'Microsoft.WindowsPhone',
	'Microsoft.WindowsSoundRecorder',
	'Microsoft.Xbox.TCUI',
	'Microsoft.XboxApp',
	'Microsoft.XboxGameOverlay',
	'Microsoft.XboxGamingOverlay',
	'Microsoft.XboxIdentityProvider',
	'Microsoft.XboxSpeechToTextOverlay',
	'Microsoft.YourPhone',
	'Microsoft.ZuneMusic',
	'Microsoft.ZuneVideo',
	'MicrosoftCorporationII.MicrosoftFamily',
	'MicrosoftCorporationII.QuickAssist',
	'MicrosoftTeams',
	'MicrosoftWindows.CrossDevice',
	'MixedRealityLearning',
	'Movies & TV',
	'MSTeams',
	'Netflix',
	'NYTCrossword',
	'OneCalendar',
	'PandoraMediaInc',
	'PhototasticCollage',
	'PicsArt-PhotoStudio',
	'Plex',
	'PolarrPhotoEditorAcademicEdition',
	'Royal Revolt',
	'Shazam',
	'Sidia.LiveWallpaper',
	'SlingTV',
	'Speed Test',
	'Spotify',
	'TikTok',
	'TuneInRadio',
	'Twitter',
	'Viber',
	'WhatsApp',
	'WinZipUniversal',
	'Wunderlist',
	'XING'
)

# Cache provisioned packages once
$provPkgs = Get-AppxProvisionedPackage -Online

Write-Host "Removing bloatware" -ForegroundColor Cyan

foreach ($App in $AppsList) {
    # Installed (per-user) removal
    $installed = Get-AppxPackage -Name $App -AllUsers -ErrorAction SilentlyContinue
    if ($installed) {
        foreach ($pkg in $installed) {
            Write-Verbose "Removing installed: $($pkg.PackageFullName)"
            Remove-AppxPackage -Package $pkg.PackageFullName -ErrorAction SilentlyContinue 
        }
    } else {
        Write-Verbose "Not installed: $App"
    }

    # Provisioned (new-user) removal
    $prov = $provPkgs | Where-Object { $_.DisplayName -eq $App }
    if ($prov) {
        Write-Verbose "Removing provisioned: $($prov.PackageName)"
        Remove-AppxProvisionedPackage -Online -PackageName $prov.PackageName -ErrorAction SilentlyContinue 
    } else {
        Write-Verbose "No provisioned package found for: $App"
    }
}

Write-Host "[DONE] Removing bloatware completed`n" -ForegroundColor Green
}

if ($UninstallExtensionsCheckbox.Checked) {
    Write-Host "Removing Extensions Managed by Your Organization" -ForegroundColor Cyan

    # Remove Chrome forced extensions
    if (Test-Path "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist") {
        Remove-Item -Path "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist" -Recurse -Force
        Write-Host "Removed Chrome extension policies" -ForegroundColor Yellow
    }

    # Remove Edge forced extensions
    if (Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist") {
        Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist" -Recurse -Force
        Write-Host "Removed Edge extension policies" -ForegroundColor Yellow
    }

    gpupdate /force | Out-Null

    # --- Refresh browsers to apply removal ---
    $EdgePath   = "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe"
    $ChromePath = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"

    if (Test-Path $EdgePath) {
        Start-Process $EdgePath
        Start-Sleep -Seconds 2
        Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
    }

    if (Test-Path $ChromePath) {
        Start-Process $ChromePath
        Start-Sleep -Seconds 2
        Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force
    }

    Write-Host "[DONE] Removing Extensions Managed by Your Organization completed`n" -ForegroundColor Green
}


if($FurMarkCheckbox.Checked) {  
	write-Host "FurMark shortcut completed" -ForegroundColor Cyan 
	$urlFurMark = "https://geeks3d.com/dl/show/728"
    $shortcutFurMarkPath = Join-Path -Path $desktopPath -ChildPath "FurMark.lnk"
    $shortcutFurMark = $shell.CreateShortcut($shortcutFurMarkPath)
    $shortcutFurMark.TargetPath = $urlFurMark
    $shortcutFurMark.IconLocation = $edgeExePath
    $shortcutFurMark.Save()
	write-Host "[DONE] FurMark shortcut completed"`n -ForegroundColor Green 
	}

if($LaunchBoxCheckbox.Checked) {  
	write-Host "LaunchBox shortcut" -ForegroundColor Cyan 
	$urlLaunchBox = "https://www.launchbox-app.com/download"
    $shortcutLaunchBoxPath = Join-Path -Path $desktopPath -ChildPath "LaunchBox.lnk"
    $shortcutLaunchBox = $shell.CreateShortcut($shortcutLaunchboxPath)
    $shortcutLaunchBox.TargetPath = $urlLaunchBox
    $shortcutLaunchBox.IconLocation = $edgeExePath
    $shortcutLaunchBox.Save()
	write-Host "[DONE] LaunchBox shortcut completed"`n -ForegroundColor Green 
	}

if($PCSX2Checkbox.Checked) {	
    write-Host "PCSX2 shortcut" -ForegroundColor Cyan
    $urlPCSX2 = "http://pcsx2.net"
    $shortcutPCSX2Path = Join-Path -Path $desktopPath -ChildPath "PCSX2.lnk"
    $shortcutPCSX2 = $shell.CreateShortcut($shortcutPCSX2Path)
    $shortcutPCSX2.TargetPath = $urlPCSX2
    $shortcutPCSX2.IconLocation = $edgeExePath
    $shortcutPCSX2.Save()
    Write-Host "[DONE] PCSX2 shortcut completed"`n -ForegroundColor Green
	}

if($TModLoaderCheckbox.Checked) {	
	write-Host "TModLoader shortcut" -ForegroundColor Cyan 
	$urlTModLoader = "https://store.steampowered.com/app/1281930/tModLoader/"
	$shortcutTModLoaderPath = Join-Path -Path $desktopPath -ChildPath "TModLoader.lnk"
	$shortcutTModLoader = $shell.CreateShortcut($shortcutTModLoaderPath)
	$shortcutTModLoader.TargetPath = $urlTModLoader
	$shortcutTModLoader.IconLocation = $edgeExePath
	$shortcutTModLoader.Save()
	write-Host "[DONE] TModLoader shortcut completed"`n -ForegroundColor Green 
	}

if($RandomizersCheckbox.Checked) {	
	write-Host "Randomizers shortcut" -ForegroundColor Cyan 
	$urlRandomizers = "https://www.debigare.com/randomizers/"
	$shortcutRandomizersPath = Join-Path -Path $desktopPath -ChildPath "Randomizers.lnk"
	$shortcutRandomizers = $shell.CreateShortcut($shortcutRandomizersPath)
	$shortcutRandomizers.TargetPath = $urlRandomizers
	$shortcutRandomizers.IconLocation = $edgeExePath
	$shortcutRandomizers.Save()
	write-Host "[DONE] Randomizers shortcut completed"`n -ForegroundColor Green 
	}

if($3DMarkCheckbox.Checked) {	
	write-Host "3DMark shortcut" -ForegroundColor Cyan 
	$url3DMark = "https://store.steampowered.com/app/223850/3DMark/"
	$shortcut3DMarkPath = Join-Path -Path $desktopPath -ChildPath "3DMark.lnk"
	$shortcut3DMark = $shell.CreateShortcut($shortcut3DmarkPath)
	$shortcut3DMark.TargetPath = $url3DMark
	$shortcut3DMark.IconLocation = $edgeExePath
	$shortcut3DMark.Save()
	write-Host "[DONE] 3DMark shortcut completed"`n -ForegroundColor Green 
	}

if($CodecksCheckbox.Checked) {	
	write-Host "Codecks shortcut" -ForegroundColor Cyan 
	$urlCodecks = "https://www.codecks.io"
	$shortcutCodecksPath = Join-Path -Path $desktopPath -ChildPath "Codecks.lnk"
	$shortcutCodecks = $shell.CreateShortcut($shortcutCodecksPath)
	$shortcutCodecks.TargetPath = $urlCodecks
	$shortcutCodecks.Save()
	$shortcutCodecks.IconLocation = $edgeExePath
	write-Host "[DONE] Codecks shortcut completed"`n -ForegroundColor Green 
	}

if($HacknPlanCheckbox.Checked) {	
	write-Host "HacknPlan shortcut" -ForegroundColor Cyan 
	$urlHacknPlan = "https://hacknplan.com"
	$shortcutHacknPlanPath = Join-Path -Path $desktopPath -ChildPath "HacknPlan.lnk"
	$shortcutHacknPlan = $shell.CreateShortcut($shortcutHacknPlanPath)
	$shortcutHacknPlan.TargetPath = $urlHacknPlan
	$shortcutHacknPlan.IconLocation = $edgeExePath
	$shortcutHacknPlan.Save()
	write-Host "[DONE] HacknPlan shortcut completed"`n -ForegroundColor Green 
	}

if($PCMarkCheckbox.Checked) {	
	write-Host "PCMark shortcut" -ForegroundColor Cyan 
	$urlPCMark = "https://store.steampowered.com/app/524390/PCMark_10/"
	$shortcutPCMarkPath = Join-Path -Path $desktopPath -ChildPath "PCMark 10.lnk"
	$shortcutPCMark = $shell.CreateShortcut($shortcutPCMarkPath)
	$shortcutPCMark.TargetPath = $urlPCMark
	$shortcutPCMark.IconLocation = $edgeExePath
	$shortcutPCMark.Save()
	write-Host "[DONE] PCMark 10 shortcut completed"`n -ForegroundColor Green 
	}

if($AmazonShortcutCheckbox.Checked) {	
	write-Host "Amazon shortcut" -ForegroundColor Cyan 
	$urlAmazon = "https://amazon.com"
	$shortcutAmazonPath = Join-Path -Path $desktopPath -ChildPath "Amazon.lnk"
	$shortcutAmazon = $shell.CreateShortcut($shortcutAmazonPath)
	$shortcutAmazon.TargetPath = $urlAmazon
	$shortcutAmazon.IconLocation = $edgeExePath
	$shortcutAmazon.Save()
	write-Host "[DONE] Amazon shortcut completed"`n -ForegroundColor Green 
	}

if($AOLShortcutCheckbox.Checked) {	
	write-Host "AOL shortcut" -ForegroundColor Cyan 
	$urlAOL = "https://aol.com"
	$shortcutAOLPath = Join-Path -Path $desktopPath -ChildPath "AOL.lnk"
	$shortcutAOL = $shell.CreateShortcut($shortcutAOLPath)
	$shortcutAOL.TargetPath = $urlAOL
	$shortcutAOL.IconLocation = $edgeExePath
	$shortcutAOL.Save()
	write-Host "[DONE] AOL shortcut completed"`n -ForegroundColor Green 
	}

if($AOLMailShortcutCheckbox.Checked) {	
	write-Host "AOL Mail shortcut" -ForegroundColor Cyan 
	$urlAOLMail = "https://mail.aol.com"
	$shortcutAOLMailPath = Join-Path -Path $desktopPath -ChildPath "AOL Mail.lnk"
	$shortcutAOLMail = $shell.CreateShortcut($shortcutAOLMailPath)
	$shortcutAOLMail.TargetPath = $urlAOLMail
	$shortcutAOLMail.IconLocation = $edgeExePath
	$shortcutAOLMail.Save()
	write-Host "[DONE] AOLMail shortcut completed"`n -ForegroundColor Green 
	}

if($BestBuyShortcutCheckbox.Checked) {	
	write-Host "Best Buy shortcut" -ForegroundColor Cyan 
	$urlBestBuy = "https://bestbuy.com"
	$shortcutBestBuyPath = Join-Path -Path $desktopPath -ChildPath "Best Buy.lnk"
	$shortcutBestBuy = $shell.CreateShortcut($shortcutBestBuyPath)
	$shortcutBestBuy.TargetPath = $urlBestBuy
	$shortcutBestBuy.IconLocation = $edgeExePath
	$shortcutBestBuy.Save()
	write-Host "[DONE] BestBuy shortcut completed"`n -ForegroundColor Green 
	}

if($FacebookShortcutCheckbox.Checked) {	
	write-Host "Facebook shortcut" -ForegroundColor Cyan 
	$urlFacebook = "https://www.facebook.com"
	$shortcutFacebookPath = Join-Path -Path $desktopPath -ChildPath "Facebook.lnk"
	$shortcutFacebook = $shell.CreateShortcut($shortcutFacebookPath)
	$shortcutFacebook.TargetPath = $urlFacebook
	$shortcutFacebook.IconLocation = $edgeExePath
	$shortcutFacebook.Save()
	write-Host "[DONE] Facebook shortcut completed"`n -ForegroundColor Green 
	}

if($GmailShortcutCheckbox.Checked) {	
	write-Host "Gmail shortcut" -ForegroundColor Cyan 
	$urlGmail = "https://www.gmail.com"
	$shortcutGmailPath = Join-Path -Path $desktopPath -ChildPath "Gmail.lnk"
	$shortcutGmail = $shell.CreateShortcut($shortcutGmailPath)
	$shortcutGmail.TargetPath = $urlGmail
	$shortcutGmail.IconLocation = $edgeExePath
	$shortcutGmail.Save()
	write-Host "[DONE] Gmail shortcut completed"`n -ForegroundColor Green 
	}

if($GoogleShortcutCheckbox.Checked) {	
	write-Host "Google shortcut" -ForegroundColor Cyan 
	$urlGoogle = "https://www.google.com"
	$shortcutGooglePath = Join-Path -Path $desktopPath -ChildPath "Google.lnk"
	$shortcutGoogle = $shell.CreateShortcut($shortcutGooglePath)
	$shortcutGoogle.TargetPath = $urlGoogle
	$shortcutGoogle.IconLocation = $edgeExePath
	$shortcutGoogle.Save()
	write-Host "[DONE] Google shortcut completed"`n -ForegroundColor Green 
	}

if($RedditShortcutCheckbox.Checked) {	
	write-Host "Reddit shortcut" -ForegroundColor Cyan 
	$urlReddit = "https://www.reddit.com"
	$shortcutRedditPath = Join-Path -Path $desktopPath -ChildPath "Reddit.lnk"
	$shortcutReddit = $shell.CreateShortcut($shortcutRedditPath)
	$shortcutReddit.TargetPath = $urlReddit
	$shortcutReddit.IconLocation = $edgeExePath
	$shortcutReddit.Save()
	write-Host "[DONE] Reddit shortcut completed"`n -ForegroundColor Green 
	}

if($TwitterShortcutCheckbox.Checked) {	
    write-Host "Twitter shortcut" -ForegroundColor Cyan 
    $urlTwitter = "https://www.twitter.com"
    $shortcutTwitterPath = Join-Path -Path $desktopPath -ChildPath "Twitter.lnk"
    $shortcutTwitter = $shell.CreateShortcut($shortcutTwitterPath)
    $shortcutTwitter.TargetPath = $urlTwitter
	$shortcutTwitter.IconLocation = $edgeExePath
    $shortcutTwitter.Save()
    write-Host "[DONE] Twitter shortcut completed" -ForegroundColor Green 
	}

if($YahooShortcutCheckbox.Checked) {	
	write-Host "Yahoo shortcut" -ForegroundColor Cyan 
	$urlYahoo = "https://www.yahoo.com"
	$shortcutYahooPath = Join-Path -Path $desktopPath -ChildPath "Yahoo.lnk"
	$shortcutYahoo = $shell.CreateShortcut($shortcutYahooPath)
	$shortcutYahoo.TargetPath = $urlYahoo
	$shortcutYahoo.IconLocation = $edgeExePath
	$shortcutYahoo.Save()
	write-Host "[DONE] Twitter shortcut completed"`n -ForegroundColor Green 
	}

if($YahooMailShortcutCheckbox.Checked) {	
	write-Host "Yahoo Mail shortcut" -ForegroundColor Cyan 
	$urlYahooMail = "https://www.mail.yahoo.com"
	$shortcutYahooMailPath = Join-Path -Path $desktopPath -ChildPath "Yahoo Mail.lnk"
	$shortcutYahooMail = $shell.CreateShortcut($shortcutYahooMailPath)
	$shortcutYahooMail.TargetPath = $urlYahooMail
	$shortcutYahooMail.IconLocation = $edgeExePath
	$shortcutYahooMail.Save()
	write-Host "[DONE] Yahoo Mail shortcut completed"`n -ForegroundColor Green 
	}

if($YouTubeShortcutCheckbox.Checked) {	
	write-Host "YouTube shortcut " -ForegroundColor Cyan 
	$urlYouTube = "https://www.youtube.com"
	$shortcutYouTubePath = Join-Path -Path $desktopPath -ChildPath "YouTube.lnk"
	$shortcutYouTube = $shell.CreateShortcut($shortcutYouTubePath)
	$shortcutYouTube.TargetPath = $urlYouTube
	$shortcutYouTube.IconLocation = $edgeExePath
	$shortcutYouTube.Save()
	write-Host "[DONE] YouTube shortcut completed"`n -ForegroundColor Green 
	}

if($OfficeShortcutsCheckbox.Checked) {  
	try {
    		write-Host "Create Office shortcuts" -ForegroundColor Cyan 
    		Copy-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Word.lnk" -Destination "C:\Users\Public\Desktop" -Force -ErrorAction Stop
    		Copy-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Excel.lnk" -Destination "C:\Users\Public\Desktop" -Force -ErrorAction Stop
    		Copy-Item -Path "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\PowerPoint.lnk" -Destination "C:\Users\Public\Desktop" -Force -ErrorAction Stop
    		write-Host "[DONE] Create Office shortcuts completed"`n -ForegroundColor Green 
		}
	catch {
    		write-Host "An error occurred: $_" -ForegroundColor Red
		}
	}

# Windows Updates	
if ($WindowsUpdatesCheckbox.Checked) {
    Write-Host "Windows Updates" -ForegroundColor Cyan 
    # Enable "Get the latest updates as soon as they're available" if registry key exists
    $uxSettingsPath = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"
    if (Test-Path $uxSettingsPath) {
        try {
            Set-ItemProperty -Path $uxSettingsPath -Name "IsContinuousInnovationOptedIn" -Type DWord -Value 1 -ErrorAction Stop
            Write-Host "Enabled ""Get the latest updates as soon as they're available"""
        } catch {
            Write-Host "Failed to enable latest updates toggle: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "Latest updates toggle not found (likely not supported on this system)" -ForegroundColor Yellow
    }
	
    try {
        Install-PackageProvider -Name NuGet -Force
        Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
        Install-Module -Name PSWindowsUpdate -Force
        Import-Module PSWindowsUpdate
        Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade'
        Write-Host "[DONE] Windows Updates completed`n" -ForegroundColor Green 
    } catch {
        Write-Host "Windows Update process failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}


if ($CleanupCheckbox.Checked) {
    Write-Host "Cleanup Tasks" -ForegroundColor Cyan

    # Disable Start Menu Recommendations (Recent Items)
    try {
        $regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        Set-ItemProperty -Path $regPath -Name Start_TrackDocs -Value 0 -ErrorAction Stop
        Write-Host "Start Menu Recommendations disabled"
    } catch {
        Write-Warning "Failed to disable Start Menu Recommendations: $_"
    }

    # Clear Recent Files (Jump Lists + Quick Access)
    try {
        $recentPaths = @(
            "$env:APPDATA\Microsoft\Windows\Recent",
            "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations",
            "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations"
        )
        foreach ($path in $recentPaths) {
            Remove-Item "$path\*" -Force -Recurse -ErrorAction SilentlyContinue
        }

        # Clear Explorer MRU (Extra improvement)
        try {
            (New-Object -ComObject Shell.Application).NameSpace(0).Self.InvokeVerb("Clear Recent Items")
            Write-Host "Explorer Recent Items history cleared"
        } catch {
            Write-Warning "Failed to clear Explorer Recent Items via COM: $_"
        }

        Write-Host "Recent Files cleared"
    } catch {
        Write-Warning "Error clearing Recent items: $_"
    }

    # Clear Temp Files
    try {
        $tempPath = $env:TEMP
        Remove-Item "$tempPath\*" -Force -Recurse -ErrorAction SilentlyContinue
        Write-Host "Temp Files cleared"
    } catch {
        Write-Warning "Error clearing Temp files: $_"
    }

    # Empty Recycle Bin
    try {
        Clear-RecycleBin -Force -ErrorAction SilentlyContinue
        Write-Host "Recycle Bin emptied"
    } catch {
        Write-Warning "Unable to clear Recycle Bin: $_"
    }

    # Restart Explorer to apply Start Menu changes
    try {
        Stop-Process -Name explorer -Force
    } catch {
        Write-Warning "Explorer restart failed: $_"
    }

    Write-Host "[DONE] Cleanup tasks completed.`n" -ForegroundColor Green
}

# Re-Enable Sleep Settings
} finally { 
  powercfg -setactive $prevGuid
}

if ($SleepCheckbox.Checked) {
    Write-Host "Disable turning off display and sleep" -ForegroundColor Cyan

    try {
        # Get the active power scheme GUID
        $activeScheme = (powercfg /getactivescheme) -match 'GUID:\s+([a-fA-F0-9\-]+)' | Out-Null
        $guid = $matches[1]

        # Set Display Timeout to Never (0) for AC power
        powercfg /setacvalueindex $guid SUB_VIDEO VIDEOIDLE 0

        # Set Display Timeout to Never (0) for DC power (laptops)
        powercfg /setdcvalueindex $guid SUB_VIDEO VIDEOIDLE 0

        # Set Sleep Timeout to Never (0) for AC power
        powercfg /setacvalueindex $guid SUB_SLEEP STANDBYIDLE 0

        # Set Sleep Timeout to Never (0) for DC power (laptops)
        powercfg /setdcvalueindex $guid SUB_SLEEP STANDBYIDLE 0

        # Apply the updated power plan
        powercfg /setactive $guid

        Write-Host "[DONE] Disable display turn-off and sleep completed`n" -ForegroundColor Green
    } catch {
        Write-Host "Failed to apply sleep/display settings: $($_.Exception.Message)" -ForegroundColor Red
    }
}

if ($RestoreCheckbox.Checked) {
    Write-Host "Enable System Restore and Creating Restore Point" -ForegroundColor Cyan
    try {
        Enable-ComputerRestore -Drive "C:\" -ErrorAction Stop
        Checkpoint-Computer -Description "Initial Setup Restore Point" -RestorePointType "MODIFY_SETTINGS"
        Write-Host "[DONE] Enable System Restore and Creating Restore Point completed`n"
    } catch {
        Write-Host "Failed to enable System Restore or create restore point: $($_.Exception.Message)`n" -ForegroundColor Red
    }
}

if ($AutoRestartCheckbox.Checked) {
	Shutdown /r /t 0
}

}

#---------------------------------------------------------------------------------------------
# Add Clicks
$RUNButton.Add_Click({ Execute })

$searchButton.Add_Click({ Search })

$searchInstalledButton.Add_Click({ Installed })

$installButton.Add_Click({ Install })

$listInstalledButton.Add_Click({ ListInstalled })

$uninstallButton.Add_Click({ Uninstall })

#---------------------------------------------------------------------------------------------
# This Displays The Form
[void] $Form.ShowDialog()