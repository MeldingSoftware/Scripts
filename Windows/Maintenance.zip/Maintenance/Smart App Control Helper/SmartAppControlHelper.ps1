# SmartAppControl_Helper.ps1
# Opens the Smart App Control settings page for the user on Windows 11.
# This script does not change Smart App Control automatically.

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Pause-And-Exit {
    param(
        [string]$Message = 'Press Enter to close'
    )
    Write-Host ''
    Read-Host $Message | Out-Null
    exit
}

try {
    $os = Get-CimInstance Win32_OperatingSystem
    $caption = [string]$os.Caption
    $buildNumber = [int]$os.BuildNumber

    Write-Host ''
    Write-Host 'Smart App Control Helper' -ForegroundColor Cyan
    Write-Host '-------------------------' -ForegroundColor Cyan
    Write-Host ''

    if ($caption -notmatch 'Windows 11' -and $buildNumber -lt 22000) {
        Write-Host 'This PC does not appear to be running Windows 11.' -ForegroundColor Yellow
        Write-Host 'Smart App Control is a Windows 11 feature, so there may be nothing to open here.' -ForegroundColor Yellow
        Pause-And-Exit
    }

    Write-Host 'This helper does not turn Smart App Control off automatically.' -ForegroundColor Yellow
    Write-Host 'It only opens the Smart App Control window so you can review it manually.' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'Important:' -ForegroundColor Yellow
    Write-Host '- Smart App Control helps protect Windows 11 from untrusted apps.' -ForegroundColor Yellow
    Write-Host '- If you turn it off, turning it back on later may require resetting or reinstalling Windows.' -ForegroundColor Yellow
    Write-Host ''

    Read-Host 'Press Enter to open the Smart App Control' 

    try {
        Start-Process "$env:WINDIR\explorer.exe" 'windowsdefender://smartapp'
    } catch {
        Write-Host ''
        Write-Host 'Direct Smart App Control link failed' -ForegroundColor Yellow
		Pause-And-Exit
    }

    exit

}
catch {
    Write-Host ''
    Write-Host "Helper failed: $($_.Exception.Message)" -ForegroundColor Red
    Pause-And-Exit
}