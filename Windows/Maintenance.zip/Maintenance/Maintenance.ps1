#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# ------------------------------------
# Paths and Globals
# ------------------------------------
$desktopPath = Join-Path ([Environment]::GetFolderPath("Desktop")) 'Maintenance Results'
New-Item -Path $desktopPath -ItemType Directory -Force | Out-Null

$reportPath       = Join-Path $desktopPath 'Maintenance_Report.html'
$chkdskScriptPath = Join-Path $desktopPath 'ChkdskResults.ps1'
$chkdskBatPath    = Join-Path $desktopPath 'Run CHKDSK Results.bat'

$sections = New-Object System.Collections.Generic.List[object]

function Add-SectionResult {
    param(
        [string]$Name,
        [string]$Status,
        [string]$Output
    )

    $sections.Add([PSCustomObject]@{
        Name   = $Name
        Status = $Status
        Output = $Output
    })
}

# ------------------------------------
# Power Plan Handling
# ------------------------------------
function Set-NoSleepPlan {
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION: Configure temporary power plan" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $schemeGuid  = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67'
    $schemeName  = 'Always on'
    $schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'

    $prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'

    function Assert-Ok { if ($LASTEXITCODE -ne 0) { throw "powercfg command failed." } }

    Assert-Ok

    try {
        powercfg -setactive $schemeGuid 2>$null
        if ($LASTEXITCODE -ne 0) {
            $null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
            Assert-Ok
            $null = powercfg -changename $schemeGuid $schemeName $schemeDescr
            $null = powercfg -setactive $schemeGuid
            Assert-Ok

            $settings = 'monitor-timeout-ac', 'monitor-timeout-dc',
                        'disk-timeout-ac', 'disk-timeout-dc',
                        'standby-timeout-ac', 'standby-timeout-dc',
                        'hibernate-timeout-ac', 'hibernate-timeout-dc'

            foreach ($setting in $settings) {
                powercfg -change $setting 0
                Assert-Ok
            }
        }

        Write-Host "Temporary power plan 'Always on' is active." -ForegroundColor Green
    } catch {
        Write-Host "Failed to configure 'Always on' plan: $_" -ForegroundColor Red
        throw
    }

    return $prevGuid
}

function Restore-PowerPlan {
    param([string]$Guid)

    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION: Restore original power plan" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    try {
        powercfg -setactive $Guid
        Write-Host "Original power plan restored." -ForegroundColor Green
    } catch {
        Write-Host "Failed to restore previous power plan: $_" -ForegroundColor Red
    }
}

# ------------------------------------
# Helpers for sizes and paths
# ------------------------------------
function Format-Path {
    param([string]$rawPath)
    [System.Environment]::ExpandEnvironmentVariables($rawPath) -replace '\\{2,}', '\'
}

function Get-FolderSizeReadable {
    param ([string]$Path)

    $expanded = Format-Path $Path

    if ($expanded -eq 'C:\Recycle.Bin') {
        $realRecyclePath = 'C:\$Recycle.Bin'
        if (-not (Test-Path $realRecyclePath)) { return "Empty" }

        try {
            $sizeBytes = (Get-ChildItem -Path "$realRecyclePath\*" -Recurse -Force -ErrorAction Stop |
                          Measure-Object -Property Length -Sum).Sum
            if (-not $sizeBytes) { return "0 MB" }
            if ($sizeBytes -ge 1GB) {
                return "{0:N2} GB" -f ($sizeBytes / 1GB)
            } else {
                return "{0:N2} MB" -f ($sizeBytes / 1MB)
            }
        } catch {
            return "Access Denied"
        }
    }

    if (-not (Test-Path $expanded)) {
        return "Does not exist"
    }

    try {
        $items = Get-ChildItem -Path $expanded -Recurse -Force -ErrorAction Stop |
                 Where-Object { -not $_.PSIsContainer }
        $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
        if (-not $totalBytes) { return "0 MB" }
        if ($totalBytes -ge 1GB) {
            return "{0:N2} GB" -f ($totalBytes / 1GB)
        } else {
            return "{0:N2} MB" -f ($totalBytes / 1MB)
        }
    } catch {
        return "Access Denied"
    }
}

function ConvertToGB {
    param([string]$size)
    if ($size -match "GB") {
        return [double]($size -replace " GB", "")
    } elseif ($size -match "MB") {
        return [double]($size -replace " MB", "") / 1024
    } else {
        return 0
    }
}

function FormatTotal {
    param([double]$value)
    if ($value -ge 1) {
        return "{0:N2} GB" -f $value
    } else {
        return "{0:N2} MB" -f ($value * 1024)
    }
}

function Get-BrowserFolderSize {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return "0 MB" }
    try {
        $items = Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue |
                 Where-Object { -not $_.PSIsContainer }
        $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
        if (-not $totalBytes) { return "0 MB" }
        if ($totalBytes -ge 1GB) { return "{0:N2} GB" -f ($totalBytes / 1GB) }
        else { return "{0:N2} MB" -f ($totalBytes / 1MB) }
    } catch {
        return "0 MB"
    }
}

# ------------------------------------
# HTML report writer
# ------------------------------------
function Write-MaintenanceReportHtml {
    param(
        [array]$Sections,
        [string]$Path
    )

    try {
        Add-Type -AssemblyName System.Web -ErrorAction SilentlyContinue | Out-Null
    } catch {}

    $timestamp = Get-Date
    $computer  = $env:COMPUTERNAME
    $user      = $env:USERNAME
    $os        = (Get-CimInstance Win32_OperatingSystem).Caption

    $rowsBuilder = New-Object System.Text.StringBuilder

    foreach ($s in $Sections) {
        $statusClass = switch -Regex ($s.Status.ToLower()) {
            'ok|completed|success' { 'status-ok' }
            'warning'              { 'status-warning' }
            'failed|error'         { 'status-error' }
            'scheduled'            { 'status-warning' }
            default                { 'status-neutral' }
        }

        $safeOutput = [System.Web.HttpUtility]::HtmlEncode($s.Output)

        if ($s.Name -eq 'File System Check (CHKDSK - C:)') {
            $chunk = @"
        <!-- CHKDSK-SECTION-START -->
        <div class="card">
            <h2>$($s.Name)</h2>
            <p class="status $statusClass"><strong>Status:</strong> $($s.Status)</p>
            <pre>$safeOutput</pre>
        </div>
        <!-- CHKDSK-SECTION-END -->
"@
        } else {
            $chunk = @"
        <div class="card">
            <h2>$($s.Name)</h2>
            <p class="status $statusClass"><strong>Status:</strong> $($s.Status)</p>
            <pre>$safeOutput</pre>
        </div>
"@
        }

        [void]$rowsBuilder.AppendLine($chunk)
    }

    $rowsHtml = $rowsBuilder.ToString()

    $html = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>System Maintenance Report - $computer</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: #0f172a;
            color: #e5e7eb;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1100px;
            margin: 30px auto 60px auto;
            background: #020617;
            border-radius: 16px;
            padding: 24px 28px 40px 28px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.65);
            border: 1px solid #1e293b;
        }
        h1 {
            margin-top: 0;
            font-size: 28px;
            color: #e5e7eb;
        }
        .meta {
            font-size: 13px;
            color: #9ca3af;
            margin-bottom: 18px;
        }
        .badge {
            display: inline-block;
            padding: 3px 9px;
            border-radius: 999px;
            font-size: 11px;
            background: #1f2937;
            color: #9ca3af;
            margin-right: 6px;
        }
        .card {
            background: #020617;
            border-radius: 12px;
            border: 1px solid #1f2937;
            padding: 14px 18px 14px 18px;
            margin-top: 18px;
        }
        .card h2 {
            margin: 0 0 6px 0;
            font-size: 18px;
            color: #e5e7eb;
        }
        .status {
            margin: 0 0 8px 0;
            font-size: 13px;
        }
        .status-ok { color: #4ade80; }
        .status-warning { color: #facc15; }
        .status-error { color: #f97373; }
        .status-neutral { color: #9ca3af; }
        pre {
            margin: 0;
            padding: 8px 10px;
            background: #020617;
            border-radius: 8px;
            border: 1px solid #1f2937;
            font-size: 12px;
            max-height: 260px;
            overflow: auto;
            white-space: pre-wrap;
        }
        .footer {
            margin-top: 24px;
            font-size: 12px;
            color: #6b7280;
            border-top: 1px solid #1f2937;
            padding-top: 12px;
        }
        a { color: #38bdf8; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>System Maintenance Report</h1>
    <div class="meta">
        <span class="badge">Machine: $computer</span>
        <span class="badge">User: $user</span>
        <span class="badge">Date: $timestamp</span>
        <div style="margin-top:6px;">OS: $os</div>
    </div>

$rowsHtml

    <div class="footer">
        For CHKDSK results, run the generated Run CHKDSK Results.bat after a reboot where CHKDSK was scheduled.<br/>
        Report generated by Melding Software maintenance script.
    </div>
</div>
</body>
</html>
"@

    Set-Content -Path $Path -Value $html -Encoding UTF8
}

# ------------------------------------
# CHKDSK helper script and bat
# ------------------------------------
function Write-ChkdskHelperScripts {
    param(
        [string]$ChkdskPs1,
        [string]$ChkdskBat
    )

    $ps1Content = @'
$ErrorActionPreference = "Stop"

try {
    Add-Type -AssemblyName System.Web -ErrorAction SilentlyContinue | Out-Null
} catch {}

$scriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$ReportPath = Join-Path $scriptDir 'Maintenance_Report.html'

if (-not (Test-Path $ReportPath)) {
    Write-Host "Report file not found at $ReportPath" -ForegroundColor Red
    exit 1
}

Write-Host "Reading CHKDSK results from Event Viewer." -ForegroundColor Cyan

try {
    $event = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        Id      = 1001
    } -MaxEvents 20 | Where-Object {
        $_.Message -match 'CHKDSK' -or $_.Message -match 'file system'
    } | Sort-Object TimeCreated -Descending | Select-Object -First 1

    if (-not $event) {
        $status  = "No CHKDSK event found in Application log."
        $when    = Get-Date
        $message = "No CHKDSK related event with ID 1001 could be located. It is possible the file system check did not run, or logging is unavailable."
    } else {
        $when    = $event.TimeCreated
        $message = $event.Message
        $status  = "CHKDSK completed. See detailed log below."

        if ($message -match 'Windows has scanned the file system and found no problems') {
            $status = "No errors were found on C."
        } elseif ($message -match 'Windows made corrections to the file system') {
            $status = "Errors were found and corrected on C."
        }
    }

    $escaped = [System.Web.HttpUtility]::HtmlEncode($message)

    $chkdskHtml = @"
        <!-- CHKDSK-SECTION-START -->
        <div class="card">
            <h2>File System Check (CHKDSK - C:)</h2>
            <p class="status status-ok"><strong>Status:</strong> $status</p>
            <p style="font-size:12px; color:#9ca3af; margin-top:0; margin-bottom:6px;">
                Source: CHKDSK related event (ID 1001) at $when
            </p>
            <pre>$escaped</pre>
        </div>
        <!-- CHKDSK-SECTION-END -->
"@

    $html = Get-Content -Path $ReportPath -Raw

    $pattern = '(?s)<!-- CHKDSK-SECTION-START -->.*?<!-- CHKDSK-SECTION-END -->'
    if ($html -match $pattern) {
        $html = [System.Text.RegularExpressions.Regex]::Replace($html, $pattern, $chkdskHtml)
        Set-Content -Path $ReportPath -Value $html -Encoding UTF8
        Write-Host "CHKDSK section updated in HTML report." -ForegroundColor Green
        Start-Process $ReportPath
    } else {
        Write-Host "CHKDSK section markers not found in HTML report." -ForegroundColor Yellow
    }
}
catch {
    Write-Host "Failed to update CHKDSK section: $_" -ForegroundColor Red
    exit 1
}
'@

    Set-Content -Path $ChkdskPs1 -Value $ps1Content -Encoding UTF8

    $batContent = @'
@echo off
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ChkdskResults.ps1"
'@

    Set-Content -Path $ChkdskBat -Value $batContent -Encoding ASCII
}

# ------------------------------------
# DISM + SFC helpers (clean output)
# ------------------------------------
function Invoke-DismPhase {
    param(
        [string]$Label,
        [scriptblock]$Command
    )

    Write-Host ""
    Write-Host ("===== {0} =====" -f $Label) -ForegroundColor Cyan

    $raw = & $Command 2>&1 | ForEach-Object { $_.ToString() }

    $filtered = foreach ($line in $raw) {
        if (-not $line) { continue }

        # Strip DISM headers and ASCII progress bars
        if ($line -match '^\s*Deployment Image Servicing and Management tool') { continue }
        if ($line -match '^\s*Version:\s*\d') { continue }
        if ($line -match '^\s*Image Version:\s*\d') { continue }
        if ($line -match '^\s*\[[=\s>0-9\.\%]+\]\s*$') { continue }

        $line
    }

    foreach ($line in $filtered) {
        Write-Host "  $line"
    }

    if (-not $filtered) {
        return @("No output captured for $Label.")
    }

    return ,$filtered
}

function Invoke-SfcClean {
    Write-Host ""
    Write-Host "===== SFC /SCANNOW =====" -ForegroundColor Cyan

    $raw = & sfc /scannow 2>&1 | ForEach-Object { $_.ToString() }

    $filtered = foreach ($line in $raw) {
        if (-not $line) { continue }

        # Remove scan/verification chatter
        if ($line -match '^\s*Beginning system scan\.') { continue }
        if ($line -match '^\s*Beginning verification phase of system scan\.') { continue }
        if ($line -match '^\s*Verification\s+\d+% complete\.\s*$') { continue }
        if ($line -match '^\s*$') { continue }

        $line
    }

    foreach ($line in $filtered) {
        Write-Host "  $line"
    }

    if (-not $filtered) {
        return @("SFC /SCANNOW completed. See CBS.log for details if any issues were detected.")
    }

    return ,$filtered
}

# ------------------------------------
# MAIN
# ------------------------------------
$previousGuid = Set-NoSleepPlan

try {
    # 1. Microsoft Store updates (manual)
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 1: Microsoft Store updates" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $storeStatus = "Completed"
    $storeOutput = "Microsoft Store updates page opened. Check for app updates manually in the Microsoft Store."

    try {
        Start-Process "ms-windows-store://updates"
        Write-Host "Microsoft Store opened to Updates page." -ForegroundColor Green
    } catch {
        $storeStatus = "Warning"
        $storeOutput = "Failed to open Microsoft Store updates page. Error: $_"
        Write-Host $storeOutput -ForegroundColor Red
    }

    Add-SectionResult -Name "Microsoft Store Updates" -Status $storeStatus -Output $storeOutput

    # 2. Startup Optimization (manual)
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 2: Startup optimization" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $startupStatus = "Completed"
    $startupOutput = "Task Manager opened. On the Startup tab, disable any unnecessary startup programs."

    try {
        Start-Process "taskmgr.exe"
        Write-Host "Task Manager opened. Use the Startup tab to review startup items." -ForegroundColor Green
    } catch {
        $startupStatus = "Warning"
        $startupOutput = "Failed to start Task Manager. Error: $_"
        Write-Host $startupOutput -ForegroundColor Red
    }

    Add-SectionResult -Name "Startup Optimization" -Status $startupStatus -Output $startupOutput

    # 3. CHKDSK scheduling (C:)
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 3: Schedule CHKDSK on C" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $chkdskStatus = "Scheduled"
    $chkdskOutput = @"
CHKDSK /x /f /r has been scheduled to run on the next boot for drive C.

After the system restarts and runs the file system check, open the 'Maintenance Results' folder on the Desktop and run:
Run CHKDSK Results.bat

That script will read the CHKDSK log from Event Viewer and update this section in the HTML report.
"@

    try {
        Write-Host "Scheduling CHKDSK on C. This may show a prompt message from chkdsk." -ForegroundColor Yellow
        Write-Output 'Y' | chkdsk C: /x /f /r
        Write-Host "CHKDSK scheduled for next boot on C." -ForegroundColor Green

        Write-ChkdskHelperScripts -ChkdskPs1 $chkdskScriptPath -ChkdskBat $chkdskBatPath
        Write-Host "Created CHKDSK helper script and 'Run CHKDSK Results.bat' in $desktopPath" -ForegroundColor Green
    } catch {
        $chkdskStatus = "Warning"
        $chkdskOutput = "Failed to schedule CHKDSK on C. Error: $_"
        Write-Host $chkdskOutput -ForegroundColor Red
    }

    Add-SectionResult -Name "File System Check (CHKDSK - C:)" -Status $chkdskStatus -Output $chkdskOutput

# ================================================================
# 4. DISM and SFC (Clean Output, No Progress Lines in HTML)
# ================================================================

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " SECTION 4: DISM and SFC" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

$dismStatus = "Completed"
$dismLines  = New-Object System.Collections.Generic.List[string]

# Phases for DISM
$phases = @(
    @{ Name = "Analyze Component Store"; Command = { 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart } },
    @{ Name = "Start Component Cleanup"; Command = { dism.exe /online /cleanup-image /startcomponentcleanup } },
    @{ Name = "Check Health";            Command = { dism.exe /online /cleanup-image /checkhealth } },
    @{ Name = "Scan Health";             Command = { dism.exe /online /cleanup-image /scanhealth } },
    @{ Name = "Restore Health";          Command = { dism.exe /online /cleanup-image /restorehealth } }
)

$totalPhases  = $phases.Count + 1   # +1 SFC
$currentPhase = 0

# -------------------------------------------------------------
# RUN EACH DISM PHASE — STRIP PROGRESS BARS
# -------------------------------------------------------------
foreach ($phase in $phases) {
    $currentPhase++
    $percent = [int](($currentPhase - 1) / $totalPhases * 100)

    Write-Progress -Activity "DISM and SFC" -Status $phase.Name -PercentComplete $percent
    $dismLines.Add("===== $($phase.Name) =====") | Out-Null

    try {
        # Capture raw output
        $raw = & $phase.Command 2>&1 | ForEach-Object { $_.ToString().Trim() }

        # Remove ALL DISM progress bars (the [===   23.0%] lines)
        $clean = foreach ($line in $raw) {
            if ($line -match "^\[=*.*\%") { continue }   # remove graphical progress bars
            if ($line -eq "") { continue }
            $line
        }

        foreach ($line in $clean) { $dismLines.Add($line) | Out-Null }
        $dismLines.Add("") | Out-Null
    }
    catch {
        $dismStatus = "Warning"
        $err = $_ | Out-String
        $dismLines.Add("===== $($phase.Name) - ERROR =====") | Out-Null
        $dismLines.Add($err) | Out-Null
        Write-Host "Error in $($phase.Name): $err" -ForegroundColor Red
    }
}

# -------------------------------------------------------------
# S F C 
# -------------------------------------------------------------
$currentPhase++
$percent = [int](($currentPhase - 1) / $totalPhases * 100)
Write-Progress -Activity "DISM and SFC" -Status "SFC /SCANNOW" -PercentComplete $percent

$dismLines.Add("===== SFC =====") | Out-Null

try {
    $raw = sfc /scannow 2>&1 | ForEach-Object { $_.Trim() }

    # Remove 100% of noisy lines
    $clean = foreach ($line in $raw) {

        if (-not $line) { continue }

        # Intro noise
        if ($line -match "^Beginning system scan") { continue }
        if ($line -match "^Beginning verification phase") { continue }

        # Remove ANY percentage progress
        if ($line -match "^[A-Za-z ]+[0-9]{1,3}%") { continue }
        if ($line -match "Verification\s+[0-9]{1,3}%") { continue }

        # Remove blank
        if ($line -eq "") { continue }

        $line
    }

    # SFC always ends with a final result message → we keep ONLY that
    $final = $clean | Select-Object -Last 1
    if (-not $final) {
        $final = "SFC completed. See CBS.log for details."
    }

    $dismLines.Add($final) | Out-Null
    Write-Host $final -ForegroundColor Green
}
catch {
    $dismStatus = "Warning"
    $err = $_ | Out-String
    $dismLines.Add("SFC /SCANNOW encountered an error:") | Out-Null
    $dismLines.Add($err) | Out-Null
    Write-Host "Error during SFC: $err" -ForegroundColor Red
}

Write-Progress -Activity "DISM and SFC" -Completed

# Flatten for HTML output
$dismText = ($dismLines | Out-String).Trim()
if ([string]::IsNullOrWhiteSpace($dismText)) {
    $dismText = "DISM and SFC completed."
}

Add-SectionResult -Name "DISM and SFC" -Status $dismStatus -Output $dismText


    # 5. Temp and cache cleanup
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 5: Temp and cache cleanup" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $foldersToClean = @(
        "$env:TEMP",
        "$env:APPDATA\Microsoft\Windows\Recent",
        "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations",
        "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations",
        "$env:LOCALAPPDATA\Microsoft\Windows\INetCache",
        "$env:LOCALAPPDATA\Microsoft\Windows\History",
        "$env:LOCALAPPDATA\Microsoft\Office\16.0\WebServiceCache",
        "$env:LOCALAPPDATA\Packages",
        "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache",
        "C:\Windows\Temp",
        "C:\Windows\Prefetch",
        "C:\Windows\SoftwareDistribution\Download",
        "C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Windows\History",
        "C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Office\16.0\WebServiceCache",
        "C:\ProgramData\Microsoft\Diagnosis",
        "C:\Windows\System32\DriverStore\FileRepository",
        "$env:LOCALAPPDATA\Microsoft\Windows\D3DSCache",
        "$env:LOCALAPPDATA\Microsoft\Windows\Explorer",
        "$env:LOCALAPPDATA\Microsoft\Windows\WebCache",
        "C:\Recycle.Bin",
        "C:\Windows.old",
        "C:\Windows\Panther",
        "$env:LOCALAPPDATA\CrashDumps",
        "C:\Windows\LiveKernelReports",
        "C:\ProgramData\Microsoft\Windows Defender\Scans\History",
        "C:\ProgramData\Microsoft\Windows\WER",
        "C:\Windows\RetailDemo",
        "C:\Windows\Logs\CBS"
    )

    $sizesBefore = @{}
    $sizesAfter  = @{}
    $totalBefore = 0.0
    $totalAfter  = 0.0

    Write-Host "Analyzing folder sizes before cleanup" -ForegroundColor Yellow
    foreach ($folder in $foldersToClean) {
        $cleanPath = Format-Path $folder
        $size = Get-FolderSizeReadable -Path $cleanPath
        $sizesBefore[$cleanPath] = $size
        Write-Host ("{0,-100} {1}" -f $cleanPath, $size)
    }

    Write-Host ""
    Write-Host "Performing cleanup" -ForegroundColor Yellow
    foreach ($folder in $foldersToClean) {
        $cleanPath = Format-Path $folder
        try {
            Remove-Item -Path "$cleanPath\*" -Recurse -Force -ErrorAction SilentlyContinue
        } catch {
        }
    }

    try {
        Clear-RecycleBin -Force -Confirm:$false -ErrorAction SilentlyContinue
    } catch {
    }

    Write-Host ""
    Write-Host "Analyzing folder sizes after cleanup" -ForegroundColor Yellow
    foreach ($folder in $foldersToClean) {
        $cleanPath = Format-Path $folder
        $size = Get-FolderSizeReadable -Path $cleanPath
        $sizesAfter[$cleanPath] = $size
        Write-Host ("{0,-100} {1}" -f $cleanPath, $size)
    }

    foreach ($folder in $foldersToClean) {
        $cleanPath = Format-Path $folder
        $totalBefore += ConvertToGB $sizesBefore[$cleanPath]
        $totalAfter  += ConvertToGB $sizesAfter[$cleanPath]
    }

    $freed = $totalBefore - $totalAfter

    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkGray
    Write-Host ("Total Before Cleanup: {0}" -f (FormatTotal $totalBefore)) -ForegroundColor Red
    Write-Host ("Total After Cleanup : {0}" -f (FormatTotal $totalAfter))  -ForegroundColor Yellow
    Write-Host ("Space Freed         : {0}" -f (FormatTotal $freed))       -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor DarkGray

    $summaryTemp = @"
Total Before Cleanup: $(FormatTotal $totalBefore)
Total After Cleanup : $(FormatTotal $totalAfter)
Space Freed         : $(FormatTotal $freed)
"@

    Add-SectionResult -Name "Temp and Cache Cleanup" -Status "Completed" -Output $summaryTemp

    # 6. Browser cleanup
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 6: Browser cleanup" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $browserSummary = New-Object System.Text.StringBuilder

    $processes = "chrome","msedge","firefox","brave","opera","opera_gx"
    foreach ($p in $processes) {
        Get-Process $p -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    }
    Start-Sleep -Seconds 2

    $chromeProfile   = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
    $edgeProfile     = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default"
    $braveProfile    = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default"
    $operaProfile    = "$env:APPDATA\Opera Software\Opera Stable"
    $operaCache      = "$env:LOCALAPPDATA\Opera Software\Opera Stable"
    $operaGXProfile  = "$env:APPDATA\Opera Software\Opera GX Stable\Default"
    $operaGXCache    = "$env:LOCALAPPDATA\Opera Software\Opera GX Stable\Default"
    $firefoxRoot     = "$env:APPDATA\Mozilla\Firefox\Profiles"

    function Clear-PathSafe {
        param([string]$Path, [string]$Desc)
        if (Test-Path $Path) {
            try {
                Remove-Item -Path $Path -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host ("  Cleared {0}" -f $Desc) -ForegroundColor Green
            } catch {
                Write-Host ("  Failed to clear {0}: {1}" -f $Desc, $_) -ForegroundColor Red
            }
        }
    }

    $browserTargets = @{}

    if (Test-Path $chromeProfile) {
        $browserTargets["Chrome"] = @{
            "Cache"                 = "$chromeProfile\Cache"
            "Code Cache"            = "$chromeProfile\Code Cache"
            "GPUCache"              = "$chromeProfile\GPUCache"
            "History and Downloads" = "$chromeProfile\History"
        }
    }
    if (Test-Path $edgeProfile) {
        $browserTargets["Edge"] = @{
            "Cache"                 = "$edgeProfile\Cache"
            "Code Cache"            = "$edgeProfile\Code Cache"
            "GPUCache"              = "$edgeProfile\GPUCache"
            "History and Downloads" = "$edgeProfile\History"
        }
    }
    if (Test-Path $braveProfile) {
        $browserTargets["Brave"] = @{
            "Cache"                 = "$braveProfile\Cache"
            "Code Cache"            = "$braveProfile\Code Cache"
            "GPUCache"              = "$braveProfile\GPUCache"
            "History and Downloads" = "$braveProfile\History"
        }
    }
    if ((Test-Path $operaProfile) -or (Test-Path $operaCache)) {
        $browserTargets["Opera Stable"] = @{}
        if (Test-Path $operaProfile) {
            $browserTargets["Opera Stable"]["History and Downloads"] = "$operaProfile\History"
        }
        if (Test-Path $operaCache) {
            $browserTargets["Opera Stable"]["Cache"]      = "$operaCache\Cache"
            $browserTargets["Opera Stable"]["GPUCache"]   = "$operaCache\GPUCache"
            $browserTargets["Opera Stable"]["Code Cache"] = "$operaCache\Code Cache"
        }
    }
    if ((Test-Path $operaGXProfile) -or (Test-Path $operaGXCache)) {
        $browserTargets["Opera GX"] = @{}
        if (Test-Path $operaGXProfile) {
            $browserTargets["Opera GX"]["History and Downloads"] = "$operaGXProfile\History"
        }
        if (Test-Path $operaGXCache) {
            $browserTargets["Opera GX"]["Cache"]      = "$operaGXCache\Cache"
            $browserTargets["Opera GX"]["GPUCache"]   = "$operaGXCache\GPUCache"
            $browserTargets["Opera GX"]["Code Cache"] = "$operaGXCache\Code Cache"
        }
    }
    if (Test-Path $firefoxRoot) {
        Get-ChildItem $firefoxRoot | ForEach-Object {
            $profilePath = $_.FullName
            $browserTargets["Firefox ($($_.Name))"] = @{
                "Cache"                 = "$profilePath\cache2"
                "History and Downloads" = "$profilePath\places.sqlite"
            }
        }
    }

    $totalBefore = 0.0
    $totalAfter  = 0.0

    foreach ($browser in $browserTargets.Keys) {
        Write-Host ""
        Write-Host ("=== {0} ===" -f $browser) -ForegroundColor Cyan
        $before = 0.0
        $after  = 0.0

        foreach ($t in $browserTargets[$browser].GetEnumerator()) {
            $size = Get-BrowserFolderSize -Path $t.Value
            $before += ConvertToGB $size
            Write-Host ("{0,-30} {1,10}" -f $t.Key, $size)
        }

        foreach ($t in $browserTargets[$browser].GetEnumerator()) {
            Clear-PathSafe -Path $t.Value -Desc ("{0} ({1})" -f $browser, $t.Key)
        }

        foreach ($t in $browserTargets[$browser].GetEnumerator()) {
            $size = Get-BrowserFolderSize -Path $t.Value
            $after += ConvertToGB $size
            Write-Host ("{0,-30} {1,10}" -f $t.Key, $size)
        }

        $freed = $before - $after
        $freedText = FormatTotal $freed
        Write-Host ("  Freed: {0}" -f $freedText) -ForegroundColor Yellow

        [void]$browserSummary.AppendLine(("{0}: Freed {1}" -f $browser, $freedText))
        $totalBefore += $before
        $totalAfter  += $after
    }

    $freedAll = $totalBefore - $totalAfter

    Write-Host ""
    Write-Host "==========================================" -ForegroundColor DarkGray
    Write-Host ("Total Before Cleanup: {0}" -f (FormatTotal $totalBefore)) -ForegroundColor Red
    Write-Host ("Total After Cleanup : {0}" -f (FormatTotal $totalAfter))  -ForegroundColor Yellow
    Write-Host ("Space Freed         : {0}" -f (FormatTotal $freedAll))    -ForegroundColor Green
    Write-Host "==========================================" -ForegroundColor DarkGray

    $browserSummaryText = @"
Per-browser freed space:
$($browserSummary.ToString())

Total freed: $(FormatTotal $freedAll)
"@

    Add-SectionResult -Name "Browser Cleanup" -Status "Completed" -Output $browserSummaryText

    # 7. Windows Updates (single progress bar, summarized HTML)
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 7: Windows Updates" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $wuStatus = "Completed"
    $wuDetails = New-Object System.Text.StringBuilder

    try {
        Write-Host "Preparing PSWindowsUpdate..." -ForegroundColor Yellow
        Write-Progress -Activity "Windows Updates" -Status "Preparing module..." -PercentComplete 5

        Install-PackageProvider -Name NuGet -Force -ErrorAction SilentlyContinue | Out-Null
        Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted -ErrorAction SilentlyContinue
        Install-Module -Name PSWindowsUpdate -Force -ErrorAction SilentlyContinue | Out-Null
        Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue

        Write-Host "Checking and installing Windows updates (no reboot)..." -ForegroundColor Yellow
        Write-Progress -Activity "Windows Updates" -Status "Installing updates..." -PercentComplete 25

        $oldProgress = $Global:ProgressPreference
        $Global:ProgressPreference = 'SilentlyContinue'

        $wuOut = Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade' -ErrorAction Continue

        $Global:ProgressPreference = $oldProgress

        Write-Progress -Activity "Windows Updates" -Status "Finalizing..." -PercentComplete 90

        if ($wuOut) {
            $installed = $wuOut | Where-Object { $_.Result -match 'Installed|Succeeded' }
            $other     = $wuOut | Where-Object { $_.Result -notmatch 'Installed|Succeeded' }

            if ($installed) {
                $wuDetails.AppendLine("Installed updates:") | Out-Null
                foreach ($u in $installed) {
                    $kb = if ($u.KB) { " ($($u.KB))" } else { "" }
                    $wuDetails.AppendLine("- $($u.Title)$kb - $($u.Result)") | Out-Null
                }
                $wuDetails.AppendLine("") | Out-Null
            } else {
                $wuDetails.AppendLine("No updates were installed.") | Out-Null
                $wuDetails.AppendLine("") | Out-Null
            }

            if ($other) {
                $wuDetails.AppendLine("Other update results:") | Out-Null
                foreach ($u in $other) {
                    $kb = if ($u.KB) { " ($($u.KB))" } else { "" }
                    $wuDetails.AppendLine("- $($u.Title)$kb - $($u.Result)") | Out-Null
                }
            }
        } else {
            $wuDetails.AppendLine("Install-WindowsUpdate returned no summary objects. No updates may have been available.") | Out-Null
        }

        Write-Progress -Activity "Windows Updates" -Completed
        Write-Host "Windows Updates step finished. See HTML report for summary." -ForegroundColor Green
    } catch {
        $wuStatus = "Warning"
        $msg = "Windows Updates encountered an issue: $($_ | Out-String)"
        Write-Host $msg -ForegroundColor Red
        $wuDetails.AppendLine($msg) | Out-Null
        Write-Progress -Activity "Windows Updates" -Completed
    }

    $wuText = $wuDetails.ToString().Trim()
    if ([string]::IsNullOrWhiteSpace($wuText)) {
        $wuText = "Windows Updates step ran. Check Windows Update history for full details."
    }

    Add-SectionResult -Name "Windows Updates" -Status $wuStatus -Output $wuText

    # 8. App Updates (winget) - single overall progress, cleaned output
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 8: App Updates (winget)" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $appStatus  = "Completed"
    $appDetails = New-Object System.Text.StringBuilder

    if (Get-Command winget -ErrorAction SilentlyContinue) {
        try {
            Write-Host "Querying apps that have updates available..." -ForegroundColor Yellow
            Write-Progress -Activity "App Updates (winget)" -Status "Checking for updates..." -PercentComplete 5

            $jsonText = winget upgrade --include-unknown --output json 2>$null

            if (-not $jsonText) {
                $appDetails.AppendLine("No apps reported as upgradable by winget.") | Out-Null
                Write-Host "No apps reported as upgradable by winget." -ForegroundColor Yellow
                Write-Progress -Activity "App Updates (winget)" -Completed
            } else {
                $pending = $null
                try {
                    $pending = $jsonText | ConvertFrom-Json
                } catch {
                    $pending = $null
                }

                $packages = @()
                if ($pending -is [System.Array]) {
                    $packages = $pending
                } elseif ($pending -and $pending.Sources) {
                    foreach ($source in $pending.Sources) {
                        if ($source.Packages) { $packages += $source.Packages }
                    }
                }

                if (-not $packages -or $packages.Count -eq 0) {
                    $appDetails.AppendLine("No apps reported as upgradable by winget.") | Out-Null
                    Write-Host "No apps reported as upgradable by winget." -ForegroundColor Yellow
                    Write-Progress -Activity "App Updates (winget)" -Completed
                } else {
                    $totalPkgs = $packages.Count
                    $index = 0
                    $appDetails.AppendLine("Apps updates attempted:") | Out-Null

                    foreach ($pkg in $packages) {
                        $index++
                        $name = $pkg.Name
                        if (-not $name -and $pkg.PackageName) { $name = $pkg.PackageName }
                        $id = $pkg.Id
                        if (-not $id -and $pkg.PackageIdentifier) { $id = $pkg.PackageIdentifier }
                        if (-not $name) { $name = $id }
                        if (-not $name) { $name = "Unknown package" }

                        $percent = [int](($index / $totalPkgs) * 100)
                        Write-Progress -Activity "App Updates (winget)" -Status "Updating $name ($index of $totalPkgs)" -PercentComplete $percent

                        Write-Host ""
                        Write-Host ("Updating {0}" -f $name) -ForegroundColor Yellow

                        try {
                            $outLines = winget upgrade --id "$id" --include-unknown --accept-source-agreements --accept-package-agreements --silent 2>&1

                            # Filter out spinner/progress-only lines like -, \, |, /
                            $cleanLines = $outLines | Where-Object { $_ -notmatch '^\s*[-\\|/]\s*$' }

                            foreach ($line in $cleanLines) {
                                if ($line -ne "") { Write-Host $line }
                            }

                            $joined = ($outLines | Out-String)
                            $statusText = "Unknown result"
                            if ($joined -match 'No applicable update') {
                                $statusText = "No update available"
                            } elseif ($joined -match 'Successfully installed') {
                                $statusText = "Installed"
                            } elseif ($joined -match 'Successfully upgraded') {
                                $statusText = "Installed"
                            } elseif ($joined -match 'is already installed') {
                                $statusText = "Already up to date"
                            } elseif ($joined -match 'error' -or $joined -match 'Failed' -or $joined -match '0x[0-9a-fA-F]+') {
                                $statusText = "Failed"
                            }

                            $lineText = "- $name [$id] - $statusText"
                            $appDetails.AppendLine($lineText) | Out-Null
                            Write-Host $lineText -ForegroundColor Cyan
                        } catch {
                            $errLine = "- $name [$id] - Failed to run winget upgrade. Error: $($_ | Out-String)"
                            $appDetails.AppendLine($errLine) | Out-Null
                            Write-Host $errLine -ForegroundColor Red
                        }
                    }

                    Write-Progress -Activity "App Updates (winget)" -Completed
                }
            }
        } catch {
            $appStatus = "Warning"
            $msg = "winget upgrade encountered an error. Error: $($_ | Out-String)"
            Write-Host $msg -ForegroundColor Red
            $appDetails.AppendLine($msg) | Out-Null
            Write-Progress -Activity "App Updates (winget)" -Completed
        }
    } else {
        $appStatus = "Warning"
        $msg = "winget is not installed on this system. App updates were skipped."
        $appDetails.AppendLine($msg) | Out-Null
        Write-Host $msg -ForegroundColor Yellow
    }

    $appText = $appDetails.ToString().Trim()
    if ([string]::IsNullOrWhiteSpace($appText)) {
        $appText = "App updates step ran. Check winget logs or console output for full details."
    }

    Add-SectionResult -Name "App Updates (winget)" -Status $appStatus -Output $appText

    # 9. Drive Optimization
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 9: Drive optimization" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    $optSummary = New-Object System.Text.StringBuilder
    $volumes = Get-Volume | Where-Object { $_.DriveType -ne 'Removable' -and $_.DriveLetter }

    foreach ($v in $volumes) {
        try {
            Optimize-Volume -DriveLetter $v.DriveLetter -ErrorAction Stop
            $msg = "Drive {0}: Optimization completed." -f $v.DriveLetter
            Write-Host $msg -ForegroundColor Green
            [void]$optSummary.AppendLine($msg)
        } catch {
            $msg = "Drive {0}: Optimization not supported or failed. {1}" -f $v.DriveLetter, $_
            Write-Host $msg -ForegroundColor Yellow
            [void]$optSummary.AppendLine($msg)
        }
    }

    Add-SectionResult -Name "Drive Optimization" -Status "Completed" -Output $optSummary.ToString()

    # 10. Generate HTML report (do NOT auto-open)
    Write-Host ""
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host " SECTION 10: Generate HTML report" -ForegroundColor Cyan
    Write-Host "==========================================" -ForegroundColor Cyan
    Write-Host ""

    Write-MaintenanceReportHtml -Sections $sections -Path $reportPath
    Write-Host ("HTML report written to: {0}" -f $reportPath) -ForegroundColor Green

    Write-Host ""
    Write-Host "Maintenance script complete. System will now restart to run CHKDSK on C if it was scheduled." -ForegroundColor Green
    Write-Host ("After the restart, open '{0}' and run 'Run CHKDSK Results.bat' to update the report with CHKDSK details." -f $desktopPath) -ForegroundColor Yellow

    Shutdown /r /t 5
}
finally {
    Restore-PowerPlan -Guid $previousGuid
}
