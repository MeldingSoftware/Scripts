#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# ----------------------------------------------------
# Paths & Base Setup
# ----------------------------------------------------
$desktopPath = Join-Path ([Environment]::GetFolderPath("Desktop")) "Maintenance Results"

if (-not (Test-Path $desktopPath)) {
    New-Item -Path $desktopPath -ItemType Directory | Out-Null
}

$reportPath        = Join-Path $desktopPath "Maintenance_Report.html"
$dismLogPath       = Join-Path $desktopPath "DISM_SFC.txt"
$tempLogPath       = Join-Path $desktopPath "Temp.txt"
$browserLogPath    = Join-Path $desktopPath "Browsers.txt"
$wuLogPath         = Join-Path $desktopPath "WindowsUpdates.txt"
$appLogPath        = Join-Path $desktopPath "AppUpdates.txt"
$optimizeLogPath   = Join-Path $desktopPath "OptimizeDrives.txt"
$chkdskScriptPath  = Join-Path $desktopPath "ChkdskResults.ps1"
$chkdskBatPath     = Join-Path $desktopPath "Run Me.bat"
$batteryReportPath = Join-Path $desktopPath "Battery_Report.html"   # temp helper file (we delete it later)

# ----------------------------------------------------
# Power Plan Handling
# ----------------------------------------------------
$schemeGuid  = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67'
$schemeName  = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'

function assert-ok {
    if ($LASTEXITCODE -ne 0) { throw "Command failed with exit code $LASTEXITCODE" }
}

# Save original active scheme (if possible)
$prevGuid = $null
try {
    $prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
} catch {
    Write-Host "Could not read current power scheme: $($_.Exception.Message)" -ForegroundColor Yellow
}

$scriptHadFatalError = $false

try {
    # --- Configure "Always on" plan but don't treat errors here as fatal ---
    try {
        $existingPlans = powercfg -list
        $planExists = $existingPlans -match $schemeGuid

        if (-not $planExists) {
            $null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
            $null = powercfg -changename $schemeGuid $schemeName $schemeDescr
        }

        powercfg -setactive $schemeGuid

        $settings = 'monitor-timeout-ac','monitor-timeout-dc','disk-timeout-ac','disk-timeout-dc',
                    'standby-timeout-ac','standby-timeout-dc','hibernate-timeout-ac','hibernate-timeout-dc'

        foreach ($setting in $settings) {
            powercfg -change $setting 0
        }

        Write-Host "Power plan set to '$schemeName' for this session.`n" -ForegroundColor Green
    }
    catch {
        Write-Host "Power plan configuration skipped due to error: $($_.Exception.Message)`n" -ForegroundColor Yellow
    }

    # ------------------------------------------------
    # Microsoft Store (manual)
    # ------------------------------------------------
    try {
        Write-Host "Microsoft Store Check for updates (manual)" -ForegroundColor Cyan
        Start-Process "ms-windows-store://updates"
        Write-Host "[DONE] Continuing script`n" -ForegroundColor Green
    } catch {
        Write-Host "Store updates step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
    }

    # ------------------------------------------------
    # Startup optimization (manual)
    # ------------------------------------------------
    try {
        Write-Host "Optimize startup (manual)" -ForegroundColor Cyan
        Start-Process taskmgr
        Write-Host "Click on Startup tab and disable unnecessary programs."
        Write-Host "[DONE] Continuing script`n" -ForegroundColor Green
    } catch {
        Write-Host "Startup optimization step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
    }

    # ------------------------------------------------
    # CHKDSK (scheduled on next boot)
    # ------------------------------------------------
    try {
        Write-Host "Scheduling CHKDSK on next boot (C: /x /f /r)" -ForegroundColor Cyan
        Write-Output 'Y' | chkdsk C: /x /f /r
        Write-Host "[DONE] CHKDSK scheduled`n" -ForegroundColor Green
    } catch {
        Write-Host "CHKDSK step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
    }

    # ------------------------------------------------
    # DISM and SFC -> DISM_SFC.txt
    # ------------------------------------------------
    try {
        $null = Start-Transcript -Path $dismLogPath -ErrorAction SilentlyContinue
        Write-Host "DISM and SFC" -ForegroundColor Cyan
        Write-Host ""

        Write-Host "Analyze Component Store`n"
        Write-Output 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart
        Write-Host "-----------------------------------------------------------------------------------------------------------`n"

        Write-Host "Start Component Cleanup`n"
        dism.exe /online /cleanup-image /startcomponentcleanup
        Write-Host "-----------------------------------------------------------------------------------------------------------`n"

        Write-Host "Check Health`n"
        dism.exe /online /cleanup-image /checkhealth
        Write-Host "-----------------------------------------------------------------------------------------------------------`n"

        Write-Host "Scan Health`n"
        dism.exe /online /cleanup-image /scanhealth
        Write-Host "-----------------------------------------------------------------------------------------------------------`n"

        Write-Host "Restore Health`n"
        dism.exe /online /cleanup-image /restorehealth
        Write-Host "-----------------------------------------------------------------------------------------------------------`n"

        Write-Host "SFC /scannow`n"
        sfc /scannow
        Write-Host ""

        Write-Host "[DONE] DISM and SFC`n" -ForegroundColor Green
        Stop-Transcript | Out-Null
    } catch {
        Write-Host "DISM/SFC step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
        try { Stop-Transcript | Out-Null } catch {}
    }

    # ------------------------------------------------
    # Browser Cleanup -> Browsers.txt
    # ------------------------------------------------
    try {
        $null = Start-Transcript -Path $browserLogPath -ErrorAction SilentlyContinue
        Write-Host "Browser Cleanup" -ForegroundColor Cyan

        $processes = "chrome","msedge","firefox","brave","opera","opera_gx"
        foreach ($p in $processes) {
            Get-Process $p -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds 2

        # --- Helpers just for browser cleanup ---
        function Get-BrowserFolderSizeReadable {
            param ([string]$Path)
            if (-not (Test-Path $Path)) { return "0 MB" }
            try {
                $items = Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue |
                         Where-Object { -not $_.PSIsContainer }
                $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
                if ($totalBytes -ge 1GB) { return "{0:N2} GB" -f ($totalBytes/1GB) }
                else                     { return "{0:N2} MB" -f ($totalBytes/1MB) }
            } catch { return "0 MB" }
        }

        function ConvertToGB {
            param($size)
            if     ($size -match "GB") { return [double]($size -replace " GB","") }
            elseif ($size -match "MB") { return [double]($size -replace " MB","") / 1024 }
            else                       { return 0 }
        }

        function FormatTotal {
            param($value)
            if ($value -ge 1) { return "{0:N2} GB" -f $value }
            else              { return "{0:N2} MB" -f ($value * 1024) }
        }

        function Clear-Path($path, $desc) {
            if (Test-Path $path) {
                try {
                    Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
                    Write-Host "  Cleared $desc" -ForegroundColor Green
                } catch {
                    Write-Host ("  Failed to clear {0}: {1}" -f $desc, $_) -ForegroundColor Red
                }
            }
        }

        # Profiles
        $chromeProfile   = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
        $edgeProfile     = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default"
        $braveProfile    = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default"
        $operaProfile    = "$env:APPDATA\Opera Software\Opera Stable"
        $operaCache      = "$env:LOCALAPPDATA\Opera Software\Opera Stable"
        $operaGXProfile  = "$env:APPDATA\Opera Software\Opera GX Stable\Default"
        $operaGXCache    = "$env:LOCALAPPDATA\Opera Software\Opera GX Stable\Default"
        $firefoxRoot     = "$env:APPDATA\Mozilla\Firefox\Profiles"

        $browserTargets = @{}

        if (Test-Path $chromeProfile) {
            $browserTargets["Chrome"] = @{
                "Cache"               = "$chromeProfile\Cache"
                "Code Cache"          = "$chromeProfile\Code Cache"
                "GPUCache"            = "$chromeProfile\GPUCache"
                "History & Downloads" = "$chromeProfile\History"
            }
        }

        if (Test-Path $edgeProfile) {
            $browserTargets["Edge"] = @{
                "Cache"               = "$edgeProfile\Cache"
                "Code Cache"          = "$edgeProfile\Code Cache"
                "GPUCache"            = "$edgeProfile\GPUCache"
                "History & Downloads" = "$edgeProfile\History"
            }
        }

        if (Test-Path $braveProfile) {
            $browserTargets["Brave"] = @{
                "Cache"               = "$braveProfile\Cache"
                "Code Cache"          = "$braveProfile\Code Cache"
                "GPUCache"            = "$braveProfile\GPUCache"
                "History & Downloads" = "$braveProfile\History"
            }
        }

        if ((Test-Path $operaProfile) -or (Test-Path $operaCache)) {
            $browserTargets["Opera Stable"] = @{}
            if (Test-Path $operaProfile) {
                $browserTargets["Opera Stable"]["History & Downloads"] = "$operaProfile\History"
            }
            if (Test-Path $operaCache) {
                $browserTargets["Opera Stable"]["Cache"]      = "$operaCache\Cache"
                $browserTargets["Opera Stable"]["GPUCache"]   = "$operaCache\GPUCache"
                $browserTargets["Opera Stable"]["Code Cache"] = "$operaCache\Code Cache"
            }
        }

        if ((Test-Path $operaGXProfile) -or (Test-Path $operaGXCache)) {
            $browserTargets["Opera GX"] = @{}
            if (Test-Path $operaGXProfile) {
                $browserTargets["Opera GX"]["History & Downloads"] = "$operaGXProfile\History"
            }
            if (Test-Path $operaGXCache) {
                $browserTargets["Opera GX"]["Cache"]      = "$operaGXCache\Cache"
                $browserTargets["Opera GX"]["GPUCache"]   = "$operaGXCache\GPUCache"
                $browserTargets["Opera GX"]["Code Cache"] = "$operaGXCache\Code Cache"
            }
        }

        if (Test-Path $firefoxRoot) {
            Get-ChildItem $firefoxRoot | ForEach-Object {
                $profilePath = $_.FullName
                $browserTargets["Firefox ($($_.Name))"] = @{
                    "Cache"               = "$profilePath\cache2"
                    "History & Downloads" = "$profilePath\places.sqlite"
                }
            }
        }

        $totalBefore = 0
        $totalAfter  = 0

        foreach ($browser in $browserTargets.Keys) {
            Write-Host "`n=== $browser ===" -ForegroundColor Cyan
            $before = 0
            $after  = 0

            foreach ($t in $browserTargets[$browser].GetEnumerator()) {
                $size = Get-BrowserFolderSizeReadable -Path $t.Value
                $before += ConvertToGB $size
                "{0,-30} {1,10}" -f $t.Key, $size
            }

            foreach ($t in $browserTargets[$browser].GetEnumerator()) {
                Clear-Path $t.Value $t.Key
            }

            foreach ($t in $browserTargets[$browser].GetEnumerator()) {
                $size = Get-BrowserFolderSizeReadable -Path $t.Value
                $after += ConvertToGB $size
                "{0,-30} {1,10}" -f $t.Key, $size
            }

            $freed = $before - $after
            Write-Host ("  >>> Freed: {0}" -f (FormatTotal $freed)) -ForegroundColor Yellow

            $totalBefore += $before
            $totalAfter  += $after
        }

        $freedAll = $totalBefore - $totalAfter

        Write-Host "`n==========================================" -ForegroundColor DarkGray
        Write-Host ("Total Before Cleanup: {0}" -f (FormatTotal $totalBefore)) -ForegroundColor Red
        Write-Host ("Total After Cleanup : {0}"  -f (FormatTotal $totalAfter)) -ForegroundColor Yellow
        Write-Host ("Space Freed         : {0}"  -f (FormatTotal $freedAll))   -ForegroundColor Green
        Write-Host "==========================================" -ForegroundColor DarkGray
        Write-Host "`n[DONE] Browser Cleanup completed`n" -ForegroundColor Green

        Stop-Transcript | Out-Null
    } catch {
        Write-Host "Browser cleanup step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
        try { Stop-Transcript | Out-Null } catch {}
    }

    # ------------------------------------------------
    # Temp / Cache Cleanup -> Temp.txt
    # ------------------------------------------------
    try {
        $null = Start-Transcript -Path $tempLogPath -ErrorAction SilentlyContinue
        Write-Host "Delete Temp Files and Cache Cleanup" -ForegroundColor Cyan
        Write-Host ""

        $foldersToClean = @(
            "$env:TEMP",
            "$env:APPDATA\Microsoft\Windows\Recent",
            "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations",
            "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations",
            "$env:LOCALAPPDATA\Microsoft\Windows\INetCache",
            "$env:LOCALAPPDATA\Microsoft\Windows\History",
            "$env:LOCALAPPDATA\Microsoft\Office\16.0\WebServiceCache",
            "$env:LOCALAPPDATA\Packages",
            "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache",
            "C:\Windows\Temp",
            "C:\Windows\Prefetch",
            "C:\Windows\SoftwareDistribution\Download",
            "C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Windows\History",
            "C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Office\16.0\WebServiceCache",
            "C:\ProgramData\Microsoft\Diagnosis",
            "C:\Windows\System32\DriverStore\FileRepository",
            "$env:LOCALAPPDATA\Microsoft\Windows\D3DSCache",
            "$env:LOCALAPPDATA\Microsoft\Windows\Explorer",
            "$env:LOCALAPPDATA\Microsoft\Windows\WebCache",
            "C:\Recycle.Bin",
            "C:\Windows.old",
            "C:\Windows\Panther",
            "$env:LOCALAPPDATA\CrashDumps",
            "C:\Windows\LiveKernelReports",
            "C:\ProgramData\Microsoft\Windows Defender\Scans\History",
            "C:\ProgramData\Microsoft\Windows\WER",
            "C:\Windows\RetailDemo",
            "C:\Windows\Logs\CBS"
        )

        function Get-FolderSizeReadable {
            param ([string]$Path)

            $expanded = [System.Environment]::ExpandEnvironmentVariables($Path) -replace '\\{2,}', '\'

            if ($expanded -eq 'C:\Recycle.Bin') {
                $realRecyclePath = 'C:\$Recycle.Bin'
                if (-not (Test-Path $realRecyclePath)) { return "Empty" }

                try {
                    $sizeBytes = (Get-ChildItem -Path "$realRecyclePath\*" -Recurse -Force -ErrorAction Stop |
                                  Measure-Object -Property Length -Sum).Sum
                    if ($sizeBytes -ge 1GB) { return "{0:N2} GB" -f ($sizeBytes / 1GB) }
                    else                    { return "{0:N2} MB" -f ($sizeBytes / 1MB) }
                } catch { return "Access Denied" }
            }

            if (-not (Test-Path $expanded)) { return "Doesn't Exist" }

            try {
                $items = Get-ChildItem -Path $expanded -Recurse -Force -ErrorAction Stop |
                         Where-Object { -not $_.PSIsContainer }
                $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum

                if    ($totalBytes -ge 1GB) { return "{0:N2} GB" -f ($totalBytes / 1GB) }
                else                        { return "{0:N2} MB" -f ($totalBytes / 1MB) }
            } catch { return "Access Denied" }
        }

        function ConvertToGB ($size) {
            if     ($size -match "GB") { return [double]($size -replace " GB", "") }
            elseif ($size -match "MB") { return [double]($size -replace " MB", "") / 1024 }
            else                       { return 0 }
        }

        function Format-Path ($rawPath) {
            return [System.Environment]::ExpandEnvironmentVariables($rawPath) -replace '\\{2,}', '\'
        }

        function FormatTotal($value) {
            if ($value -ge 1) { return "{0:N2} GB" -f $value }
            else              { return "{0:N2} MB" -f ($value * 1024) }
        }

        $sizesBefore = @{}
        $sizesAfter  = @{}

        Write-Host "Analyzing folder sizes before cleanup" -ForegroundColor Yellow
        foreach ($folder in $foldersToClean) {
            $cleanPath = Format-Path $folder
            $size      = Get-FolderSizeReadable -Path $cleanPath
            $sizesBefore[$cleanPath] = $size
            "{0,-100} {1}" -f $cleanPath, $size
        }

        Write-Host "`nCleaning up" -ForegroundColor Yellow
        foreach ($folder in $foldersToClean) {
            $cleanPath = Format-Path $folder
            try {
                Remove-Item -Path "$cleanPath\*" -Recurse -Force -ErrorAction SilentlyContinue
            } catch {}
        }

        try { Clear-RecycleBin -Force -Confirm:$false -ErrorAction SilentlyContinue } catch {}

        Write-Host "`nAnalyzing folder sizes after cleanup" -ForegroundColor Yellow
        foreach ($folder in $foldersToClean) {
            $cleanPath = Format-Path $folder
            $size      = Get-FolderSizeReadable -Path $cleanPath
            $sizesAfter[$cleanPath] = $size
            "{0,-100} {1}" -f $cleanPath, $size
        }

        $totalBefore = 0
        $totalAfter  = 0

        foreach ($folder in $foldersToClean) {
            $cleanPath = Format-Path $folder
            $totalBefore += ConvertToGB $sizesBefore[$cleanPath]
            $totalAfter  += ConvertToGB  $sizesAfter[$cleanPath]
        }

        $freed = $totalBefore - $totalAfter

        Write-Host "`n==========================================" -ForegroundColor DarkGray
        Write-Host ("Total Before Cleanup: {0}" -f (FormatTotal $totalBefore)) -ForegroundColor Red
        Write-Host ("Total After Cleanup : {0}" -f (FormatTotal $totalAfter))  -ForegroundColor Yellow
        Write-Host ("Space Freed         : {0}" -f (FormatTotal $freed))        -ForegroundColor Green
        Write-Host "==========================================" -ForegroundColor DarkGray
        Write-Host "`n[DONE] Temp Files and Cache Cleanup completed`n" -ForegroundColor Green

        Stop-Transcript | Out-Null
    } catch {
        Write-Host "Temp/cache cleanup step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
        try { Stop-Transcript | Out-Null } catch {}
    }

    # ------------------------------------------------
    # Windows Updates -> WindowsUpdates.txt
    # ------------------------------------------------
    try {
        Write-Host "Windows Updates`n" -ForegroundColor Cyan
        Install-PackageProvider -Name NuGet -Force
        Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
        Install-Module -Name PSWindowsUpdate -Force
        Import-Module PSWindowsUpdate

        Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade' |
            Out-File -FilePath $wuLogPath -Encoding UTF8

        Write-Host "[DONE] Windows updates completed`n" -ForegroundColor Green
    } catch {
        Write-Host "Windows Update step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
    }

    # ------------------------------------------------
    # App Updates (winget) -> AppUpdates.txt
    # ------------------------------------------------
    try {
        $null = Start-Transcript -Path $appLogPath -ErrorAction SilentlyContinue
        Write-Host "App Updates (winget)" -ForegroundColor Cyan
        Write-Host ""

        winget upgrade -h --all --include-unknown `
            --accept-source-agreements `
            --accept-package-agreements

        Write-Host "`n[DONE] App Updates (winget) completed`n" -ForegroundColor Green
        Stop-Transcript | Out-Null
    } catch {
        Write-Host "winget step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
        try { Stop-Transcript | Out-Null } catch {}
    }

    # ------------------------------------------------
    # Optimize Drives -> OptimizeDrives.txt
    # ------------------------------------------------
    try {
        $null = Start-Transcript -Path $optimizeLogPath -ErrorAction SilentlyContinue
        Write-Host "Optimize drives" -ForegroundColor Cyan
        Write-Host ""

        $Volumes = Get-Volume | Where-Object {
            $_.DriveLetter -and $_.DriveType -ne 'Removable'
        }

        foreach ($Volume in $Volumes) {
            Write-Host "Optimizing $($Volume.DriveLetter):" -ForegroundColor Cyan
            try {
                Optimize-Volume -DriveLetter $Volume.DriveLetter -ErrorAction Stop
                Write-Host "$($Volume.DriveLetter): Optimized`n" -ForegroundColor Green
                Write-Host ""
            }
            catch {
                Write-Host "$($Volume.DriveLetter): Not Supported`n" -ForegroundColor Yellow
                Write-Host ""
            }
        }

        Write-Host "[DONE] Optimize drives completed`n" -ForegroundColor Green
        Stop-Transcript | Out-Null
    } catch {
        Write-Host "Optimize drives step failed: $($_.Exception.Message)`n" -ForegroundColor Yellow
        try { Stop-Transcript | Out-Null } catch {}
    }

    # ------------------------------------------------
    # HTML Report Helpers
    # ------------------------------------------------
    function Convert-ToHtmlSafe {
        param([string]$text)
        if (-not $text) { return "" }
        $t = $text -replace '&','&amp;'
        $t = $t -replace '<','&lt;'
        $t = $t -replace '>','&gt;'
        return $t
    }

    function Get-LogOrMessage {
        param(
            [string]$Path,
            [string]$EmptyMessage
        )
        if (Test-Path $Path) {
            $raw = Get-Content $Path -Raw -ErrorAction SilentlyContinue
            if ([string]::IsNullOrWhiteSpace($raw)) { return $EmptyMessage }
            return $raw
        } else {
            return $EmptyMessage
        }
    }

    function Get-StatusFromContent {
        param([string]$content)

        if ([string]::IsNullOrWhiteSpace($content)) {
            return 'Completed'
        }

        $lower = $content.ToLowerInvariant()

        if (
            $lower -match 'error'       -or
            $lower -match 'failed'      -or
            $lower -match 'failure'     -or
            $lower -match '0x[0-9a-f]+' -or
            $lower -match 'not found'   -or
            $lower -match 'unavailable'
        ) {
            return 'Warning'
        }

        return 'Completed'
    }

    function Remove-TranscriptHeaders {
        param([string]$raw)

        if ([string]::IsNullOrWhiteSpace($raw)) {
            return ""
        }

        $lines = $raw -split "`r?`n"
        $out = New-Object System.Collections.Generic.List[string]

        foreach ($line in $lines) {
            if ($line -match '^\*{5,}$')                    { continue }
            if ($line -match 'transcript start')            { continue }
            if ($line -match 'transcript end')              { continue }
            if ($line -match '^(Start|End) time:')          { continue }
            if ($line -match '^Username:')                  { continue }
            if ($line -match '^RunAs User:')                { continue }
            if ($line -match '^Machine:')                   { continue }
            if ($line -match '^Host Application:')          { continue }
            if ($line -match '^Process ID:')                { continue }
            if ($line -match '^PSVersion:')                 { continue }
            if ($line -match '^PSEdition:')                 { continue }
            if ($line -match '^PSCompatibleVersions:')      { continue }
            if ($line -match '^BuildVersion:')              { continue }
            if ($line -match '^CLRVersion:')                { continue }
            if ($line -match '^WSManStackVersion:')         { continue }
            if ($line -match '^PSRemotingProtocolVersion:') { continue }
            if ($line -match '^SerializationVersion:')      { continue }
            if ($line -match '^Configuration Name:')        { continue }

            $out.Add($line)
        }

        return ($out -join "`r`n")
    }

    function Format-StorageSize {
        param([uint64]$bytes)
        if ($bytes -ge 1TB) { return ("{0:N1} TB" -f ($bytes / 1TB)) }
        if ($bytes -ge 1GB) { return ("{0:N0} GB" -f ($bytes / 1GB)) }
        return ("{0:N0} MB" -f ($bytes / 1MB))
    }

    # ------------------------------------------------
    # Collect System Info for Header
    # ------------------------------------------------
    $os   = Get-CimInstance Win32_OperatingSystem
    $cs   = Get-CimInstance Win32_ComputerSystem
    $cpu  = Get-CimInstance Win32_Processor | Select-Object -First 1
    $gpus = Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue

    $integratedList = @()
    $dedicatedList  = @()

    foreach ($g in $gpus) {
        $name = $g.Name.Trim()

        if ($name -match "Microsoft Basic Render" -or
            $name -match "VMware"                -or
            $name -match "VirtualBox") {
            continue
        }

        if ($name -match "UHD" -or
            $name -match "Iris" -or
            $name -match "Intel" -or
            $name -match "Radeon\(TM\)" -or
            $name -match "Radeon Graphics") {
            $integratedList += $name
        } else {
            $dedicatedList += $name
        }
    }

    $primaryGpu   = ""
    $secondaryGpu = ""

    if ($dedicatedList.Count -gt 0) {
        $primaryGpu = $dedicatedList[0]
        if ($integratedList.Count -gt 0) {
            $secondaryGpu = $integratedList -join " | "
        }
    } elseif ($integratedList.Count -gt 0) {
        $primaryGpu = $integratedList[0]
    } else {
        $primaryGpu = "No GPU Reported"
    }

    $primaryGpuHtml   = Convert-ToHtmlSafe $primaryGpu
    $secondaryGpuHtml = Convert-ToHtmlSafe $secondaryGpu

    $hostname = $env:COMPUTERNAME
    $userName = $env:USERNAME

    # RAM
    try {
        $memModules = Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue
        $totalRamBytes = ($memModules | Measure-Object -Property Capacity -Sum).Sum
        $ramGB = [math]::Round($totalRamBytes / 1GB, 1)

        function Get-DDRType($memType) {
            switch ($memType) {
                20 { return "DDR" }
                21 { return "DDR2" }
                22 { return "DDR2 FB-DIMM" }
                24 { return "DDR3" }
                26 { return "DDR4" }
                34 { return "DDR5" }
                default { return "Unknown" }
            }
        }

        $ramSticks = @()
        foreach ($m in $memModules) {
            $sizeGB = [math]::Round($m.Capacity / 1GB)
            $ddrType = Get-DDRType $m.SMBIOSMemoryType
            $speed   = $m.Speed
            $vendor  = if ($m.Manufacturer) { $m.Manufacturer } else { "Unknown" }
            $ramSticks += ("{0} GB {1} {2} MHz ({3})" -f $sizeGB, $ddrType, $speed, $vendor)
        }
        $ramSticksHtml = ($ramSticks | ForEach-Object { Convert-ToHtmlSafe $_ }) -join '<br />'
    } catch {
        $ramGB = "Unknown"
        $ramSticksHtml = "RAM information unavailable"
    }

    $osName = $os.Caption
    $now    = Get-Date

    # Motherboard
    $baseBoard  = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
    $moboModel  = $null
    $moboVendor = $null
    if ($baseBoard) {
        $moboModel  = $baseBoard.Product
        $moboVendor = $baseBoard.Manufacturer
    }
    if (-not $moboModel)  { $moboModel  = $cs.Model }
    if (-not $moboVendor) { $moboVendor = $cs.Manufacturer }

    # BIOS
    $bios        = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
    $biosVersion = "Unknown"
    $biosDate    = "Unknown"

    if ($bios) {
        if ($bios.SMBIOSBIOSVersion) { $biosVersion = $bios.SMBIOSBIOSVersion }

        $rawDate = $bios.ReleaseDate
        if ($rawDate) {
            try {
                $parsed = [datetime]::Parse($rawDate)
                $biosDate = $parsed.ToString("yyyy-MM-dd")
            } catch {
                try {
                    $parsed = [Management.ManagementDateTimeConverter]::ToDateTime($rawDate)
                    $biosDate = $parsed.ToString("yyyy-MM-dd")
                } catch {}
            }
        }
    }

    # Battery
    $batteryHealthText = "Battery is not installed"
    $batteryFullText   = ""
    $batteryDesignText = ""

    try {
        $designCap = $null
        $fullCap   = $null
        $bats = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue

        if ($bats) {
            $bat = $bats | Select-Object -First 1
            if ($bat.DesignCapacity -and $bat.FullChargeCapacity -and $bat.DesignCapacity -gt 0) {
                $designCap = [double]$bat.DesignCapacity
                $fullCap   = [double]$bat.FullChargeCapacity
            }
        }

        if (-not $designCap -or -not $fullCap) {
            # Create a temporary battery report, scrape the numbers, then delete it later
            powercfg /batteryreport /output "$batteryReportPath" /duration 1 | Out-Null 2>$null

            if (Test-Path $batteryReportPath) {
                $htmlBat = Get-Content $batteryReportPath -Raw -ErrorAction SilentlyContinue
                $mDesign = [regex]::Match($htmlBat, 'DESIGN CAPACITY[^0-9]*([\d,]+)\s*mWh', 'IgnoreCase')
                $mFull   = [regex]::Match($htmlBat, 'FULL CHARGE CAPACITY[^0-9]*([\d,]+)\s*mWh', 'IgnoreCase')

                if ($mDesign.Success -and $mFull.Success) {
                    $designCap = [double]($mDesign.Groups[1].Value -replace ',','')
                    $fullCap   = [double]($mFull.Groups[1].Value -replace ',','')
                }
            }
        }

        if ($designCap -and $fullCap -and $designCap -gt 0) {
            $healthPct = [math]::Round(($fullCap / $designCap) * 100, 0)
            $batteryHealthText = "Health: $healthPct%"
            $batteryFullText   = ("{0:N0} mWh" -f $fullCap)
            $batteryDesignText = ("{0:N0} mWh" -f $designCap)
        }
        elseif ($bats) {
            $batteryHealthText = "Battery detected (health unknown)"
        }
    } catch {
        # leave defaults
    }
    finally {
        # delete Battery_Report.html so it doesn't clutter the folder
        try {
            if (Test-Path $batteryReportPath) { Remove-Item $batteryReportPath -Force -ErrorAction SilentlyContinue }
        } catch {}
    }

    # Storage
    $storageLines = @()
    try {
        $vols = Get-CimInstance Win32_LogicalDisk | Where-Object {
            $_.DriveType -eq 3 -and $_.DeviceID -match "^[A-Z]:$"
        }

        foreach ($v in $vols) {
            $letter = $v.DeviceID
            $free   = Format-StorageSize $v.FreeSpace
            $size   = Format-StorageSize $v.Size

            $type = "Cloud"
            try {
                $parts = Get-CimInstance -Query "
                    ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='$letter'}
                    WHERE AssocClass=Win32_LogicalDiskToPartition
                "

                if ($parts) {
                    foreach ($p in $parts) {
                        $drives = Get-CimInstance -Query "
                            ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($p.DeviceID)'}
                            WHERE AssocClass=Win32_DiskDriveToDiskPartition
                        "

                        if ($drives) {
                            $drive = $drives[0]
                            $model = $drive.Model
                            $media = $drive.MediaType
                            $bus   = $drive.InterfaceType

                            if ($model -match "NVMe" -or $bus -match "NVMe") {
                                $type = "NVMe"
                            }
                            elseif ($media -match "SSD" -or $model -match "SSD") {
                                $type = "SSD"
                            }
                            elseif ($media -match "HDD" -or $model -match "HDD|ST|WD|Seagate|Hitachi|TOSHIBA") {
                                $type = "HDD"
                            }
                            else {
                                $type = "Disk"
                            }

                            break
                        }
                    }
                }
            } catch {}

            $storageLines += ("{0} {1} - {2} free of {3}" -f $letter, $type, $free, $size)
        }
    } catch {}

    if ($storageLines.Count -eq 0) {
        $storageLines = @("Storage information not available.")
    }

    $storageHtml = ($storageLines | ForEach-Object { Convert-ToHtmlSafe $_ }) -join '<br />'

    # ------------------------------------------------
    # Load and Clean Log Contents
    # ------------------------------------------------
    $dismRaw     = Get-LogOrMessage -Path $dismLogPath     -EmptyMessage "No DISM / SFC transcript was found."
    $dismContent = Remove-TranscriptHeaders $dismRaw

    $tempRaw     = Get-LogOrMessage -Path $tempLogPath     -EmptyMessage "No temp cleanup transcript was found."
    $tempContent = Remove-TranscriptHeaders $tempRaw

    $browserRaw  = Get-LogOrMessage -Path $browserLogPath  -EmptyMessage "No browser cleanup transcript was found."
    $browserContent = Remove-TranscriptHeaders $browserRaw

    $optRaw      = Get-LogOrMessage -Path $optimizeLogPath -EmptyMessage "Non-removable volumes were optimized using Optimize-Volume. Details were not captured."
    $optContent  = Remove-TranscriptHeaders $optRaw

    $wuRaw = ""
    if (Test-Path $wuLogPath) {
        $wuRaw = Get-Content $wuLogPath -Raw -ErrorAction SilentlyContinue
    }
    $wuContent = if ([string]::IsNullOrWhiteSpace($wuRaw)) {
        "No Windows updates were available to be installed."
    } else { $wuRaw }

    $appRaw = ""
    if (Test-Path $appLogPath) {
        $appRaw = Get-Content $appLogPath -Raw -ErrorAction SilentlyContinue
    }
    $appContent = if ([string]::IsNullOrWhiteSpace($appRaw)) {
        "No app updates were installed via winget."
    } else {
        Remove-TranscriptHeaders $appRaw
    }
    $appStatus = Get-StatusFromContent $appContent

    # ------------------------------------------------
    # Build Sections for HTML
    # ------------------------------------------------
    $sections = @()

    $sections += [PSCustomObject]@{
        Id      = 'wu'
        Title   = 'Windows Updates'
        Status  = Get-StatusFromContent $wuContent
        Summary = 'Windows and Microsoft updates attempted via PSWindowsUpdate.'
        Content = $wuContent
    }

    $sections += [PSCustomObject]@{
        Id      = 'apps'
        Title   = 'App Updates (winget)'
        Status  = $appStatus
        Summary = 'winget upgrade -h --all --include-unknown was run to update installed applications.'
        Content = $appContent
    }

    $sections += [PSCustomObject]@{
        Id      = 'store'
        Title   = 'Microsoft Store App Updates (Manual)'
        Status  = 'Completed'
        Summary = 'The Microsoft Store Updates page was opened. Review and install Store app updates manually.'
        Content = 'Apps were updated from the Microsoft Store.'
    }

    $sections += [PSCustomObject]@{
        Id      = 'startup'
        Title   = 'Startup Optimization (Manual)'
        Status  = 'Completed'
        Summary = 'Task Manager was opened. Disable unnecessary startup programs manually.'
        Content = 'Startup items were optimized.'
    }

    $sections += [PSCustomObject]@{
        Id      = 'drives'
        Title   = 'Drive Optimization'
        Status  = Get-StatusFromContent $optContent
        Summary = 'Optimize-Volume was run for all non-removable volumes with drive letters.'
        Content = $optContent
    }

    $sections += [PSCustomObject]@{
        Id      = 'chkdsk'
        Title   = 'CHKDSK'
        Status  = 'Warning'
        Summary = 'CHKDSK was scheduled on C: for next boot. After reboot, run Run Me.bat to inject the CHKDSK log into this report.'
        Content = ''
    }

    $sections += [PSCustomObject]@{
        Id      = 'dism'
        Title   = 'DISM and SFC'
        Status  = Get-StatusFromContent $dismContent
        Summary = 'Deployment Image Servicing and Management operations plus System File Checker (SFC /scannow).'
        Content = $dismContent
    }

    $sections += [PSCustomObject]@{
        Id      = 'browser'
        Title   = 'Browser Cleanup'
        Status  = Get-StatusFromContent $browserContent
        Summary = 'Browser caches, code caches, GPU caches, and histories cleared for detected browsers.'
        Content = $browserContent
    }

    $sections += [PSCustomObject]@{
        Id      = 'temp'
        Title   = 'Temp Files and Cache Cleanup'
        Status  = Get-StatusFromContent $tempContent
        Summary = 'Windows temp folders and common cache locations cleaned, with before/after size comparison.'
        Content = $tempContent
    }

    # ------------------------------------------------
    # Build HTML
    # ------------------------------------------------
    $sb = New-Object System.Text.StringBuilder

    $null = $sb.AppendLine('<!DOCTYPE html>')
    $null = $sb.AppendLine('<html lang="en">')
    $null = $sb.AppendLine('<head>')
    $null = $sb.AppendLine('<meta charset="utf-8" />')
    $null = $sb.AppendLine("<title>Maintenance Report - $hostname</title>")
    $null = $sb.AppendLine('<style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: #050608;
            color: #f5f7fb;
            margin: 0;
            padding: 0;
        }
        .page {
            max-width: 1100px;
            margin: 0 auto;
            padding: 24px 16px 40px 16px;
        }
        .title {
            font-size: 30px;
            font-weight: 700;
            margin-bottom: 4px;
            color: #ffffff;
        }
        .subtitle {
            font-size: 14px;
            color: #a0a4b8;
            margin-bottom: 20px;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 12px;
            margin-bottom: 18px;
        }
        .card {
            background: radial-gradient(circle at top left, #17223b, #090b11);
            border-radius: 12px;
            padding: 12px 14px;
            border: 1px solid #1b2338;
            box-shadow: 0 6px 18px rgba(0,0,0,0.6);
        }
        .card-label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7c829a;
            margin-bottom: 4px;
        }
        .card-value {
            font-size: 15px;
            font-weight: 600;
            color: #f5f7fb;
        }
        .card-meta {
            font-size: 12px;
            color: #8f95ad;
            margin-top: 2px;
        }
        .status-row {
            margin: 16px 0 22px 0;
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }
        .status-pill {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 999px;
            border: 1px solid transparent;
            background: rgba(20,25,40,0.95);
        }
        .status-pill.ok {
            border-color: #20c997;
            color: #20c997;
        }
        .status-pill.warn {
            border-color: #ffb347;
            color: #ffb347;
        }
        .section {
            border-radius: 12px;
            border: 1px solid #1c2336;
            margin-bottom: 10px;
            overflow: hidden;
            background: rgba(10,12,20,0.96);
            box-shadow: 0 5px 14px rgba(0,0,0,0.55);
        }
        .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 12px;
            cursor: pointer;
            background: linear-gradient(90deg, rgba(31,45,85,0.9), rgba(16,23,42,0.9));
        }
        .section-header:hover {
            background: linear-gradient(90deg, rgba(45,65,120,0.95), rgba(18,26,48,0.9));
        }
        .section-left {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .section-icon {
            font-size: 13px;
            width: 18px;
            text-align: center;
            color: #9fa6c6;
        }
        .section-title {
            font-size: 14px;
            font-weight: 600;
            color: #f5f7ff;
        }
        .section-status-pill {
            font-size: 12px;
            padding: 3px 8px;
            border-radius: 999px;
            border: 1px solid transparent;
        }
        .section-status-ok {
            border-color: #20c997;
            color: #20c997;
        }
        .section-status-warn {
            border-color: #ffb347;
            color: #ffb347;
        }
        .section-body {
            padding: 10px 12px 12px 12px;
            display: block;
        }
        .section-summary {
            font-size: 13px;
            color: #b4bad6;
            margin-top: 0;
            margin-bottom: 8px;
        }
        pre {
            font-family: "Cascadia Code", "Consolas", "Fira Code", monospace;
            font-size: 12px;
            background: #05070f;
            border-radius: 8px;
            padding: 10px;
            white-space: pre-wrap;
            word-wrap: break-word;
            max-height: 420px;
            overflow: auto;
            border: 1px solid #12182c;
        }
        .footer {
            font-size: 12px;
            color: #737995;
            margin-top: 20px;
            border-top: 1px solid #181e32;
            padding-top: 10px;
        }
    </style>
    <script>
        function toggleSection(id) {
            var body = document.getElementById(id);
            var icon = document.getElementById(id + "-icon");
            if (!body) return;
            if (body.style.display === "none") {
                body.style.display = "block";
                if (icon) icon.textContent = "v";
            } else {
                body.style.display = "none";
                if (icon) icon.textContent = ">";
            }
        }
    </script>')
    $null = $sb.AppendLine('</head>')
    $null = $sb.AppendLine('<body>')
    $null = $sb.AppendLine('<div class="page">')
    $null = $sb.AppendLine('<div class="title">Maintenance Report</div>')
    $null = $sb.AppendLine("<div class=""subtitle"">$($now.ToString("yyyy-MM-dd HH:mm:ss"))</div>")

    # Summary cards
    $null = $sb.AppendLine('<div class="summary-grid">')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">Computer</div>
        <div class="card-value">' + (Convert-ToHtmlSafe $hostname) + '</div>
        <div class="card-meta">User: ' + (Convert-ToHtmlSafe $userName) + '</div>
    </div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">Operating System</div>
        <div class="card-value">' + (Convert-ToHtmlSafe $osName) + '</div>
        <div class="card-meta">BIOS Version: ' + (Convert-ToHtmlSafe $biosVersion) + '</div>
        <div class="card-meta">BIOS Date: ' + (Convert-ToHtmlSafe $biosDate) + '</div>
    </div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">Battery</div>
        <div class="card-value">' + (Convert-ToHtmlSafe $batteryHealthText) + '</div>
        <div class="card-meta">Full: ' + (Convert-ToHtmlSafe $batteryFullText) + '</div>
        <div class="card-meta">Design: ' + (Convert-ToHtmlSafe $batteryDesignText) + '</div>
    </div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">Motherboard</div>
        <div class="card-value">' + (Convert-ToHtmlSafe $moboModel) + '</div>
        <div class="card-meta">MFG: ' + (Convert-ToHtmlSafe $moboVendor) + '</div>
    </div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">CPU</div>
        <div class="card-value">' + (Convert-ToHtmlSafe $cpu.Name) + '</div>
        <div class="card-meta">' + $cpu.NumberOfCores + ' cores / ' + $cpu.NumberOfLogicalProcessors + ' threads</div>
    </div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">GPU</div>
        <div class="card-value">' + $primaryGpuHtml + '</div>' +
        ($(if ($secondaryGpuHtml) { '<div class="card-meta">' + $secondaryGpuHtml + '</div>' } else { '' })) +
    '</div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">RAM</div>
        <div class="card-value">' + $ramGB + ' GB</div>
        <div class="card-meta">' + $ramSticksHtml + '</div>
    </div>')

    $null = $sb.AppendLine('<div class="card">
        <div class="card-label">Storage</div>
        <div class="card-value">Drives</div>
        <div class="card-meta">' + $storageHtml + '</div>
    </div>')

    $null = $sb.AppendLine('</div>') # summary-grid

    # Status pills
    $null = $sb.AppendLine('<div class="status-row">')
    foreach ($sec in $sections) {
        switch ($sec.Status) {
            'Warning' { $cls = 'status-pill warn' }
            default   { $cls = 'status-pill ok' }
        }
        $label = "{0} - {1}" -f $sec.Title, $sec.Status
        $null = $sb.AppendLine("<span id=""pill-$($sec.Id)"" class=""$cls"">" + (Convert-ToHtmlSafe $label) + "</span>")
    }
    $null = $sb.AppendLine('</div>')

    # Detailed sections
    $index = 0
    foreach ($sec in $sections) {
        $index++
        $bodyId = "sec$index"
        $iconId = "$bodyId-icon"
        $encodedContent = Convert-ToHtmlSafe $sec.Content
        $encodedSummary = Convert-ToHtmlSafe $sec.Summary

        switch ($sec.Status) {
            'Warning' { $statusClass = 'section-status-warn' }
            default   { $statusClass = 'section-status-ok' }
        }

        $null = $sb.AppendLine('<div class="section">')
        $null = $sb.AppendLine('<div class="section-header" onclick="toggleSection(''' + $bodyId + ''')">')
        $null = $sb.AppendLine('<div class="section-left">')
        $null = $sb.AppendLine('<span id="' + $iconId + '" class="section-icon">v</span>')
        $null = $sb.AppendLine('<span class="section-title">' + (Convert-ToHtmlSafe $sec.Title) + '</span>')
        $null = $sb.AppendLine('</div>')
        $null = $sb.AppendLine('<span id="sectionstatus-' + $sec.Id + '" class="section-status-pill ' + $statusClass + '">' + (Convert-ToHtmlSafe $sec.Status) + '</span>')
        $null = $sb.AppendLine('</div>')

        $null = $sb.AppendLine('<div id="' + $bodyId + '" class="section-body">')
        $null = $sb.AppendLine('<p class="section-summary">' + $encodedSummary + '</p>')

        if ($sec.Id -eq 'chkdsk') {
            $null = $sb.AppendLine('<pre id="chkdsk-results"><!-- CHKDSK-PLACEHOLDER --></pre>')
        }
        else {
            if (-not [string]::IsNullOrWhiteSpace($sec.Content)) {
                $null = $sb.AppendLine('<pre>' + $encodedContent + '</pre>')
            } else {
                $null = $sb.AppendLine('<pre>No additional details were captured for this section.</pre>')
            }
        }

        $null = $sb.AppendLine('</div>')
        $null = $sb.AppendLine('</div>')
    }

    $null = $sb.AppendLine('<div class="footer">')
    $null = $sb.AppendLine('Maintenance completed at ' + (Convert-ToHtmlSafe ($now.ToString("yyyy-MM-dd HH:mm:ss"))) + '. ')
    $null = $sb.AppendLine('After reboot, use <strong>Run Me.bat</strong> in this folder to inject CHKDSK results into the CHKDSK section.')
    $null = $sb.AppendLine('</div>')

    $null = $sb.AppendLine('</div>')
    $null = $sb.AppendLine('</body>')
    $null = $sb.AppendLine('</html>')

    [System.IO.File]::WriteAllText($reportPath, $sb.ToString(), [System.Text.Encoding]::UTF8)
    Write-Host "HTML report written to: $reportPath" -ForegroundColor Green

    # ------------------------------------------------
    # Cleanup TXT logs (+ Battery_Report.html)
    # ------------------------------------------------
    $logFiles = @(
        $dismLogPath,
        $tempLogPath,
        $browserLogPath,
        $wuLogPath,
        $appLogPath,
        $optimizeLogPath,
        $batteryReportPath
    )

    foreach ($log in $logFiles) {
        if (Test-Path $log) {
            Remove-Item $log -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Host "Intermediate logs removed after HTML generation." -ForegroundColor DarkGray

    # ------------------------------------------------
    # Create CHKDSK helper files (Run Me.bat + ChkdskResults.ps1)
    # ------------------------------------------------
    $chkdskPs1Content = @'
$ErrorActionPreference = "Stop"

function Convert-ToHtmlSafe {
    param([string]$text)
    if (-not $text) { return "" }
    $t = $text -replace "&","&amp;"
    $t = $t -replace "<","&lt;"
    $t = $t -replace ">","&gt;"
    return $t
}

try {
    $reportPath = Join-Path $PSScriptRoot "Maintenance_Report.html"
    if (-not (Test-Path $reportPath)) { exit }

    $found = $false

    $evt = Get-WinEvent -FilterHashtable @{
        LogName = "Application"
        Id      = 1001
    } -MaxEvents 50 |
    Where-Object { $_.ProviderName -eq "Microsoft-Windows-Wininit" } |
    Sort-Object TimeCreated -Descending |
    Select-Object -First 1

    if (-not $evt) {
        $msg  = "No CHKDSK (Microsoft-Windows-Wininit, ID 1001) event found in the Application log."
        $time = Get-Date
    }
    else {
        $msg   = $evt.Message
        $time  = $evt.TimeCreated
        $found = $true
    }

    $header = "File System Check (CHKDSK - C:)`r`nTime: $time`r`n`r`n"
    $full   = $header + $msg
    $encoded = Convert-ToHtmlSafe $full
    $replacement = "<pre>" + $encoded + "</pre>"

    $html = Get-Content -Path $reportPath -Raw

    if ($found) {
        $html = $html -replace '(<span id="pill-chkdsk" class="status-pill)[^"]*(">CHKDSK - )Warning','${1} ok">CHKDSK - Completed'
        $html = $html -replace '(<span id="sectionstatus-chkdsk" class="section-status-pill )section-status-warn(">)(Warning)','${1}section-status-ok">Completed'
    }

    $pattern = '<pre id="chkdsk-results"><!-- CHKDSK-PLACEHOLDER --></pre>'
    $html = $html -replace [regex]::Escape($pattern), $replacement

    Set-Content -Path $reportPath -Value $html -Encoding UTF8
    Start-Process $reportPath
}
catch {
    exit
}
'@

    Set-Content -Path $chkdskScriptPath -Value $chkdskPs1Content -Encoding UTF8

    $chkdskBatContent = @'
@echo off
powershell -NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0ChkdskResults.ps1"
exit
'@

    Set-Content -Path $chkdskBatPath -Value $chkdskBatContent -Encoding ASCII

} catch {
    $scriptHadFatalError = $true
    Write-Host "Fatal error in maintenance script: $($_.Exception.Message)" -ForegroundColor Red
} finally {
    if ($prevGuid) {
        try {
            powercfg -setactive $prevGuid
            Write-Host "Original power plan restored." -ForegroundColor Green
        } catch {
            Write-Host "Failed to restore original power plan: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

# Restart
if (-not $scriptHadFatalError) {
    Write-Host "Restarting computer now..." -ForegroundColor Cyan
    Shutdown /r /t 0
} else {
    Write-Host "Automatic restart skipped because of a fatal error." -ForegroundColor Yellow
}
