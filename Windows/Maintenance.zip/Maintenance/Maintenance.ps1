# Create Maintenance Results On Desktop
$desktopPath = [Environment]::GetFolderPath("Desktop") + "\Maintenance Results"

if (!(Test-Path $desktopPath)) {
    New-Item $desktopPath -ItemType Directory
}

# Disable Sleep
$schemeGuid = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67' 
$schemeName = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'
function assert-ok { if ($LASTEXITCODE -ne 0) { throw } }
$prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
assert-ok
try {
	powercfg -setactive $schemeGuid 2>$null
	if ($LASTEXITCODE -ne 0) { 
    	$null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
    	assert-ok
    	$null = powercfg -changename $schemeGuid $schemeName $schemeDescr
    	$null = powercfg -setactive $schemeGuid
    	assert-ok
    	$settings = 'monitor-timeout-ac', 'monitor-timeout-dc', 'disk-timeout-ac', 'disk-timeout-dc', 'standby-timeout-ac', 'standby-timeout-dc', 'hibernate-timeout-ac', 'hibernate-timeout-dc'
    	foreach ($setting in $settings) {
      	powercfg -change $setting 0 # 0 == Never
      	assert-ok
    }
  }

# Microsoft Store Check for updates (Manually)
Write-Host "Microsoft Store Check for updates (manually)" -ForegroundColor Cyan
Start-Process "ms-windows-store://updates"
Write-Host "[DONE] Continuing script"`n -ForegroundColor Green

# Optimize Startup (Manually)
Write-Host "Optimize startup (manually)" -ForegroundColor Cyan 
taskmgr
Write-Host "Click on the Startup tab and manually disable any unecessary startup programs". 
Write-Host "[DONE] Continuing script"`n -ForegroundColor Green 

# Chkdsk On Next Boot
Write-Host "chkdsk on next boot" -ForegroundColor Cyan 
Write-Output 'Y' | chkdsk C: /x /f /r
Write-Host "[DONE] chkdsk on next boot completed"`n -ForegroundColor Green 

# DISM And SFC
$null = Start-Transcript -Path "$desktopPath\DISM_SFC.txt" -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "DISM and SFC"`n -ForegroundColor Cyan 
Write-Host "Analyze Component Store"`n
Write-Output 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart
Write-Host "-----------------------------------------------------------------------------------------------------------"`n
Write-Host "Start Component Cleanup"`n
dism.exe /online /cleanup-image /startcomponentcleanup
Write-Host "-----------------------------------------------------------------------------------------------------------"`n
Write-Host "Check Health"`n
dism.exe /online /cleanup-image /checkhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------"`n
Write-Host "Scan Health"`n
dism.exe /online /cleanup-image /scanhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------"`n
Write-Host "Restore Health"`n
dism.exe /online /cleanup-image /restorehealth
Write-Host "-----------------------------------------------------------------------------------------------------------"`n
Write-Host "SFC"`n
sfc /scannow
Write-Host ""
Write-Host "[DONE] DISM and SFC completed"`n -ForegroundColor Green 
Stop-Transcript | Out-Null
Write-Host ""

# Delete Temp Files and Cache
$null = Start-Transcript -Path "$desktopPath\Temp.txt" -ErrorAction SilentlyContinue
# Define folders to clean
$foldersToClean = @(
    "$env:TEMP",
    "$env:APPDATA\Microsoft\Windows\Recent",
    "$env:APPDATA\Microsoft\Windows\Recent\AutomaticDestinations",
    "$env:APPDATA\Microsoft\Windows\Recent\CustomDestinations",
    "$env:LOCALAPPDATA\Microsoft\Windows\INetCache",
    "$env:LOCALAPPDATA\Microsoft\Windows\History",
    "$env:LOCALAPPDATA\Microsoft\Office\16.0\WebServiceCache",
    "$env:LOCALAPPDATA\Packages",
    "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache",
    "C:\Windows\Temp",
    "C:\Windows\Prefetch",
    "C:\Windows\SoftwareDistribution\Download",
    "C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Windows\History",
    "C:\Windows\System32\config\systemprofile\AppData\Local\Microsoft\Office\16.0\WebServiceCache",
    "C:\ProgramData\Microsoft\Diagnosis",
    "C:\Windows\System32\DriverStore\FileRepository",
    "$env:LOCALAPPDATA\Microsoft\Windows\D3DSCache",
    "$env:LOCALAPPDATA\Microsoft\Windows\Explorer",
    "$env:LOCALAPPDATA\Microsoft\Windows\WebCache",
    "C:\Recycle.Bin",
    "C:\Windows.old",
    "C:\Windows\Panther",
    "$env:LOCALAPPDATA\CrashDumps",
    "C:\Windows\LiveKernelReports",
    "C:\ProgramData\Microsoft\Windows Defender\Scans\History",
    "C:\ProgramData\Microsoft\Windows\WER",
    "C:\Windows\RetailDemo",
    "C:\Windows\Logs\CBS"
)

# Get folder size formatted
function Get-FolderSizeReadable {
    param ([string]$Path)

    $expanded = [System.Environment]::ExpandEnvironmentVariables($Path) -replace '\\{2,}', '\'

    if ($expanded -eq 'C:\Recycle.Bin') {
        $realRecyclePath = 'C:\$Recycle.Bin'
        if (-not (Test-Path $realRecyclePath)) { return "Empty" }

        try {
            $sizeBytes = (Get-ChildItem -Path "$realRecyclePath\*" -Recurse -Force -ErrorAction Stop | Measure-Object -Property Length -Sum).Sum
            if ($sizeBytes -ge 1GB) {
                return "{0:N2} GB" -f ($sizeBytes / 1GB)
            } else {
                return "{0:N2} MB" -f ($sizeBytes / 1MB)
            }
        } catch {
            return "Access Denied"
        }
    }

    if (-not (Test-Path $expanded)) {
        return "Doesn't Exist"
    }

    try {
        $items = Get-ChildItem -Path $expanded -Recurse -Force -ErrorAction Stop | Where-Object { -not $_.PSIsContainer }
        $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
        if ($totalBytes -ge 1GB) {
            return "{0:N2} GB" -f ($totalBytes / 1GB)
        } else {
            return "{0:N2} MB" -f ($totalBytes / 1MB)
        }
    } catch {
        return "Access Denied"
    }
}

# Helpers
function ConvertToGB ($size) {
    if ($size -match "GB") {
        return [double]($size -replace " GB", "")
    } elseif ($size -match "MB") {
        return [double]($size -replace " MB", "") / 1024
    } else {
        return 0
    }
}

function Format-Path ($rawPath) {
    return [System.Environment]::ExpandEnvironmentVariables($rawPath) -replace '\\{2,}', '\'
}

function FormatTotal($value) {
    if ($value -ge 1) {
        return "{0:N2} GB" -f $value
    } else {
        return "{0:N2} MB" -f ($value * 1024)
    }
}

# Size tracking
$sizesBefore = @{}
$sizesAfter = @{}

Write-Host "Analyzing folder sizes before cleanup" -ForegroundColor Yellow
foreach ($folder in $foldersToClean) {
    $cleanPath = Format-Path $folder
    $size = Get-FolderSizeReadable -Path $cleanPath
    $sizesBefore[$cleanPath] = $size
    "{0,-100} {1}" -f $cleanPath, $size
}

# Cleanup
Write-Host "`nCleaning up" -ForegroundColor Yellow
foreach ($folder in $foldersToClean) {
    $cleanPath = Format-Path $folder
    try {
        Remove-Item -Path "$cleanPath\*" -Recurse -Force -ErrorAction SilentlyContinue
    } catch { }
}

# Clear Recycle Bin
try {
    Clear-RecycleBin -Force -Confirm:$false -ErrorAction SilentlyContinue
} catch { }

# Post-cleanup sizes
Write-Host "`nAnalyzing folder sizes after cleanup" -ForegroundColor Yellow
foreach ($folder in $foldersToClean) {
    $cleanPath = Format-Path $folder
    $size = Get-FolderSizeReadable -Path $cleanPath
    $sizesAfter[$cleanPath] = $size
    "{0,-100} {1}" -f $cleanPath, $size
}

# Totals
$totalBefore = 0
$totalAfter = 0
foreach ($folder in $foldersToClean) {
    $cleanPath = Format-Path $folder
    $totalBefore += ConvertToGB $sizesBefore[$cleanPath]
    $totalAfter  += ConvertToGB $sizesAfter[$cleanPath]
}
$freed = $totalBefore - $totalAfter

# Display summary
Write-Host "`n==========================================" -ForegroundColor DarkGray
Write-Host ("Total Before Cleanup: {0}" -f (FormatTotal $totalBefore)) -ForegroundColor Red
Write-Host ("Total After Cleanup : {0}" -f (FormatTotal $totalAfter))  -ForegroundColor Yellow
Write-Host ("Space Freed         : {0}" -f (FormatTotal $freed))       -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor DarkGray
Write-Host "`n[DONE] Temp Files and Cache cleanup completed.`n" -ForegroundColor Green
Stop-Transcript | Out-Null

# Browser Cleanup
$null = Start-Transcript -Path "$desktopPath\Browsers.txt" -ErrorAction SilentlyContinue
Write-Host "Browser cleanup" -ForegroundColor Cyan

# Kill browsers
$processes = "chrome","msedge","firefox","brave","opera","opera_gx"
foreach ($p in $processes) {
    Get-Process $p -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
}
Start-Sleep -Seconds 2

# Paths
$chromeProfile   = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default"
$edgeProfile     = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default"
$braveProfile    = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default"
$operaProfile    = "$env:APPDATA\Opera Software\Opera Stable"
$operaCache      = "$env:LOCALAPPDATA\Opera Software\Opera Stable"
$operaGXProfile  = "$env:APPDATA\Opera Software\Opera GX Stable\Default"
$operaGXCache    = "$env:LOCALAPPDATA\Opera Software\Opera GX Stable\Default"
$firefoxRoot     = "$env:APPDATA\Mozilla\Firefox\Profiles"

# Helpers
function Get-FolderSizeReadable {
    param ([string]$Path)
    if (-not (Test-Path $Path)) { return "0 MB" }
    try {
        $items = Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer }
        $totalBytes = ($items | Measure-Object -Property Length -Sum).Sum
        if ($totalBytes -ge 1GB) { return "{0:N2} GB" -f ($totalBytes / 1GB) }
        else { return "{0:N2} MB" -f ($totalBytes / 1MB) }
    } catch { return "0 MB" }
}

function ConvertToGB ($size) {
    if ($size -match "GB") { return [double]($size -replace " GB", "") }
    elseif ($size -match "MB") { return [double]($size -replace " MB", "") / 1024 }
    else { return 0 }
}

function FormatTotal ($value) {
    if ($value -ge 1) { return "{0:N2} GB" -f $value }
    else { return "{0:N2} MB" -f ($value * 1024) }
}

function Clear-Path($path, $desc) {
    if (Test-Path $path) {
        try {
            Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "  Cleared $desc" -ForegroundColor Green
        } catch {
            Write-Host ("  Failed to clear {0}: {1}" -f $desc, $_) -ForegroundColor Red
        }
    }
}

# Define cleanup targets
$browserTargets = @{}

if (Test-Path $chromeProfile) {
    $browserTargets["Chrome"] = @{
        "Cache"               = "$chromeProfile\Cache"
        "Code Cache"          = "$chromeProfile\Code Cache"
        "GPUCache"            = "$chromeProfile\GPUCache"
        "History & Downloads" = "$chromeProfile\History"
    }
}

if (Test-Path $edgeProfile) {
    $browserTargets["Edge"] = @{
        "Cache"               = "$edgeProfile\Cache"
        "Code Cache"          = "$edgeProfile\Code Cache"
        "GPUCache"            = "$edgeProfile\GPUCache"
        "History & Downloads" = "$edgeProfile\History"
    }
}

if (Test-Path $braveProfile) {
    $browserTargets["Brave"] = @{
        "Cache"               = "$braveProfile\Cache"
        "Code Cache"          = "$braveProfile\Code Cache"
        "GPUCache"            = "$braveProfile\GPUCache"
        "History & Downloads" = "$braveProfile\History"
    }
}

if ((Test-Path $operaProfile) -or (Test-Path $operaCache)) {
    $browserTargets["Opera Stable"] = @{}
    if (Test-Path $operaProfile) {
        $browserTargets["Opera Stable"]["History & Downloads"] = "$operaProfile\History"
    }
    if (Test-Path $operaCache) {
        $browserTargets["Opera Stable"]["Cache"]      = "$operaCache\Cache"
        $browserTargets["Opera Stable"]["GPUCache"]   = "$operaCache\GPUCache"
        $browserTargets["Opera Stable"]["Code Cache"] = "$operaCache\Code Cache"
    }
}

if ((Test-Path $operaGXProfile) -or (Test-Path $operaGXCache)) {
    $browserTargets["Opera GX"] = @{}
    if (Test-Path $operaGXProfile) {
        $browserTargets["Opera GX"]["History & Downloads"] = "$operaGXProfile\History"
    }
    if (Test-Path $operaGXCache) {
        $browserTargets["Opera GX"]["Cache"]      = "$operaGXCache\Cache"
        $browserTargets["Opera GX"]["GPUCache"]   = "$operaGXCache\GPUCache"
        $browserTargets["Opera GX"]["Code Cache"] = "$operaGXCache\Code Cache"
    }
}

if (Test-Path $firefoxRoot) {
    Get-ChildItem $firefoxRoot | ForEach-Object {
        $profilePath = $_.FullName
        $browserTargets["Firefox ($($_.Name))"] = @{
            "Cache"               = "$profilePath\cache2"
            "History & Downloads" = "$profilePath\places.sqlite"
        }
    }
}

# Run cleanup per browser
$totalBefore = 0; $totalAfter = 0
foreach ($browser in $browserTargets.Keys) {
    Write-Host "`n=== $browser ===" -ForegroundColor Cyan
    $before = 0; $after = 0

    foreach ($t in $browserTargets[$browser].GetEnumerator()) {
        $size = Get-FolderSizeReadable -Path $t.Value
        $before += ConvertToGB $size
        "{0,-30} {1,10}" -f $t.Key, $size
    }

    foreach ($t in $browserTargets[$browser].GetEnumerator()) {
        Clear-Path $t.Value $t.Key
    }

    foreach ($t in $browserTargets[$browser].GetEnumerator()) {
        $size = Get-FolderSizeReadable -Path $t.Value
        $after += ConvertToGB $size
        "{0,-30} {1,10}" -f $t.Key, $size
    }

    $freed = $before - $after
    Write-Host ("  >>> Freed: {0}" -f (FormatTotal $freed)) -ForegroundColor Yellow
    $totalBefore += $before; $totalAfter += $after
}

# Totals
$freedAll = $totalBefore - $totalAfter
Write-Host "`n==========================================" -ForegroundColor DarkGray
Write-Host ("Total Before Cleanup: {0}" -f (FormatTotal $totalBefore)) -ForegroundColor Red
Write-Host ("Total After Cleanup : {0}" -f (FormatTotal $totalAfter))  -ForegroundColor Yellow
Write-Host ("Space Freed         : {0}" -f (FormatTotal $freedAll))    -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor DarkGray
Write-Host "`n[DONE] Browser cleanup completed`n" -ForegroundColor Cyan

Stop-Transcript | Out-Null

# Windows Updates
Write-Host "Windows updates" -ForegroundColor Cyan 
Install-PackageProvider -Name NuGet -Force
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module -Name PSWindowsUpdate -Force
Import-Module PSWindowsUpdate
Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade' | Out-File "$desktopPath\WindowsUpdates.txt"
Write-Host "[DONE] Windows updates completed"`n -ForegroundColor Green 

# App Updates
$null = Start-Transcript -Path "$desktopPath\AppUpdates.txt" -ErrorAction SilentlyContinue
Write-Host "App updates" -ForegroundColor Cyan 
Write-Output 'Y' | winget upgrade -h --all --include-unknown
Write-Host "[DONE] App updates completed"`n -ForegroundColor Green 
Stop-Transcript | Out-Null

# Optimize Drives
Write-Host "Optimize drives" -ForegroundColor Cyan 
$Volumes = Get-Volume | Where-Object { $_.DriveType -ne 'Removable' -and $_.DriveLetter }
foreach ($Volume in $Volumes) {
    Write-Host "Optimizing $($Volume.DriveLetter)" -ForegroundColor Cyan 
    try {
        Optimize-Volume -DriveLetter $Volume.DriveLetter -ErrorAction Stop
        Write-Host "[DONE] $($Volume.DriveLetter) Optimized"`n -ForegroundColor Green 
    } catch {
        Write-Host "[DONE] $($Volume.DriveLetter) Not Supported"`n -ForegroundColor Green 
    }
}
Write-Host "[DONE] Optimize drives completed`n" -ForegroundColor Green

# Re-Enable Sleep Settings
} finally { 
  powercfg -setactive $prevGuid
}

# Restart
Shutdown /r /t 0