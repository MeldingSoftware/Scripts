﻿param(
    [Parameter(Position=0)]
    [string]$Uri
)

if ([string]::IsNullOrWhiteSpace($Uri)) { exit }

try {
    # Only a small hard-coded set of Windows tools can be launched.
    if ($Uri -match '^threatinspection://tool/(?<tool>[a-z0-9-]+)/?$') {
        $tool = $matches['tool'].ToLowerInvariant()
        switch ($tool) {
            'firewall' {
                $target = Join-Path $env:SystemRoot 'System32\wf.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'scheduler' {
                $target = Join-Path $env:SystemRoot 'System32\taskschd.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'services' {
                $target = Join-Path $env:SystemRoot 'System32\services.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'devicemanager' {
                $target = Join-Path $env:SystemRoot 'System32\devmgmt.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'taskmanager' {
                $target = Join-Path $env:SystemRoot 'System32\Taskmgr.exe'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
        }
        exit
    }

    # Browser notification settings are fixed internal browser pages, never
    # arbitrary user-supplied URLs or commands. Only known browser IDs can
    # pass through this route; the URL and executable names are hard-coded.
    if ($Uri -match '^threatinspection://browser-notifications/(?<browser>chrome|edge|brave|vivaldi|opera-gx|opera|firefox)/?$') {
        $browserId = $matches['browser'].ToLowerInvariant()
        $settingsPage = ''
        $relativePaths = @()
        $appPathExecutables = @()
        switch ($browserId) {
            'chrome' {
                $settingsPage = 'chrome://settings/content/notifications'
                $relativePaths = @('Google\Chrome\Application\chrome.exe')
                $appPathExecutables = @('chrome.exe')
            }
            'edge' {
                $settingsPage = 'edge://settings/content/notifications'
                $relativePaths = @('Microsoft\Edge\Application\msedge.exe')
                $appPathExecutables = @('msedge.exe')
            }
            'brave' {
                $settingsPage = 'brave://settings/content/notifications'
                $relativePaths = @('BraveSoftware\Brave-Browser\Application\brave.exe')
                $appPathExecutables = @('brave.exe')
            }
            'vivaldi' {
                # Chromium's protected content-settings page is accessible
                # from Vivaldi through its internal chrome:// settings pages.
                $settingsPage = 'chrome://settings/content/notifications'
                $relativePaths = @('Vivaldi\Application\vivaldi.exe')
                $appPathExecutables = @('vivaldi.exe')
            }
            'opera-gx' {
                $settingsPage = 'opera://settings/content/notifications'
                $relativePaths = @('Programs\Opera GX\launcher.exe', 'Programs\Opera GX\opera.exe', 'Opera GX\launcher.exe', 'Opera GX\opera.exe')
            }
            'opera' {
                $settingsPage = 'opera://settings/content/notifications'
                $relativePaths = @('Programs\Opera\launcher.exe', 'Programs\Opera\opera.exe', 'Opera\launcher.exe', 'Opera\opera.exe')
            }
            'firefox' {
                # Firefox exposes website-notification permissions from the
                # Privacy & Security pane, under Permissions > Notifications.
                $settingsPage = 'about:preferences#privacy'
                $relativePaths = @('Mozilla Firefox\firefox.exe', 'Programs\Mozilla Firefox\firefox.exe')
                $appPathExecutables = @('firefox.exe')
            }
        }

        # Resolve the installed browser itself, not the browser displaying the
        # HTML report. Never execute an executable or URL supplied in the URI.
        $roots = @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:LOCALAPPDATA) |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
        $browserExe = ''
        foreach ($root in $roots) {
            foreach ($relative in $relativePaths) {
                $candidate = Join-Path $root $relative
                if (Test-Path -LiteralPath $candidate -PathType Leaf -ErrorAction SilentlyContinue) {
                    $browserExe = $candidate
                    break
                }
            }
            if ($browserExe) { break }
        }

        # App Paths supports Chrome/Edge/Brave/Firefox/Vivaldi installed in
        # non-default locations. Only an exact allowlisted executable basename
        # is acceptable; registry values are not treated as command strings.
        if (-not $browserExe) {
            foreach ($exeName in $appPathExecutables) {
                foreach ($hive in @('HKLM:', 'HKCU:')) {
                    $appKey = "$hive\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exeName"
                    try {
                        $regKey = Get-Item -LiteralPath $appKey -ErrorAction Stop
                        $registered = [string]$regKey.GetValue('')
                        if ($registered -and
                            [IO.Path]::GetFileName($registered).Equals($exeName, [StringComparison]::OrdinalIgnoreCase) -and
                            (Test-Path -LiteralPath $registered -PathType Leaf -ErrorAction SilentlyContinue)) {
                            $browserExe = $registered
                            break
                        }
                    } catch { }
                }
                if ($browserExe) { break }
            }
        }

        if ($browserExe -and $settingsPage) {
            Start-Process -FilePath $browserExe -ArgumentList @($settingsPage)
        }
        exit
    }

    if ($Uri -notmatch '^threatinspection://folder/(?<payload>[A-Za-z0-9_-]+)/?$') {
        exit
    }

    $payload = $matches['payload'].Replace('-', '+').Replace('_', '/')
    switch ($payload.Length % 4) {
        2 { $payload += '==' }
        3 { $payload += '=' }
        1 { exit }
    }

    $bytes = [Convert]::FromBase64String($payload)
    $path = [Text.Encoding]::UTF8.GetString($bytes)
    if ([string]::IsNullOrWhiteSpace($path)) { exit }

    $path = [Environment]::ExpandEnvironmentVariables($path.Trim().Trim('"'))

    # Only allow rooted local-drive or UNC filesystem paths.
    if ($path -notmatch '^(?:[A-Za-z]:\\|\\\\)') { exit }

    $target = ''
    if (Test-Path -LiteralPath $path -PathType Container -ErrorAction SilentlyContinue) {
        $target = $path
    } elseif (Test-Path -LiteralPath $path -PathType Leaf -ErrorAction SilentlyContinue) {
        $target = Split-Path -LiteralPath $path -Parent
    } else {
        try {
            $parent = Split-Path -Path $path -Parent
            if ($parent -and (Test-Path -LiteralPath $parent -PathType Container -ErrorAction SilentlyContinue)) {
                $target = $parent
            }
        } catch { }
    }

    if ([string]::IsNullOrWhiteSpace($target)) { exit }

    # Opening a directory directly through the Windows shell launches normal File Explorer.
    Start-Process -FilePath $target
} catch { }
