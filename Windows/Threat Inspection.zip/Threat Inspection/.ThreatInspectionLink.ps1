﻿param(
    [Parameter(Position=0)]
    [string]$Uri
)

if ([string]::IsNullOrWhiteSpace($Uri)) { exit }

try {
    # Only a small hard-coded set of Windows tools can be launched.
    if ($Uri -match '^threatinspection://tool/(?<tool>[a-z0-9-]+)/?$') {
        $tool = $matches['tool'].ToLowerInvariant()
        switch ($tool) {
            'firewall' {
                $target = Join-Path $env:SystemRoot 'System32\wf.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'scheduler' {
                $target = Join-Path $env:SystemRoot 'System32\taskschd.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'services' {
                $target = Join-Path $env:SystemRoot 'System32\services.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'devicemanager' {
                $target = Join-Path $env:SystemRoot 'System32\devmgmt.msc'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
            'taskmanager' {
                $target = Join-Path $env:SystemRoot 'System32\Taskmgr.exe'
                if (Test-Path -LiteralPath $target) { Start-Process -FilePath $target }
            }
        }
        exit
    }

    if ($Uri -notmatch '^threatinspection://folder/(?<payload>[A-Za-z0-9_-]+)/?$') {
        exit
    }

    $payload = $matches['payload'].Replace('-', '+').Replace('_', '/')
    switch ($payload.Length % 4) {
        2 { $payload += '==' }
        3 { $payload += '=' }
        1 { exit }
    }

    $bytes = [Convert]::FromBase64String($payload)
    $path = [Text.Encoding]::UTF8.GetString($bytes)
    if ([string]::IsNullOrWhiteSpace($path)) { exit }

    $path = [Environment]::ExpandEnvironmentVariables($path.Trim().Trim('"'))

    # Only allow rooted local-drive or UNC filesystem paths.
    if ($path -notmatch '^(?:[A-Za-z]:\\|\\\\)') { exit }

    $target = ''
    if (Test-Path -LiteralPath $path -PathType Container -ErrorAction SilentlyContinue) {
        $target = $path
    } elseif (Test-Path -LiteralPath $path -PathType Leaf -ErrorAction SilentlyContinue) {
        $target = Split-Path -LiteralPath $path -Parent
    } else {
        try {
            $parent = Split-Path -Path $path -Parent
            if ($parent -and (Test-Path -LiteralPath $parent -PathType Container -ErrorAction SilentlyContinue)) {
                $target = $parent
            }
        } catch { }
    }

    if ([string]::IsNullOrWhiteSpace($target)) { exit }

    # Opening a directory directly through the Windows shell launches normal File Explorer.
    Start-Process -FilePath $target
} catch { }
