﻿#requires -Version 5.1
#requires -RunAsAdministrator

<#
.SYNOPSIS
    Performs a read-only Windows 10/11 malicious-threat inspection and creates an HTML report.

.DESCRIPTION
    Inspects the locations and settings from the Windows 10/11 Malicious Threat Checklist:
    accounts/remote access, installed programs/startup, Autoruns/persistence, scheduled tasks,
    services/drivers/processes, suspicious recent files, browsers, network configuration, and
    Windows Security. Findings are classified as Good, Review, Warning, or Info.

    The script does not remediate or delete inspected files, disable settings, quarantine threats, or upload files/hashes.
    If Microsoft Autorunsc is not already available, it can be downloaded temporarily from
    download.sysinternals.com, verified as Microsoft-signed, used locally, and removed afterward.

.PARAMETER RecentDays
    Number of days used for recent-app and recent-file review. Default: 30.

.PARAMETER SkipAutorunsDownload
    Do not download Autoruns if Autorunsc is not already available in PATH.

.PARAMETER NoOpenReport
    Create the HTML report but do not automatically open it when inspection completes.
#>

[CmdletBinding()]
param(
    [ValidateRange(1, 365)]
    [int]$RecentDays = 30,

    [switch]$SkipAutorunsDownload,
    [switch]$NoOpenReport
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# ----------------------------------------------------
# Threat Inspection v1.8
# Read-only Windows 10/11 inspection and HTML report.
# v1.7: Split Accounts and Remote Access sections; recognize Codex sandbox accounts as expected inventory; remote-tool path fallback.
# v1.8: Tightened artifact matching (Wave Browser/DriverFix/DeskIn), HomeGroupUser$ inventory handling, Remote Assistance Info state, and Autoruns invalid-path resilience.
# v1.4: Large remote-access/RMM and PUP/PUA watchlists; warning matches across apps, runtime, startup, browser extensions, and common folders.
# v1.2: Windows PowerShell 5.1 compatibility fixes for empty Generic List<T> results.
# No inspected files, tasks, services, registry values, browser settings,
# Defender settings, firewall rules, or user accounts are modified.
# ----------------------------------------------------

# ----------------------------------------------------
# Console Helpers
# ----------------------------------------------------
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern System.IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(System.IntPtr hWnd, System.Int32 nCmdShow);

[DllImport("user32.dll")]
public static extern bool SetForegroundWindow(System.IntPtr hWnd);
' -ErrorAction SilentlyContinue

function Show-Console {
    try {
        $consolePtr = [Console.Window]::GetConsoleWindow()
        if ($consolePtr -eq [IntPtr]::Zero) {
            $consolePtr = (Get-Process -Id $PID -ErrorAction SilentlyContinue).MainWindowHandle
        }
        if ($consolePtr -ne [IntPtr]::Zero) {
            [Console.Window]::ShowWindow($consolePtr, 3) | Out-Null
            [Console.Window]::SetForegroundWindow($consolePtr) | Out-Null
        }
        try {
            $raw = $Host.UI.RawUI
            $raw.WindowSize = $raw.MaxPhysicalWindowSize
        } catch { }
    } catch { }
}

function Write-SectionHeader {
    param([Parameter(Mandatory)][string]$Title)
    Write-Host $Title -ForegroundColor Cyan
    Write-Host ""
}

function Write-ResultLine {
    param(
        [ValidateSet('Good','Review','Warning','Info')]
        [string]$Status,
        [string]$Text
    )

    $color = switch ($Status) {
        'Good'    { 'Green' }
        'Review'  { 'Yellow' }
        'Warning' { 'Red' }
        default   { 'Gray' }
    }

    Write-Host ("[{0}] {1}" -f $Status, $Text) -ForegroundColor $color
}

function Write-FindingsConsole {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.IEnumerable]$Findings,
        [int]$MaxAttentionLines = 20
    )

    $itemsList = New-Object System.Collections.Generic.List[object]
    if ($null -ne $Findings) {
        foreach ($findingItem in $Findings) {
            if ($null -ne $findingItem) { $itemsList.Add($findingItem) | Out-Null }
        }
    }
    $items = $itemsList.ToArray()
    $warnings = @($items | Where-Object Status -eq 'Warning')
    $reviews  = @($items | Where-Object Status -eq 'Review')
    $good     = @($items | Where-Object Status -eq 'Good')
    $info     = @($items | Where-Object Status -eq 'Info')

    $attention = @($warnings + $reviews)
    foreach ($finding in $attention | Select-Object -First $MaxAttentionLines) {
        Write-ResultLine $finding.Status $finding.Text
    }
    if ($attention.Count -gt $MaxAttentionLines) {
        Write-Host ("... {0} additional Review/Warning item(s) are in the HTML report." -f ($attention.Count - $MaxAttentionLines)) -ForegroundColor DarkGray
    }

    if ($attention.Count -eq 0) {
        Write-Host "No Review or Warning items were generated for this section." -ForegroundColor Green
    }

    Write-Host ("Captured: {0} Good | {1} Review | {2} Warning | {3} Info" -f $good.Count, $reviews.Count, $warnings.Count, $info.Count) -ForegroundColor DarkGray
    Write-Host ""
}

try { Show-Console } catch { }

# ----------------------------------------------------
# Paths & Base Setup
# ----------------------------------------------------
$desktopRoot      = [Environment]::GetFolderPath('Desktop')
$localAppDataRoot = [Environment]::GetFolderPath('LocalApplicationData')
$dateStamp        = Get-Date -Format 'MM-dd-yy'
$timeStamp        = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
$reportName       = "Threat Inspection $dateStamp.html"
$finalReportPath  = Join-Path $desktopRoot $reportName
$tempRoot         = Join-Path $localAppDataRoot 'Threat Inspection Temp'
$autorunsRoot     = Join-Path $tempRoot 'Autoruns'
$autorunsZip      = Join-Path $tempRoot 'Autoruns.zip'
$autorunsCsv      = Join-Path $tempRoot 'Autoruns.csv'
$script:SelfPath = if ($PSCommandPath) { [System.IO.Path]::GetFullPath($PSCommandPath) } else { '' }
$script:SelfRoot = if ($script:SelfPath) { Split-Path -Parent $script:SelfPath } else { '' }

if (Test-Path -LiteralPath $tempRoot) {
    try { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue } catch { }
}
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    (Get-Item -LiteralPath $tempRoot -Force).Attributes = ((Get-Item -LiteralPath $tempRoot -Force).Attributes -bor [System.IO.FileAttributes]::Hidden)
} catch { }

# ----------------------------------------------------
# Generic Helpers
# ----------------------------------------------------
function Convert-ToHtmlSafe {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return '' }
    return [System.Net.WebUtility]::HtmlEncode([string]$Text)
}

function Get-PropertyValue {
    param(
        [Parameter(Mandatory)]$Object,
        [Parameter(Mandatory)][string[]]$Names
    )
    foreach ($name in $Names) {
        $prop = $Object.PSObject.Properties[$name]
        if ($prop) { return $prop.Value }
    }
    return $null
}

function Add-Finding {
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][System.Collections.Generic.List[object]]$List,
        [Parameter(Mandatory)][ValidateSet('Good','Review','Warning','Info')][string]$Status,
        [Parameter(Mandatory)][string]$Text,
        [string]$Detail = '',
        [string]$ConcernKey = ''
    )

    $List.Add([PSCustomObject]@{
        Status     = $Status
        Text       = $Text
        Detail     = $Detail
        ConcernKey = $ConcernKey
    }) | Out-Null
}

function Get-SectionStatus {
    param([AllowEmptyCollection()][System.Collections.IEnumerable]$Findings)

    $hasWarning = $false
    $hasReview  = $false
    $hasGood    = $false

    if ($null -ne $Findings) {
        foreach ($item in $Findings) {
            if ($null -eq $item) { continue }
            switch ([string]$item.Status) {
                'Warning' { $hasWarning = $true }
                'Review'  { $hasReview  = $true }
                'Good'    { $hasGood    = $true }
            }
        }
    }

    if ($hasWarning) { return 'Warning' }
    if ($hasReview)  { return 'Review' }
    if ($hasGood)    { return 'Good' }
    return 'Info'
}

function Get-SeverityRank {
    param([string]$Status)
    switch ($Status) {
        'Warning' { return 4 }
        'Review'  { return 3 }
        'Info'    { return 2 }
        'Good'    { return 1 }
        default   { return 0 }
    }
}


function Get-UniqueConcernCount {
    param(
        [AllowEmptyCollection()][System.Collections.IEnumerable]$Findings,
        [Parameter(Mandatory)][ValidateSet('Review','Warning')][string]$Status
    )

    $seen = @{}
    if ($null -ne $Findings) {
        foreach ($item in $Findings) {
            if ($null -eq $item -or [string]$item.Status -ne $Status) { continue }
            $key = if ($item.PSObject.Properties['ConcernKey'] -and -not [string]::IsNullOrWhiteSpace([string]$item.ConcernKey)) {
                ([string]$item.ConcernKey).Trim().ToLowerInvariant()
            } else {
                ([string]$item.Text).Trim().ToLowerInvariant()
            }
            if ($key) { $seen[$key] = $true }
        }
    }
    return $seen.Count
}

function Test-IsInspectionOwnPath {
    param([AllowNull()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    try { $full = [System.IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))) } catch { $full = $Path }

    if ($script:SelfPath -and $full -ieq $script:SelfPath) { return $true }
    if ($finalReportPath -and $full -ieq $finalReportPath) { return $true }
    if ($tempRoot -and $full.StartsWith($tempRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }

    if ($script:SelfRoot -and (Test-Path -LiteralPath $script:SelfRoot -PathType Container -ErrorAction SilentlyContinue)) {
        $rootLeaf = Split-Path $script:SelfRoot -Leaf
        if ($rootLeaf -match '(?i)^Threat\s*Inspection') {
            if ($full.StartsWith($script:SelfRoot, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
        } elseif ((Split-Path $full -Parent) -ieq $script:SelfRoot -and (Split-Path $full -Leaf) -match '(?i)^(Run Me\.bat|ThreatInspection(?:_v[\d.]+)?\.ps1)$') {
            return $true
        }
    }
    return $false
}

function Get-Sha256Safe {
    param([AllowNull()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return '' }
    try { return [string](Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash } catch { return '' }
}

function Get-IfeoVerifierReferences {
    param([Parameter(Mandatory)][string]$TargetPath)
    $results = New-Object System.Collections.Generic.List[string]
    $root = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
    if (-not (Test-Path -LiteralPath $root)) { return @() }
    $targetName = [System.IO.Path]::GetFileName($TargetPath)
    try {
        foreach ($key in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            try {
                $props = Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
                foreach ($name in @('VerifierDlls','Debugger')) {
                    $prop = $props.PSObject.Properties[$name]
                    if (-not $prop -or [string]::IsNullOrWhiteSpace([string]$prop.Value)) { continue }
                    $value = [string]$prop.Value
                    $fullMatch = $value.IndexOf($TargetPath, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
                    $nameMatch = $targetName -and ($value.IndexOf($targetName, [System.StringComparison]::OrdinalIgnoreCase) -ge 0)
                    if ($fullMatch -or $nameMatch) {
                        $results.Add(("{0} | {1}={2}" -f $key.PSChildName, $name, $prop.Value)) | Out-Null
                    }
                }
            } catch { }
        }
    } catch { }
    return $results.ToArray()
}

# ----------------------------------------------------
# Known Software Watchlists
# ----------------------------------------------------
# A match means "technician attention required", not "confirmed malware".
# Remote-access/RMM tools are legitimate in many environments but are commonly abused.
# PUP/PUA entries are a technician watchlist and can be customized for local policy.

$script:RemoteAccessWatchlist = @(
    [PSCustomObject]@{ Name='Action1'; NamePattern='(?i)Action1'; ArtifactPattern='(?i)Action1' },
    [PSCustomObject]@{ Name='AeroAdmin'; NamePattern='(?i)AeroAdmin'; ArtifactPattern='(?i)AeroAdmin' },
    [PSCustomObject]@{ Name='Ammyy Admin'; NamePattern='(?i)Ammyy(?:\s*Admin)?'; ArtifactPattern='(?i)Ammyy|AA_v\d+\.exe' },
    [PSCustomObject]@{ Name='AnyDesk'; NamePattern='(?i)AnyDesk'; ArtifactPattern='(?i)AnyDesk' },
    [PSCustomObject]@{ Name='AnyViewer'; NamePattern='(?i)AnyViewer'; ArtifactPattern='(?i)AnyViewer' },
    [PSCustomObject]@{ Name='Atera'; NamePattern='(?i)^\s*Atera(?:Agent)?\b|AteraAgent'; ArtifactPattern='(?i)AteraAgent|Atera Networks|\\Atera(?:Agent)?\\' },
    [PSCustomObject]@{ Name='BeyondTrust / Bomgar'; NamePattern='(?i)BeyondTrust|Bomgar'; ArtifactPattern='(?i)BeyondTrust|Bomgar|bomgar-scc' },
    [PSCustomObject]@{ Name='ConnectWise Automate'; NamePattern='(?i)ConnectWise\s+Automate|LabTech'; ArtifactPattern='(?i)ConnectWise\s*Automate|LabTech|LTService|LTSvcMon' },
    [PSCustomObject]@{ Name='ConnectWise ScreenConnect'; NamePattern='(?i)ScreenConnect|ConnectWise\s+(?:Control|ScreenConnect)'; ArtifactPattern='(?i)ScreenConnect|ConnectWiseControl|ScreenConnect\.Client' },
    [PSCustomObject]@{ Name='Dameware'; NamePattern='(?i)Dameware'; ArtifactPattern='(?i)Dameware|DWRCS' },
    [PSCustomObject]@{ Name='Datto RMM / CentraStage'; NamePattern='(?i)Datto\s*RMM|CentraStage'; ArtifactPattern='(?i)Datto\s*RMM|CentraStage|CagService' },
    [PSCustomObject]@{ Name='DWService'; NamePattern='(?i)DWService'; ArtifactPattern='(?i)DWService|dwagent' },
    [PSCustomObject]@{ Name='FixMe.IT'; NamePattern='(?i)FixMe\.IT|Techinline'; ArtifactPattern='(?i)FixMe\.IT|Techinline' },
    [PSCustomObject]@{ Name='FleetDeck'; NamePattern='(?i)FleetDeck'; ArtifactPattern='(?i)FleetDeck' },
    [PSCustomObject]@{ Name='GoTo Resolve / GoToAssist'; NamePattern='(?i)GoTo\s*(?:Resolve|Assist)|GoToAssist'; ArtifactPattern='(?i)GoTo\s*(?:Resolve|Assist)|GoToAssist|g2ax_' },
    [PSCustomObject]@{ Name='GoToMyPC'; NamePattern='(?i)GoToMyPC'; ArtifactPattern='(?i)GoToMyPC|g2comm|g2pre' },
    [PSCustomObject]@{ Name='Goverlan'; NamePattern='(?i)Goverlan'; ArtifactPattern='(?i)Goverlan' },
    [PSCustomObject]@{ Name='Gorelo RMM'; NamePattern='(?i)Gorelo'; ArtifactPattern='(?i)Gorelo' },
    [PSCustomObject]@{ Name='Heartbeat RM'; NamePattern='(?i)Heartbeat\s*RM'; ArtifactPattern='(?i)Heartbeat\s*RM' },
    [PSCustomObject]@{ Name='HelpWire'; NamePattern='(?i)HelpWire'; ArtifactPattern='(?i)HelpWire' },
    [PSCustomObject]@{ Name='ImmyBot'; NamePattern='(?i)ImmyBot'; ArtifactPattern='(?i)ImmyBot' },
    [PSCustomObject]@{ Name='ISL Online'; NamePattern='(?i)ISL\s*(?:Online|Light|AlwaysOn)'; ArtifactPattern='(?i)ISL\s*(?:Online|Light|AlwaysOn)|ISLLight|ISLAlwaysOn' },
    [PSCustomObject]@{ Name='ITarian / Comodo RMM'; NamePattern='(?i)ITarian|Comodo\s+(?:One|RMM)'; ArtifactPattern='(?i)ITarian|Comodo\s*(?:One|RMM)|RmmService' },
    [PSCustomObject]@{ Name='Jump Desktop'; NamePattern='(?i)Jump\s*Desktop'; ArtifactPattern='(?i)Jump\s*Desktop|JumpDesktop' },
    [PSCustomObject]@{ Name='Kaseya VSA'; NamePattern='(?i)Kaseya|VSA\s*Agent'; ArtifactPattern='(?i)Kaseya|KaseyaAgent' },
    [PSCustomObject]@{ Name='Level.io'; NamePattern='(?i)Level\.io'; ArtifactPattern='(?i)Level\.io|level-agent' },
    [PSCustomObject]@{ Name='LiteManager'; NamePattern='(?i)LiteManager'; ArtifactPattern='(?i)LiteManager|ROMServer' },
    [PSCustomObject]@{ Name='LogMeIn'; NamePattern='(?i)LogMeIn'; ArtifactPattern='(?i)LogMeIn|LMIGuardian|LogMeInSystray' },
    [PSCustomObject]@{ Name='ManageEngine Remote Access Plus'; NamePattern='(?i)Remote\s*Access\s*Plus'; ArtifactPattern='(?i)Remote\s*Access\s*Plus|UEMS_RemoteAccess' },
    [PSCustomObject]@{ Name='MeshCentral / MeshAgent'; NamePattern='(?i)MeshCentral|MeshAgent'; ArtifactPattern='(?i)MeshCentral|MeshAgent' },
    [PSCustomObject]@{ Name='Miradore'; NamePattern='(?i)Miradore'; ArtifactPattern='(?i)Miradore' },
    [PSCustomObject]@{ Name='N-able / N-central / N-sight'; NamePattern='(?i)N-able|N-central|N-sight|SolarWinds\s+RMM'; ArtifactPattern='(?i)N-able|N-central|N-sight|SolarWinds\s*RMM|winagent' },
    [PSCustomObject]@{ Name='NetSupport Manager'; NamePattern='(?i)NetSupport'; ArtifactPattern='(?i)NetSupport' },
    [PSCustomObject]@{ Name='NinjaOne / NinjaRMM'; NamePattern='(?i)NinjaOne|NinjaRMM|NinjaRMMAgent'; ArtifactPattern='(?i)NinjaOne|NinjaRMM|NinjaRMMAgent' },
    [PSCustomObject]@{ Name='NoMachine'; NamePattern='(?i)NoMachine'; ArtifactPattern='(?i)NoMachine|nxserver|nxplayer' },
    [PSCustomObject]@{ Name='Parsec'; NamePattern='(?i)^\s*Parsec\b'; ArtifactPattern='(?i)\\Parsec\\|parsecd\.exe|parsec\.exe' },
    [PSCustomObject]@{ Name='PDQ Connect / PDQ Deploy'; NamePattern='(?i)PDQ\s+(?:Connect|Deploy)'; ArtifactPattern='(?i)PDQ\s*(?:Connect|Deploy)|PDQConnectAgent' },
    [PSCustomObject]@{ Name='Pulseway'; NamePattern='(?i)Pulseway|PC\s*Monitor'; ArtifactPattern='(?i)Pulseway|PCMonitorManager' },
    [PSCustomObject]@{ Name='Remote Utilities'; NamePattern='(?i)Remote\s+Utilities'; ArtifactPattern='(?i)Remote\s*Utilities|rutserv|rfusclient' },
    [PSCustomObject]@{ Name='RemotePC'; NamePattern='(?i)^\s*RemotePC\b|IDrive\s+RemotePC'; ArtifactPattern='(?i)RemotePC|RemotePCService' },
    [PSCustomObject]@{ Name='RemoteToPC'; NamePattern='(?i)RemoteToPC'; ArtifactPattern='(?i)RemoteToPC' },
    [PSCustomObject]@{ Name='RPort'; NamePattern='(?i)^\s*RPort\b'; ArtifactPattern='(?i)\\RPort\\|rport\.exe' },
    [PSCustomObject]@{ Name='RustDesk'; NamePattern='(?i)RustDesk'; ArtifactPattern='(?i)RustDesk' },
    [PSCustomObject]@{ Name='SimpleHelp'; NamePattern='(?i)SimpleHelp'; ArtifactPattern='(?i)SimpleHelp' },
    [PSCustomObject]@{ Name='Splashtop'; NamePattern='(?i)Splashtop'; ArtifactPattern='(?i)Splashtop|SRManager|SplashtopRemoteService' },
    [PSCustomObject]@{ Name='Supremo'; NamePattern='(?i)^\s*Supremo\b'; ArtifactPattern='(?i)Supremo' },
    [PSCustomObject]@{ Name='Syncro'; NamePattern='(?i)Syncro(?:MSP)?|SyncroLive'; ArtifactPattern='(?i)Syncro(?:MSP)?|SyncroLive|Kabuto' },
    [PSCustomObject]@{ Name='Tactical RMM'; NamePattern='(?i)Tactical\s*RMM'; ArtifactPattern='(?i)Tactical\s*RMM|tacticalrmm|tacticalagent' },
    [PSCustomObject]@{ Name='TeamViewer'; NamePattern='(?i)TeamViewer'; ArtifactPattern='(?i)TeamViewer' },
    [PSCustomObject]@{ Name='TightVNC'; NamePattern='(?i)TightVNC'; ArtifactPattern='(?i)TightVNC|tvnserver|tvnviewer' },
    [PSCustomObject]@{ Name='Tiflux'; NamePattern='(?i)Tiflux'; ArtifactPattern='(?i)Tiflux' },
    [PSCustomObject]@{ Name='TigerVNC'; NamePattern='(?i)TigerVNC'; ArtifactPattern='(?i)TigerVNC|winvnc4' },
    [PSCustomObject]@{ Name='TSplus Remote Support'; NamePattern='(?i)TSplus\s+Remote\s+Support'; ArtifactPattern='(?i)TSplus|TSplusRemoteSupport' },
    [PSCustomObject]@{ Name='UltraViewer'; NamePattern='(?i)UltraViewer'; ArtifactPattern='(?i)UltraViewer' },
    [PSCustomObject]@{ Name='UltraVNC / WinVNC'; NamePattern='(?i)UltraVNC|WinVNC'; ArtifactPattern='(?i)UltraVNC|WinVNC|uvnc_service' },
    [PSCustomObject]@{ Name='Zoho Assist'; NamePattern='(?i)Zoho\s+Assist'; ArtifactPattern='(?i)Zoho\s*Assist|ZohoAssist' },
    [PSCustomObject]@{ Name='Chrome Remote Desktop'; NamePattern='(?i)Chrome\s+Remote\s+Desktop'; ArtifactPattern='(?i)Chrome\s*Remote\s*Desktop|remoting_host\.exe' },
    [PSCustomObject]@{ Name='RealVNC / VNC Connect'; NamePattern='(?i)RealVNC|VNC\s+Connect'; ArtifactPattern='(?i)RealVNC|VNC\s*Connect|vncserver(?:ui)?\.exe' },
    [PSCustomObject]@{ Name='Radmin'; NamePattern='(?i)^\s*Radmin\b|Famatech'; ArtifactPattern='(?i)Radmin|Famatech|r_server\.exe' },
    [PSCustomObject]@{ Name='Iperius Remote'; NamePattern='(?i)Iperius\s+Remote'; ArtifactPattern='(?i)Iperius\s*Remote|IperiusRemote' },
    [PSCustomObject]@{ Name='Getscreen.me'; NamePattern='(?i)GetScreen(?:\.me)?'; ArtifactPattern='(?i)GetScreen(?:\.me)?|getscreen\.exe' },
    [PSCustomObject]@{ Name='HopToDesk'; NamePattern='(?i)HopToDesk'; ArtifactPattern='(?i)HopToDesk' },
    [PSCustomObject]@{ Name='DeskIn'; NamePattern='(?i)^\s*DeskIn\b'; ArtifactPattern='(?i)(?:^|[\\/])DeskIn(?:[\\/]|\.exe|$)|(?:^|[\\/])DeskIn(?:Client|Remote)?\.exe$' },
    [PSCustomObject]@{ Name='ShowMyPC'; NamePattern='(?i)ShowMyPC'; ArtifactPattern='(?i)ShowMyPC' },
    [PSCustomObject]@{ Name='Mikogo'; NamePattern='(?i)Mikogo'; ArtifactPattern='(?i)Mikogo' },
    [PSCustomObject]@{ Name='eHorus'; NamePattern='(?i)eHorus'; ArtifactPattern='(?i)eHorus' },
    [PSCustomObject]@{ Name='Microsoft Quick Assist'; NamePattern='(?i)^\s*(?:Microsoft\s+)?Quick\s+Assist\s*$'; ArtifactPattern='(?i)QuickAssist(?:\.exe)?' }
)

$script:PupPuaWatchlist = @(
    # User/workplace-observed items
    [PSCustomObject]@{ Name='Blazer'; NamePattern='(?i)^\s*Blazer(?:\s+Browser)?\s*$'; ArtifactPattern='(?i)(?:^|[\\/])Blazer(?:\s+Browser)?(?:[\\/]|$)|(?:^|[\\/])blazer\.exe$' },
    [PSCustomObject]@{ Name='Wave Browser'; NamePattern='(?i)^\s*Wave(?:\s+Browser)?\s*$'; ArtifactPattern='(?i)(?:^|[\\/])Wave(?:\s+Browser)?(?:[\\/]|$)|(?:^|[\\/])Wave\s+Browser(?:\s*[-_]\s*[^\\/]*)?\.exe$|wavebrowser(?:\.exe)?' },
    [PSCustomObject]@{ Name='Shift Browser'; NamePattern='(?i)^\s*Shift(?:\s+Browser)?\s*$'; ArtifactPattern='(?i)(?:^|[\\/])Shift(?:\s+Browser)?(?:[\\/]|$)|Shift--(?:Browser|Calendars)|(?:^|[\\/])shift\.exe$' },
    [PSCustomObject]@{ Name='OneStart'; NamePattern='(?i)^\s*OneStart(?:\.ai)?\s*$'; ArtifactPattern='(?i)OneStart(?:\.ai)?' },
    [PSCustomObject]@{ Name='One Browser'; NamePattern='(?i)^\s*One\s+Browser\s*$'; ArtifactPattern='(?i)(?:^|[\\/])One\s*Browser(?:[\\/]|$)|OneBrowser' },
    [PSCustomObject]@{ Name='Driver Support / Driver Support One'; NamePattern='(?i)^\s*Driver\s+Support(?:\s+One)?\b'; ArtifactPattern='(?i)Driver\s*Support(?:\s*One)?|DriverSupportOne' },
    [PSCustomObject]@{ Name='Web Companion'; NamePattern='(?i)^\s*(?:Adaware\s+)?Web\s+Companion\b'; ArtifactPattern='(?i)Web\s*Companion|WebCompanion|Lavasoft' },
    [PSCustomObject]@{ Name='Search Protect'; NamePattern='(?i)^\s*Search\s+Protect\b'; ArtifactPattern='(?i)Search\s*Protect|SearchProtect|Conduit' },
    [PSCustomObject]@{ Name='Browser Assistant'; NamePattern='(?i)^\s*Browser\s+Assistant\b'; ArtifactPattern='(?i)(?:^|[\\/])Browser(?:\s|_)?Assistant(?:\.exe|[\\/]|$)|BrowserAssistant(?:\.exe|[\\/]|$)'; ExcludePattern='(?i)Opera\s+GX|[\\/]Opera GX[\\/]|Opera Software' },
    [PSCustomObject]@{ Name='PDF Tools'; NamePattern='(?i)^\s*PDF\s+Tools\s*$'; ArtifactPattern='(?i)(?:^|[\\/])PDF\s*Tools(?:[\\/]|$)|PDFTools' },
    [PSCustomObject]@{ Name='PDF Hub'; NamePattern='(?i)^\s*PDF\s+Hub\s*$'; ArtifactPattern='(?i)(?:^|[\\/])PDF\s*Hub(?:[\\/]|$)|PDFHub' },
    [PSCustomObject]@{ Name='PC App Store'; NamePattern='(?i)^\s*PC\s*App\s*Store\b'; ArtifactPattern='(?i)PC\s*App\s*Store|PCAppStore' },
    [PSCustomObject]@{ Name='Clear / ClearBrowser'; NamePattern='(?i)^\s*(?:Clear|Clear\s+Browser|ClearBrowser)\s*$'; ArtifactPattern='(?i)ClearBrowser(?:\.exe)?|(?:^|[\\/])Clear(?:[\\/]|$)' },

    # Additional higher-signal PUP/PUA names commonly seen in cleanup work
    [PSCustomObject]@{ Name='OneLaunch'; NamePattern='(?i)^\s*OneLaunch\b'; ArtifactPattern='(?i)OneLaunch' },
    [PSCustomObject]@{ Name='WebDiscover Browser'; NamePattern='(?i)^\s*WebDiscover(?:\s+Browser)?\b'; ArtifactPattern='(?i)WebDiscover' },
    [PSCustomObject]@{ Name='WebNavigator Browser'; NamePattern='(?i)^\s*WebNavigator(?:\s+Browser)?\b'; ArtifactPattern='(?i)WebNavigator' },
    [PSCustomObject]@{ Name='Chromstera Browser'; NamePattern='(?i)^\s*Chromstera(?:\s+Browser)?\b'; ArtifactPattern='(?i)Chromstera' },
    [PSCustomObject]@{ Name='SAntivirus / Segurazo'; NamePattern='(?i)^\s*(?:SAntivirus|Segurazo)\b'; ArtifactPattern='(?i)SAntivirus|Segurazo' },
    [PSCustomObject]@{ Name='ByteFence'; NamePattern='(?i)^\s*ByteFence\b'; ArtifactPattern='(?i)ByteFence' },
    [PSCustomObject]@{ Name='PremierOpinion'; NamePattern='(?i)^\s*PremierOpinion\b'; ArtifactPattern='(?i)PremierOpinion' },
    [PSCustomObject]@{ Name='RelevantKnowledge'; NamePattern='(?i)^\s*RelevantKnowledge\b'; ArtifactPattern='(?i)RelevantKnowledge|rlvknlg' },
    [PSCustomObject]@{ Name='PC Accelerate Pro'; NamePattern='(?i)^\s*PC\s+Accelerate\s+Pro\b'; ArtifactPattern='(?i)PC\s*Accelerate\s*Pro|PCAcceleratePro' },
    [PSCustomObject]@{ Name='PC Speed Maximizer'; NamePattern='(?i)^\s*PC\s+Speed\s+Maximizer\b'; ArtifactPattern='(?i)PC\s*Speed\s*Maximizer|PCSpeedMaximizer' },
    [PSCustomObject]@{ Name='Optimizer Pro'; NamePattern='(?i)^\s*(?:Super\s+)?Optimizer\s+Pro\b'; ArtifactPattern='(?i)Optimizer\s*Pro|SuperOptimizer' },
    [PSCustomObject]@{ Name='MyCleanPC'; NamePattern='(?i)^\s*MyCleanPC\b'; ArtifactPattern='(?i)MyCleanPC' },
    [PSCustomObject]@{ Name='SlimCleaner / Slimware'; NamePattern='(?i)^\s*SlimCleaner|Slimware'; ArtifactPattern='(?i)SlimCleaner|Slimware' },
    [PSCustomObject]@{ Name='DriverUpdate / Slimware DriverUpdate'; NamePattern='(?i)^\s*DriverUpdate\b|Slimware\s+Driver'; ArtifactPattern='(?i)(?:^|[\\/])DriverUpdate(?:[\\/]|\.exe|$)|Slimware' },
    [PSCustomObject]@{ Name='PC HelpSoft Driver Updater'; NamePattern='(?i)^\s*PC\s+HelpSoft\s+Driver\s+Updater\b'; ArtifactPattern='(?i)PCHelpSoft|PC\s*HelpSoft\s*Driver' },
    [PSCustomObject]@{ Name='Quick Driver Updater'; NamePattern='(?i)^\s*Quick\s+Driver\s+Updater\b'; ArtifactPattern='(?i)Quick\s*Driver\s*Updater|QuickDriverUpdater' },
    [PSCustomObject]@{ Name='WinZip Driver Updater'; NamePattern='(?i)^\s*WinZip\s+Driver\s+Updater\b'; ArtifactPattern='(?i)WinZip\s*Driver\s*Updater|WinZipDriverUpdater' },
    [PSCustomObject]@{ Name='Ask Toolbar'; NamePattern='(?i)^\s*Ask(?:\.com)?\s+Toolbar\b'; ArtifactPattern='(?i)Ask(?:\.com)?\s*Toolbar' },
    [PSCustomObject]@{ Name='Babylon Toolbar'; NamePattern='(?i)^\s*Babylon(?:\s+Toolbar)?\b'; ArtifactPattern='(?i)Babylon\s*Toolbar|BabylonToolbar' },
    [PSCustomObject]@{ Name='MyWay / Mindspark'; NamePattern='(?i)MyWay|Mindspark'; ArtifactPattern='(?i)MyWay|Mindspark|AskPartnerNetwork' },
    [PSCustomObject]@{ Name='Search Manager'; NamePattern='(?i)^\s*Search\s+Manager\b'; ArtifactPattern='(?i)Search\s*Manager|SearchManager' },
    [PSCustomObject]@{ Name='Universal Browser / Web Browser Solutions'; NamePattern='(?i)^\s*(?:Universal\s+Browser|Web\s+Browser\s+Solutions)\b'; ArtifactPattern='(?i)UniversalBrowserSolutions|WebBrowserSolutions|Universal\s*Browser' },
    [PSCustomObject]@{ Name='Artificius / Artificus'; NamePattern='(?i)^\s*Artific(?:ius|us)\b'; ArtifactPattern='(?i)Artificius|Artificus' },
    [PSCustomObject]@{ Name='Wise Care 365'; NamePattern='(?i)^\s*Wise\s+Care(?:\s+365)?\b'; ArtifactPattern='(?i)WiseCare|Wise\s*Care' },
    [PSCustomObject]@{ Name='Custom Search Bar'; NamePattern='(?i)^\s*Custom\s+Search\s+Bar\b'; ArtifactPattern='(?i)CustomSearchBar|Custom\s*Search\s*Bar' },
    [PSCustomObject]@{ Name='Active Search Bar'; NamePattern='(?i)^\s*Active\s+Search\s+Bar\b'; ArtifactPattern='(?i)ActiveSearchBar|Active\s*Search\s*Bar' },
    [PSCustomObject]@{ Name='Auslogics Driver Updater'; NamePattern='(?i)^\s*Auslogics\s+Driver\s+Updater\b'; ArtifactPattern='(?i)Auslogics\s*Driver\s*Updater|AuslogicsDriverUpdater' },
    [PSCustomObject]@{ Name='DriverHive'; NamePattern='(?i)^\s*DriverHive\b'; ArtifactPattern='(?i)DriverHive' },
    [PSCustomObject]@{ Name='DriverFix'; NamePattern='(?i)^\s*DriverFix\b'; ArtifactPattern='(?i)(?:^|[\\/ _-])DriverFix(?:Setup|Installer)?(?:[\\/ ._-]|$)' },
    [PSCustomObject]@{ Name='DriverPack'; NamePattern='(?i)^\s*DriverPack\b'; ArtifactPattern='(?i)DriverPack' },
    [PSCustomObject]@{ Name='DriverToolkit'; NamePattern='(?i)^\s*DriverToolkit\b'; ArtifactPattern='(?i)DriverToolkit' },
    [PSCustomObject]@{ Name='DriverTuner'; NamePattern='(?i)^\s*DriverTuner\b'; ArtifactPattern='(?i)DriverTuner' },
    [PSCustomObject]@{ Name='DriveTheLife'; NamePattern='(?i)^\s*DriveTheLife\b'; ArtifactPattern='(?i)DriveTheLife' },
    [PSCustomObject]@{ Name='WiperSoft'; NamePattern='(?i)^\s*WiperSoft\b'; ArtifactPattern='(?i)WiperSoft' },
    [PSCustomObject]@{ Name='WinThruster'; NamePattern='(?i)^\s*WinThruster\b'; ArtifactPattern='(?i)WinThruster' },
    [PSCustomObject]@{ Name='PCSpeedCat'; NamePattern='(?i)^\s*PCSpeedCat\b'; ArtifactPattern='(?i)PCSpeedCat' },
    [PSCustomObject]@{ Name='SystemKeeper Pro'; NamePattern='(?i)^\s*SystemKeeper\s+Pro\b'; ArtifactPattern='(?i)SystemKeeperPro|SystemKeeper\s*Pro' },
    [PSCustomObject]@{ Name='Restoro / Reimage'; NamePattern='(?i)^\s*(?:Restoro|Reimage)\b'; ArtifactPattern='(?i)Restoro|ReimagePlus|Reimage' },
    [PSCustomObject]@{ Name='Super Cleanup'; NamePattern='(?i)^\s*Super\s+Cleanup\b'; ArtifactPattern='(?i)SuperCleanup|Super\s*Cleanup' },
    [PSCustomObject]@{ Name='SearchEncrypt'; NamePattern='(?i)^\s*SearchEncrypt\b'; ArtifactPattern='(?i)SearchEncrypt' },
    [PSCustomObject]@{ Name='Trovi'; NamePattern='(?i)^\s*Trovi\b'; ArtifactPattern='(?i)Trovi|trovigo' },
    [PSCustomObject]@{ Name='Spigot'; NamePattern='(?i)^\s*Spigot\b'; ArtifactPattern='(?i)Spigot' },
    [PSCustomObject]@{ Name='Wajam'; NamePattern='(?i)^\s*Wajam\b'; ArtifactPattern='(?i)Wajam' },
    [PSCustomObject]@{ Name='Webbar'; NamePattern='(?i)^\s*Webbar\b'; ArtifactPattern='(?i)Webbar' },
    [PSCustomObject]@{ Name='CrossBrowse'; NamePattern='(?i)^\s*CrossBrowse\b'; ArtifactPattern='(?i)CrossBrowse' },
    [PSCustomObject]@{ Name='BrowseFox'; NamePattern='(?i)^\s*BrowseFox\b'; ArtifactPattern='(?i)BrowseFox' },
    [PSCustomObject]@{ Name='MyPCBackup'; NamePattern='(?i)^\s*MyPCBackup\b'; ArtifactPattern='(?i)MyPCBackup' },
    [PSCustomObject]@{ Name='OpenCandy'; NamePattern='(?i)^\s*OpenCandy\b'; ArtifactPattern='(?i)OpenCandy' },
    [PSCustomObject]@{ Name='Softonic Downloader'; NamePattern='(?i)^\s*Softonic(?:\s+Downloader)?\b'; ArtifactPattern='(?i)Softonic' },
    [PSCustomObject]@{ Name='Advanced System Repair'; NamePattern='(?i)^\s*Advanced\s+System\s+Repair\b'; ArtifactPattern='(?i)AdvancedSystemRepair|Advanced\s*System\s*Repair' },
    [PSCustomObject]@{ Name='WinZip System Utilities Suite'; NamePattern='(?i)^\s*WinZip\s+System\s+Utilities\s+Suite\b'; ArtifactPattern='(?i)WinZip\s*System\s*Utilities|WinZipSystemUtilities' }
)

function Find-WatchlistEntry {
    param(
        [AllowNull()][string]$Text,
        [Parameter(Mandatory)][object[]]$Watchlist,
        [ValidateSet('Name','Artifact')][string]$Mode = 'Artifact'
    )

    if ([string]::IsNullOrWhiteSpace($Text)) { return $null }
    foreach ($entry in $Watchlist) {
        $pattern = if ($Mode -eq 'Name') { [string]$entry.NamePattern } else { [string]$entry.ArtifactPattern }
        if (-not $pattern -or $Text -notmatch $pattern) { continue }
        if ($entry.PSObject.Properties['ExcludePattern']) {
            $exclude = [string]$entry.ExcludePattern
            if ($exclude -and $Text -match $exclude) { continue }
        }
        return $entry
    }
    return $null
}

function Get-WatchlistInstalledMatches {
    param(
        [object[]]$Apps,
        [Parameter(Mandatory)][object[]]$Watchlist,
        [Parameter(Mandatory)][string]$Kind
    )

    $results = New-Object System.Collections.Generic.List[object]
    foreach ($app in @($Apps)) {
        $match = Find-WatchlistEntry -Text ([string]$app.Name) -Watchlist $Watchlist -Mode Name
        if ($match) {
            $results.Add([PSCustomObject]@{ Kind=$Kind; Product=$match.Name; App=$app }) | Out-Null
        }
    }
    return @($results.ToArray() | Sort-Object Product, @{Expression={$_.App.Name}} -Unique)
}

function Get-WatchlistRuntimeMatches {
    param(
        [Parameter(Mandatory)][object[]]$Watchlist,
        [Parameter(Mandatory)][string]$Kind
    )

    $results = New-Object System.Collections.Generic.List[object]
    $genericHelperNames = '(?i)^(crashpad_handler|crashpad|update|updater|uninstall|unins\d*)\.exe$'

    try {
        foreach ($proc in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
            $text = "$($proc.Name) $($proc.ExecutablePath) $($proc.CommandLine)"
            $match = Find-WatchlistEntry -Text $text -Watchlist $Watchlist -Mode Artifact
            if (-not $match) { continue }
            if ($Kind -eq 'Remote Access' -and [string]$proc.Name -match $genericHelperNames) { continue }
            $results.Add([PSCustomObject]@{
                Kind=$Kind; Product=$match.Name; Type='Process'; Name=[string]$proc.Name;
                Path=[string]$proc.ExecutablePath; Detail=[string]$proc.CommandLine
            }) | Out-Null
        }
    } catch { }

    try {
        foreach ($svc in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
            $text = "$($svc.Name) $($svc.DisplayName) $($svc.PathName)"
            $match = Find-WatchlistEntry -Text $text -Watchlist $Watchlist -Mode Artifact
            if (-not $match) { continue }
            $results.Add([PSCustomObject]@{
                Kind=$Kind; Product=$match.Name; Type='Service'; Name=[string]$svc.DisplayName;
                Path=[string]$svc.PathName; Detail="State: $($svc.State) | Start mode: $($svc.StartMode)"
            }) | Out-Null
        }
    } catch { }

    return @($results.ToArray() | Sort-Object Product, Type, Name, Path -Unique)
}

function Get-WatchlistArtifactMatches {
    param([int]$MaxResults = 150)

    $results = New-Object System.Collections.Generic.List[object]
    $roots = New-Object System.Collections.Generic.List[object]

    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData)) {
        if ($base -and (Test-Path -LiteralPath $base -PathType Container)) {
            $roots.Add([PSCustomObject]@{ Path=$base; Depth=3 }) | Out-Null
        }
    }
    foreach ($profile in Get-UserProfileRoots) {
        foreach ($relative in @('AppData\Local','AppData\Roaming','Downloads','Desktop')) {
            $path = Join-Path $profile $relative
            if (Test-Path -LiteralPath $path -PathType Container) {
                $roots.Add([PSCustomObject]@{ Path=$path; Depth=3 }) | Out-Null
            }
        }
    }

    $seen = @{}
    foreach ($root in $roots) {
        if ($results.Count -ge $MaxResults) { break }
        try {
            Get-ChildItem -LiteralPath $root.Path -Force -Recurse -Depth $root.Depth -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.PSIsContainer -or $_.Extension -in @('.exe','.dll','.bat','.cmd','.ps1','.vbs','.js','.hta','.scr','.lnk')
                } |
                ForEach-Object {
                    if ($results.Count -ge $MaxResults) { return }
                    $item = $_
                    if ((Test-IsInspectionOwnPath $item.FullName) -or $item.FullName -match '(?i)\\(cache|caches|code cache|gpucache|node_modules|windowsapps|packages)\\') { return }
                    $text = [string]$item.FullName
                    $remote = Find-WatchlistEntry -Text $text -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
                    $pup = Find-WatchlistEntry -Text $text -Watchlist $script:PupPuaWatchlist -Mode Artifact
                    foreach ($hit in @(
                        $(if ($remote) { [PSCustomObject]@{ Kind='Remote Access'; Product=$remote.Name } }),
                        $(if ($pup) { [PSCustomObject]@{ Kind='PUP/PUA'; Product=$pup.Name } })
                    )) {
                        if (-not $hit) { continue }
                        $key = "$($hit.Kind)|$($hit.Product)|$($item.FullName)"
                        if ($seen.ContainsKey($key)) { continue }
                        $seen[$key] = $true
                        $results.Add([PSCustomObject]@{
                            Kind=$hit.Kind; Product=$hit.Product; Path=$item.FullName;
                            ItemType=$(if ($item.PSIsContainer) { 'Folder' } else { 'File' });
                            Modified=$item.LastWriteTime
                        }) | Out-Null
                    }
                }
        } catch { }
    }

    return [PSCustomObject]@{ Matches=$results.ToArray(); Limited=($results.Count -ge $MaxResults) }
}

$script:SignatureCache = @{}
function Get-SignatureInfo {
    param([AllowNull()][string]$Path)

    $result = [PSCustomObject]@{
        Path      = $Path
        Exists    = $false
        Status    = 'Unknown'
        Signer    = ''
        Company   = ''
        LastWrite = $null
        Length    = $null
    }

    if ([string]::IsNullOrWhiteSpace($Path)) { return $result }

    $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
    $expanded = $expanded -replace '^\\\?\?\\', ''
    $expanded = $expanded -replace '^\\\\\?\\', ''
    if ($expanded -like '\SystemRoot\*') {
        $expanded = Join-Path $env:SystemRoot ($expanded.Substring(12))
    } elseif ($expanded -like 'System32\*') {
        $expanded = Join-Path $env:SystemRoot $expanded
    } else {
        # Autorunsc can return malformed/control-character paths. IsPathRooted()
        # throws on illegal path characters, so never let one bad row abort the
        # entire Autoruns inspection.
        $isRooted = $false
        try {
            $isRooted = [System.IO.Path]::IsPathRooted($expanded)
        } catch {
            $result.Status = 'InvalidPath'
            return $result
        }

        if (-not $isRooted) {
            try {
                $resolvedCommand = Get-Command $expanded -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($resolvedCommand -and $resolvedCommand.Source) { $expanded = $resolvedCommand.Source }
            } catch { }
        }
    }
    if ($script:SignatureCache.ContainsKey($expanded)) {
        return $script:SignatureCache[$expanded]
    }

    try {
        if (-not (Test-Path -LiteralPath $expanded -PathType Leaf)) {
            $script:SignatureCache[$expanded] = $result
            return $result
        }

        $item = Get-Item -LiteralPath $expanded -Force -ErrorAction Stop
        $result.Exists = $true
        $result.LastWrite = $item.LastWriteTime
        $result.Length = $item.Length

        try {
            $sig = Get-AuthenticodeSignature -LiteralPath $expanded -ErrorAction Stop
            $result.Status = [string]$sig.Status
            if ($sig.SignerCertificate) {
                $result.Signer = [string]$sig.SignerCertificate.Subject
            }
        } catch {
            $result.Status = 'Unknown'
        }

        try {
            $result.Company = [string]$item.VersionInfo.CompanyName
        } catch { }
    } catch { }

    $script:SignatureCache[$expanded] = $result
    return $result
}

function Get-ExecutablePathFromCommand {
    param([AllowNull()][string]$Command)

    if ([string]::IsNullOrWhiteSpace($Command)) { return $null }
    $expanded = [Environment]::ExpandEnvironmentVariables($Command.Trim())
    $expanded = $expanded -replace '^\\\?\?\\', ''
    $expanded = $expanded -replace '^\\\\\?\\', ''

    if ($expanded -match '^\s*"([^"]+)"') {
        return $matches[1]
    }

    # Handles unquoted executable paths that contain spaces, such as service ImagePath values.
    if ($expanded -match '^\s*(.+?\.(?:exe|com|bat|cmd|ps1|vbs|vbe|js|jse|hta|dll|sys|scr))(?=\s|$)') {
        return $matches[1].Trim().Trim('"')
    }

    $first = ($expanded -split '\s+', 2)[0].Trim('"')
    if ($first) { return $first }
    return $null
}

function Get-ReferencedScriptPaths {
    param([AllowNull()][string]$CommandLine)

    if ([string]::IsNullOrWhiteSpace($CommandLine)) { return @() }
    $expanded = [Environment]::ExpandEnvironmentVariables($CommandLine)
    $results = New-Object System.Collections.Generic.List[string]

    $patterns = @(
        '"([^"\r\n]+\.(?:ps1|vbs|vbe|js|jse|hta|bat|cmd|dll|scr|exe))"',
        '(?i)([A-Z]:\\[^\s"'']+\.(?:ps1|vbs|vbe|js|jse|hta|bat|cmd|dll|scr|exe))'
    )

    foreach ($pattern in $patterns) {
        foreach ($match in [regex]::Matches($expanded, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            $value = $match.Groups[1].Value
            if ($value -and -not $results.Contains($value)) {
                $results.Add($value) | Out-Null
            }
        }
    }

    return $results.ToArray()
}

function Test-UserWritableOrUnusualPath {
    param([AllowNull()][string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    $p = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"')).ToLowerInvariant()

    $needles = @(
        '\appdata\',
        '\temp\',
        '\downloads\',
        '\desktop\',
        '\users\public\',
        '\programdata\'
    )

    foreach ($needle in $needles) {
        if ($p.Contains($needle)) { return $true }
    }

    if ($p -match '^[a-z]:\\[^\\]+\.(exe|dll|bat|cmd|ps1|vbs|js|hta|scr)$') { return $true }
    return $false
}

function Test-SuspiciousCommandLine {
    param([AllowNull()][string]$CommandLine)

    if ([string]::IsNullOrWhiteSpace($CommandLine)) { return $false }
    $c = $CommandLine.ToLowerInvariant()

    if ($c -match '(powershell|pwsh)(\.exe)?\s+.*(-enc|-encodedcommand)\b') { return $true }
    if ($c -match '\bmshta(\.exe)?\b.*https?://') { return $true }
    if ($c -match '\b(rundll32|regsvr32)(\.exe)?\b.*https?://') { return $true }
    if ($c -match '\b(wscript|cscript)(\.exe)?\b.*\\(appdata|temp|downloads)\\') { return $true }
    return $false
}

function Format-FileContext {
    param([AllowNull()][string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return '' }
    $info = Get-SignatureInfo $Path
    if (-not $info.Exists) { return "Path: $Path | File not found" }

    $company = if ($info.Company) { $info.Company } elseif ($info.Signer) { $info.Signer } else { 'Unknown publisher' }
    $date = if ($info.LastWrite) { $info.LastWrite.ToString('yyyy-MM-dd HH:mm') } else { 'Unknown date' }
    return "Path: $Path | Signature: $($info.Status) | Publisher: $company | Modified: $date"
}

function Get-UserProfileRoots {
    $profiles = New-Object System.Collections.Generic.List[string]
    try {
        Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue |
            Where-Object { -not $_.Special -and $_.LocalPath -and (Test-Path -LiteralPath $_.LocalPath -PathType Container) } |
            ForEach-Object {
                if (-not $profiles.Contains([string]$_.LocalPath)) {
                    $profiles.Add([string]$_.LocalPath) | Out-Null
                }
            }
    } catch { }

    if ($profiles.Count -eq 0) {
        try {
            Get-ChildItem -LiteralPath "$env:SystemDrive\Users" -Directory -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -notin @('Public','Default','Default User','All Users') } |
                ForEach-Object { $profiles.Add($_.FullName) | Out-Null }
        } catch { }
    }

    return @($profiles.ToArray() | Sort-Object -Unique)
}

function Get-LoadedUserRegistryRoots {
    $roots = New-Object System.Collections.Generic.List[string]
    try {
        foreach ($key in Get-ChildItem Registry::HKEY_USERS -ErrorAction SilentlyContinue) {
            if ($key.PSChildName -match '^S-1-5-21-(\d+-){2,}\d+$') {
                $roots.Add("Registry::HKEY_USERS\$($key.PSChildName)") | Out-Null
            }
        }
    } catch { }
    return $roots.ToArray()
}

function Convert-InstallDate {
    param([AllowNull()][string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }

    $formats = @('yyyyMMdd','yyyy-MM-dd','MM/dd/yyyy','M/d/yyyy')
    foreach ($format in $formats) {
        $parsed = [datetime]::MinValue
        if ([datetime]::TryParseExact($Value, $format, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$parsed)) {
            return $parsed
        }
    }

    $fallback = [datetime]::MinValue
    if ([datetime]::TryParse($Value, [ref]$fallback)) { return $fallback }
    return $null
}

function Get-InstalledApplications {
    $apps = New-Object System.Collections.Generic.List[object]
    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )

    foreach ($path in $paths) {
        try {
            foreach ($item in @(Get-ItemProperty -Path $path -ErrorAction SilentlyContinue)) {
                if ([string]::IsNullOrWhiteSpace($item.DisplayName)) { continue }
                $apps.Add([PSCustomObject]@{
                    Name        = [string]$item.DisplayName
                    Version     = [string]$item.DisplayVersion
                    Publisher   = [string]$item.Publisher
                    InstallDate = Convert-InstallDate ([string]$item.InstallDate)
                    InstallPath = [string]$item.InstallLocation
                    Uninstall   = [string]$item.UninstallString
                }) | Out-Null
            }
        } catch { }
    }

    return @($apps.ToArray() | Sort-Object Name, Version -Unique)
}

function Get-ThirdPartyAppxPackages {
    $results = New-Object System.Collections.Generic.List[object]
    try {
        if (Get-Command Get-AppxPackage -ErrorAction SilentlyContinue) {
            foreach ($pkg in @(Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue)) {
                $publisher = [string]$pkg.Publisher
                if ($publisher -match '(?i)(CN=Microsoft|O=Microsoft Corporation)') { continue }
                $results.Add([PSCustomObject]@{
                    Name = [string]$pkg.Name
                    Version = [string]$pkg.Version
                    Publisher = $publisher
                    InstallLocation = [string]$pkg.InstallLocation
                }) | Out-Null
            }
        }
    } catch { }
    return @($results.ToArray() | Sort-Object Name, Version -Unique)
}

function Get-RemoteToolMatches {
    param([object[]]$Apps)
    return @(Get-WatchlistInstalledMatches -Apps $Apps -Watchlist $script:RemoteAccessWatchlist -Kind 'Remote Access')
}

function Get-RemoteToolRuntimeMatches {
    return @(Get-WatchlistRuntimeMatches -Watchlist $script:RemoteAccessWatchlist -Kind 'Remote Access')
}

function Get-PupPuaInstalledMatches {
    param([object[]]$Apps)
    return @(Get-WatchlistInstalledMatches -Apps $Apps -Watchlist $script:PupPuaWatchlist -Kind 'PUP/PUA')
}

function Get-PupPuaRuntimeMatches {
    return @(Get-WatchlistRuntimeMatches -Watchlist $script:PupPuaWatchlist -Kind 'PUP/PUA')
}

function Get-WmiPersistenceItems {
    $results = New-Object System.Collections.Generic.List[object]

    try {
        foreach ($item in @(Get-CimInstance -Namespace 'root\subscription' -ClassName CommandLineEventConsumer -ErrorAction SilentlyContinue)) {
            $results.Add([PSCustomObject]@{
                Type = 'CommandLineEventConsumer'
                Name = [string]$item.Name
                Detail = "Executable: $($item.ExecutablePath) | Command: $($item.CommandLineTemplate)"
                Severity = 'Review'
            }) | Out-Null
        }
    } catch { }

    try {
        foreach ($item in @(Get-CimInstance -Namespace 'root\subscription' -ClassName ActiveScriptEventConsumer -ErrorAction SilentlyContinue)) {
            $scriptText = [string]$item.ScriptText
            if ($scriptText.Length -gt 700) { $scriptText = $scriptText.Substring(0,700) + '...' }
            $results.Add([PSCustomObject]@{
                Type = 'ActiveScriptEventConsumer'
                Name = [string]$item.Name
                Detail = "Engine: $($item.ScriptingEngine) | Script: $scriptText"
                Severity = 'Review'
            }) | Out-Null
        }
    } catch { }

    return $results.ToArray()
}

function Get-StartupEntries {
    $entries = New-Object System.Collections.Generic.List[object]

    try {
        foreach ($item in @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue)) {
            $startupName = [string]$item.Name
            $startupCommand = [string]$item.Command
            if ([string]::IsNullOrWhiteSpace($startupName) -and [string]::IsNullOrWhiteSpace($startupCommand)) { continue }
            $entries.Add([PSCustomObject]@{
                Source  = 'Win32_StartupCommand'
                Name    = $startupName
                Command = $startupCommand
                User    = [string]$item.User
                Path    = Get-ExecutablePathFromCommand $startupCommand
            }) | Out-Null
        }
    } catch { }

    $registryTargets = New-Object System.Collections.Generic.List[object]
    foreach ($base in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion')) {
        foreach ($leaf in @('Run','RunOnce')) {
            $registryTargets.Add([PSCustomObject]@{ Label = "$base\$leaf"; Path = "$base\$leaf" }) | Out-Null
        }
    }

    foreach ($root in Get-LoadedUserRegistryRoots) {
        foreach ($leaf in @('Run','RunOnce')) {
            $path = "$root\Software\Microsoft\Windows\CurrentVersion\$leaf"
            $registryTargets.Add([PSCustomObject]@{ Label = $path; Path = $path }) | Out-Null
        }
    }

    foreach ($target in $registryTargets) {
        try {
            if (-not (Test-Path -LiteralPath $target.Path)) { continue }
            $props = Get-ItemProperty -LiteralPath $target.Path -ErrorAction SilentlyContinue
            foreach ($prop in $props.PSObject.Properties) {
                if ($prop.Name -match '^PS(Path|ParentPath|ChildName|Drive|Provider)$') { continue }
                $command = [string]$prop.Value
                if ([string]::IsNullOrWhiteSpace($command)) { continue }
                $entries.Add([PSCustomObject]@{
                    Source  = $target.Label
                    Name    = $prop.Name
                    Command = $command
                    User    = ''
                    Path    = Get-ExecutablePathFromCommand $command
                }) | Out-Null
            }
        } catch { }
    }

    foreach ($profile in Get-UserProfileRoots) {
        $startupFolder = Join-Path $profile 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup'
        if (-not (Test-Path -LiteralPath $startupFolder -PathType Container)) { continue }
        try {
            foreach ($file in @(Get-ChildItem -LiteralPath $startupFolder -Force -File -ErrorAction SilentlyContinue)) {
                if ($file.Name -ieq 'desktop.ini') { continue }
                $entries.Add([PSCustomObject]@{
                    Source  = $startupFolder
                    Name    = $file.Name
                    Command = $file.FullName
                    User    = Split-Path $profile -Leaf
                    Path    = $file.FullName
                }) | Out-Null
            }
        } catch { }
    }

    $commonStartup = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp'
    if (Test-Path -LiteralPath $commonStartup -PathType Container) {
        try {
            foreach ($file in @(Get-ChildItem -LiteralPath $commonStartup -Force -File -ErrorAction SilentlyContinue)) {
                if ($file.Name -ieq 'desktop.ini') { continue }
                $entries.Add([PSCustomObject]@{
                    Source  = $commonStartup
                    Name    = $file.Name
                    Command = $file.FullName
                    User    = 'All Users'
                    Path    = $file.FullName
                }) | Out-Null
            }
        } catch { }
    }

    # Win32_StartupCommand overlaps heavily with Run/RunOnce. Deduplicate by normalized path/command.
    $dedup = @{}
    $ordered = New-Object System.Collections.Generic.List[object]
    foreach ($entry in @($entries.ToArray() | Sort-Object @{Expression={ if ($_.Source -eq 'Win32_StartupCommand') { 2 } else { 1 } }}, Source, Name)) {
        $pathKey = ([string]$entry.Path).Trim().Trim('"').ToLowerInvariant()
        $commandKey = ([string]$entry.Command).Trim().ToLowerInvariant()
        if ($pathKey) {
            $key = $pathKey + '|' + ($commandKey -replace '^\s*"?[^" ]+"?\s*','')
        } else {
            $key = $commandKey
        }
        if (-not $key) { $key = (([string]$entry.Name) + '|' + ([string]$entry.Source)).ToLowerInvariant() }
        if ($dedup.ContainsKey($key)) { continue }
        $dedup[$key] = $true
        $ordered.Add($entry) | Out-Null
    }
    return $ordered.ToArray()
}

function Get-SuspiciousScheduledTasks {
    $results = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($task in @(Get-ScheduledTask -ErrorAction SilentlyContinue)) {
            foreach ($action in @($task.Actions)) {
                if (-not $action) { continue }
                $command = (([string]$action.Execute) + ' ' + ([string]$action.Arguments)).Trim()
                $exePath = Get-ExecutablePathFromCommand ([string]$action.Execute)
                $targets = @(Get-ReferencedScriptPaths $command)
                $severity = 'Info'
                $reason = New-Object System.Collections.Generic.List[string]

                $remoteHit = Find-WatchlistEntry -Text $command -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
                $pupHit = Find-WatchlistEntry -Text $command -Watchlist $script:PupPuaWatchlist -Mode Artifact
                if ($remoteHit -or $pupHit) {
                    $severity = 'Warning'
                    if ($remoteHit) { $reason.Add("Remote-access watchlist: $($remoteHit.Name)") | Out-Null }
                    if ($pupHit) { $reason.Add("PUP/PUA watchlist: $($pupHit.Name)") | Out-Null }
                } elseif (Test-SuspiciousCommandLine $command) {
                    $severity = 'Warning'
                    $reason.Add('Strongly suspicious command pattern') | Out-Null
                } else {
                    $needsReview = $false
                    if (Test-UserWritableOrUnusualPath $exePath) {
                        $sig = Get-SignatureInfo $exePath
                        if (-not $sig.Exists -or $sig.Status -ne 'Valid') {
                            $needsReview = $true
                            $reason.Add("Executable in user-writable/unusual path with signature $($sig.Status)") | Out-Null
                        }
                    }
                    foreach ($target in $targets) {
                        if (-not (Test-UserWritableOrUnusualPath $target)) { continue }
                        $sig = Get-SignatureInfo $target
                        if (-not $sig.Exists -or $sig.Status -ne 'Valid') {
                            $needsReview = $true
                            $reason.Add("Referenced target needs review: $target ($($sig.Status))") | Out-Null
                        }
                    }
                    if ($needsReview) { $severity = 'Review' }
                }

                if ($severity -eq 'Info') { continue }
                $results.Add([PSCustomObject]@{
                    TaskName  = $task.TaskName
                    TaskPath  = $task.TaskPath
                    State     = [string]$task.State
                    Command   = $command
                    Severity  = $severity
                    Reason    = ($reason -join '; ')
                    RemoteHit = if ($remoteHit) { $remoteHit.Name } else { '' }
                    PupHit    = if ($pupHit) { $pupHit.Name } else { '' }
                }) | Out-Null
            }
        }
    } catch { }
    return @($results.ToArray() | Sort-Object TaskPath, TaskName, Command -Unique)
}

function Get-ServiceDriverFindings {
    $results = New-Object System.Collections.Generic.List[object]

    try {
        foreach ($svc in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
            $raw = [string]$svc.PathName
            $path = Get-ExecutablePathFromCommand $raw
            if ([string]::IsNullOrWhiteSpace($path)) { continue }
            if (-not (Test-UserWritableOrUnusualPath $path)) { continue }
            $sig = Get-SignatureInfo $path
            if ($sig.Exists -and $sig.Status -eq 'Valid') { continue }
            $results.Add([PSCustomObject]@{
                Type      = 'Service'
                Name      = [string]$svc.Name
                Display   = [string]$svc.DisplayName
                State     = [string]$svc.State
                StartMode = [string]$svc.StartMode
                Path      = $path
                Signature = $sig.Status
                Severity  = 'Review'
            }) | Out-Null
        }
    } catch { }

    try {
        foreach ($drv in @(Get-CimInstance Win32_SystemDriver -ErrorAction SilentlyContinue)) {
            $raw = [string]$drv.PathName
            $path = Get-ExecutablePathFromCommand $raw
            if ([string]::IsNullOrWhiteSpace($path)) { continue }
            if ($path -like '\SystemRoot\*') { $path = Join-Path $env:SystemRoot ($path.Substring(12)) }
            if ($path -like 'System32\*') { $path = Join-Path $env:SystemRoot $path }
            $sig = Get-SignatureInfo $path
            $review = (-not $sig.Exists) -or ($sig.Status -ne 'Valid' -and (Test-UserWritableOrUnusualPath $path))
            if (-not $review) { continue }
            $results.Add([PSCustomObject]@{
                Type      = 'Driver'
                Name      = [string]$drv.Name
                Display   = [string]$drv.DisplayName
                State     = [string]$drv.State
                StartMode = [string]$drv.StartMode
                Path      = $path
                Signature = $sig.Status
                Severity  = 'Review'
            }) | Out-Null
        }
    } catch { }

    return @($results.ToArray() | Sort-Object Type, Name, Path -Unique)
}

function Get-ProcessFindings {
    $rawResults = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($proc in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
            $path = [string]$proc.ExecutablePath
            if ([string]::IsNullOrWhiteSpace($path)) { continue }
            $warning = Test-SuspiciousCommandLine ([string]$proc.CommandLine)
            $unusual = Test-UserWritableOrUnusualPath $path
            $sig = if ($warning -or $unusual) { Get-SignatureInfo $path } else { $null }
            $review = $unusual -and (-not $sig.Exists -or $sig.Status -ne 'Valid')
            if (-not $warning -and -not $review) { continue }

            $rawResults.Add([PSCustomObject]@{
                Name        = [string]$proc.Name
                PID         = [int]$proc.ProcessId
                Path        = $path
                CommandLine = [string]$proc.CommandLine
                Signature   = if ($sig) { $sig.Status } else { 'Unknown' }
                Publisher   = if ($sig) { if ($sig.Company) { $sig.Company } else { $sig.Signer } } else { '' }
                Severity    = if ($warning) { 'Warning' } else { 'Review' }
            }) | Out-Null
        }
    } catch { }

    # Aggregate multi-process applications (Chromium/Electron/etc.) by executable path and severity.
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($group in @($rawResults.ToArray() | Group-Object Severity, Path, Name)) {
        $first = $group.Group | Select-Object -First 1
        $pids = @($group.Group | Select-Object -ExpandProperty PID | Sort-Object -Unique)
        $results.Add([PSCustomObject]@{
            Name        = $first.Name
            PID         = ($pids -join ', ')
            InstanceCount = $group.Count
            Path        = $first.Path
            CommandLine = $first.CommandLine
            Signature   = $first.Signature
            Publisher   = $first.Publisher
            Severity    = $first.Severity
        }) | Out-Null
    }
    return $results.ToArray()
}

function Get-RecentFileCandidates {
    param(
        [int]$Days,
        [int]$MaxResults = 250
    )

    $cutoff = (Get-Date).AddDays(-1 * $Days)
    $extensions = @('.exe','.dll','.bat','.cmd','.ps1','.vbs','.vbe','.js','.jse','.hta','.scr')
    $results = New-Object System.Collections.Generic.List[object]
    $scanned = 0

    $targets = New-Object System.Collections.Generic.List[object]
    foreach ($profile in Get-UserProfileRoots) {
        foreach ($relative in @('AppData\Roaming','AppData\Local','Downloads','Desktop')) {
            $path = Join-Path $profile $relative
            if (Test-Path -LiteralPath $path -PathType Container) {
                $depth = if ($relative -in @('Downloads','Desktop')) { 4 } else { 4 }
                $targets.Add([PSCustomObject]@{ Path = $path; Depth = $depth }) | Out-Null
            }
        }
    }

    if (Test-Path -LiteralPath $env:ProgramData -PathType Container) {
        $targets.Add([PSCustomObject]@{ Path = $env:ProgramData; Depth = 4 }) | Out-Null
    }

    foreach ($target in $targets) {
        if ($results.Count -ge $MaxResults) { break }
        try {
            foreach ($file in @(Get-ChildItem -LiteralPath $target.Path -File -Force -Recurse -Depth $target.Depth -ErrorAction SilentlyContinue)) {
                if ($results.Count -ge $MaxResults) { break }
                if ($file.LastWriteTime -lt $cutoff) { continue }
                if ($extensions -notcontains $file.Extension.ToLowerInvariant()) { continue }
                $scanned++

                $skip = (Test-IsInspectionOwnPath $file.FullName) -or ($file.FullName -match '(?i)\\(cache|caches|code cache|gpucache|node_modules|windowsapps|packages)\\')
                if ($skip) { continue }

                $sig = Get-SignatureInfo $file.FullName
                $ext = $file.Extension.ToLowerInvariant()
                $highSignalScript = $ext -in @('.bat','.cmd','.ps1','.vbs','.vbe','.jse','.hta','.scr')
                $unsignedExecutable = ($ext -eq '.exe' -and $sig.Status -ne 'Valid')
                $noisyTypeInHighRiskLocation = ($ext -in @('.dll','.js')) -and ($sig.Status -ne 'Valid') -and ($file.FullName -match '(?i)\\(temp|downloads|desktop)\\')
                $review = $highSignalScript -or $unsignedExecutable -or $noisyTypeInHighRiskLocation
                if (-not $review) { continue }

                $results.Add([PSCustomObject]@{
                    Path       = $file.FullName
                    Modified   = $file.LastWriteTime
                    SizeKB     = [math]::Round($file.Length / 1KB, 1)
                    Signature  = $sig.Status
                    Publisher  = if ($sig.Company) { $sig.Company } else { $sig.Signer }
                    Severity   = 'Review'
                }) | Out-Null
            }
        } catch { }
    }

    # C:\ root only, not recursive.
    try {
        foreach ($file in @(Get-ChildItem -LiteralPath "$env:SystemDrive\" -File -Force -ErrorAction SilentlyContinue)) {
            if ($results.Count -ge $MaxResults) { break }
            if ($file.LastWriteTime -lt $cutoff) { continue }
            if ($extensions -notcontains $file.Extension.ToLowerInvariant()) { continue }
            if (Test-IsInspectionOwnPath $file.FullName) { continue }
            $sig = Get-SignatureInfo $file.FullName
            $results.Add([PSCustomObject]@{
                Path       = $file.FullName
                Modified   = $file.LastWriteTime
                SizeKB     = [math]::Round($file.Length / 1KB, 1)
                Signature  = $sig.Status
                Publisher  = if ($sig.Company) { $sig.Company } else { $sig.Signer }
                Severity   = 'Review'
            }) | Out-Null
        }
    } catch { }

    return [PSCustomObject]@{
        Files   = $results.ToArray()
        Scanned = $scanned
        Limited = ($results.Count -ge $MaxResults)
    }
}

function Get-ChromiumProfileLocations {
    $results = New-Object System.Collections.Generic.List[object]
    $browserDefs = @(
        @{ Name='Chrome';   Relative='AppData\Local\Google\Chrome\User Data';                     Direct=$false },
        @{ Name='Edge';     Relative='AppData\Local\Microsoft\Edge\User Data';                    Direct=$false },
        @{ Name='Brave';    Relative='AppData\Local\BraveSoftware\Brave-Browser\User Data';       Direct=$false },
        @{ Name='Vivaldi';  Relative='AppData\Local\Vivaldi\User Data';                           Direct=$false },
        @{ Name='Opera GX'; Relative='AppData\Roaming\Opera Software\Opera GX Stable';            Direct=$true  },
        @{ Name='Opera';    Relative='AppData\Roaming\Opera Software\Opera Stable';               Direct=$true  }
    )

    foreach ($profileRoot in Get-UserProfileRoots) {
        $userName = Split-Path $profileRoot -Leaf
        foreach ($browser in $browserDefs) {
            $base = Join-Path $profileRoot $browser.Relative
            if (-not (Test-Path -LiteralPath $base -PathType Container)) { continue }

            if ($browser.Direct) {
                if (Test-Path -LiteralPath (Join-Path $base 'Preferences') -PathType Leaf) {
                    $results.Add([PSCustomObject]@{
                        Browser=$browser.Name; User=$userName; Profile='Default'; Path=$base
                    }) | Out-Null
                }
            } else {
                foreach ($profile in @(Get-ChildItem -LiteralPath $base -Directory -Force -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' })) {
                    if (-not (Test-Path -LiteralPath (Join-Path $profile.FullName 'Preferences') -PathType Leaf)) { continue }
                    $results.Add([PSCustomObject]@{
                        Browser=$browser.Name; User=$userName; Profile=$profile.Name; Path=$profile.FullName
                    }) | Out-Null
                }
            }
        }
    }

    return $results.ToArray()
}

function Resolve-ChromiumExtensionName {
    param(
        [Parameter(Mandatory)][string]$ManifestPath,
        [AllowNull()][string]$RawName
    )

    if ([string]::IsNullOrWhiteSpace($RawName)) { return 'Unknown extension' }
    if ($RawName -notmatch '^__MSG_(.+)__$') { return $RawName }

    $key = $matches[1]
    $versionFolder = Split-Path $ManifestPath -Parent
    $locales = New-Object System.Collections.Generic.List[string]

    try {
        $manifestJson = Get-Content -LiteralPath $ManifestPath -Raw -ErrorAction Stop | ConvertFrom-Json
        if ($manifestJson.default_locale) { $locales.Add([string]$manifestJson.default_locale) | Out-Null }
    } catch { }

    foreach ($locale in @('en','en_US','en_GB')) {
        if (-not $locales.Contains($locale)) { $locales.Add($locale) | Out-Null }
    }

    $localeRoot = Join-Path $versionFolder '_locales'
    if (Test-Path -LiteralPath $localeRoot -PathType Container) {
        try {
            foreach ($dir in @(Get-ChildItem -LiteralPath $localeRoot -Directory -Force -ErrorAction SilentlyContinue)) {
                if (-not $locales.Contains($dir.Name)) { $locales.Add($dir.Name) | Out-Null }
            }
        } catch { }
    }

    foreach ($locale in $locales) {
        $messages = Join-Path $versionFolder "_locales\$locale\messages.json"
        if (-not (Test-Path -LiteralPath $messages -PathType Leaf)) { continue }
        try {
            $json = Get-Content -LiteralPath $messages -Raw -ErrorAction Stop | ConvertFrom-Json
            $prop = $json.PSObject.Properties[$key]
            if ($prop -and $prop.Value.message) { return [string]$prop.Value.message }
        } catch { }
    }
    return $RawName
}

function Get-ChromiumExtensions {
    $results = New-Object System.Collections.Generic.List[object]

    foreach ($browserProfile in @(Get-ChromiumProfileLocations)) {
        $extensionsRoot = Join-Path $browserProfile.Path 'Extensions'
        if (-not (Test-Path -LiteralPath $extensionsRoot -PathType Container)) { continue }

        foreach ($extensionId in @(Get-ChildItem -LiteralPath $extensionsRoot -Directory -Force -ErrorAction SilentlyContinue)) {
            $versions = @(Get-ChildItem -LiteralPath $extensionId.FullName -Directory -Force -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
            if ($versions.Count -eq 0) { continue }
            $manifest = Join-Path $versions[0].FullName 'manifest.json'
            if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
            try {
                $json = Get-Content -LiteralPath $manifest -Raw -ErrorAction Stop | ConvertFrom-Json
                $name = Resolve-ChromiumExtensionName -ManifestPath $manifest -RawName ([string]$json.name)
                $results.Add([PSCustomObject]@{
                    Browser   = $browserProfile.Browser
                    User      = $browserProfile.User
                    Profile   = $browserProfile.Profile
                    Name      = $name
                    ID        = $extensionId.Name
                    Version   = [string]$json.version
                    UpdateURL = [string]$json.update_url
                }) | Out-Null
            } catch { }
        }
    }

    return $results.ToArray()
}

function Get-BrowserNotificationAssessment {
    param([Parameter(Mandatory)][string]$Origin)

    $displayOrigin = ($Origin -split ',',2)[0].Trim()
    $severity = 'Review'
    $reason = 'Notifications are allowed; confirm this site is expected.'
    $host = ''
    $scheme = ''
    $port = ''

    if ($displayOrigin -match '^(?<scheme>https?)://(?:\[\*\.\])?(?<host>[^/:,]+)(?::(?<port>\d+))?') {
        $scheme = $matches['scheme'].ToLowerInvariant()
        $host = $matches['host'].Trim().TrimEnd('.').ToLowerInvariant()
        $port = $matches['port']
    } elseif ($displayOrigin -match '^(?:\[\*\.\])?(?<host>[^/:,]+)') {
        $host = $matches['host'].Trim().TrimEnd('.').ToLowerInvariant()
    }

    $pupHit = Find-WatchlistEntry -Text "$displayOrigin $host" -Watchlist $script:PupPuaWatchlist -Mode Artifact
    if ($pupHit) {
        return [PSCustomObject]@{
            Severity='Warning'; Display=$displayOrigin; Host=$host
            Reason="Allowed notification origin matches PUP/PUA watchlist: $($pupHit.Name)"
        }
    }

    if ($scheme -eq 'http') {
        return [PSCustomObject]@{
            Severity='Warning'; Display=$displayOrigin; Host=$host
            Reason='Notifications are allowed from a non-HTTPS origin.'
        }
    }

    if ($host -match '(^|\.)xn--') {
        return [PSCustomObject]@{
            Severity='Warning'; Display=$displayOrigin; Host=$host
            Reason='Allowed notification host uses Punycode; verify the domain carefully.'
        }
    }

    $ip = [System.Net.IPAddress]::None
    if ($host -and [System.Net.IPAddress]::TryParse($host, [ref]$ip)) {
        $bytes = $ip.GetAddressBytes()
        $isPrivate = $false
        if ($bytes.Length -eq 4) {
            $isPrivate = ($bytes[0] -eq 10) -or
                         ($bytes[0] -eq 127) -or
                         ($bytes[0] -eq 192 -and $bytes[1] -eq 168) -or
                         ($bytes[0] -eq 172 -and $bytes[1] -ge 16 -and $bytes[1] -le 31)
        }
        if (-not $isPrivate) {
            return [PSCustomObject]@{
                Severity='Warning'; Display=$displayOrigin; Host=$host
                Reason='Notifications are allowed directly from a public IP address.'
            }
        }
    }

    if ($port -and $port -notin @('443','80')) {
        $reason = "Notifications are allowed on nonstandard port $port; confirm this site is expected."
    }

    return [PSCustomObject]@{
        Severity=$severity; Display=$displayOrigin; Host=$host; Reason=$reason
    }
}

function Get-ChromiumBrowserSettings {
    $results = New-Object System.Collections.Generic.List[object]

    foreach ($browserProfile in @(Get-ChromiumProfileLocations)) {
        $preferencesPath = Join-Path $browserProfile.Path 'Preferences'
        if (-not (Test-Path -LiteralPath $preferencesPath -PathType Leaf)) { continue }

        try {
            $json = Get-Content -LiteralPath $preferencesPath -Raw -ErrorAction Stop | ConvertFrom-Json
            $homepage = [string]$json.homepage
            $startupMode = [string]$json.session.restore_on_startup
            $startupUrls = @($json.session.startup_urls) -join ', '
            $searchName = ''
            try { $searchName = [string]$json.default_search_provider_data.template_url_data.short_name } catch { }
            if (-not $searchName) {
                try { $searchName = [string]$json.default_search_provider.name } catch { }
            }

            $detailParts = New-Object System.Collections.Generic.List[string]
            if ($homepage) { $detailParts.Add("Homepage: $homepage") | Out-Null }
            if ($startupMode) { $detailParts.Add("Startup mode: $startupMode") | Out-Null }
            if ($startupUrls) { $detailParts.Add("Startup URLs: $startupUrls") | Out-Null }
            if ($searchName) { $detailParts.Add("Search: $searchName") | Out-Null }
            if ($detailParts.Count -gt 0) {
                $results.Add([PSCustomObject]@{
                    Type='Settings'; Browser=$browserProfile.Browser; User=$browserProfile.User; Profile=$browserProfile.Profile;
                    Name='Homepage / Startup / Search'; Detail=($detailParts -join ' | '); Severity='Info'
                }) | Out-Null
            }

            try {
                $notificationRoot = $json.profile.content_settings.exceptions.notifications
                if ($notificationRoot) {
                    foreach ($prop in $notificationRoot.PSObject.Properties) {
                        $setting = $null
                        try { $setting = [int]$prop.Value.setting } catch { }
                        if ($setting -ne 1) { continue }

                        $assessment = Get-BrowserNotificationAssessment -Origin $prop.Name
                        $results.Add([PSCustomObject]@{
                            Type='Notification'; Browser=$browserProfile.Browser; User=$browserProfile.User; Profile=$browserProfile.Profile;
                            Name=$assessment.Display; Detail=("Notifications allowed | " + $assessment.Reason); Severity=$assessment.Severity
                        }) | Out-Null
                    }
                }
            } catch { }
        } catch { }
    }

    return $results.ToArray()
}

function Get-FirefoxBrowserSettings {
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($profileRoot in Get-UserProfileRoots) {
        $userName = Split-Path $profileRoot -Leaf
        $profilesRoot = Join-Path $profileRoot 'AppData\Roaming\Mozilla\Firefox\Profiles'
        if (-not (Test-Path -LiteralPath $profilesRoot -PathType Container)) { continue }
        try {
            foreach ($ffProfile in @(Get-ChildItem -LiteralPath $profilesRoot -Directory -Force -ErrorAction SilentlyContinue)) {
                $prefsPath = Join-Path $ffProfile.FullName 'prefs.js'
                if (-not (Test-Path -LiteralPath $prefsPath -PathType Leaf)) { continue }
                $interesting = @()
                try {
                    $interesting = @(Get-Content -LiteralPath $prefsPath -ErrorAction SilentlyContinue | Where-Object {
                        $_ -match 'user_pref\("browser\.startup\.(homepage|page)"' -or
                        $_ -match 'user_pref\("browser\.search\.(defaultenginename|selectedEngine)"'
                    })
                } catch { }
                if ($interesting.Count -gt 0) {
                    $results.Add([PSCustomObject]@{
                        Type='Settings'; Browser='Firefox'; User=$userName; Profile=$ffProfile.Name;
                        Name='Homepage / Startup / Search'; Detail=($interesting -join ' | '); Severity='Info'
                    }) | Out-Null
                }
            }
        } catch { }
    }
    return $results.ToArray()
}

function Get-FirefoxExtensions {
    $results = New-Object System.Collections.Generic.List[object]
    foreach ($profileRoot in Get-UserProfileRoots) {
        $userName = Split-Path $profileRoot -Leaf
        $profilesRoot = Join-Path $profileRoot 'AppData\Roaming\Mozilla\Firefox\Profiles'
        if (-not (Test-Path -LiteralPath $profilesRoot -PathType Container)) { continue }
        try {
            foreach ($ffProfile in @(Get-ChildItem -LiteralPath $profilesRoot -Directory -Force -ErrorAction SilentlyContinue)) {
                $extensionsJson = Join-Path $ffProfile.FullName 'extensions.json'
                if (-not (Test-Path -LiteralPath $extensionsJson -PathType Leaf)) { continue }
                try {
                    $json = Get-Content -LiteralPath $extensionsJson -Raw -ErrorAction Stop | ConvertFrom-Json
                    foreach ($addon in @($json.addons)) {
                        if (-not $addon.active) { continue }
                        $results.Add([PSCustomObject]@{
                            Browser    = 'Firefox'
                            User       = $userName
                            Profile    = $ffProfile.Name
                            Name       = if ($addon.defaultLocale.name) { [string]$addon.defaultLocale.name } else { [string]$addon.id }
                            ID         = [string]$addon.id
                            Version    = [string]$addon.version
                            SignedState= [string]$addon.signedState
                        }) | Out-Null
                    }
                } catch { }
            }
        } catch { }
    }
    return $results.ToArray()
}

function Get-BrowserPolicyFindings {
    $results = New-Object System.Collections.Generic.List[object]
    $targets = @(
        @{ Browser='Chrome'; Path='HKLM:\SOFTWARE\Policies\Google\Chrome' },
        @{ Browser='Chrome'; Path='HKCU:\SOFTWARE\Policies\Google\Chrome' },
        @{ Browser='Edge'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Edge' },
        @{ Browser='Edge'; Path='HKCU:\SOFTWARE\Policies\Microsoft\Edge' },
        @{ Browser='Brave'; Path='HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' },
        @{ Browser='Brave'; Path='HKCU:\SOFTWARE\Policies\BraveSoftware\Brave' },
        @{ Browser='Firefox'; Path='HKLM:\SOFTWARE\Policies\Mozilla\Firefox' },
        @{ Browser='Firefox'; Path='HKCU:\SOFTWARE\Policies\Mozilla\Firefox' }
    )

    foreach ($target in $targets) {
        if (-not (Test-Path -LiteralPath $target.Path)) { continue }
        try {
            $props = Get-ItemProperty -LiteralPath $target.Path -ErrorAction SilentlyContinue
            $named = @($props.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS(Path|ParentPath|ChildName|Drive|Provider)$' })
            if ($named.Count -gt 0) {
                $text = ($named | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; '
                $results.Add([PSCustomObject]@{ Browser=$target.Browser; Path=$target.Path; Values=$text; Severity='Review' }) | Out-Null
            }

            foreach ($sub in @(Get-ChildItem -LiteralPath $target.Path -Recurse -ErrorAction SilentlyContinue)) {
                $subProps = Get-ItemProperty -LiteralPath $sub.PSPath -ErrorAction SilentlyContinue
                $values = @($subProps.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS(Path|ParentPath|ChildName|Drive|Provider)$' })
                if ($values.Count -eq 0) { continue }
                $text = ($values | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; '
                $results.Add([PSCustomObject]@{ Browser=$target.Browser; Path=$sub.Name; Values=$text; Severity='Review' }) | Out-Null
            }
        } catch { }
    }

    return @($results.ToArray() | Sort-Object Browser, Path -Unique)
}

function Get-HostsEntries {
    $path = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
    $entries = New-Object System.Collections.Generic.List[string]
    try {
        foreach ($line in @(Get-Content -LiteralPath $path -ErrorAction SilentlyContinue)) {
            $trim = $line.Trim()
            if (-not $trim -or $trim.StartsWith('#')) { continue }
            if ($trim -match '^\s*(127\.0\.0\.1|::1)\s+localhost\s*$') { continue }
            $entries.Add($trim) | Out-Null
        }
    } catch { }
    return $entries.ToArray()
}

function Get-ExternalEstablishedConnections {
    $results = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($conn in @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue)) {
            $remote = [string]$conn.RemoteAddress
            if ($remote -in @('127.0.0.1','::1','0.0.0.0','::')) { continue }
            $procName = ''
            $procPath = ''
            try {
                $proc = Get-Process -Id $conn.OwningProcess -ErrorAction Stop
                $procName = $proc.ProcessName
                try { $procPath = $proc.Path } catch { }
            } catch { }

            $severity = 'Info'
            $product = ''
            $watchText = "$procName $procPath"
            $remoteHit = Find-WatchlistEntry -Text $watchText -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
            $pupHit = Find-WatchlistEntry -Text $watchText -Watchlist $script:PupPuaWatchlist -Mode Artifact
            if ($remoteHit -or $pupHit) {
                $severity = 'Warning'
                $product = if ($remoteHit) { $remoteHit.Name } else { $pupHit.Name }
            } elseif (Test-UserWritableOrUnusualPath $procPath) {
                $sig = Get-SignatureInfo $procPath
                if (-not $sig.Exists -or $sig.Status -ne 'Valid') { $severity = 'Review' }
            }

            $results.Add([PSCustomObject]@{
                Process     = $procName
                PID         = [int]$conn.OwningProcess
                Local       = "$($conn.LocalAddress):$($conn.LocalPort)"
                Remote      = "$($conn.RemoteAddress):$($conn.RemotePort)"
                ProcessPath = $procPath
                Severity    = $severity
                Product     = $product
            }) | Out-Null
        }
    } catch { }
    return $results.ToArray()
}

function Get-AutorunsData {
    param([switch]$SkipDownload)

    $result = [PSCustomObject]@{
        Available = $false
        Downloaded = $false
        Message = ''
        Entries = @()
    }

    try {
        New-Item -ItemType Directory -Path $autorunsRoot -Force | Out-Null

        $exeName = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') {
            'Autorunsc64a.exe'
        } elseif ([Environment]::Is64BitOperatingSystem) {
            'Autorunsc64.exe'
        } else {
            'Autorunsc.exe'
        }

        $autorunExe = $null
        $candidateNames = @($exeName, 'Autorunsc64.exe', 'Autorunsc.exe') | Select-Object -Unique

        foreach ($candidate in $candidateNames) {
            $cmd = Get-Command $candidate -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($cmd -and $cmd.Source) {
                $autorunExe = $cmd.Source
                break
            }
        }

        if (-not $autorunExe -and -not $SkipDownload) {
            try {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                Invoke-WebRequest -Uri 'https://download.sysinternals.com/files/Autoruns.zip' -OutFile $autorunsZip -UseBasicParsing -ErrorAction Stop
                Expand-Archive -LiteralPath $autorunsZip -DestinationPath $autorunsRoot -Force
                $autorunExe = Join-Path $autorunsRoot $exeName
                if (-not (Test-Path -LiteralPath $autorunExe -PathType Leaf)) {
                    foreach ($candidate in $candidateNames) {
                        $fallback = Join-Path $autorunsRoot $candidate
                        if (Test-Path -LiteralPath $fallback -PathType Leaf) {
                            $autorunExe = $fallback
                            break
                        }
                    }
                }
                $result.Downloaded = $true
            } catch {
                $result.Message = "Autorunsc download failed: $($_.Exception.Message)"
            }
        }

        if (-not $autorunExe -or -not (Test-Path -LiteralPath $autorunExe -PathType Leaf)) {
            if (-not $result.Message) {
                $result.Message = if ($SkipDownload) { 'Autorunsc was not found and download was skipped.' } else { 'Autorunsc was not found.' }
            }
            return $result
        }

        $sig = Get-AuthenticodeSignature -LiteralPath $autorunExe -ErrorAction Stop
        $signerSubject = if ($sig.SignerCertificate) { [string]$sig.SignerCertificate.Subject } else { '' }
        if ($sig.Status -ne 'Valid' -or $signerSubject -notmatch 'Microsoft') {
            $result.Message = "Autorunsc was not executed because its Microsoft signature could not be verified. Signature: $($sig.Status); Signer: $signerSubject"
            return $result
        }

        $autorunsStdOut = Join-Path $tempRoot 'Autoruns.stdout.txt'
        $autorunsStdErr = Join-Path $tempRoot 'Autoruns.stderr.txt'
        Remove-Item -LiteralPath $autorunsStdOut, $autorunsStdErr -Force -ErrorAction SilentlyContinue

        $autorunsProcess = Start-Process -FilePath $autorunExe `
            -ArgumentList @('-accepteula','-a','*','-c','-h','-s','-m') `
            -RedirectStandardOutput $autorunsStdOut `
            -RedirectStandardError $autorunsStdErr `
            -WindowStyle Hidden -Wait -PassThru

        $outputLines = @()
        if (Test-Path -LiteralPath $autorunsStdOut -PathType Leaf) {
            $outputLines = @(Get-Content -LiteralPath $autorunsStdOut -ErrorAction SilentlyContinue | ForEach-Object { [string]$_ })
        }
        $errorLines = @()
        if (Test-Path -LiteralPath $autorunsStdErr -PathType Leaf) {
            $errorLines = @(Get-Content -LiteralPath $autorunsStdErr -ErrorAction SilentlyContinue | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        }

        if ($outputLines.Count -eq 0) {
            $diagnostic = if ($errorLines.Count -gt 0) { ($errorLines -join ' | ') } else { "Exit code $($autorunsProcess.ExitCode)" }
            $result.Message = "Autorunsc returned no parseable output. $diagnostic"
            return $result
        }
        $headerIndex = -1
        for ($i = 0; $i -lt $outputLines.Count; $i++) {
            if ($outputLines[$i] -match '(?i)Entry Location' -and $outputLines[$i] -match '(?i)Entry') {
                $headerIndex = $i
                break
            }
        }
        if ($headerIndex -lt 0) {
            $result.Message = 'Autorunsc output was returned, but its CSV header could not be recognized.'
            return $result
        }
        if ($headerIndex -gt 0) {
            $outputLines = @($outputLines[$headerIndex..($outputLines.Count - 1)])
        }
        $outputLines | Set-Content -LiteralPath $autorunsCsv -Encoding UTF8
        $rows = @($outputLines | ConvertFrom-Csv)
        $parsed = New-Object System.Collections.Generic.List[object]

        $seenRows = @{}
        foreach ($row in $rows) {
            $entry = [string](Get-PropertyValue -Object $row -Names @('Entry','Entry Name'))
            $location = [string](Get-PropertyValue -Object $row -Names @('Entry Location','Location'))
            $category = [string](Get-PropertyValue -Object $row -Names @('Category'))
            $profile = [string](Get-PropertyValue -Object $row -Names @('Profile'))
            $description = [string](Get-PropertyValue -Object $row -Names @('Description'))
            $signer = [string](Get-PropertyValue -Object $row -Names @('Signer'))
            $company = [string](Get-PropertyValue -Object $row -Names @('Company'))
            $image = [string](Get-PropertyValue -Object $row -Names @('Image Path','Image'))
            $launch = [string](Get-PropertyValue -Object $row -Names @('Launch String','Launch'))
            $enabled = [string](Get-PropertyValue -Object $row -Names @('Enabled'))
            $sha256 = [string](Get-PropertyValue -Object $row -Names @('SHA-256','SHA256'))

            # Suppress empty structural rows (commonly seen in Winsock categories).
            if ([string]::IsNullOrWhiteSpace($entry) -and [string]::IsNullOrWhiteSpace($image) -and [string]::IsNullOrWhiteSpace($launch) -and [string]::IsNullOrWhiteSpace($description)) { continue }

            $normalizedLocation = ($location -replace '(?i)\\Wow6432Node', '')
            $rowKey = ("{0}|{1}|{2}|{3}|{4}" -f $category,$entry,$normalizedLocation,$image,$launch).ToLowerInvariant()
            if ($seenRows.ContainsKey($rowKey)) { continue }
            $seenRows[$rowKey] = $true

            $combined = "$entry $description $image $launch $signer $company"
            $severity = 'Info'
            $reason = ''
            $remoteHit = Find-WatchlistEntry -Text $combined -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
            $pupHit = Find-WatchlistEntry -Text $combined -Watchlist $script:PupPuaWatchlist -Mode Artifact

            if ($remoteHit -or $pupHit) {
                $severity = 'Warning'
                $reason = if ($remoteHit) { "Remote-access watchlist: $($remoteHit.Name)" } else { "PUP/PUA watchlist: $($pupHit.Name)" }
            } elseif (Test-SuspiciousCommandLine $launch) {
                $severity = 'Warning'
                $reason = 'Strongly suspicious launch command'
            } else {
                $reportedMissing = $combined -match '(?i)file not found'
                $knownDllNoise = ($category -match '(?i)Known DLLs') -or ($location -match '(?i)KnownDlls')
                $candidatePath = Get-ExecutablePathFromCommand $image
                if (-not $candidatePath) { $candidatePath = Get-ExecutablePathFromCommand $launch }
                $sigInfo = if ($candidatePath) { Get-SignatureInfo $candidatePath } else { $null }

                $isWindowsAppAlias = $candidatePath -and ($candidatePath -match '(?i)\\AppData\\Local\\Microsoft\\WindowsApps\\')
                $isWindowsComponent = (($category -match '(?i)Scheduled Tasks') -and ($entry -match '^\\Microsoft\\Windows\\') -and ($candidatePath -match '(?i)^C:\\Windows\\')) -or
                                      (($location -match '(?i)Font Drivers') -and ($launch -match '(?i)^atmfd\.dll$'))
                $cleanLaunch = ($launch -replace '[\x00-\x1F]', '').Trim()
                $malformedMissingRow = $reportedMissing -and ($image -match '(?i)file not found:\s*\.exe\s*$') -and [string]::IsNullOrWhiteSpace($cleanLaunch)

                if ($malformedMissingRow) {
                    $severity = 'Info'
                    $reason = 'Malformed/empty Autoruns structural row suppressed from attention'
                } elseif ($reportedMissing -and -not $knownDllNoise -and -not $isWindowsAppAlias -and -not $isWindowsComponent) {
                    if ($candidatePath -and (Test-UserWritableOrUnusualPath $candidatePath)) {
                        $severity = 'Review'
                        $reason = 'Autoruns reports a missing target in a user-writable/unusual location'
                    } else {
                        $severity = 'Info'
                        $reason = 'Stale/missing target in a normal vendor/system location'
                    }
                } elseif ($candidatePath -and (Test-UserWritableOrUnusualPath $candidatePath)) {
                    if (-not $sigInfo.Exists -or $sigInfo.Status -ne 'Valid') {
                        $severity = 'Review'
                        $reason = "User-writable/unusual path; signature $($sigInfo.Status)"
                    }
                }
                # "Not verified" alone is not sufficient to flag files in normal Program Files locations.
            }

            $parsed.Add([PSCustomObject]@{
                Entry       = $entry
                Location    = $location
                Category    = $category
                Profile     = $profile
                Description = $description
                Signer      = $signer
                Company     = $company
                ImagePath   = $image
                Launch      = $launch
                Enabled     = $enabled
                SHA256      = $sha256
                Severity    = $severity
                Reason      = $reason
                Product     = if ($remoteHit) { $remoteHit.Name } elseif ($pupHit) { $pupHit.Name } else { '' }
            }) | Out-Null
        }

        $result.Available = $true
        $result.Entries = $parsed.ToArray()
        $result.Message = "Autorunsc inspected all autostart categories for the current user and system-wide locations while hiding Microsoft entries. $($parsed.Count) third-party/non-Microsoft entries were returned."
        $unexpectedDiagnostics = @($errorLines | Where-Object { $_ -notmatch '(?i)^Error expanding profile path for NT AUTHORITY\\(?:LOCAL SERVICE|NETWORK SERVICE|SYSTEM)' })
        if ($unexpectedDiagnostics.Count -gt 0) {
            $result.Message += " Autorunsc diagnostic: " + (($unexpectedDiagnostics | Select-Object -First 3) -join ' | ')
        }
        return $result
    } catch {
        $result.Message = "Autorunsc inspection failed: $($_.Exception.Message)"
        return $result
    }
}

# ----------------------------------------------------
# System Information
# ----------------------------------------------------
$now = Get-Date
$hostname = $env:COMPUTERNAME
$userName = [Environment]::UserName
$os = $null
$cs = $null
try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop } catch { }
try { $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch { }
$osName = if ($os.Caption) { [string]$os.Caption } else { 'Unknown Windows version' }
$osBuild = if ($os.BuildNumber) { [string]$os.BuildNumber } else { 'Unknown' }
$manufacturer = if ($cs.Manufacturer) { [string]$cs.Manufacturer } else { 'Unknown' }
$model = if ($cs.Model) { [string]$cs.Model } else { 'Unknown' }
$profiles = @(Get-UserProfileRoots)

$installedApps = @(Get-InstalledApplications)
$thirdPartyAppx = @(Get-ThirdPartyAppxPackages)

# Security Center antivirus inventory used by Windows Security section and summary.
$avProducts = @()
try {
    $avProducts = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntivirusProduct -ErrorAction SilentlyContinue |
        Select-Object displayName, productState, pathToSignedProductExe, pathToSignedReportingExe)
} catch { }
$avNames = @($avProducts | ForEach-Object { $_.displayName } | Where-Object { $_ } | Sort-Object -Unique)
$avSummary = if ($avNames.Count -gt 0) { $avNames -join ', ' } else { 'No provider returned by Security Center' }
$thirdPartyAvPresent = @($avNames | Where-Object { $_ -notmatch '(?i)Microsoft Defender|Windows Defender' }).Count -gt 0

# ----------------------------------------------------
# Accounts
# ----------------------------------------------------
Write-SectionHeader 'Accounts'
$accountsFindings = New-Object System.Collections.Generic.List[object]

# Known local accounts created by OpenAI Codex sandboxing. Keep them visible as
# inventory, but do not treat their mere presence as a threat concern.
$knownCodexSandboxAccounts = @('CodexSandboxOffline','CodexSandboxOnline')
# Legacy/expected local accounts that should remain visible as inventory without
# being treated as suspicious solely because they are enabled.
$knownExpectedLocalAccounts = @('HomeGroupUser$')

$localUsers = @()
try {
    if (Get-Command Get-LocalUser -ErrorAction SilentlyContinue) {
        $localUsers = @(Get-LocalUser -ErrorAction SilentlyContinue)
    } else {
        $localUsers = @(Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' -ErrorAction SilentlyContinue)
    }
} catch { }

if ($localUsers.Count -gt 0) {
    foreach ($u in $localUsers) {
        $name = [string]$u.Name
        $enabled = if ($u.PSObject.Properties['Enabled']) { [bool]$u.Enabled } else { -not [bool]$u.Disabled }
        $status = 'Info'
        $detail = ''

        if ($knownCodexSandboxAccounts -contains $name) {
            $detail = 'Known OpenAI Codex sandbox account used to isolate Codex CLI/IDE command, script, and file-edit execution.'
        } elseif ($knownExpectedLocalAccounts -contains $name) {
            $detail = 'Recognized legacy/expected local account; retained as inventory.'
        } elseif ($enabled -and $name -ine $userName) {
            $status = 'Review'
        }

        Add-Finding $accountsFindings $status ("Local user: {0} ({1})" -f $name, $(if ($enabled) { 'Enabled' } else { 'Disabled' })) $detail $(if ($status -eq 'Review') { "local-user:$name" } else { '' })
    }
} else {
    Add-Finding $accountsFindings 'Review' 'Local user enumeration returned no results.' '' 'local-users:enumeration'
}

$adminMembers = @()
try {
    if (Get-Command Get-LocalGroup -ErrorAction SilentlyContinue) {
        $adminGroup = Get-LocalGroup -SID 'S-1-5-32-544' -ErrorAction Stop
        $adminMembers = @(Get-LocalGroupMember -Group $adminGroup.Name -ErrorAction SilentlyContinue)
    }
} catch { }

if ($adminMembers.Count -gt 0) {
    foreach ($member in $adminMembers) {
        $memberSid = if ($member.PSObject.Properties['SID']) { [string]$member.SID } else { '' }
        $memberLeaf = ([string]$member.Name -split '\\')[-1]
        $memberStatus = if ($memberSid -match '-500$' -or $memberLeaf -ieq $userName -or ($knownCodexSandboxAccounts -contains $memberLeaf) -or ($knownExpectedLocalAccounts -contains $memberLeaf)) { 'Info' } else { 'Review' }
        $detail = if ($knownCodexSandboxAccounts -contains $memberLeaf) {
            "SID: $memberSid | Known OpenAI Codex sandbox account."
        } elseif ($memberSid) {
            "SID: $memberSid"
        } else {
            ''
        }
        Add-Finding $accountsFindings $memberStatus ("Administrators member: {0} [{1}]" -f $member.Name, $member.ObjectClass) $detail $(if ($memberStatus -eq 'Review') { "admin-member:$memberSid$memberLeaf" } else { '' })
    }
} else {
    Add-Finding $accountsFindings 'Review' 'Administrator group membership could not be enumerated automatically.' '' 'admin-members:enumeration'
}

Write-FindingsConsole $accountsFindings

# ----------------------------------------------------
# Remote Access
# ----------------------------------------------------
Write-SectionHeader 'Remote Access'
$remoteAccessFindings = New-Object System.Collections.Generic.List[object]

$rdpEnabled = $false
try {
    $rdp = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -ErrorAction Stop
    $rdpEnabled = ([int]$rdp.fDenyTSConnections -eq 0)
    Add-Finding $remoteAccessFindings $(if ($rdpEnabled) { 'Review' } else { 'Good' }) ("Remote Desktop: {0}" -f $(if ($rdpEnabled) { 'Enabled - confirm this is expected' } else { 'Disabled' })) '' $(if ($rdpEnabled) { 'remote-desktop' } else { '' })
} catch {
    Add-Finding $remoteAccessFindings 'Review' 'Remote Desktop state could not be determined.' '' 'remote-desktop:unknown'
}

try {
    $ra = Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name fAllowToGetHelp -ErrorAction Stop
    $raEnabled = ([int]$ra.fAllowToGetHelp -eq 1)
    Add-Finding $remoteAccessFindings $(if ($raEnabled) { 'Info' } else { 'Good' }) ("Remote Assistance: {0}" -f $(if ($raEnabled) { 'Enabled' } else { 'Disabled' })) ''
} catch {
    Add-Finding $remoteAccessFindings 'Info' 'Remote Assistance state was not available.'
}

$remoteMatches = @(Get-RemoteToolMatches $installedApps)
$remoteRuntime = @(Get-RemoteToolRuntimeMatches)
$remoteProducts = @((@($remoteMatches | Select-Object -ExpandProperty Product) + @($remoteRuntime | Select-Object -ExpandProperty Product)) | Where-Object { $_ } | Sort-Object -Unique)
if ($remoteProducts.Count -gt 0) {
    foreach ($product in $remoteProducts) {
        $details = New-Object System.Collections.Generic.List[string]
        foreach ($match in @($remoteMatches | Where-Object Product -eq $product)) {
            $app = $match.App
            $installPath = [string]$app.InstallPath
            if ([string]::IsNullOrWhiteSpace($installPath)) {
                $runtimePath = @($remoteRuntime | Where-Object { $_.Product -eq $product -and $_.Path } | Select-Object -First 1 -ExpandProperty Path)
                if ($runtimePath) { $installPath = [string]$runtimePath }
            }
            $pathText = if ([string]::IsNullOrWhiteSpace($installPath)) { 'Not recorded' } else { $installPath }
            $details.Add(("Installed: {0} {1} | Publisher: {2} | Path: {3}" -f $app.Name,$app.Version,$app.Publisher,$pathText).Trim()) | Out-Null
        }
        foreach ($item in @($remoteRuntime | Where-Object Product -eq $product)) {
            $details.Add(("{0}: {1} | Path: {2} | {3}" -f $item.Type,$item.Name,$item.Path,$item.Detail)) | Out-Null
        }
        Add-Finding $remoteAccessFindings 'Warning' ("Known remote-access/RMM software detected: $product") (($details -join ' || ') + ' || Presence does not prove malicious use; verify authorization.') ("remote:" + $product)
    }
} else {
    Add-Finding $remoteAccessFindings 'Good' ("No matches were found in the built-in remote-access/RMM watchlist ({0} products/aliases)." -f $script:RemoteAccessWatchlist.Count)
}

Write-FindingsConsole $remoteAccessFindings

# ----------------------------------------------------
# Programs & Startup
# ----------------------------------------------------
Write-SectionHeader 'Programs & Startup'
$programsFindings = New-Object System.Collections.Generic.List[object]
$recentCutoff = (Get-Date).AddDays(-1 * $RecentDays)
$recentApps = @($installedApps | Where-Object { $_.InstallDate -and $_.InstallDate -ge $recentCutoff } | Sort-Object InstallDate -Descending)

$pupInstalledMatches = @(Get-PupPuaInstalledMatches $installedApps)
$pupRuntimeMatches = @(Get-PupPuaRuntimeMatches)
$pupProducts = @((@($pupInstalledMatches | Select-Object -ExpandProperty Product) + @($pupRuntimeMatches | Select-Object -ExpandProperty Product)) | Where-Object { $_ } | Sort-Object -Unique)
if ($pupProducts.Count -gt 0) {
    foreach ($product in $pupProducts) {
        $details = New-Object System.Collections.Generic.List[string]
        foreach ($match in @($pupInstalledMatches | Where-Object Product -eq $product)) {
            $app = $match.App
            $details.Add(("Installed: {0} {1} | Publisher: {2} | Path: {3}" -f $app.Name,$app.Version,$app.Publisher,$app.InstallPath).Trim()) | Out-Null
        }
        foreach ($item in @($pupRuntimeMatches | Where-Object Product -eq $product)) {
            $details.Add(("{0}: {1} | Path: {2} | {3}" -f $item.Type,$item.Name,$item.Path,$item.Detail)) | Out-Null
        }
        Add-Finding $programsFindings 'Warning' ("PUP/PUA watchlist software detected: $product") (($details -join ' || ') + ' || Verify whether this software is wanted.') ("pup:" + $product)
    }
} else {
    Add-Finding $programsFindings 'Good' ("No installed/runtime matches were found in the built-in PUP/PUA watchlist ({0} names/aliases)." -f $script:PupPuaWatchlist.Count)
}

# Check Appx/MSIX names against both watchlists, but keep normal package inventory compact.
foreach ($pkg in $thirdPartyAppx) {
    $remotePkg = Find-WatchlistEntry -Text ([string]$pkg.Name) -Watchlist $script:RemoteAccessWatchlist -Mode Name
    $pupPkg = Find-WatchlistEntry -Text ([string]$pkg.Name) -Watchlist $script:PupPuaWatchlist -Mode Name
    if ($remotePkg) { Add-Finding $programsFindings 'Warning' ("Remote-access/RMM Appx/MSIX match: $($remotePkg.Name) - $($pkg.Name)") ("Publisher: $($pkg.Publisher) | Location: $($pkg.InstallLocation)") ("remote:" + $remotePkg.Name) }
    if ($pupPkg) { Add-Finding $programsFindings 'Warning' ("PUP/PUA Appx/MSIX match: $($pupPkg.Name) - $($pkg.Name)") ("Publisher: $($pkg.Publisher) | Location: $($pkg.InstallLocation)") ("pup:" + $pupPkg.Name) }
}

if ($recentApps.Count -gt 0) {
    Add-Finding $programsFindings 'Info' "$($recentApps.Count) installed application(s) report an install date within the last $RecentDays days."
    $recentPublisherGroups = @($recentApps | Group-Object { if ([string]::IsNullOrWhiteSpace([string]$_.Publisher)) { 'Unknown publisher' } else { [string]$_.Publisher } } | Sort-Object @{Expression='Count';Descending=$true}, Name)
    foreach ($group in $recentPublisherGroups | Select-Object -First 10) {
        $names = @($group.Group | Sort-Object @{Expression='InstallDate';Descending=$true}, Name | Select-Object -First 5 | ForEach-Object { $_.Name })
        $extra = if ($group.Count -gt $names.Count) { " | $($group.Count - $names.Count) additional" } else { '' }
        Add-Finding $programsFindings 'Info' ("Recent apps by publisher: $($group.Name) - $($group.Count)") (("Examples: " + ($names -join ' | ')) + $extra)
    }
    if ($recentPublisherGroups.Count -gt 10) { Add-Finding $programsFindings 'Info' "$($recentPublisherGroups.Count - 10) additional recent publisher group(s) were omitted from detail." }
} else {
    Add-Finding $programsFindings 'Good' "No applications with a recorded install date in the last $RecentDays days were found."
}

Add-Finding $programsFindings 'Info' "$($installedApps.Count) installed application record(s) were enumerated. Normal older applications are intentionally omitted from the detailed report to reduce noise."
if ($thirdPartyAppx.Count -gt 0) { Add-Finding $programsFindings 'Info' "$($thirdPartyAppx.Count) non-Microsoft Appx/MSIX package record(s) were enumerated; only watchlist matches are detailed." }

$startupEntries = @(Get-StartupEntries)
if ($startupEntries.Count -gt 0) {
    Add-Finding $programsFindings 'Info' "$($startupEntries.Count) unique startup/Run/RunOnce/Startup-folder item(s) were found after deduplication."
    foreach ($entry in $startupEntries) {
        $severity = 'Info'
        $watchText = "$($entry.Name) $($entry.Path) $($entry.Command)"
        $remoteHit = Find-WatchlistEntry -Text $watchText -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
        $pupHit = Find-WatchlistEntry -Text $watchText -Watchlist $script:PupPuaWatchlist -Mode Artifact
        $concernKey = ''
        if ($remoteHit) { $severity = 'Warning'; $concernKey = 'remote:' + $remoteHit.Name }
        elseif ($pupHit) { $severity = 'Warning'; $concernKey = 'pup:' + $pupHit.Name }
        elseif (Test-SuspiciousCommandLine $entry.Command) { $severity = 'Warning'; $concernKey = 'startup:suspicious:' + ([string]$entry.Name) }
        elseif ($entry.Path) {
            $sig = Get-SignatureInfo $entry.Path
            $isWindowsAppAlias = ([string]$entry.Path) -match '(?i)\\AppData\\Local\\Microsoft\\WindowsApps\\'
            if (-not $sig.Exists -and -not $isWindowsAppAlias) {
                if (Test-UserWritableOrUnusualPath $entry.Path) {
                    $severity = 'Review'
                    $concernKey = 'startup:missing:' + ([string]$entry.Path).ToLowerInvariant()
                } else {
                    $severity = 'Info'
                }
            } elseif ((Test-UserWritableOrUnusualPath $entry.Path) -and $sig.Exists -and $sig.Status -ne 'Valid') {
                $severity = 'Review'
                $concernKey = 'startup:' + ([string]$entry.Path).ToLowerInvariant()
            }
        }
        $detail = "Source: $($entry.Source) | Command: $($entry.Command)"
        if ($remoteHit) { $detail += " | Remote-access watchlist: $($remoteHit.Name)" }
        if ($pupHit) { $detail += " | PUP/PUA watchlist: $($pupHit.Name)" }
        if ($entry.Path) {
            $detail += " | $(Format-FileContext $entry.Path)"
            if (([string]$entry.Path) -match '(?i)\\AppData\\Local\\Microsoft\\WindowsApps\\' -and -not (Test-Path -LiteralPath $entry.Path -PathType Leaf)) {
                $detail += ' | WindowsApps/MSIX app-execution alias; Test-Path may report the target as absent.'
            }
        }
        Add-Finding $programsFindings $severity ("Startup: {0}" -f $entry.Name) $detail $concernKey
    }
} else {
    Add-Finding $programsFindings 'Good' 'No startup entries were returned by the automated checks.'
}

Write-FindingsConsole $programsFindings

# ----------------------------------------------------
# Autoruns / Persistence
# ----------------------------------------------------
Write-SectionHeader 'Autoruns / Persistence'
$autorunsFindings = New-Object System.Collections.Generic.List[object]
$autoruns = Get-AutorunsData -SkipDownload:$SkipAutorunsDownload

if ($autoruns.Available) {
    Add-Finding $autorunsFindings 'Info' $autoruns.Message
    $attentionAutoruns = @($autoruns.Entries | Where-Object { $_.Severity -in @('Review','Warning') })
    if ($attentionAutoruns.Count -gt 0) {
        Add-Finding $autorunsFindings 'Info' "$($attentionAutoruns.Count) Autoruns entr$(if ($attentionAutoruns.Count -eq 1) { 'y needs' } else { 'ies need' }) technician attention after signature/path/noise filtering."
        foreach ($entry in $attentionAutoruns | Sort-Object @{Expression={Get-SeverityRank $_.Severity};Descending=$true}, Category, Entry | Select-Object -First 150) {
            $detail = "Category: $($entry.Category) | Location: $($entry.Location) | Profile: $($entry.Profile) | Image: $($entry.ImagePath) | Signer: $($entry.Signer) | Launch: $($entry.Launch)"
            if ($entry.PSObject.Properties['Reason'] -and $entry.Reason) { $detail += " | Reason: $($entry.Reason)" }
            $key = if ($entry.Product) {
                $kind = if ((Find-WatchlistEntry -Text ("$($entry.Entry) $($entry.ImagePath) $($entry.Launch)") -Watchlist $script:RemoteAccessWatchlist -Mode Artifact)) { 'remote:' } else { 'pup:' }
                $kind + $entry.Product
            } else { 'autoruns:' + (("$($entry.Category)|$($entry.Entry)|$($entry.ImagePath)|$($entry.Launch)").ToLowerInvariant()) }
            Add-Finding $autorunsFindings $entry.Severity ("Autoruns: {0}" -f $(if ($entry.Entry) { $entry.Entry } else { $entry.Description })) $detail $key
        }
        if ($attentionAutoruns.Count -gt 150) { Add-Finding $autorunsFindings 'Info' "$($attentionAutoruns.Count - 150) additional attention Autoruns entries were omitted from the detailed list." }
    } else {
        Add-Finding $autorunsFindings 'Good' 'Autorunsc returned no third-party entries that met the refined Warning/Review criteria.'
    }
    $lowRiskAutoruns = @($autoruns.Entries | Where-Object { $_.Severity -eq 'Info' }).Count
    if ($lowRiskAutoruns -gt 0) { Add-Finding $autorunsFindings 'Info' "$lowRiskAutoruns lower-risk third-party Autoruns entries were inventoried but omitted from detail." }
} else {
    Add-Finding $autorunsFindings 'Review' $autoruns.Message '' 'autoruns:unavailable'
    Add-Finding $autorunsFindings 'Info' 'Native startup, scheduled-task, service, driver, process, and WMI subscription checks continue even when Autorunsc is unavailable.'
}

$wmiPersistence = @(Get-WmiPersistenceItems)
if ($wmiPersistence.Count -gt 0) {
    Add-Finding $autorunsFindings 'Info' "$($wmiPersistence.Count) persistent WMI command/script consumer(s) were found."
    foreach ($item in $wmiPersistence) {
        Add-Finding $autorunsFindings $item.Severity ("WMI persistence: $($item.Type) - $($item.Name)") $item.Detail ("wmi:$($item.Type):$($item.Name)")
    }
} else {
    Add-Finding $autorunsFindings 'Good' 'No persistent WMI CommandLineEventConsumer or ActiveScriptEventConsumer entries were found.'
}

Write-FindingsConsole $autorunsFindings

# ----------------------------------------------------
# Scheduled Tasks / Services / Processes
# ----------------------------------------------------
Write-SectionHeader 'Scheduled Tasks / Services / Processes'
$taskProcessFindings = New-Object System.Collections.Generic.List[object]

$taskResults = @(Get-SuspiciousScheduledTasks)
if ($taskResults.Count -gt 0) {
    Add-Finding $taskProcessFindings 'Info' "$($taskResults.Count) scheduled task action(s) met the refined Warning/Review criteria. Validly signed updater tasks in normal per-user locations are not flagged solely for being under AppData."
    foreach ($task in $taskResults | Sort-Object @{Expression={Get-SeverityRank $_.Severity};Descending=$true}, TaskPath, TaskName | Select-Object -First 100) {
        $key = if ($task.RemoteHit) { 'remote:' + $task.RemoteHit } elseif ($task.PupHit) { 'pup:' + $task.PupHit } else { 'task:' + (("$($task.TaskPath)$($task.TaskName)|$($task.Command)").ToLowerInvariant()) }
        Add-Finding $taskProcessFindings $task.Severity ("Task: {0}{1}" -f $task.TaskPath, $task.TaskName) ("State: $($task.State) | Command: $($task.Command) | Reason: $($task.Reason)") $key
    }
} else {
    Add-Finding $taskProcessFindings 'Good' 'No scheduled-task actions met the refined suspicious-command or unsigned/untrusted unusual-path criteria.'
}

$svcDrv = @(Get-ServiceDriverFindings)
if ($svcDrv.Count -gt 0) {
    Add-Finding $taskProcessFindings 'Info' "$($svcDrv.Count) service/driver item(s) met the refined unusual-path/signature criteria. Validly signed items are not flagged solely for their path."
    foreach ($item in $svcDrv | Select-Object -First 75) {
        Add-Finding $taskProcessFindings $item.Severity ("$($item.Type): $($item.Name) - $($item.Display)") ("State: $($item.State) | Start: $($item.StartMode) | Path: $($item.Path) | Signature: $($item.Signature)") ("$($item.Type.ToLowerInvariant()):$($item.Name)")
    }
} else {
    Add-Finding $taskProcessFindings 'Good' 'No unsigned/untrusted services or drivers in selected unusual locations were detected.'
}

$processResults = @(Get-ProcessFindings)
if ($processResults.Count -gt 0) {
    Add-Finding $taskProcessFindings 'Info' "$($processResults.Count) unique running executable(s) met the refined unsigned/untrusted unusual-path or suspicious-command criteria. Multi-process apps are aggregated by executable path."
    foreach ($proc in $processResults | Sort-Object @{Expression={Get-SeverityRank $_.Severity};Descending=$true}, Name | Select-Object -First 75) {
        $instanceText = if ($proc.InstanceCount -gt 1) { " | Instances: $($proc.InstanceCount) | PIDs: $($proc.PID)" } else { " | PID: $($proc.PID)" }
        Add-Finding $taskProcessFindings $proc.Severity ("Process: $($proc.Name)") ("Path: $($proc.Path) | Signature: $($proc.Signature) | Publisher: $($proc.Publisher)$instanceText | Example command: $($proc.CommandLine)") ("process:" + ([string]$proc.Path).ToLowerInvariant())
    }
} else {
    Add-Finding $taskProcessFindings 'Good' 'No running processes met the refined suspicious-command or unsigned/untrusted unusual-path criteria.'
}

Write-FindingsConsole $taskProcessFindings

# ----------------------------------------------------
# Suspicious Files
# ----------------------------------------------------
Write-SectionHeader 'Suspicious Files'
$fileFindings = New-Object System.Collections.Generic.List[object]
Add-Finding $fileFindings 'Info' ("Checking common program/user locations against {0} remote-access/RMM and {1} PUP/PUA watchlist entries." -f $script:RemoteAccessWatchlist.Count, $script:PupPuaWatchlist.Count)
$watchArtifacts = Get-WatchlistArtifactMatches -MaxResults 200
if ($watchArtifacts.Matches.Count -gt 0) {
    foreach ($group in @($watchArtifacts.Matches | Group-Object Kind, Product | Sort-Object Name)) {
        $first = $group.Group | Select-Object -First 1
        $paths = @($group.Group | Select-Object -ExpandProperty Path -Unique | Select-Object -First 5)
        $detail = "Artifacts found: $($group.Count) | Examples: " + ($paths -join ' | ')
        if ($group.Count -gt $paths.Count) { $detail += " | $($group.Count - $paths.Count) additional related artifact(s) omitted." }
        $keyPrefix = if ($first.Kind -eq 'Remote Access') { 'remote:' } else { 'pup:' }
        $alreadyDetected = if ($first.Kind -eq 'Remote Access') { $remoteProducts -contains $first.Product } else { $pupProducts -contains $first.Product }
        $artifactSeverity = if ($alreadyDetected) { 'Info' } else { 'Warning' }
        $suffix = if ($alreadyDetected) { 'Related artifacts corroborate software already reported elsewhere.' } else { 'No installed/runtime match was found; verify whether this residual or portable software is expected.' }
        Add-Finding $fileFindings $artifactSeverity ("$($first.Kind) artifacts detected: $($first.Product) ($($group.Count) related item(s))") ($detail + ' | ' + $suffix) $(if ($artifactSeverity -eq 'Warning') { $keyPrefix + $first.Product } else { '' })
    }
} else {
    Add-Finding $fileFindings 'Good' 'No remote-access/RMM or PUP/PUA watchlist artifacts were found in the common folders scanned.'
}
if ($watchArtifacts.Limited) { Add-Finding $fileFindings 'Review' 'The known-software artifact result limit was reached. Additional watchlist artifacts may exist.' '' 'artifact-scan:limited' }

Add-Finding $fileFindings 'Info' "Scanning selected user-writable locations for recently modified executable/script types from the last $RecentDays days. The inspection script, its launcher/report folder, and its temporary Autoruns workspace are excluded."
$fileScan = Get-RecentFileCandidates -Days $RecentDays -MaxResults 250
Add-Finding $fileFindings 'Info' "$($fileScan.Scanned) recent file(s) with checklist extensions were evaluated before noise/signature filtering."

if ($fileScan.Files.Count -gt 0) {
    # Collapse .NET single-file extraction bundles (for example installers) into one review item.
    $bundleGroups = @{}
    $individual = New-Object System.Collections.Generic.List[object]
    foreach ($file in $fileScan.Files) {
        $bundleKey = ''
        if ($file.Path -match '(?i)\\Temp\\\.net\\([^\\]+)\\') { $bundleKey = "Temp .NET bundle: $($matches[1])" }
        if ($bundleKey) {
            if (-not $bundleGroups.ContainsKey($bundleKey)) { $bundleGroups[$bundleKey] = New-Object System.Collections.Generic.List[object] }
            $bundleGroups[$bundleKey].Add($file) | Out-Null
        } else { $individual.Add($file) | Out-Null }
    }

    Add-Finding $fileFindings 'Info' "$($fileScan.Files.Count) recent unsigned/script candidate file(s) remained after filtering. Related temporary bundles are grouped below."
    foreach ($bundleKey in $bundleGroups.Keys | Sort-Object) {
        $group = $bundleGroups[$bundleKey]
        $examples = @($group | Sort-Object Modified -Descending | Select-Object -First 5 | ForEach-Object { $_.Path })
        $activeTypes = @($group | Where-Object { [IO.Path]::GetExtension([string]$_.Path).ToLowerInvariant() -in @('.exe','.ps1','.bat','.cmd','.vbs','.vbe','.js','.jse','.hta','.scr') })
        $bundleSeverity = if ($activeTypes.Count -gt 0) { 'Review' } else { 'Info' }
        $bundleDetail = "Examples: " + ($examples -join ' | ')
        if ($bundleSeverity -eq 'Info') { $bundleDetail += ' | DLL-only .NET single-file extraction bundle; retained as context rather than a threat concern.' }
        Add-Finding $fileFindings $bundleSeverity "$bundleKey ($($group.Count) candidate file(s))" $bundleDetail $(if ($bundleSeverity -eq 'Review') { "file-bundle:" + $bundleKey.ToLowerInvariant() } else { '' })
    }
    foreach ($file in $individual | Sort-Object Modified -Descending) {
        Add-Finding $fileFindings $file.Severity $file.Path ("Modified: $($file.Modified.ToString('yyyy-MM-dd HH:mm')) | Size: $($file.SizeKB) KB | Signature: $($file.Signature) | Publisher: $($file.Publisher)") ("file:" + ([string]$file.Path).ToLowerInvariant())
    }
} else {
    Add-Finding $fileFindings 'Good' 'No recent candidate files matching the refined inspection criteria were found.'
}
if ($fileScan.Limited) { Add-Finding $fileFindings 'Review' 'The suspicious-file result limit was reached. Additional candidates may exist and were not listed.' '' 'file-scan:limited' }
Add-Finding $fileFindings 'Info' 'This is a targeted review, not an antivirus scan. Large cache/package directories are intentionally skipped to reduce noise.'

Write-FindingsConsole $fileFindings

# ----------------------------------------------------
# Browsers
# ----------------------------------------------------
Write-SectionHeader 'Browsers'
$browserFindings = New-Object System.Collections.Generic.List[object]
$chromiumExt = @(Get-ChromiumExtensions)
$firefoxExt = @(Get-FirefoxExtensions)
$chromiumSettings = @(Get-ChromiumBrowserSettings)
$firefoxSettings = @(Get-FirefoxBrowserSettings)
$browserPolicies = @(Get-BrowserPolicyFindings)

$allExtensions = @($chromiumExt) + @($firefoxExt)
if ($allExtensions.Count -gt 0) {
    Add-Finding $browserFindings 'Info' "$($allExtensions.Count) active/installed browser extension record(s) were found across available user profiles."
    foreach ($ext in $allExtensions | Sort-Object Browser, User, Profile, Name | Select-Object -First 125) {
        $detail = "User: $($ext.User) | Profile: $($ext.Profile) | ID: $($ext.ID) | Version: $($ext.Version)"
        if ($ext.PSObject.Properties['SignedState'] -and $ext.SignedState) { $detail += " | Firefox signed state: $($ext.SignedState)" }
        if ($ext.PSObject.Properties['UpdateURL'] -and $ext.UpdateURL) { $detail += " | Update URL: $($ext.UpdateURL)" }
        $extensionText = "$($ext.Name) $($ext.ID) $($ext.UpdateURL)"
        $remoteExtHit = Find-WatchlistEntry -Text $extensionText -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
        $pupExtHit = Find-WatchlistEntry -Text $extensionText -Watchlist $script:PupPuaWatchlist -Mode Artifact
        $extSeverity = if ($remoteExtHit -or $pupExtHit) { 'Warning' } else { 'Info' }
        $key = ''
        if ($remoteExtHit) { $detail += " | Remote-access watchlist: $($remoteExtHit.Name)"; $key = 'remote:' + $remoteExtHit.Name }
        if ($pupExtHit) { $detail += " | PUP/PUA watchlist: $($pupExtHit.Name)"; $key = 'pup:' + $pupExtHit.Name }
        Add-Finding $browserFindings $extSeverity ("$($ext.Browser) extension: $($ext.Name)") $detail $key
    }
    if ($allExtensions.Count -gt 125) { Add-Finding $browserFindings 'Info' "$($allExtensions.Count - 125) additional extension records were omitted from detail." }
} else {
    Add-Finding $browserFindings 'Info' 'No supported browser extension inventories were found in the available user profiles.'
}

$browserSettings = @($chromiumSettings) + @($firefoxSettings)
$notificationSettings = @($browserSettings | Where-Object { $_.Type -eq 'Notification' })
if ($browserSettings.Count -gt 0) {
    Add-Finding $browserFindings 'Info' "$($browserSettings.Count) browser setting/notification record(s) were captured."
    foreach ($setting in $browserSettings | Sort-Object Browser, User, Profile, Type, Name | Select-Object -First 100) {
        Add-Finding $browserFindings $setting.Severity ("$($setting.Browser) $($setting.Type.ToLowerInvariant()): $($setting.Name)") ("User: $($setting.User) | Profile: $($setting.Profile) | $($setting.Detail)") $(if ($setting.Severity -in @('Review','Warning')) { "browser-setting:$($setting.Browser):$($setting.User):$($setting.Profile):$($setting.Type):$($setting.Name)" } else { '' })
    }
}
if ($notificationSettings.Count -eq 0) {
    Add-Finding $browserFindings 'Good' 'No allowed website-notification origins were found in the supported Chromium profiles that could be read.'
} else {
    $warningNotifications = @($notificationSettings | Where-Object { $_.Severity -eq 'Warning' }).Count
    $reviewNotifications = @($notificationSettings | Where-Object { $_.Severity -eq 'Review' }).Count
    Add-Finding $browserFindings 'Info' "$($notificationSettings.Count) allowed website-notification origin(s) were found ($warningNotifications Warning / $reviewNotifications Review)."
}

if ($browserPolicies.Count -gt 0) {
    Add-Finding $browserFindings 'Info' "$($browserPolicies.Count) browser policy location(s) contain configured values."
    foreach ($policy in $browserPolicies | Select-Object -First 75) {
        Add-Finding $browserFindings 'Review' ("$($policy.Browser) policy: $($policy.Path)") $policy.Values ("browser-policy:$($policy.Browser):$($policy.Path)")
    }
} else {
    Add-Finding $browserFindings 'Good' 'No configured Chrome, Edge, Brave, or Firefox policy values were found in the checked policy locations.'
}

Add-Finding $browserFindings 'Info' 'Automated browser coverage is partial: Chrome, Edge, Brave, Vivaldi, Opera and Opera GX Chromium preferences are checked for homepage/startup/search settings and allowed notification origins. Allowed notification sites are surfaced for review and higher-risk origin patterns are escalated to Warning. Firefox notification permissions are stored in permissions.sqlite and still require manual review unless a SQLite reader is added.'

Write-FindingsConsole $browserFindings

# ----------------------------------------------------
# Network
# ----------------------------------------------------
Write-SectionHeader 'Network'
$networkFindings = New-Object System.Collections.Generic.List[object]

try {
    $proxy = Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
    if ($proxy -and [int]$proxy.ProxyEnable -eq 1) {
        Add-Finding $networkFindings 'Review' "User proxy is enabled: $($proxy.ProxyServer)" '' 'network:proxy'
    } else {
        Add-Finding $networkFindings 'Good' 'Current-user Internet proxy is disabled.'
    }
} catch { Add-Finding $networkFindings 'Info' 'Current-user Internet proxy state could not be read.' }

try {
    $winHttpProxy = (netsh winhttp show proxy 2>$null | Out-String).Trim()
    if ($winHttpProxy) { Add-Finding $networkFindings 'Info' 'WinHTTP proxy configuration captured.' $winHttpProxy }
} catch { }

try {
    $dnsRows = @(Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.ServerAddresses.Count -gt 0 })
    foreach ($row in $dnsRows) { Add-Finding $networkFindings 'Info' ("DNS: $($row.InterfaceAlias)") (($row.ServerAddresses -join ', ')) }
} catch { }

try {
    $vpn = New-Object System.Collections.Generic.List[object]
    if (Get-Command Get-VpnConnection -ErrorAction SilentlyContinue) {
        try { foreach ($v in @(Get-VpnConnection -ErrorAction SilentlyContinue)) { $vpn.Add($v) | Out-Null } } catch { }
        try { foreach ($v in @(Get-VpnConnection -AllUserConnection -ErrorAction SilentlyContinue)) { $vpn.Add($v) | Out-Null } } catch { }
    }
    foreach ($v in @($vpn | Sort-Object Name -Unique)) { Add-Finding $networkFindings 'Info' ("VPN connection: $($v.Name)") ("Server: $($v.ServerAddress) | Tunnel: $($v.TunnelType) | Split tunneling: $($v.SplitTunneling)") }
} catch { }

try {
    $installedNameText = (($installedApps | Select-Object -ExpandProperty Name) -join ' | ')
    foreach ($adapter in @(Get-NetAdapter -ErrorAction SilentlyContinue)) {
        $adapterText = "$($adapter.Name) $($adapter.InterfaceDescription)"
        $adapterStatus = 'Info'
        $expectedVirtual = $false
        if ($adapterText -match '(?i)nordlynx|openvpn.*nordvpn') { $expectedVirtual = $installedNameText -match '(?i)NordVPN' }
        elseif ($adapterText -match '(?i)openvpn|tap-windows') { $expectedVirtual = $installedNameText -match '(?i)OpenVPN|NordVPN|ExpressVPN|ProtonVPN|Surfshark|Private Internet Access|CyberGhost' }
        elseif ($adapterText -match '(?i)wireguard|wintun') { $expectedVirtual = $installedNameText -match '(?i)WireGuard|NordVPN|Mullvad|ProtonVPN|Surfshark|Windscribe|Private Internet Access|IVPN' }
        elseif ($adapterText -match '(?i)hamachi') { $expectedVirtual = $installedNameText -match '(?i)Hamachi|LogMeIn' }
        elseif ($adapterText -match '(?i)zerotier') { $expectedVirtual = $installedNameText -match '(?i)ZeroTier' }
        elseif ($adapterText -match '(?i)tailscale') { $expectedVirtual = $installedNameText -match '(?i)Tailscale' }
        if (($adapterText -match '(?i)(hamachi|zerotier|tailscale|wireguard|wintun|tap-windows|openvpn|nordlynx)') -and -not $expectedVirtual) { $adapterStatus = 'Review' }
        Add-Finding $networkFindings $adapterStatus ("Network adapter: $($adapter.Name)") ("Status: $($adapter.Status) | Description: $($adapter.InterfaceDescription) | MAC: $($adapter.MacAddress) | Link: $($adapter.LinkSpeed)") $(if ($adapterStatus -eq 'Review') { "network-adapter:$($adapter.Name)" } else { '' })
    }
} catch { }

$hostsEntries = @(Get-HostsEntries)
if ($hostsEntries.Count -gt 0) {
    Add-Finding $networkFindings 'Info' "$($hostsEntries.Count) custom hosts-file entr$(if ($hostsEntries.Count -eq 1) { 'y was' } else { 'ies were' }) found."
    foreach ($line in $hostsEntries) { Add-Finding $networkFindings 'Review' "Hosts: $line" 'Confirm this redirect/block is expected.' ("hosts:" + $line.ToLowerInvariant()) }
} else { Add-Finding $networkFindings 'Good' 'No custom hosts-file redirects were found.' }

try {
    $fwProfiles = @(Get-NetFirewallProfile -ErrorAction SilentlyContinue)
    foreach ($profile in $fwProfiles) {
        $status = if ($profile.Enabled) { 'Good' } else { 'Warning' }
        Add-Finding $networkFindings $status ("Windows Firewall $($profile.Name): " + $(if ($profile.Enabled) { 'Enabled' } else { 'Disabled' })) '' $(if (-not $profile.Enabled) { "firewall-profile:$($profile.Name)" } else { '' })
    }

    $attentionRules = New-Object System.Collections.Generic.List[object]
    $enabledRules = @(Get-NetFirewallRule -Enabled True -ErrorAction SilentlyContinue)
    $ruleById = @{}
    foreach ($rule in $enabledRules) { if ($rule.InstanceID) { $ruleById[[string]$rule.InstanceID] = $rule } }
    $ruleSeen = @{}
    try {
        foreach ($appFilter in @($enabledRules | Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue)) {
            $program = [Environment]::ExpandEnvironmentVariables([string]$appFilter.Program).Trim('"')
            if (-not $program -or $program -eq 'Any' -or -not (Test-UserWritableOrUnusualPath $program)) { continue }
            $rule = $ruleById[[string]$appFilter.InstanceID]
            $sig = Get-SignatureInfo $program
            if ($sig.Exists -and $sig.Status -eq 'Valid') { continue }
            $name = if ($rule) { [string]$rule.DisplayName } else { [string]$appFilter.InstanceID }
            $direction = if ($rule) { [string]$rule.Direction } else { '' }
            $action = if ($rule) { [string]$rule.Action } else { '' }
            $key = ("$name|$direction|$action|$program").ToLowerInvariant()
            if ($ruleSeen.ContainsKey($key)) { continue }
            $ruleSeen[$key] = $true
            $attentionRules.Add([PSCustomObject]@{ Name=$name; Direction=$direction; Action=$action; Program=$program; Exists=$sig.Exists; Signature=$sig.Status }) | Out-Null
        }
    } catch { }
    if ($attentionRules.Count -gt 0) {
        $missingRules = @($attentionRules | Where-Object { -not $_.Exists })
        $untrustedRules = @($attentionRules | Where-Object { $_.Exists -and $_.Signature -ne 'Valid' })

        if ($missingRules.Count -gt 0) {
            foreach ($group in @($missingRules | Group-Object Name)) {
                $examples = @($group.Group | Select-Object -ExpandProperty Program -Unique | Select-Object -First 4)
                Add-Finding $networkFindings 'Info' ("Stale firewall rule(s): $($group.Name) - $($group.Count) missing executable target(s)") ("Examples: " + ($examples -join ' | ') + ' | Stale rules are retained as cleanup context, not a threat concern.')
            }
        }

        if ($untrustedRules.Count -gt 0) {
            Add-Finding $networkFindings 'Info' "$($untrustedRules.Count) enabled firewall rule(s) reference existing unsigned/untrusted executables in user-writable/unusual paths."
            foreach ($rule in $untrustedRules | Select-Object -First 50) {
                Add-Finding $networkFindings 'Review' ("Firewall rule: $($rule.Name)") ("$($rule.Direction) $($rule.Action) | Program: $($rule.Program) | Exists: $($rule.Exists) | Signature: $($rule.Signature)") ("firewall-rule:" + (("$($rule.Name)|$($rule.Program)").ToLowerInvariant()))
            }
        }
    }
} catch { Add-Finding $networkFindings 'Info' 'Windows Firewall rules could not be fully enumerated.' }

$connections = @(Get-ExternalEstablishedConnections)
if ($connections.Count -gt 0) {
    Add-Finding $networkFindings 'Info' "$($connections.Count) established TCP connection(s) were captured at inspection time. Normal connections from validly signed applications are not individually listed."
    $attentionConnections = @($connections | Where-Object { $_.Severity -in @('Review','Warning') })
    foreach ($group in @($attentionConnections | Group-Object Severity, ProcessPath, Process, Product)) {
        $first = $group.Group | Select-Object -First 1
        $remotes = @($group.Group | Select-Object -ExpandProperty Remote -Unique | Select-Object -First 8)
        $key = if ($first.Product) {
            $remoteHit = Find-WatchlistEntry -Text ("$($first.Process) $($first.ProcessPath)") -Watchlist $script:RemoteAccessWatchlist -Mode Artifact
            if ($remoteHit) { 'remote:' + $first.Product } else { 'pup:' + $first.Product }
        } else { 'connection:' + ([string]$first.ProcessPath).ToLowerInvariant() }
        Add-Finding $networkFindings $first.Severity ("Connection activity: $($first.Process) ($($group.Count) established connection(s))") ("Process path: $($first.ProcessPath) | Remote examples: " + ($remotes -join ', ')) $key
    }
    if ($attentionConnections.Count -eq 0) { Add-Finding $networkFindings 'Good' 'No established connection was owned by a watchlist tool or an unsigned/untrusted process in an unusual path.' }
}

Write-FindingsConsole $networkFindings

# ----------------------------------------------------
# Windows Security
# ----------------------------------------------------
Write-SectionHeader 'Windows Security'
$securityFindings = New-Object System.Collections.Generic.List[object]
Add-Finding $securityFindings 'Info' "Security Center antivirus provider(s): $avSummary"

$mpStatus = $null
$mpPref = $null
try { if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) { $mpStatus = Get-MpComputerStatus -ErrorAction Stop } } catch { }
try { if (Get-Command Get-MpPreference -ErrorAction SilentlyContinue) { $mpPref = Get-MpPreference -ErrorAction Stop } } catch { }

if ($mpStatus) {
    $rtEnabled = [bool]$mpStatus.RealTimeProtectionEnabled
    $avEnabled = [bool]$mpStatus.AntivirusEnabled
    $tamper = $null
    if ($mpStatus.PSObject.Properties['IsTamperProtected']) { $tamper = [bool]$mpStatus.IsTamperProtected }

    if ($thirdPartyAvPresent -and (-not $rtEnabled -or -not $avEnabled)) {
        Add-Finding $securityFindings 'Info' 'Microsoft Defender real-time antivirus is not fully active while a third-party antivirus provider is registered.'
    } else {
        Add-Finding $securityFindings $(if ($rtEnabled -and $avEnabled) { 'Good' } else { 'Warning' }) ("Microsoft Defender antivirus/real-time protection: AV={0}, Real-time={1}" -f $avEnabled, $rtEnabled)
    }

    if ($null -ne $tamper) {
        Add-Finding $securityFindings $(if ($tamper) { 'Good' } else { 'Review' }) ("Tamper Protection: " + $(if ($tamper) { 'Enabled' } else { 'Disabled or not enforced' }))
    }

    if ($mpStatus.AntivirusSignatureLastUpdated) {
        $sigAge = (New-TimeSpan -Start $mpStatus.AntivirusSignatureLastUpdated -End (Get-Date)).TotalDays
        $sigStatus = if ($sigAge -le 3) { 'Good' } else { 'Review' }
        Add-Finding $securityFindings $sigStatus ("Defender security intelligence last updated: $($mpStatus.AntivirusSignatureLastUpdated.ToString('yyyy-MM-dd HH:mm'))")
    }
} else {
    Add-Finding $securityFindings $(if ($thirdPartyAvPresent) { 'Info' } else { 'Warning' }) 'Microsoft Defender status cmdlets were unavailable or Defender status could not be read.'
}

if ($mpPref) {
    $maps = [int]$mpPref.MAPSReporting
    Add-Finding $securityFindings $(if ($maps -gt 0) { 'Good' } else { 'Review' }) ("Cloud-delivered protection (MAPS reporting): " + $(if ($maps -gt 0) { "Enabled (level $maps)" } else { 'Disabled' }))

    if ($mpPref.PSObject.Properties['PUAProtection']) {
        $puaMode = [int]$mpPref.PUAProtection
        $puaText = switch ($puaMode) { 1 { 'Block' } 2 { 'Audit' } 0 { 'Disabled' } default { "Unknown ($puaMode)" } }
        $puaStatus = if ($puaMode -eq 1) { 'Good' } elseif ($puaMode -eq 2) { 'Info' } else { 'Review' }
        Add-Finding $securityFindings $puaStatus "Microsoft Defender PUA protection: $puaText"
    }

    $exclusions = New-Object System.Collections.Generic.List[object]
    foreach ($x in @($mpPref.ExclusionPath))      { if ($x) { $exclusions.Add([PSCustomObject]@{ Type='Path'; Value=[string]$x }) | Out-Null } }
    foreach ($x in @($mpPref.ExclusionProcess))   { if ($x) { $exclusions.Add([PSCustomObject]@{ Type='Process'; Value=[string]$x }) | Out-Null } }
    foreach ($x in @($mpPref.ExclusionExtension)) { if ($x) { $exclusions.Add([PSCustomObject]@{ Type='Extension'; Value=[string]$x }) | Out-Null } }
    foreach ($x in @($mpPref.ExclusionIpAddress)) { if ($x) { $exclusions.Add([PSCustomObject]@{ Type='IP'; Value=[string]$x }) | Out-Null } }

    if ($exclusions.Count -gt 0) {
        Add-Finding $securityFindings 'Info' "$($exclusions.Count) Microsoft Defender exclusion(s) are configured. Each exclusion is evaluated below."
        foreach ($x in $exclusions) {
            $severity = 'Review'
            $detailParts = New-Object System.Collections.Generic.List[string]
            $detailParts.Add('Confirm this exclusion is expected; excluded content may be skipped by Defender scanning.') | Out-Null

            if ($x.Type -eq 'Path') {
                $expanded = [Environment]::ExpandEnvironmentVariables($x.Value)
                $isDirectory = Test-Path -LiteralPath $expanded -PathType Container -ErrorAction SilentlyContinue
                if ($isDirectory) {
                    $detailParts.Add('Exists: True | Type: Directory') | Out-Null
                } else {
                    $sig = Get-SignatureInfo $expanded
                    if ($sig.Exists) {
                        $detailParts.Add("Exists: True | Type: File | Signature: $($sig.Status) | Publisher: $(if ($sig.Company) { $sig.Company } else { $sig.Signer }) | Modified: $($sig.LastWrite)") | Out-Null
                        $hash = Get-Sha256Safe $expanded
                        if ($hash) { $detailParts.Add("SHA-256: $hash") | Out-Null }
                        if ($sig.Status -ne 'Valid') { $severity = 'Warning' }
                    } else {
                        $detailParts.Add('Exists: False (the exclusion remains configured even though the exact file/path was not found).') | Out-Null
                    }
                }

                if ([System.IO.Path]::GetFileName($expanded) -ieq 'SppExtComObjHook.dll') {
                    $severity = 'Warning'
                    $detailParts.Add('High-priority review: SppExtComObjHook.dll is not treated as a normal Windows Defender exclusion by this inspection policy.') | Out-Null
                    $ifeoRefs = @(Get-IfeoVerifierReferences -TargetPath $expanded)
                    if ($ifeoRefs.Count -gt 0) { $detailParts.Add('IFEO reference(s): ' + ($ifeoRefs -join ' || ')) | Out-Null }
                    else { $detailParts.Add('No matching IFEO VerifierDlls/Debugger reference was found in the checked Image File Execution Options keys.') | Out-Null }
                }
            }

            Add-Finding $securityFindings $severity ("Defender exclusion: $($x.Type): $($x.Value)") ($detailParts -join ' | ') (("defender-exclusion:{0}:{1}" -f $x.Type, $x.Value).ToLowerInvariant())
        }
    } else {
        Add-Finding $securityFindings 'Good' 'No Microsoft Defender path/process/extension/IP exclusions were returned.'
    }

    $rawIds = @($mpPref.ThreatIDDefaultAction_Ids)
    $rawActions = @($mpPref.ThreatIDDefaultAction_Actions)
    $threatMappings = New-Object System.Collections.Generic.List[object]

    for ($i = 0; $i -lt $rawIds.Count; $i++) {
        $idText = if ($null -ne $rawIds[$i]) { ([string]$rawIds[$i]).Trim() } else { '' }
        if ([string]::IsNullOrWhiteSpace($idText)) { continue }

        $actionText = 'Unknown'
        if ($i -lt $rawActions.Count -and $null -ne $rawActions[$i]) {
            $candidateAction = ([string]$rawActions[$i]).Trim()
            if (-not [string]::IsNullOrWhiteSpace($candidateAction)) {
                $actionText = $candidateAction
            }
        }

        $threatMappings.Add([PSCustomObject]@{
            ThreatID = $idText
            Action   = $actionText
        }) | Out-Null
    }

    if ($threatMappings.Count -gt 0) {
        Add-Finding $securityFindings 'Info' "$($threatMappings.Count) custom Defender threat action mapping(s) are configured. Review individual mappings below."
        foreach ($mapping in $threatMappings) {
            Add-Finding $securityFindings 'Review' "Threat ID $($mapping.ThreatID) -> Action $($mapping.Action)" '' ("defender-threat-action:$($mapping.ThreatID)")
        }
    }
}

try {
    if (Get-Command Get-MpThreatDetection -ErrorAction SilentlyContinue) {
        $detections = @(Get-MpThreatDetection -ErrorAction SilentlyContinue | Sort-Object InitialDetectionTime -Descending | Select-Object -First 25)
        if ($detections.Count -gt 0) {
            Add-Finding $securityFindings 'Info' "$($detections.Count) recent Defender threat-detection record(s) were returned (up to 25 shown)."
            foreach ($d in $detections) {
                $resources = @($d.Resources) -join '; '
                Add-Finding $securityFindings 'Review' ("Defender detection: Threat ID $($d.ThreatID)") ("Initial: $($d.InitialDetectionTime) | Action success: $($d.ActionSuccess) | Resources: $resources") ("defender-detection:$($d.ThreatID):$($d.InitialDetectionTime)")
            }
        } else {
            Add-Finding $securityFindings 'Good' 'No Defender threat-detection records were returned.'
        }
    }
} catch {
    Add-Finding $securityFindings 'Info' 'Defender protection history could not be fully enumerated.'
}

Write-FindingsConsole $securityFindings

# ----------------------------------------------------
# Build Section Objects
# ----------------------------------------------------
$browserSectionStatus = Get-SectionStatus $browserFindings
if ($browserSectionStatus -notin @('Warning','Review')) { $browserSectionStatus = 'Info' }

$sections = @(
    [PSCustomObject]@{ Id='accounts'; Title='Accounts'; Summary='Local users and local Administrators-group membership, with known Codex sandbox accounts identified as expected inventory.'; Findings=$accountsFindings.ToArray(); Status=(Get-SectionStatus $accountsFindings) },
    [PSCustomObject]@{ Id='remote-access'; Title='Remote Access'; Summary='Remote Desktop, Remote Assistance, and the remote-access/RMM watchlist across installed software and runtime activity.'; Findings=$remoteAccessFindings.ToArray(); Status=(Get-SectionStatus $remoteAccessFindings) },
    [PSCustomObject]@{ Id='programs'; Title='Programs & Startup'; Summary='PUP/PUA watchlist matches, compact installed-software context, and deduplicated startup persistence.'; Findings=$programsFindings.ToArray(); Status=(Get-SectionStatus $programsFindings) },
    [PSCustomObject]@{ Id='autoruns'; Title='Autoruns / Persistence'; Summary='Microsoft Autorunsc inspection with blank-row suppression, signature-aware filtering, and WMI persistence checks.'; Findings=$autorunsFindings.ToArray(); Status=(Get-SectionStatus $autorunsFindings) },
    [PSCustomObject]@{ Id='tasks'; Title='Scheduled Tasks / Services / Processes'; Summary='Signature-aware scheduled-task, service/driver, and aggregated process checks.'; Findings=$taskProcessFindings.ToArray(); Status=(Get-SectionStatus $taskProcessFindings) },
    [PSCustomObject]@{ Id='files'; Title='Suspicious Files'; Summary='Grouped remote-access/PUP artifacts plus targeted recent-file review with self-generated files excluded.'; Findings=$fileFindings.ToArray(); Status=(Get-SectionStatus $fileFindings) },
    [PSCustomObject]@{ Id='browsers'; Title='Browsers'; Summary='Chrome/Edge/Brave/Vivaldi/Opera/Opera GX/Firefox extensions, selected settings, notification origins, and configured browser policies. Automated coverage is partial.'; Findings=$browserFindings.ToArray(); Status=$browserSectionStatus },
    [PSCustomObject]@{ Id='network'; Title='Network'; Summary='Proxy, DNS, VPN/adapters, hosts file, signature-aware firewall rules, and grouped attention-worthy connections.'; Findings=$networkFindings.ToArray(); Status=(Get-SectionStatus $networkFindings) },
    [PSCustomObject]@{ Id='security'; Title='Windows Security'; Summary='Antivirus providers, Defender protection state, PUA protection, exclusions with file inspection, and detection history.'; Findings=$securityFindings.ToArray(); Status=(Get-SectionStatus $securityFindings) }
)

$allFindings = @($sections | ForEach-Object { $_.Findings })
$warningCount = Get-UniqueConcernCount -Findings $allFindings -Status 'Warning'
$reviewCount  = Get-UniqueConcernCount -Findings $allFindings -Status 'Review'
$rawWarningFindingCount = @($allFindings | Where-Object Status -eq 'Warning').Count
$rawReviewFindingCount  = @($allFindings | Where-Object Status -eq 'Review').Count
$goodCount    = @($allFindings | Where-Object Status -eq 'Good').Count
$infoCount    = @($allFindings | Where-Object Status -eq 'Info').Count

# ----------------------------------------------------
# Build HTML
# ----------------------------------------------------
$completedAt = Get-Date
$sb = New-Object System.Text.StringBuilder
$null = $sb.AppendLine('<!DOCTYPE html>')
$null = $sb.AppendLine('<html lang="en">')
$null = $sb.AppendLine('<head>')
$null = $sb.AppendLine('<meta charset="utf-8" />')
$null = $sb.AppendLine('<meta name="viewport" content="width=device-width, initial-scale=1" />')
$null = $sb.AppendLine('<title>Threat Inspection Report - ' + (Convert-ToHtmlSafe $hostname) + '</title>')
$null = $sb.AppendLine(@'
<style>
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        background: #050608;
        color: #f5f7fb;
        margin: 0;
        padding: 0;
    }
    .page {
        max-width: 1100px;
        margin: 0 auto;
        padding: 24px 16px 40px 16px;
    }
    .title {
        font-size: 30px;
        font-weight: 700;
        margin-bottom: 4px;
        color: #ffffff;
    }
    .subtitle {
        font-size: 14px;
        color: #a0a4b8;
        margin-bottom: 20px;
    }
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
        gap: 12px;
        margin-bottom: 18px;
    }
    .card {
        background: radial-gradient(circle at top left, #17223b, #090b11);
        border-radius: 12px;
        padding: 12px 14px;
        border: 1px solid #1b2338;
        box-shadow: 0 6px 18px rgba(0,0,0,0.6);
    }
    .card-label {
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #7c829a;
        margin-bottom: 4px;
    }
    .card-value {
        font-size: 15px;
        font-weight: 600;
        color: #f5f7fb;
        overflow-wrap: anywhere;
    }
    .card-meta {
        font-size: 12px;
        color: #8f95ad;
        margin-top: 2px;
        overflow-wrap: anywhere;
    }
    .status-row {
        margin: 16px 0 22px 0;
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
    }
    .status-pill, .section-status-pill, .finding-status {
        font-size: 12px;
        padding: 4px 8px;
        border-radius: 999px;
        border: 1px solid transparent;
        background: rgba(20,25,40,0.95);
        text-decoration: none;
        display: inline-block;
        white-space: nowrap;
    }
    .status-pill:hover { filter: brightness(1.08); }
    .status-good { border-color: #20c997; color: #20c997; }
    .status-review { border-color: #65a9ff; color: #65a9ff; }
    .status-warning { border-color: #ff8f5a; color: #ff8f5a; }
    .status-info { border-color: #8f95ad; color: #aab0c6; }
    .section {
        border-radius: 12px;
        border: 1px solid #1c2336;
        margin-bottom: 10px;
        overflow: hidden;
        background: rgba(10,12,20,0.96);
        box-shadow: 0 5px 14px rgba(0,0,0,0.55);
        scroll-margin-top: 16px;
    }
    .section-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        cursor: pointer;
        background: linear-gradient(90deg, rgba(31,45,85,0.9), rgba(16,23,42,0.9));
    }
    .section-header:hover {
        background: linear-gradient(90deg, rgba(45,65,120,0.95), rgba(18,26,48,0.9));
    }
    .section-left { display: flex; align-items: center; gap: 8px; }
    .section-icon { font-size: 13px; width: 18px; text-align: center; color: #9fa6c6; }
    .section-title { font-size: 14px; font-weight: 600; color: #f5f7ff; }
    .section-body { padding: 10px 12px 12px 12px; display: block; }
    .section-summary { font-size: 13px; color: #b4bad6; margin-top: 0; margin-bottom: 10px; }
    .findings {
        display: flex;
        flex-direction: column;
        gap: 6px;
        max-height: 540px;
        overflow: auto;
        padding-right: 2px;
    }
    .finding {
        display: grid;
        grid-template-columns: 86px 1fr;
        gap: 8px;
        align-items: start;
        background: #05070f;
        border: 1px solid #12182c;
        border-radius: 8px;
        padding: 8px;
    }
    .finding-main { min-width: 0; }
    .finding-text {
        font-family: "Cascadia Code", "Consolas", "Fira Code", monospace;
        font-size: 12px;
        color: #e6e9f3;
        white-space: pre-wrap;
        word-break: break-word;
    }
    .finding-detail {
        margin-top: 4px;
        font-family: "Cascadia Code", "Consolas", "Fira Code", monospace;
        font-size: 11px;
        color: #8f95ad;
        white-space: pre-wrap;
        word-break: break-word;
    }
    .legend {
        font-size: 12px;
        color: #9298af;
        margin: -8px 0 18px 0;
    }
    .footer {
        font-size: 12px;
        color: #737995;
        margin-top: 20px;
        border-top: 1px solid #181e32;
        padding-top: 10px;
        line-height: 1.5;
    }
</style>
<script>
    function toggleSection(id) {
        var body = document.getElementById(id);
        var icon = document.getElementById(id + "-icon");
        if (!body) return;
        if (body.style.display === "none") {
            body.style.display = "block";
            if (icon) icon.textContent = "v";
        } else {
            body.style.display = "none";
            if (icon) icon.textContent = ">";
        }
    }
</script>
'@)
$null = $sb.AppendLine('</head>')
$null = $sb.AppendLine('<body>')
$null = $sb.AppendLine('<div class="page">')
$null = $sb.AppendLine('<div class="title">Malicious Threat Inspection</div>')
$null = $sb.AppendLine('<div class="subtitle">' + (Convert-ToHtmlSafe $timeStamp) + ' - Threat Inspection v1.8 - Read-only technician inspection</div>')

$null = $sb.AppendLine('<div class="summary-grid">')
$null = $sb.AppendLine('<div class="card"><div class="card-label">Computer</div><div class="card-value">' + (Convert-ToHtmlSafe $hostname) + '</div><div class="card-meta">User: ' + (Convert-ToHtmlSafe $userName) + '</div></div>')
$null = $sb.AppendLine('<div class="card"><div class="card-label">Operating System</div><div class="card-value">' + (Convert-ToHtmlSafe $osName) + '</div><div class="card-meta">Build: ' + (Convert-ToHtmlSafe $osBuild) + '</div></div>')
$null = $sb.AppendLine('<div class="card"><div class="card-label">System</div><div class="card-value">' + (Convert-ToHtmlSafe $manufacturer) + '</div><div class="card-meta">' + (Convert-ToHtmlSafe $model) + '</div></div>')
$null = $sb.AppendLine('<div class="card"><div class="card-label">Antivirus</div><div class="card-value">' + (Convert-ToHtmlSafe $avSummary) + '</div><div class="card-meta">Security Center provider inventory</div></div>')
$null = $sb.AppendLine('<div class="card"><div class="card-label">Review Concerns</div><div class="card-value">' + $reviewCount + '</div><div class="card-meta">Unique items requiring technician review</div></div>')
$null = $sb.AppendLine('<div class="card"><div class="card-label">Warning Concerns</div><div class="card-value">' + $warningCount + '</div><div class="card-meta">Unique higher-confidence risky conditions</div></div>')
$null = $sb.AppendLine('</div>')

$null = $sb.AppendLine('<div class="legend">Good = expected security state &nbsp; | &nbsp; Review = verify legitimacy &nbsp; | &nbsp; Warning = stronger risk indicator &nbsp; | &nbsp; Info = inventory/context</div>')

$null = $sb.AppendLine('<div class="status-row">')
foreach ($sec in $sections) {
    $cls = 'status-' + $sec.Status.ToLowerInvariant()
    $label = "$($sec.Title) - $($sec.Status)"
    $null = $sb.AppendLine('<a class="status-pill ' + $cls + '" href="#section-' + $sec.Id + '">' + (Convert-ToHtmlSafe $label) + '</a>')
}
$null = $sb.AppendLine('</div>')

$index = 0
foreach ($sec in $sections) {
    $index++
    $bodyId = "sec$index"
    $iconId = "$bodyId-icon"
    $cls = 'status-' + $sec.Status.ToLowerInvariant()

    $null = $sb.AppendLine('<div id="section-' + $sec.Id + '" class="section">')
    $null = $sb.AppendLine('<div class="section-header" onclick="toggleSection(''' + $bodyId + ''')">')
    $null = $sb.AppendLine('<div class="section-left"><span id="' + $iconId + '" class="section-icon">v</span><span class="section-title">' + (Convert-ToHtmlSafe $sec.Title) + '</span></div>')
    $null = $sb.AppendLine('<span class="section-status-pill ' + $cls + '">' + (Convert-ToHtmlSafe $sec.Status) + '</span>')
    $null = $sb.AppendLine('</div>')
    $null = $sb.AppendLine('<div id="' + $bodyId + '" class="section-body">')
    $null = $sb.AppendLine('<p class="section-summary">' + (Convert-ToHtmlSafe $sec.Summary) + '</p>')
    $null = $sb.AppendLine('<div class="findings">')

    foreach ($finding in $sec.Findings) {
        $fcls = 'status-' + $finding.Status.ToLowerInvariant()
        $null = $sb.AppendLine('<div class="finding">')
        $null = $sb.AppendLine('<div><span class="finding-status ' + $fcls + '">' + (Convert-ToHtmlSafe $finding.Status) + '</span></div>')
        $null = $sb.AppendLine('<div class="finding-main"><div class="finding-text">' + (Convert-ToHtmlSafe $finding.Text) + '</div>')
        if (-not [string]::IsNullOrWhiteSpace([string]$finding.Detail)) {
            $null = $sb.AppendLine('<div class="finding-detail">' + (Convert-ToHtmlSafe $finding.Detail) + '</div>')
        }
        $null = $sb.AppendLine('</div></div>')
    }

    $null = $sb.AppendLine('</div>')
    $null = $sb.AppendLine('</div>')
    $null = $sb.AppendLine('</div>')
}

$null = $sb.AppendLine('<div class="footer">')
$null = $sb.AppendLine('Threat inspection completed at ' + (Convert-ToHtmlSafe ($completedAt.ToString('yyyy-MM-dd HH:mm:ss'))) + '.<br>')
$null = $sb.AppendLine('This report is an inspection aid, not a malware verdict. Review items may be legitimate. The script does not remediate or delete inspected files, disable settings, quarantine threats, or upload files/hashes.<br>')
$null = $sb.AppendLine('Summary cards count unique Warning/Review concerns rather than duplicate evidence rows. Raw evidence rows: ' + $rawWarningFindingCount + ' Warning / ' + $rawReviewFindingCount + ' Review.<br>')
$null = $sb.AppendLine('Some browser site permissions and unloaded/offline per-user registry hives may still require manual review.')
$null = $sb.AppendLine('</div>')
$null = $sb.AppendLine('</div>')
$null = $sb.AppendLine('</body>')
$null = $sb.AppendLine('</html>')

[System.IO.File]::WriteAllText($finalReportPath, $sb.ToString(), [System.Text.Encoding]::UTF8)

# ----------------------------------------------------
# Final
# ----------------------------------------------------
Write-Host "Threat Inspection" -ForegroundColor Cyan
Write-Host ""
Write-Host "Report: $finalReportPath" -ForegroundColor Green
Write-Host "Review concerns: $reviewCount" -ForegroundColor Yellow
Write-Host "Warning concerns: $warningCount" -ForegroundColor $(if ($warningCount -gt 0) { 'Red' } else { 'Green' })
Write-Host ""
Write-Host "Threat inspection completed." -ForegroundColor Green

if (-not $NoOpenReport) {
    try { Start-Process $finalReportPath | Out-Null } catch { }
}

try { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue } catch { }
