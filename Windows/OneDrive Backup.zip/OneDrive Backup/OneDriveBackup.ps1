[CmdletBinding()]
param(
    [string]$OneDrivePath,
    [string]$DestinationPath,
    [string]$DestinationLabel,
    [int]$SourceFreeBufferGB = 5,
    [int]$DestinationFreeBufferGB = 5,
    [int]$HydrationTimeoutMinutes = 90,
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -----------------------------
# Output helpers
# -----------------------------

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
}

function Write-WarnLine {
    param([string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[OK]   $Message" -ForegroundColor Green
}

function Write-ErrLine {
    param([string]$Message)
    Write-Host "[ERR]  $Message" -ForegroundColor Red
}

function Format-Bytes {
    param([double]$Bytes)

    if ($Bytes -ge 1TB) { return ('{0:N2} TB' -f ($Bytes / 1TB)) }
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N2} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N2} KB' -f ($Bytes / 1KB)) }
    return ('{0:N0} B' -f $Bytes)
}

function Get-SafeCount {
    param($InputObject)

    if ($null -eq $InputObject) {
        return 0
    }

    return @($InputObject).Count
}

function Test-CommandAvailable {
    param([string]$Name)
    return ($null -ne (Get-Command -Name $Name -ErrorAction SilentlyContinue))
}

function Ensure-DirectoryExists {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Test-IsSkippedItem {
    param([System.IO.FileSystemInfo]$Item)

    if ($null -eq $Item) {
        return $true
    }

    if ($Item.Name -ieq 'desktop.ini') {
        return $true
    }

    $isHidden = [bool]($Item.Attributes -band [System.IO.FileAttributes]::Hidden)
    $isSystem = [bool]($Item.Attributes -band [System.IO.FileAttributes]::System)

    if (($isHidden -or $isSystem) -and
        ($Item.Name -match '^\.[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$')) {
        return $true
    }

    return $false
}

function Test-IsIgnoredDestinationLabel {
    param([string]$Label)

    if ([string]::IsNullOrWhiteSpace($Label)) {
        return $false
    }

    $patterns = @(
        'Google Drive*'
        'OneDrive*'
        'Dropbox*'
        'iCloud*'
        'Box*'
        'SharePoint*'
    )

    foreach ($pattern in $patterns) {
        if ($Label -like $pattern) {
            return $true
        }
    }

    return $false
}

# -----------------------------
# Path / drive helpers
# -----------------------------

function Resolve-ExistingPath {
    param([string]$Path)

    return (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
}

function Get-DriveLetterFromPath {
    param([string]$Path)

    $resolved = Resolve-ExistingPath -Path $Path
    $root = [System.IO.Path]::GetPathRoot($resolved)

    if ([string]::IsNullOrWhiteSpace($root)) {
        throw "Unable to determine drive root for path: $Path"
    }

    return $root.Substring(0, 1).ToUpperInvariant()
}

function Get-FreeBytesForDriveLetter {
    param([string]$DriveLetter)

    $DriveLetter = $DriveLetter.Substring(0, 1).ToUpperInvariant()

    if (Test-CommandAvailable -Name 'Get-Volume') {
        $volume = Get-Volume -DriveLetter $DriveLetter -ErrorAction SilentlyContinue
        if ($volume -and $null -ne $volume.SizeRemaining) {
            return [int64]$volume.SizeRemaining
        }
    }

    try {
        $disk = Get-WmiObject -Class Win32_LogicalDisk -Filter ("DeviceID='{0}:'" -f $DriveLetter) -ErrorAction Stop
        if ($disk -and $null -ne $disk.FreeSpace) {
            return [int64]$disk.FreeSpace
        }
    } catch {
    }

    throw "Unable to determine free space for drive ${DriveLetter}:"
}

function Get-FreeBytesForPath {
    param([string]$Path)

    $driveLetter = Get-DriveLetterFromPath -Path $Path
    return (Get-FreeBytesForDriveLetter -DriveLetter $driveLetter)
}

function Get-RelativePath {
    param(
        [string]$BasePath,
        [string]$TargetPath
    )

    $baseResolved = Resolve-ExistingPath -Path $BasePath
    $targetResolved = Resolve-ExistingPath -Path $TargetPath

    if (-not $baseResolved.EndsWith('\')) {
        $baseResolved += '\'
    }

    $baseUri = New-Object System.Uri($baseResolved)
    $targetUri = New-Object System.Uri($targetResolved)
    $relativeUri = $baseUri.MakeRelativeUri($targetUri)

    return ([System.Uri]::UnescapeDataString($relativeUri.ToString())).Replace('/', '\')
}

# -----------------------------
# OneDrive detection
# -----------------------------

function Resolve-OneDrivePath {
    param([string]$ExplicitPath)

    if ($ExplicitPath) {
        if (-not (Test-Path -LiteralPath $ExplicitPath -PathType Container)) {
            throw "The supplied OneDrive path does not exist: ${ExplicitPath}"
        }

        return (Resolve-ExistingPath -Path $ExplicitPath)
    }

    $candidates = New-Object System.Collections.ArrayList

    foreach ($value in @(
        $env:OneDriveCommercial,
        $env:OneDriveConsumer,
        $env:OneDrive
    )) {
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            [void]$candidates.Add($value)
        }
    }

    foreach ($regPath in @(
        'HKCU:\Software\Microsoft\OneDrive',
        'HKCU:\Software\Microsoft\OneDrive\Accounts\Personal'
    )) {
        try {
            if (Test-Path -LiteralPath $regPath) {
                $props = Get-ItemProperty -LiteralPath $regPath -ErrorAction Stop
                if ($props.UserFolder) {
                    [void]$candidates.Add($props.UserFolder)
                }
            }
        } catch {
        }
    }

    $accountsRoot = 'HKCU:\Software\Microsoft\OneDrive\Accounts'
    if (Test-Path -LiteralPath $accountsRoot) {
        try {
            Get-ChildItem -LiteralPath $accountsRoot -ErrorAction Stop | ForEach-Object {
                try {
                    $props = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction Stop
                    if ($props.UserFolder) {
                        [void]$candidates.Add($props.UserFolder)
                    }
                } catch {
                }
            }
        } catch {
        }
    }

    $resolved = @(
        $candidates |
        Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) } |
        Select-Object -Unique
    )

    $resolvedCount = Get-SafeCount $resolved

    if ($resolvedCount -eq 0) {
        throw "Unable to locate the OneDrive sync folder automatically."
    }

    if ($resolvedCount -gt 1) {
        Write-WarnLine "Multiple OneDrive candidates found. Using the first one:"
        foreach ($item in @($resolved)) {
            Write-Host "  $item"
        }
    }

    return (Resolve-ExistingPath -Path (@($resolved)[0]))
}

# -----------------------------
# Destination detection
# -----------------------------

function Get-ExternalVolumeCandidates {
    param([string]$ExcludeDriveLetter)

    $results = New-Object System.Collections.ArrayList
    $exclude = $null

    if ($ExcludeDriveLetter) {
        $exclude = $ExcludeDriveLetter.Substring(0, 1).ToUpperInvariant()
    }

    # Preferred method: Storage module + USB bus type only
    if ((Test-CommandAvailable -Name 'Get-Disk') -and
        (Test-CommandAvailable -Name 'Get-Partition') -and
        (Test-CommandAvailable -Name 'Get-Volume')) {

        $usbDiskNumbers = @(
            Get-Disk -ErrorAction SilentlyContinue |
            Where-Object { $_.BusType -eq 'USB' } |
            Select-Object -ExpandProperty Number
        )

        foreach ($diskNumber in $usbDiskNumbers) {
            try {
                $volumes = Get-Partition -DiskNumber $diskNumber -ErrorAction Stop |
                    Get-Volume -ErrorAction Stop |
                    Where-Object {
                        $_.DriveLetter -and
                        $_.SizeRemaining -ge 0 -and
                        $_.FileSystem
                    }

                foreach ($volume in $volumes) {
                    $letter = ([string]$volume.DriveLetter).ToUpperInvariant()

                    if ($exclude -and $letter -eq $exclude) {
                        continue
                    }

                    if (Test-IsIgnoredDestinationLabel -Label $volume.FileSystemLabel) {
                        continue
                    }

                    [void]$results.Add([pscustomobject]@{
                        DriveLetter = $letter
                        Label       = $volume.FileSystemLabel
                        FreeBytes   = [int64]$volume.SizeRemaining
                        RootPath    = ('{0}:\' -f $letter)
                        Source      = 'StorageModule-USB'
                    })
                }
            } catch {
            }
        }
    }

    # Fallback: WMI association chain, USB physical disks only
    if ((Get-SafeCount $results) -eq 0) {
        try {
            $usbDrives = Get-WmiObject -Class Win32_DiskDrive -ErrorAction Stop | Where-Object {
                $_.InterfaceType -eq 'USB' -or
                $_.PNPDeviceID -like 'USBSTOR*'
            }

            foreach ($usbDrive in $usbDrives) {
                try {
                    $partitions = @($usbDrive.GetRelated('Win32_DiskPartition'))
                    foreach ($partition in $partitions) {
                        $logicalDisks = @($partition.GetRelated('Win32_LogicalDisk'))
                        foreach ($disk in $logicalDisks) {
                            if (-not $disk.DeviceID) {
                                continue
                            }

                            $letter = $disk.DeviceID.Substring(0, 1).ToUpperInvariant()

                            if ($exclude -and $letter -eq $exclude) {
                                continue
                            }

                            if (Test-IsIgnoredDestinationLabel -Label $disk.VolumeName) {
                                continue
                            }

                            [void]$results.Add([pscustomobject]@{
                                DriveLetter = $letter
                                Label       = $disk.VolumeName
                                FreeBytes   = [int64]$disk.FreeSpace
                                RootPath    = ('{0}:\' -f $letter)
                                Source      = 'WMI-USB'
                            })
                        }
                    }
                } catch {
                }
            }
        } catch {
        }
    }

    return @(
        $results |
        Sort-Object DriveLetter -Unique
    )
}

function Resolve-DestinationRoot {
    param(
        [string]$ExplicitPath,
        [string]$VolumeLabel,
        [string]$SourceDriveLetter
    )

    if ($ExplicitPath) {
        $fullPath = [System.IO.Path]::GetFullPath($ExplicitPath)
        $root = [System.IO.Path]::GetPathRoot($fullPath)

        if ([string]::IsNullOrWhiteSpace($root) -or -not (Test-Path -LiteralPath $root)) {
            throw "Destination root does not exist: ${root}"
        }

        if (-not (Test-Path -LiteralPath $fullPath)) {
            if ($WhatIf) {
                Write-Info "Would create destination path: $fullPath"
            } else {
                Ensure-DirectoryExists -Path $fullPath
            }
        }

        return $fullPath
    }

    if ($VolumeLabel) {
        if (Test-CommandAvailable -Name 'Get-Volume') {
            $match = Get-Volume -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.FileSystemLabel -eq $VolumeLabel -and $_.DriveLetter
                } |
                Sort-Object SizeRemaining -Descending |
                Select-Object -First 1

            if ($match) {
                return ('{0}:\' -f ([string]$match.DriveLetter).ToUpperInvariant())
            }
        }

        try {
            $matchWmi = Get-WmiObject -Class Win32_LogicalDisk -ErrorAction Stop |
                Where-Object {
                    $_.VolumeName -eq $VolumeLabel -and $_.DeviceID
                } |
                Sort-Object FreeSpace -Descending |
                Select-Object -First 1

            if ($matchWmi) {
                return ($matchWmi.DeviceID + '\')
            }
        } catch {
        }

        Write-WarnLine "No writable volume with label '$VolumeLabel' was found."
        return $null
    }

    $candidates = @(Get-ExternalVolumeCandidates -ExcludeDriveLetter $SourceDriveLetter)
    $candidateCount = Get-SafeCount $candidates

    if ($candidateCount -eq 0) {
        Write-WarnLine "No external USB drives were found."
        return $null
    }

    $best = @($candidates) |
        Sort-Object FreeBytes -Descending |
        Select-Object -First 1

    Write-Info ("Auto-selected destination volume {0} ({1}) with {2} free." -f
        $best.RootPath.TrimEnd('\'),
        $(if ([string]::IsNullOrWhiteSpace($best.Label)) { 'No Label' } else { $best.Label }),
        (Format-Bytes $best.FreeBytes))

    return $best.RootPath
}

# -----------------------------
# Files On-Demand helpers
# -----------------------------

function Invoke-Attrib {
    param([string]$Arguments)

    $attribPath = Join-Path $env:SystemRoot 'System32\attrib.exe'

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $attribPath
    $psi.Arguments = $Arguments
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true

    $proc = [System.Diagnostics.Process]::Start($psi)
    $stdout = $proc.StandardOutput.ReadToEnd()
    $stderr = $proc.StandardError.ReadToEnd()
    $proc.WaitForExit()

    return [pscustomobject]@{
        ExitCode = $proc.ExitCode
        StdOut   = $stdout
        StdErr   = $stderr
    }
}

function Get-PathState {
    param([string]$Path)

    $result = Invoke-Attrib -Arguments ("`"{0}`"" -f $Path)
    if ($result.ExitCode -ne 0) {
        return 'Unknown'
    }

    $line = ($result.StdOut -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -First 1)
    if (-not $line) {
        return 'Unknown'
    }

    if ($line -match '^\s*([A-Z ]+?)\s+[A-Za-z]:\\') {
        $flags = ($matches[1] -replace '\s', '')
    } else {
        $flags = ($line -replace '\s', '')
    }

    if ($flags.Contains('P')) { return 'AlwaysAvailable' }
    if ($flags.Contains('U')) { return 'OnlineOnly' }
    return 'LocallyAvailable'
}

function Get-OnlineOnlyFilesUnderPath {
    param([string]$Path)

    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        $item = Get-Item -LiteralPath $Path -Force
        if (Test-IsSkippedItem -Item $item) {
            return @()
        }

        if ((Get-PathState -Path $item.FullName) -eq 'OnlineOnly') {
            return @($item)
        }

        return @()
    }

    $result = Invoke-Attrib -Arguments ("/s /d `"{0}\*`"" -f $Path)
    if ($result.ExitCode -ne 0 -and [string]::IsNullOrWhiteSpace($result.StdOut)) {
        return @()
    }

    $onlineOnly = New-Object System.Collections.ArrayList

    foreach ($line in ($result.StdOut -split "`r?`n")) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        if ($line -notmatch '^\s*([A-Z ]+?)\s+(.+)$') {
            continue
        }

        $flags = ($matches[1] -replace '\s', '')
        $candidatePath = $matches[2].Trim()

        if (-not $flags.Contains('U')) { continue }
        if ($flags.Contains('P')) { continue }
        if (-not (Test-Path -LiteralPath $candidatePath -PathType Leaf)) { continue }

        try {
            $file = Get-Item -LiteralPath $candidatePath -Force -ErrorAction Stop
            if (Test-IsSkippedItem -Item $file) {
                continue
            }
            [void]$onlineOnly.Add($file)
        } catch {
        }
    }

    return @($onlineOnly)
}

function Get-WorkItemPlan {
    param([string]$Path)

    $isDirectory = Test-Path -LiteralPath $Path -PathType Container
    $onlineOnlyFiles = @(Get-OnlineOnlyFilesUnderPath -Path $Path)

    $onlineOnlyBytes = 0
    if ((Get-SafeCount $onlineOnlyFiles) -gt 0) {
        $measure = $onlineOnlyFiles | Measure-Object -Property Length -Sum
        if ($measure -and $null -ne $measure.Sum) {
            $onlineOnlyBytes = [int64]$measure.Sum
        }
    }

    return [pscustomobject]@{
        Path            = $Path
        IsDirectory     = $isDirectory
        OnlineOnlyFiles = $onlineOnlyFiles
        OnlineOnlyBytes = [int64]$onlineOnlyBytes
    }
}

function Set-FilesAlwaysAvailable {
    param([array]$Files)

    foreach ($file in $Files) {
        $result = Invoke-Attrib -Arguments ("-u +p `"{0}`"" -f $file.FullName)
        if ($result.ExitCode -ne 0) {
            throw "Failed to pin file: $($file.FullName)`n$($result.StdErr)"
        }
    }
}

function Set-FilesOnlineOnly {
    param([array]$Files)

    foreach ($file in $Files) {
        if (-not (Test-Path -LiteralPath $file.FullName -PathType Leaf)) {
            continue
        }

        $result = Invoke-Attrib -Arguments ("+u -p `"{0}`"" -f $file.FullName)
        if ($result.ExitCode -ne 0) {
            throw "Failed to restore file to online-only: $($file.FullName)`n$($result.StdErr)"
        }
    }
}

function Wait-UntilFilesHydrated {
    param(
        [array]$Files,
        [int]$TimeoutMinutes
    )

    if ((Get-SafeCount $Files) -eq 0) {
        return
    }

    $deadline = (Get-Date).AddMinutes($TimeoutMinutes)

    do {
        $remaining = @(
            foreach ($file in $Files) {
                if (-not (Test-Path -LiteralPath $file.FullName -PathType Leaf)) {
                    continue
                }

                if ((Get-PathState -Path $file.FullName) -eq 'OnlineOnly') {
                    $file
                }
            }
        )

        if ((Get-SafeCount $remaining) -eq 0) {
            return
        }

        Start-Sleep -Seconds 5
    } while ((Get-Date) -lt $deadline)

    throw "Hydration timeout. $(Get-SafeCount $remaining) file(s) were still online-only after $TimeoutMinutes minute(s)."
}

# -----------------------------
# File size / manifest helpers
# -----------------------------

function Get-TotalSourceBytes {
    param([string]$SourceRoot)

    $sum = Get-ChildItem -LiteralPath $SourceRoot -File -Recurse -Force -ErrorAction SilentlyContinue |
        Where-Object { -not (Test-IsSkippedItem -Item $_) } |
        Measure-Object -Property Length -Sum

    if ($null -eq $sum -or $null -eq $sum.Sum) {
        return 0
    }

    return [int64]$sum.Sum
}

function Save-Manifest {
    param(
        [string]$ManifestPath,
        [System.Collections.ArrayList]$Manifest
    )

    if ($WhatIf) {
        return
    }

    $json = $Manifest | ConvertTo-Json -Depth 6
    $json | Out-File -LiteralPath $ManifestPath -Encoding utf8 -Force
}

function Add-ManifestEntries {
    param(
        [System.Collections.ArrayList]$Manifest,
        [array]$Files,
        [string]$BatchRoot
    )

    foreach ($file in $Files) {
        [void]$Manifest.Add([pscustomobject]@{
            Path          = $file.FullName
            OriginalState = 'OnlineOnly'
            BatchRoot     = $BatchRoot
            Pinned        = $false
            Restored      = $false
            Timestamp     = (Get-Date).ToString('s')
        })
    }
}

function Mark-ManifestBatchPinned {
    param(
        [System.Collections.ArrayList]$Manifest,
        [string]$BatchRoot
    )

    foreach ($entry in $Manifest) {
        if ($entry.BatchRoot -eq $BatchRoot -and -not $entry.Pinned) {
            $entry.Pinned = $true
        }
    }
}

function Mark-ManifestBatchRestored {
    param(
        [System.Collections.ArrayList]$Manifest,
        [string]$BatchRoot
    )

    foreach ($entry in $Manifest) {
        if ($entry.BatchRoot -eq $BatchRoot -and $entry.Pinned -and -not $entry.Restored) {
            $entry.Restored = $true
        }
    }
}

# -----------------------------
# Robocopy helper
# -----------------------------

function Invoke-RobocopyItem {
    param(
        [string]$ItemPath,
        [string]$SourceRoot,
        [string]$BackupRoot,
        [string]$LogFile,
        [switch]$WhatIfMode
    )

    if (Test-Path -LiteralPath $ItemPath -PathType Container) {
        $relative = Get-RelativePath -BasePath $SourceRoot -TargetPath $ItemPath
        $destPath = Join-Path -Path $BackupRoot -ChildPath $relative

        $args = @(
            $ItemPath
            $destPath
            '/E'
            '/ZB'
            '/J'
            '/COPY:DAT'
            '/DCOPY:DAT'
            '/R:2'
            '/W:2'
            '/MT:16'
            '/XJ'
            '/TEE'
        )
    } else {
        $sourceDir = [System.IO.Path]::GetDirectoryName($ItemPath)
        $fileName  = [System.IO.Path]::GetFileName($ItemPath)

        if ([string]::IsNullOrWhiteSpace($sourceDir)) {
            throw "Unable to determine source directory for file: $ItemPath"
        }

        $resolvedSourceRoot = Resolve-ExistingPath -Path $SourceRoot
        $resolvedSourceDir  = Resolve-ExistingPath -Path $sourceDir

        if ($resolvedSourceDir.TrimEnd('\') -eq $resolvedSourceRoot.TrimEnd('\')) {
            $destPath = $BackupRoot
        } else {
            $relativeParent = Get-RelativePath -BasePath $SourceRoot -TargetPath $sourceDir

            if ([string]::IsNullOrWhiteSpace($relativeParent) -or $relativeParent -eq '.') {
                $destPath = $BackupRoot
            } else {
                $destPath = Join-Path -Path $BackupRoot -ChildPath $relativeParent
            }
        }

        $args = @(
            $sourceDir
            $destPath
            $fileName
            '/ZB'
            '/J'
            '/COPY:DAT'
            '/R:2'
            '/W:2'
            '/MT:16'
            '/XJ'
            '/TEE'
        )
    }

    if (-not $WhatIfMode) {
        Ensure-DirectoryExists -Path $destPath
        $args += "/LOG+:$LogFile"
    }

    if ($WhatIfMode) {
        Write-Host ("robocopy " + ($args -join ' '))
        return 0
    }

    $output = @(& robocopy @args 2>&1)
    $exitCode = $LASTEXITCODE

    if ($exitCode -ge 8) {
        Write-ErrLine ("Robocopy failed with exit code {0} for '{1}'." -f $exitCode, $ItemPath)

        $tail = @($output | Select-Object -Last 20)
        if ((Get-SafeCount $tail) -gt 0) {
            Write-WarnLine "Last robocopy output lines:"
            foreach ($line in $tail) {
                Write-Host $line
            }
        }

        if (Test-Path -LiteralPath $LogFile) {
            Write-WarnLine ("See log file: {0}" -f $LogFile)
        }
    }

    return $exitCode
}

# -----------------------------
# Main
# -----------------------------

try {
    $sourceRoot = Resolve-OneDrivePath -ExplicitPath $OneDrivePath
    Write-Info "Source OneDrive path: $sourceRoot"

    $sourceDriveLetter = Get-DriveLetterFromPath -Path $sourceRoot
    $destinationRoot = Resolve-DestinationRoot -ExplicitPath $DestinationPath -VolumeLabel $DestinationLabel -SourceDriveLetter $sourceDriveLetter

    if ([string]::IsNullOrWhiteSpace($destinationRoot)) {
        Write-WarnLine "Backup canceled."
        return
    }

    Write-Info "Destination root: $destinationRoot"

    $sourceDriveFree = Get-FreeBytesForPath -Path $sourceRoot
    $destinationDriveFree = Get-FreeBytesForPath -Path $destinationRoot

    $sourceBufferBytes = [int64]$SourceFreeBufferGB * 1GB
    $destinationBufferBytes = [int64]$DestinationFreeBufferGB * 1GB

    $totalSourceBytes = Get-TotalSourceBytes -SourceRoot $sourceRoot
    Write-Info ("Total OneDrive logical size: {0}" -f (Format-Bytes $totalSourceBytes))

    if (($destinationDriveFree - $destinationBufferBytes) -lt $totalSourceBytes) {
        Write-WarnLine ("Not enough free space on destination. Need at least {0} plus buffer, but only {1} is currently free." -f
            (Format-Bytes $totalSourceBytes),
            (Format-Bytes $destinationDriveFree))
        Write-WarnLine "Backup canceled."
        return
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd_HH-mm-ss'
    $backupRoot = Join-Path $destinationRoot ("Backups\{0}\OneDriveBackup_{1}" -f $env:COMPUTERNAME, $timestamp)
    $logFile = Join-Path $backupRoot 'robocopy.log'
    $manifestPath = Join-Path $backupRoot 'hydration-manifest.json'

    if ($WhatIf) {
        Write-Info "WhatIf mode is on. No files will be modified or copied."
        Write-Info "Would use backup root: $backupRoot"
    } else {
        Ensure-DirectoryExists -Path $backupRoot
    }

    $manifest = New-Object System.Collections.ArrayList
    $queue = New-Object System.Collections.Queue

    Get-ChildItem -LiteralPath $sourceRoot -Force -ErrorAction Stop |
        Where-Object { -not (Test-IsSkippedItem -Item $_) } |
        ForEach-Object { $queue.Enqueue($_.FullName) }

    if ($queue.Count -eq 0) {
        Write-WarnLine "No transferable items were found in the OneDrive folder."
    }

    while ($queue.Count -gt 0) {
        $currentPath = [string]$queue.Dequeue()
        $plan = Get-WorkItemPlan -Path $currentPath

        $currentSourceFree = Get-FreeBytesForPath -Path $sourceRoot
        $requiredTempBytes = [int64]$plan.OnlineOnlyBytes + [int64]$sourceBufferBytes

        if ($plan.OnlineOnlyBytes -gt 0 -and $currentSourceFree -lt $requiredTempBytes) {
            if ($plan.IsDirectory) {
                $children = Get-ChildItem -LiteralPath $currentPath -Force -ErrorAction SilentlyContinue |
                    Where-Object { -not (Test-IsSkippedItem -Item $_) }

                if ((Get-SafeCount $children) -gt 0) {
                    Write-WarnLine ("Not enough free source space to hydrate '{0}' as one batch. Splitting into child items." -f $currentPath)
                    foreach ($child in $children) {
                        $queue.Enqueue($child.FullName)
                    }
                    continue
                }
            }

            Write-WarnLine ("Skipping '{0}' because it needs {1} temporary local space and only {2} is free on the source drive." -f
                $currentPath,
                (Format-Bytes $plan.OnlineOnlyBytes),
                (Format-Bytes $currentSourceFree))
            continue
        }

        $batchFilesToRestore = @()

        try {
            if ((Get-SafeCount $plan.OnlineOnlyFiles) -gt 0) {
                Write-Info ("Hydrating {0} online-only file(s) under '{1}' ({2})." -f
                    (Get-SafeCount $plan.OnlineOnlyFiles),
                    $currentPath,
                    (Format-Bytes $plan.OnlineOnlyBytes))

                Add-ManifestEntries -Manifest $manifest -Files $plan.OnlineOnlyFiles -BatchRoot $currentPath
                Save-Manifest -ManifestPath $manifestPath -Manifest $manifest

                if (-not $WhatIf) {
                    Set-FilesAlwaysAvailable -Files $plan.OnlineOnlyFiles
                    Mark-ManifestBatchPinned -Manifest $manifest -BatchRoot $currentPath
                    Save-Manifest -ManifestPath $manifestPath -Manifest $manifest

                    Wait-UntilFilesHydrated -Files $plan.OnlineOnlyFiles -TimeoutMinutes $HydrationTimeoutMinutes
                }

                $batchFilesToRestore = @($plan.OnlineOnlyFiles)
            }

            Write-Info "Copying: $currentPath"
            $roboExit = Invoke-RobocopyItem -ItemPath $currentPath -SourceRoot $sourceRoot -BackupRoot $backupRoot -LogFile $logFile -WhatIfMode:$WhatIf

            if ($roboExit -ge 8) {
                throw ("Robocopy failed for '{0}' with exit code {1}." -f $currentPath, $roboExit)
            }

            Write-Ok "Finished: $currentPath"
        }
        finally {
            if (-not $WhatIf -and (Get-SafeCount $batchFilesToRestore) -gt 0) {
                try {
                    Write-Info "Restoring temporary online-only files."
                    Set-FilesOnlineOnly -Files $batchFilesToRestore
                    Mark-ManifestBatchRestored -Manifest $manifest -BatchRoot $currentPath
                    Save-Manifest -ManifestPath $manifestPath -Manifest $manifest
                } catch {
                    Write-WarnLine ("Failed to restore some files in batch '{0}': {1}" -f $currentPath, $_.Exception.Message)
                }
            }
        }
    }

    Write-Ok "Backup complete."
    Write-Host ""
    Write-Host ("Backup root : {0}" -f $backupRoot)

    if (-not $WhatIf) {
        Write-Host ("Log file    : {0}" -f $logFile)
        Write-Host ("Manifest    : {0}" -f $manifestPath)
    }
}
catch {
    Write-ErrLine $_.Exception.Message
    Write-WarnLine "Backup canceled."
}
finally {
    Read-Host "Press Enter to exit"
}