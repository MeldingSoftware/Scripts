@echo off
set "SCRIPT=%~dp0OneDriveBackup.ps1"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
exit