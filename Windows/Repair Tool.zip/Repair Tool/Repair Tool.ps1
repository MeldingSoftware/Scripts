# Create Maintenance Directory
$desktopPath = ""

if (Test-Path "$env:userprofile\Desktop") {
    $desktopPath = "$env:userprofile\Desktop\Repair Tool Results"
    if (!(Test-Path $desktopPath)) {
        New-Item $desktopPath -ItemType Directory
    }
}
else {
    $desktopPath = "$env:userprofile\OneDrive\Desktop\Repair Tool Results"
    if (!(Test-Path $desktopPath)) {
        New-Item $desktopPath -ItemType Directory
    }
}

$null = Start-Transcript -Path "$desktopPath\DISM_SFC.txt" -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "DISM and SFC"`n -ForegroundColor Cyan
Write-Host "Analyze Component Store"`n
Write-Output 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Start Component Cleanup"`n
dism.exe /online /cleanup-image /startcomponentcleanup
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Check Health"`n
dism.exe /online /cleanup-image /checkhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Scan Health"`n
dism.exe /online /cleanup-image /scanhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Restore Health"`n
dism.exe /online /cleanup-image /restorehealth
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "SFC"`n
sfc /scannow
Write-Host ""
Write-Host "[Done] DISM and SFC completed"`n -ForegroundColor Green
Stop-Transcript | Out-Null
Write-Host ""
Read-Host "Press Enter to exit"