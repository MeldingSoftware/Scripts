Add-Type -assemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class KeyListener {
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);
}
"@

$a = @(1..100)

Write-Host "Press the Esc key to close.`n"

$lastMove = Get-Date

while ($true) {
    # Check if the Esc key (key code 27) is pressed
    $keyState = [KeyListener]::GetAsyncKeyState(0x1B)
    if (($keyState -band 0x8000) -ne 0) {
        break
    }

    # Check if 5 seconds have passed since the last mouse movement
    $now = Get-Date
    if (($now - $lastMove).TotalSeconds -ge 5) {
        [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point(($a | Get-Random), ($a | Get-Random))
        $lastMove = $now
    }

    Start-Sleep -Milliseconds 100  # Small sleep to avoid high CPU usage
}
