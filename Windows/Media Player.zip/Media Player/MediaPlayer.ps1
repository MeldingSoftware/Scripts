# DLLs for show and hide console
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'

# Function to hide the console window
function Hide-Console {
    $consolePtr = [Console.Window]::GetConsoleWindow()
    [Console.Window]::ShowWindow($consolePtr, 0)  # 0 = Hide the window
}

# Add necessary WPF and Windows Forms assemblies
Add-Type -AssemblyName PresentationCore, PresentationFramework
Add-Type -AssemblyName System.Windows.Forms

# Hide the PowerShell console window at the start
Hide-Console

# Define emojis
$LoadEmoji = [char]0x2630  # ☰
$PlayEmoji = [char]0x25B6   # ▶
$PauseEmoji = [char]0x23F8  # ⏸
$RewindEmoji = [char]0x23EA  # ⏪
$FastForwardEmoji = [char]0x23E9  # ⏩
$FullscreenEmoji = [char]0x2921 
$CloseEmoji = [char]0x274C  # ❌

# Updated XAML Definition
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Media Player" ResizeMode="CanResizeWithGrip" 
        WindowStartupLocation="CenterScreen" Width="1200" Height="600" Background="Black">
    <Grid>
        <MediaElement Stretch="Fill" Name="MediaPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />

        <StackPanel Orientation="Vertical" HorizontalAlignment="Center" VerticalAlignment="Bottom" Margin="0,0,0,10" Name="ControlsPanel">
            <!-- Interactive ProgressBar -->
            <Grid Height="10" Width="1150">
                <!-- ProgressBar -->
                <ProgressBar Name="ProgressBar" Width="1150" Height="10" Minimum="0" Maximum="100" Value="0" 
                             Foreground="Red" Background="Gray" />
                <!-- Overlay for Interactivity -->
                <Slider Name="ProgressSlider" Width="1150" Height="10" Minimum="0" Maximum="100" Value="0" 
                        Opacity="0" IsMoveToPointEnabled="True" />
            </Grid>
            
            <!-- Button Panel -->
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="150,10,0,0" Name="ButtonPanel">
                <!-- Playback Time -->
                <TextBlock Name="PlaybackTime" Foreground="White" FontSize="16" 
                           HorizontalAlignment="Left" VerticalAlignment="Center" Margin="-200,0,20,0" />
                <!-- Buttons -->
                <Button Content="$LoadEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="LoadButton" />
                <Button Content="$PlayEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="PlayButton" />
                <Button Content="$PauseEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="PauseButton" />
                <Button Content="$RewindEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="RewindButton" />
                <Button Content="$FastForwardEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="FastForwardButton" />
                <Button Width="80" Height="40" Name="FullscreenButton">
                    <TextBlock Text="$FullscreenEmoji" FontSize="35" FontFamily="Segoe UI Emoji" VerticalAlignment="Center" Margin="0,-5,0,0" />
                </Button>
                <Button Content="$CloseEmoji" Width="80" Height="40" FontSize="24" FontFamily="Segoe UI Emoji" Name="CloseButton" />
                <!-- Volume Slider -->
                <Slider Orientation="Horizontal" Width="200" Height="25" Minimum="0" Maximum="1" Name="VolumeSlider" 
                        Value="1" IsMoveToPointEnabled="True" VerticalAlignment="Center" Margin="60,5,0,0" />
            </StackPanel>
        </StackPanel>
    </Grid>
</Window>
"@


# Load XAML
$reader = New-Object System.Xml.XmlNodeReader $XAML
$window = [Windows.Markup.XamlReader]::Load($reader)

# Access elements
$mediaPlayer = $window.FindName("MediaPlayer")
$loadButton = $window.FindName("LoadButton")
$playButton = $window.FindName("PlayButton")
$pauseButton = $window.FindName("PauseButton")
$rewindButton = $window.FindName("RewindButton")
$fastForwardButton = $window.FindName("FastForwardButton")
$fullscreenButton = $window.FindName("FullscreenButton")
$closeButton = $window.FindName("CloseButton")
$volumeSlider = $window.FindName("VolumeSlider")
$controlsPanel = $window.FindName("ControlsPanel")
$progressBar = $window.FindName("ProgressBar")
$progressSlider = $window.FindName("ProgressSlider")
$playbackTime = $window.FindName("PlaybackTime")

# Save the original window position and size
$originalWindowState = @{
    Left   = $window.Left
    Top    = $window.Top
    Width  = $window.Width
    Height = $window.Height
}

# Timer to hide buttons and slider after 2 seconds
$hideButtonsTimer = New-Object System.Windows.Threading.DispatcherTimer
$hideButtonsTimer.Interval = [System.TimeSpan]::FromSeconds(2)
$hideButtonsTimer.Add_Tick({
    if ($mediaPlayer.HasVideo -or $mediaPlayer.HasAudio) {
        Hide-Controls
    }
})

# Timer to update ProgressBar, ProgressSlider, and Playback Time
$progressTimer = New-Object System.Windows.Threading.DispatcherTimer
$progressTimer.Interval = [System.TimeSpan]::FromMilliseconds(500)
$progressTimer.Add_Tick({
    if ($mediaPlayer.NaturalDuration.HasTimeSpan) {
        $progressBar.Maximum = $mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds
        $progressSlider.Maximum = $mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds
        $progressBar.Value = $mediaPlayer.Position.TotalSeconds
        $progressSlider.Value = $mediaPlayer.Position.TotalSeconds

        # Update playback time
        $currentTime = $mediaPlayer.Position.ToString("hh\:mm\:ss")
        $totalTime = $mediaPlayer.NaturalDuration.TimeSpan.ToString("hh\:mm\:ss")
        $playbackTime.Text = "$currentTime / $totalTime"
    } else {
        $playbackTime.Text = "00:00:00 / 00:00:00"
    }
})

# Start the ProgressBar and Playback Time Timer when media plays
$playButton.Add_Click({
    $mediaPlayer.Play()
    $progressTimer.Start()
    Write-Host "Playback Started"
})

# Stop the ProgressBar and Playback Time Timer when media pauses
$pauseButton.Add_Click({
    $mediaPlayer.Pause()
    $progressTimer.Stop()
    Write-Host "Playback Paused"
})

# Allow seeking via ProgressSlider
$progressSlider.Add_ValueChanged({
    if ($progressSlider.IsMouseOver -and $mediaPlayer.NaturalDuration.HasTimeSpan) {
        $mediaPlayer.Position = [TimeSpan]::FromSeconds($progressSlider.Value)
        $progressBar.Value = $progressSlider.Value
        Write-Host "Seek to Position: $($mediaPlayer.Position)"
    }
})

# Function to hide buttons, slider, progress bar, and playback time
function Hide-Controls {
    $controlsPanel.Visibility = "Collapsed"
    $progressBar.Visibility = "Collapsed"
    $progressSlider.Visibility = "Collapsed"
    $playbackTime.Visibility = "Collapsed"
    $window.Cursor = "None"
}

# Function to show buttons, slider, progress bar, and playback time
function Show-Controls {
    $controlsPanel.Visibility = "Visible"
    $progressBar.Visibility = "Visible"
    $progressSlider.Visibility = "Visible"
    $playbackTime.Visibility = "Visible"
    $window.Cursor = "Arrow"
}

# Button Actions
$loadButton.Add_Click({
    $fileDialog = New-Object Windows.Forms.OpenFileDialog
    $fileDialog.Filter = "Media Files|*.mp4;*.mp3;*.wmv;*.avi;*.mkv|All Files|*.*"
    if ($fileDialog.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) {
        $mediaPlayer.Source = New-Object Uri($fileDialog.FileName)
        $mediaPlayer.MediaOpened += {
            if ($mediaPlayer.NaturalDuration.HasTimeSpan) {
                $progressBar.Maximum = $mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds
                $progressSlider.Maximum = $mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds
                $progressBar.Value = 0
                $progressSlider.Value = 0
                $playbackTime.Text = "00:00:00 / $($mediaPlayer.NaturalDuration.TimeSpan.ToString("hh\:mm\:ss"))"
            }
        }

        $mediaPlayer.Play()
        $progressTimer.Start()
        Write-Host "Playback Started"
        $hideButtonsTimer.Start()
    }
})

$rewindButton.Add_Click({ $mediaPlayer.Position = $mediaPlayer.Position.Add([TimeSpan]::FromSeconds(-10)) })
$fastForwardButton.Add_Click({ $mediaPlayer.Position = $mediaPlayer.Position.Add([TimeSpan]::FromSeconds(10)) })
$fullscreenButton.Add_Click({ Toggle-Fullscreen })
$closeButton.Add_Click({ $mediaPlayer.Stop(); $window.Close() })

# Adjust volume dynamically based on slider movement
$volumeSlider.Add_ValueChanged({
    $mediaPlayer.Volume = $volumeSlider.Value
    Write-Host "Volume Adjusted: $($mediaPlayer.Volume)"
})

# Fullscreen Functionality with Maximized-to-Windowed Check
function Toggle-Fullscreen {
    $currentPosition = $mediaPlayer.Position

    # Check if the window is maximized
    if ($window.WindowState -eq [System.Windows.WindowState]::Maximized) {
        $window.WindowState = [System.Windows.WindowState]::Normal
        Write-Host "Window restored to normal mode before fullscreen."
    }

    if ($window.WindowStyle -eq "None") {
        # Restore original window state
        $window.WindowStyle = "SingleBorderWindow"
        $window.ResizeMode = "CanResizeWithGrip"
        $window.Topmost = $false
        $window.Left = $originalWindowState.Left
        $window.Top = $originalWindowState.Top
        $window.Width = $originalWindowState.Width
        $window.Height = $originalWindowState.Height
        $controlsPanel.Margin = [System.Windows.Thickness]::new(0, 0, 0, 10)
    } else {
        # Save current window state
        $originalWindowState.Left = $window.Left
        $originalWindowState.Top = $window.Top
        $originalWindowState.Width = $window.Width
        $originalWindowState.Height = $window.Height

        # Get the current screen of the window
        $screen = [System.Windows.Forms.Screen]::FromHandle([System.Windows.Interop.WindowInteropHelper]::new($window).Handle)

        # Enter fullscreen on the current monitor
        $window.WindowStyle = "None"
        $window.ResizeMode = "NoResize"
        $window.Topmost = $true
        $window.Left = $screen.Bounds.Left
        $window.Top = $screen.Bounds.Top
        $window.Width = $screen.Bounds.Width
        $window.Height = $screen.Bounds.Height
        $controlsPanel.Margin = [System.Windows.Thickness]::new(0, 0, 0, 50)
    }

    $mediaPlayer.Position = $currentPosition
}

# Mouse Events
$window.Add_MouseMove({
    if ($mediaPlayer.HasVideo -or $mediaPlayer.HasAudio) {
        Show-Controls
        $hideButtonsTimer.Stop()
        $hideButtonsTimer.Start()
    }
})

# Double-click to toggle fullscreen, excluding buttons and slider
$window.Add_MouseDoubleClick({
    $source = $_.OriginalSource
    while ($source -ne $null) {
        if ($source -is [System.Windows.Controls.Button] -or $source -is [System.Windows.Controls.Slider]) {
            return
        }
        $source = [System.Windows.Media.VisualTreeHelper]::GetParent($source)
    }
    Toggle-Fullscreen
})

# Exit fullscreen with ESC
$window.Add_KeyDown({
    if ($_.Key -eq [System.Windows.Input.Key]::Escape -and $window.WindowStyle -eq "None") {
        Toggle-Fullscreen
    }
})

# Start Timers
$hideButtonsTimer.Start()
$window.ShowDialog()

