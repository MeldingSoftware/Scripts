# Define components for stopping services
$components = @("wuauserv", "cryptSvc", "bits", "msiserver")

# Stop Windows Update components
Write-Host "Stopping related services" -ForegroundColor Cyan
foreach ($component in $components) {
    try {
        Stop-Service -Name $component -Force
        Write-Host "$component stopped successfully" -ForegroundColor Yellow
    } catch {
        Write-Host "Failed to stop $component. Error: $_" -ForegroundColor Red
    }
}
Write-Host "[Done] Service stopping completed"`n -ForegroundColor Green

# Delete SoftwareDistribution and catroot2 folders
Write-Host "Deleting SoftwareDistribution and catroot2 folders" -ForegroundColor Cyan
Remove-Item -Path C:\Windows\SoftwareDistribution -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path C:\Windows\System32\catroot2 -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[Done] Folder deletion completed"`n -ForegroundColor Green

# DISM 
Write-Host "Running DISM to clean up and repair Windows image" -ForegroundColor Cyan
dism /Online /Cleanup-image /StartComponentCleanup
dism /Online /Cleanup-image /ScanHealth
dism /Online /Cleanup-image /RestoreHealth
Write-Host "[Done] DISM cleanup and repair completed"`n -ForegroundColor Green

# Run SFC to repair system files
Write-Host "Running System File Checker (SFC)" -ForegroundColor Cyan
sfc /scannow
Write-Host "[Done] SFC scan completed"`n -ForegroundColor Green

# Start Windows Update components
Write-Host "Starting related services" -ForegroundColor Cyan
foreach ($component in $components) {
    try {
        Start-Service -Name $component
        Write-Host "$component started successfully" -ForegroundColor Yellow
    } catch {
        Write-Host "Failed to start $component. Error: $_" -ForegroundColor Red
    }
}
Write-Host "[Done] Service starting completed"`n -ForegroundColor Green

Read-Host "Press enter to exit"