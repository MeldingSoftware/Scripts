﻿Start-Process iexplore -ArgumentList '-k https://player.vimeo.com/video/198392879' -PassThru | 
ForEach-Object { 
    Start-Sleep -Seconds 2
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("{F11}")
    Start-Sleep -Milliseconds 500
    [System.Windows.Forms.SendKeys]::SendWait(" ")
}