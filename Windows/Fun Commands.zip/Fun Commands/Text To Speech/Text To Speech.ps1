﻿param([string]$text = "")

try {
    $TTS = New-Object -ComObject SAPI.SPVoice
    $voices = @()
    
    # List available voices and store them
    foreach ($voice in $TTS.GetVoices()) {
        $voices += $voice.GetDescription()
    }
    
    if ($voices.Count -eq 0) {
        throw "No text-to-speech voices found - please install one."
    }

    # Display available voices and prompt user to select one
    Write-Host "Available voices:" -ForegroundColor Cyan
    for ($i = 0; $i -lt $voices.Count; $i++) {
        Write-Host "$($i+1). $($voices[$i])"
    }

    $choice = Read-Host "Select a voice by number"
    
    # Add a space after the voice selection prompt
    Write-Host ""

    # Ensure valid voice selection
    if ($choice -match '^\d+$' -and [int]$choice -ge 1 -and [int]$choice -le $voices.Count) {
        $TTS.Voice = $TTS.GetVoices().Item([int]$choice - 1)
    } else {
        throw "Invalid choice. Exiting."
    }
    
    # Infinite loop for text-to-speech until user exits
    while ($true) {
        if ($text -eq "") {
            $text = Read-Host "Enter the English text to speak (or type 'exit' to quit)"
        }

        if ($text.ToLower() -eq "exit") {
            Write-Host "Exiting..."
            exit 0
        }

        [void]$TTS.Speak($text)

        # Add space between spoken text and next prompt
        Write-Host "" # Blank line
        $text = ""  # Reset text for the next prompt
    }

} catch {
    "⚠️ Error in line $($_.InvocationInfo.ScriptLineNumber): $($Error[0])"
    exit 1
}
