﻿$answers = @(
    "Yes", "No", "Maybe", "Ask again later", "Definitely",
    "I wouldn't count on it", "Absolutely!", "Very doubtful"
)

function Get-KeyPress {
    $key = $null
    while ($key -ne 'Enter' -and $key -ne 'Escape') {
        $key = [System.Console]::ReadKey($true).Key
    }
    return $key
}

do {
    Clear-Host
    Write-Host "Magic 8-Ball"
    Write-Host "======================"
    Write-Host "Ask a yes/no question, then press Enter..."
    Read-Host | Out-Null  # Wait for user input but don't store it
    Write-Host "Thinking..."
    Start-Sleep -Seconds 2
    Write-Host "Magic 8-Ball says: " -NoNewline
    Write-Host ($answers | Get-Random) -ForegroundColor Cyan

    Write-Host "`nPress Enter to ask another question or Esc to exit."
    $keyPress = Get-KeyPress
    if ($keyPress -eq 'Escape') { exit }  # Properly closes the window
} while ($true)


