﻿# Blackjack in PowerShell (6-Deck Version with Double, Insurance, Surrender)

# Initialize 6 Decks
$deck = @()
$suits = @("Hearts", "Diamonds", "Clubs", "Spades")
$ranks = @("2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A")

function Initialize-Deck {
    $global:deck = @()
    for ($i = 0; $i -lt 6; $i++) {
        foreach ($suit in $suits) {
            foreach ($rank in $ranks) {
                $global:deck += @{Rank = $rank; Suit = $suit}
            }
        }
    }
    $global:deck = $deck | Sort-Object {Get-Random}
}

Initialize-Deck

function Get-CardValue($card) {
    if ($card.Rank -match "^[JQK]$") { return 10 }
    elseif ($card.Rank -eq "A") { return 11 }
    else { return [int]$card.Rank }
}

function Deal-Card {
    if ($deck.Count -lt 15) {
        Write-Host "`nShuffling Deck..."
        Start-Sleep -Seconds 1
        Initialize-Deck
    }
    $card = $deck[0]
    $script:deck = $deck[1..($deck.Count - 1)]
    return $card
}

function Get-HandValue($hand) {
    $total = 0
    $aces = 0
    foreach ($card in $hand) {
        $value = Get-CardValue $card
        if ($value -eq 11) { $aces++ }
        $total += $value
    }
    while ($total -gt 21 -and $aces -gt 0) {
        $total -= 10
        $aces--
    }
    return $total
}

function Show-Hand($label, $hand, $hideFirst = $false) {
    $cards = ""
    $total = Get-HandValue $hand

    if ($hideFirst) {
        $cards = "? "
        for ($i = 1; $i -lt $hand.Count; $i++) {
            $cards += "$($hand[$i].Rank) "
        }
        $total = Get-HandValue @($hand[1])
    } else {
        $cards = ($hand | ForEach-Object { $_.Rank }) -join " "
    }

    Write-Host "$label's Hand: $cards = $total"
}

function Restart-Game {
    $global:money = 100
    $global:bet = 0
    Initialize-Deck
}

$money = 100
$bet = 0

function Show-Menu {
    Clear-Host
    Write-Host "=== BLACKJACK (6-Deck) ===`n"
    Write-Host "Press 1 to Bet | Press Enter to Deal | Press Esc to Exit`n"
    Write-Host "Your Balance: `$ $money"
    Write-Host "Current Bet: `$ $bet`n"
}

while ($true) {
    if ($money -lt 5 -and $bet -eq 0) {
        Write-Host "`nGAME OVER"
        $choice = Read-Host "Play Again? (y or n)"
        if ($choice -eq "y") {
            Restart-Game
        } else {
            exit
        }
    }

    while ($true) {
        Show-Menu
        $key = $host.ui.RawUI.ReadKey("NoEcho,IncludeKeyDown").VirtualKeyCode
        if ($key -eq 49) {
            if ($money -ge 5) {
                $bet += 5
                $money -= 5
            } else {
                Write-Host "Not enough balance to increase bet."
                Start-Sleep -Seconds 2
            }
        } elseif ($key -eq 13) {
            if ($bet -eq 0) {
                Write-Host "You must press 1 to place a bet."
                Start-Sleep -Seconds 2
            } else {
                break
            }
        } elseif ($key -eq 27) {
            exit
        }
    }

    $playerHand = @()
    $dealerHand = @()
    $playerHand += $(Deal-Card)
    $playerHand += $(Deal-Card)
    $dealerHand += $(Deal-Card)
    $dealerHand += $(Deal-Card)
    $surrendered = $false
    $insuranceBet = 0

    Show-Menu
    Show-Hand "Player" $playerHand
    Show-Hand "Dealer" $dealerHand $true

    # Insurance Offer
    if ($dealerHand[1].Rank -eq "A") {
        Write-Host "`nDealer shows an Ace. Do you want Insurance? (Y/N)"
        $insurance = Read-Host "Your Choice"
        if ($insurance -eq "Y" -and $money -ge ($bet / 2)) {
            $insuranceBet = [math]::Floor($bet / 2)
            $money -= $insuranceBet
        }
    }

    # Immediate Blackjack Check
    $playerTotal = Get-HandValue $playerHand
    $dealerTotal = Get-HandValue $dealerHand
    $playerHasBlackjack = ($playerTotal -eq 21 -and $playerHand.Count -eq 2)
    $dealerHasBlackjack = ($dealerTotal -eq 21 -and $dealerHand.Count -eq 2)

    if ($playerHasBlackjack -or $dealerHasBlackjack) {
        Show-Menu
        Show-Hand "Player" $playerHand
        Show-Hand "Dealer" $dealerHand
        if ($dealerHasBlackjack -and $insuranceBet -gt 0) {
            $money += $insuranceBet * 3
            Write-Host "`nInsurance pays 2:1"
        }
        if ($playerHasBlackjack -and -not $dealerHasBlackjack) {
            Write-Host "`nBLACKJACK! You Win!"
            $money += [math]::Round($bet * 2.5)
        } elseif ($dealerHasBlackjack -and -not $playerHasBlackjack) {
            Write-Host "`nDealer has Blackjack! You lose."
        } else {
            Write-Host "`nIt's a Tie!"
            $money += $bet
        }
        $bet = 0
        Write-Host "`nPress Enter to continue..."
        Read-Host | Out-Null
        continue
    }

    # Player Turn
    while ((Get-HandValue $playerHand) -lt 21) {
        Show-Menu
        Show-Hand "Player" $playerHand
        Show-Hand "Dealer" $dealerHand $true
        Write-Host "`n(H)it, (S)tand, (D)ouble Down, S(u)rrender"
        $choice = Read-Host "Your Choice"

        if ($choice -eq "H") {
            $playerHand += Deal-Card
        } elseif ($choice -eq "S") {
            break
        } elseif ($choice -eq "D" -and $money -ge $bet -and $playerHand.Count -eq 2) {
            $money -= $bet
            $bet *= 2
            $playerHand += Deal-Card
            break
        } elseif ($choice -eq "U") {
            $money += [math]::Floor($bet / 2)
            $surrendered = $true
            break
        } else {
            Write-Host "`nInvalid choice. Try again."
        }
    }

    # Dealer Turn
    if (-not $surrendered -and (Get-HandValue $playerHand) -le 21) {
        $dealerTotal = Get-HandValue $dealerHand
        while ($dealerTotal -lt 17) {
            $dealerHand += Deal-Card
            $dealerTotal = Get-HandValue $dealerHand
        }
    }

    # Show Final Hands
    Show-Menu
    Show-Hand "Player" $playerHand
    Show-Hand "Dealer" $dealerHand

    $playerTotal = Get-HandValue $playerHand
    $dealerTotal = Get-HandValue $dealerHand

    Write-Host "`nGame Result:"
    if ($surrendered) {
        Write-Host "You surrendered. Half your bet is returned."
    } elseif ($playerTotal -gt 21) {
        Write-Host "You Busted! Dealer Wins!"
    } elseif ($dealerTotal -gt 21) {
        Write-Host "Dealer Busted! You Win!"
        $money += $bet * 2
    } elseif ($playerTotal -gt $dealerTotal) {
        Write-Host "You Win!"
        $money += $bet * 2
    } elseif ($playerTotal -eq $dealerTotal) {
        Write-Host "It's a Tie!"
        $money += $bet
    } else {
        Write-Host "Dealer Wins!"
    }

    $bet = 0
    Write-Host "`nPress Enter to continue..."
    Read-Host | Out-Null
}
