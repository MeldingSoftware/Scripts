﻿#Requires -Version 5.1
Using Assembly PresentationCore
Using Assembly PresentationFramework
Using Namespace System.Collections.Generic
Using Namespace System.ComponentModel
Using Namespace System.Linq
Using Namespace System.Reflection
Using Namespace System.Text
Using Namespace System.Windows
Using Namespace System.Windows.Input
Using Namespace System.Windows.Markup
Using Namespace System.Windows.Media
Using Namespace System.Windows.Threading
Using Namespace System.Media

Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);'
[void][Console.Window]::ShowWindow([Console.Window]::GetConsoleWindow(), 0)  # Hide console

Set-StrictMode -Version Latest

[Int32] $boardWidth = 20
[Int32] $boardHeight = 15
[Int32] $fieldSizePixels = 30
[Int32] $stepsMilliseconds = 75
[Int32] $minStepsMilliseconds = 30

$collisionSound = [SystemSounds]::Hand

class ViewModel : INotifyPropertyChanged {
    hidden [PropertyChangedEventHandler] $PropertyChanged
    [int] $BoardWidthPixels
    [int] $BoardHeightPixels
    [int] $FieldDisplaySizePixels
    [int] $HalfFieldDisplaySizePixels
    [int] $Score
    [object] $SnakeGeometry
    [object] $FoodCenter
    [bool] $GameOverVisible
    [bool] $WonVisible

    [void] add_PropertyChanged([PropertyChangedEventHandler] $handler) {
        $this.PropertyChanged = [Delegate]::Combine($this.PropertyChanged, $handler)
    }
    [void] remove_PropertyChanged([PropertyChangedEventHandler] $handler) {
        $this.PropertyChanged = [Delegate]::Remove($this.PropertyChanged, $handler)
    }
    hidden [void] NotifyPropertyChanged([string] $prop) {
        if ($this.PropertyChanged) {
            $this.PropertyChanged.Invoke($this, [PropertyChangedEventArgs]::new($prop))
        }
    }
    [void] SetScore([int] $val) {
        if ($this.Score -ne $val) {
            $this.Score = $val
            $this.NotifyPropertyChanged('Score')
        }
    }
    [void] SetSnakeGeometry([object] $val) {
        if ($this.SnakeGeometry -ne $val) {
            $this.SnakeGeometry = $val
            $this.NotifyPropertyChanged('SnakeGeometry')
        }
    }
    [void] SetFoodCenter([object] $val) {
        if ($this.FoodCenter -ne $val) {
            $this.FoodCenter = $val
            $this.NotifyPropertyChanged('FoodCenter')
        }
    }
    [void] SetGameOverVisible([bool] $val) {
        if ($this.GameOverVisible -ne $val) {
            $this.GameOverVisible = $val
            $this.NotifyPropertyChanged('GameOverVisible')
        }
    }
    [void] SetWonVisible([bool] $val) {
        if ($this.WonVisible -ne $val) {
            $this.WonVisible = $val
            $this.NotifyPropertyChanged('WonVisible')
        }
    }
}

enum SnakeDirection { Left; Right; Up; Down }
enum SnakeAction { Nothing; Collision; FoodEaten }

class SnakeSegment {
    [int] $Length
    [SnakeDirection] $Direction
    SnakeSegment([int] $length, [SnakeDirection] $direction) {
        $this.Length = $length
        $this.Direction = $direction
    }
    [string] GetGeometryOperation([int] $size) {
        $d = @('h','v')[$this.Direction -gt [SnakeDirection]::Right]
        $f = $this.Direction % 2 * 2 - 1
        return "$d $($this.Length * $size * $f)"
    }
}

class Snake {
    hidden [int] $BoardWidth
    hidden [int] $BoardHeight
    hidden [int] $FieldSizePixels
    [int] $HeadX
    [int] $HeadY
    [int] $TailX
    [int] $TailY
    [List[SnakeSegment]] $Segments
    [SnakeDirection] $Direction

    Snake([int] $bw, [int] $bh, [int] $fs) {
        $this.BoardWidth = $bw
        $this.BoardHeight = $bh
        $this.FieldSizePixels = $fs
        $this.Reset()
    }

    [void] Reset() {
        $this.TailX = [int]($this.BoardWidth / 2 - 2)
        $this.TailY = [int]($this.BoardHeight / 2)
        $this.HeadX = $this.TailX + 4
        $this.HeadY = $this.TailY
        $this.Segments = [List[SnakeSegment]]::new()
        $this.Segments.Add([SnakeSegment]::new(4, [SnakeDirection]::Right))
        $this.Direction = [SnakeDirection]::Right
    }

    [string] GetGeometryString() {
        $sb = [Text.StringBuilder]::new()
        $sb.Append("m $($this.TailX * $this.FieldSizePixels + $this.FieldSizePixels / 2) $($this.TailY * $this.FieldSizePixels + $this.FieldSizePixels / 2)")
        foreach ($seg in $this.Segments) {
            $sb.Append($seg.GetGeometryOperation($this.FieldSizePixels))
        }
        return $sb.ToString()
    }

    [HashSet[Tuple[int,int]]] GetPoints() {
        $pts = [HashSet[Tuple[int,int]]]::new()
        $x = $this.TailX
        $y = $this.TailY
        $pts.Add([Tuple]::Create($x, $y))
        foreach ($seg in $this.Segments) {
            1..$seg.Length | ForEach-Object {
                switch ($seg.Direction) {
                    'Left' { $x-- } 'Right' { $x++ } 'Up' { $y-- } 'Down' { $y++ }
                }
                $pts.Add([Tuple]::Create($x, $y))
            }
        }
        return $pts
    }

    [SnakeAction] Move([Food] $food) {
        $prevX = $this.HeadX
        $prevY = $this.HeadY
        switch ($this.Direction) {
            'Left' { $this.HeadX-- } 'Right' { $this.HeadX++ } 'Up' { $this.HeadY-- } 'Down' { $this.HeadY++ }
        }
        if ($this.HeadX -lt 0 -or $this.HeadX -ge $this.BoardWidth -or $this.HeadY -lt 0 -or $this.HeadY -ge $this.BoardHeight) {
            $this.HeadX = $prevX; $this.HeadY = $prevY; return [SnakeAction]::Collision
        }
        if ($this.GetPoints().Contains([Tuple]::Create($this.HeadX, $this.HeadY))) {
            $this.HeadX = $prevX; $this.HeadY = $prevY; return [SnakeAction]::Collision
        }
        $result = if ($this.HeadX -eq $food.FoodX -and $this.HeadY -eq $food.FoodY) {[SnakeAction]::FoodEaten} else {[SnakeAction]::Nothing}
        $headSeg = $this.Segments[-1]
        if ($headSeg.Direction -eq $this.Direction) { $headSeg.Length++ } else { $this.Segments.Add([SnakeSegment]::new(1, $this.Direction)) }
        if ($result -ne [SnakeAction]::FoodEaten) {
            $tailSeg = $this.Segments[0]; $tailSeg.Length--
            switch ($tailSeg.Direction) {
                'Left' { $this.TailX-- } 'Right' { $this.TailX++ } 'Up' { $this.TailY-- } 'Down' { $this.TailY++ }
            }
            if ($tailSeg.Length -eq 0) { $this.Segments.RemoveAt(0) }
        }
        return $result
    }
}

class Food {
    hidden [int] $FieldSizePixels
    hidden [Random] $Random
    hidden [HashSet[Tuple[int,int]]] $AllValidPoints
    [int] $FoodX
    [int] $FoodY

    Food([int] $w, [int] $h, [int] $p) {
        $this.FieldSizePixels = $p
        $this.Random = [Random]::new()
        $this.AllValidPoints = [HashSet[Tuple[int,int]]]::new()
        for ($x = 0; $x -lt $w; $x++) {
            for ($y = 0; $y -lt $h; $y++) {
                $this.AllValidPoints.Add([Tuple]::Create($x, $y))
            }
        }
    }

    [Tuple[int,int]] GetGeometryLocation() {
        return [Tuple]::Create($this.FoodX * $this.FieldSizePixels + $this.FieldSizePixels / 2,
                               $this.FoodY * $this.FieldSizePixels + $this.FieldSizePixels / 2)
    }

    [bool] Move([Snake] $snake) {
        $free = [HashSet[Tuple[int,int]]]::new($this.AllValidPoints)
        $free.ExceptWith($snake.GetPoints())
        if ($free.Count -eq 0) { return $true }
        $pos = [Linq.Enumerable]::ElementAt($free, $this.Random.Next($free.Count))
        $this.FoodX = $pos.Item1; $this.FoodY = $pos.Item2
        return $false
    }
}

$viewModel = [ViewModel]::new()
$viewModel.BoardWidthPixels = $boardWidth * $fieldSizePixels
$viewModel.BoardHeightPixels = $boardHeight * $fieldSizePixels
$viewModel.FieldDisplaySizePixels = $fieldSizePixels - 2
$viewModel.HalfFieldDisplaySizePixels = ($fieldSizePixels - 2) / 2

$snake = [Snake]::new($boardWidth, $boardHeight, $fieldSizePixels)
$food = [Food]::new($boardWidth, $boardHeight, $fieldSizePixels)
$food.Move($snake) | Out-Null

$timer = [DispatcherTimer]::new()
$timer.Interval = [TimeSpan]::FromMilliseconds($stepsMilliseconds)
$timer.Tag = [SnakeAction]::Nothing

function Update-View {
    $viewModel.SetSnakeGeometry([Geometry]::Parse((
        "m " + ($snake.TailX * $fieldSizePixels + $fieldSizePixels / 2) + " " + ($snake.TailY * $fieldSizePixels + $fieldSizePixels / 2) +
        ($snake.Segments | ForEach-Object { $_.GetGeometryOperation($fieldSizePixels) }) -join ''
    )))
    $loc = $food.GetGeometryLocation()
    $viewModel.SetFoodCenter([Point]::new($loc.Item1, $loc.Item2))
}

$timer.add_Tick({
    $action = $snake.Move($food)
    switch ($action) {
        'Collision' {
            if ($timer.Tag -ceq 'Collision') {
                $collisionSound.Play()
                $viewModel.SetGameOverVisible($true)
                $timer.Stop()
            }
        }
        'FoodEaten' {
            $viewModel.SetScore($viewModel.Score + 1)
            $stepsMilliseconds = [Math]::Max($minStepsMilliseconds, $stepsMilliseconds - 2)
            $timer.Interval = [TimeSpan]::FromMilliseconds($stepsMilliseconds)
            if ($food.Move($snake)) {
                $viewModel.SetWonVisible($true)
                $timer.Stop()
            }
        }
    }
    Update-View
    $timer.Tag = $action
})

[Window] $mainWindow = [XamlReader]::Parse(@"
<Window xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
        Title='{Binding Score, StringFormat={}Snake - {0}}'
        SizeToContent='WidthAndHeight'
        ResizeMode='NoResize'>
    <Window.Resources>
        <BooleanToVisibilityConverter x:Key='VisibilityConverter' />
    </Window.Resources>
    <Grid Margin='5'>
        <Grid.RowDefinitions>
            <RowDefinition Height='Auto' />
            <RowDefinition Height='*' />
        </Grid.RowDefinitions>
        <DockPanel Grid.Row='0' LastChildFill='True' Margin='0 0 0 5'>
            <TextBlock DockPanel.Dock='Left' Text='{Binding Score, StringFormat={}Score: {0}}' Margin='0 0 5 0'/>
            <TextBlock DockPanel.Dock='Left' Text='GAME OVER' FontWeight='Bold' Visibility='{Binding GameOverVisible, Converter={StaticResource VisibilityConverter}}'/>
            <TextBlock DockPanel.Dock='Left' Text='YOU WON' FontWeight='Bold' Foreground='DarkGreen' Visibility='{Binding WonVisible, Converter={StaticResource VisibilityConverter}}'/>
            <TextBlock Text='Use arrow keys to move, Enter to restart, Esc to quit.' TextAlignment='Right'/>
        </DockPanel>
        <Border Grid.Row='1' BorderBrush='Black' BorderThickness='1'>
            <Canvas Width='{Binding BoardWidthPixels}' Height='{Binding BoardHeightPixels}'>
                <Path StrokeThickness='{Binding FieldDisplaySizePixels}' StrokeStartLineCap='Round' StrokeEndLineCap='Round' StrokeLineJoin='Round' Data='{Binding SnakeGeometry}'>
                    <Path.Stroke>
                        <LinearGradientBrush StartPoint='0,0' EndPoint='1,0'>
                            <GradientStop Color='Green' Offset='0'/>
                            <GradientStop Color='Blue' Offset='1'/>
                        </LinearGradientBrush>
                    </Path.Stroke>
                </Path>
                <Path Fill='DarkRed'>
                    <Path.Data>
                        <EllipseGeometry Center='{Binding FoodCenter}' RadiusX='{Binding HalfFieldDisplaySizePixels}' RadiusY='{Binding HalfFieldDisplaySizePixels}'/>
                    </Path.Data>
                </Path>
            </Canvas>
        </Border>
    </Grid>
</Window>
"@)

$mainWindow.DataContext = $viewModel

$mainWindow.add_Loaded({
    Update-View
    $mainWindow.WindowStartupLocation = 'CenterScreen'
    $timer.Start()
})

[EventManager]::RegisterClassHandler([Window], [Keyboard]::KeyDownEvent, [KeyEventHandler] {
    param($sender, $e)
    switch ($e.Key) {
        'Left'  { if ($snake.Segments[-1].Direction -ne 'Right') { $snake.Direction = 'Left' } }
        'Right' { if ($snake.Segments[-1].Direction -ne 'Left')  { $snake.Direction = 'Right' } }
        'Up'    { if ($snake.Segments[-1].Direction -ne 'Down')  { $snake.Direction = 'Up' } }
        'Down'  { if ($snake.Segments[-1].Direction -ne 'Up')    { $snake.Direction = 'Down' } }
        'Return' {
            $snake.Reset()
            $food.Move($snake)
            $viewModel.SetScore(0)
            $viewModel.SetGameOverVisible($false)
            $viewModel.SetWonVisible($false)
            $stepsMilliseconds = 75
            $timer.Interval = [TimeSpan]::FromMilliseconds($stepsMilliseconds)
            Update-View
            $timer.Start()
        }
        'Escape' { $mainWindow.Close() }
    }
})

[Application]::new().Run($mainWindow) | Out-Null
$timer.Stop()
