﻿function Restart-Script {
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -WindowStyle Normal
    exit
}

$symbols = @("Cherry", "Lemon", "Bell", "Diamond", "Jackpot", "Star", "Seven")
$symbolPayouts = @{
    "Lemon"    = 40
    "Cherry"   = 50
    "Bell"     = 60
    "Seven"    = 70
    "Diamond"  = 80
    "Star"     = 90
    "Jackpot"  = 500
}

$accountBalance = 100  # Total money available to the user
$slotBalance = 0       # Money available for playing
$spinCost = 10
$transferAmount = 10   # Amount to transfer from account to slot machine per press

function Get-KeyPress {
    return [System.Console]::ReadKey($true).Key
}

Clear-Host

do {
    # Clear screen and display menu
    Clear-Host
    Write-Host "=== SLOT MACHINE ==="
    Write-Host ""
    Write-Host "Press 1 to enter `$10 into slots | Each spin is `$10 | Press Enter to spin | Press Esc to exit"
    Write-Host "Your Balance: $($accountBalance)"
    Write-Host "Slot Machine: $($slotBalance)"
    Write-Host ""

    # Wait for user action
    $keyPress = Get-KeyPress

    if ($keyPress -eq 'Escape') { exit }

    if ($keyPress -eq 'D1') {  # PowerShell reads "1" as "D1"
        if ($accountBalance -ge $transferAmount) {
            $accountBalance -= $transferAmount
            $slotBalance += $transferAmount
        } else {
            Write-Host "`nNot enough money in your balance!"
            Start-Sleep -Seconds 2
        }
        Continue
    }

    if ($keyPress -eq 'Enter') {
        if ($slotBalance -lt $spinCost) {
            Write-Host "`nNot enough money in the slot machine! Press 1 to add funds."
            if ($accountBalance -lt $transferAmount) {
                Write-Host "`nYou're out of money! GAME OVER."
                exit
            }
            Start-Sleep -Seconds 2
            Continue
        }

        # Deduct spin cost BEFORE displaying "Spinning..."
        $slotBalance -= $spinCost
        Clear-Host
        Write-Host "=== SLOT MACHINE ==="
        Write-Host ""
        Write-Host "Press 1 to enter `$10 into slots | Each spin is `$10 | Press Enter to spin | Press Esc to exit"
        Write-Host "Your Balance: $($accountBalance)"
        Write-Host "Slot Machine: $($slotBalance)"
        Write-Host ""
        Write-Host "`nSpinning..."
        Start-Sleep -Seconds 2

        # Generate slot results
        $slot1 = $symbols | Get-Random
        $slot2 = $symbols | Get-Random
        $slot3 = $symbols | Get-Random

        # Display spin results
        Write-Host "`n$slot1 | $slot2 | $slot3`n"

        # Determine win condition and payout
        $winnings = 0
        if ($slot1 -eq $slot2 -and $slot2 -eq $slot3) {
            # Three of a kind wins based on symbol value
            $winnings = $symbolPayouts[$slot1]
            Write-Host "$slot1 x3! You win `$$winnings!" -ForegroundColor Yellow
            $accountBalance += $winnings  # All three-of-a-kind winnings now go to account balance
        } elseif ($slot1 -eq $slot2 -or $slot2 -eq $slot3 -or $slot1 -eq $slot3) {
            $winnings = 20  # Two matches payout remains $20
            Write-Host "Two matches! You win `$20!"
            $slotBalance += $winnings
        } else {
            Write-Host "Better luck next time!"
        }

        # Check if game is over (No balance left, No money in slot, and No win)
        if ($accountBalance -eq 0 -and $slotBalance -eq 0 -and $winnings -eq 0) {
            Write-Host "`nGAME OVER"
            Write-Host "Play Again? (y or n)"

            do {
                $playAgain = Read-Host
                if ($playAgain -eq 'y') {
                    Restart-Script  # Restart the game from the beginning
                } elseif ($playAgain -eq 'n') {
                    exit  # Exit the game
                }
            } until ($playAgain -eq 'y' -or $playAgain -eq 'n')
        }

        # Show "Press Enter" at the bottom
        Write-Host "`nPress Enter"

        # Now only allow Enter (to spin again) or Esc (to exit)
        do {
            $keyPress = Get-KeyPress
        } until ($keyPress -eq 'Enter' -or $keyPress -eq 'Escape')

        if ($keyPress -eq 'Escape') { exit }
    }

} while ($true)
