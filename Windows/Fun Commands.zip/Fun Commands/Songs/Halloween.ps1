function Halloween {
for($i=0;$i -le 15; $i++) {
if ($i%8 -in (6,7)) {
	$note1=1046
	$note2=699
	$note3=1109
} else {
	$note1=1109
	$note2=740
	$note3=1175
}
[System.Console]::Beep($note1,250);
[System.Console]::Beep($note2,250);
[System.Console]::Beep($note2,250);
[System.Console]::Beep($note1,250);
[System.Console]::Beep($note2,250);
[System.Console]::Beep($note2,250);
[System.Console]::Beep($note1,250);
[System.Console]::Beep($note2,250);
[System.Console]::Beep($note3,250);
[System.Console]::Beep($note2,250);
}
}
Halloween