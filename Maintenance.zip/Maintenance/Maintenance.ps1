# 1. Create Maintenance Directory
$desktopPath = ""

if (Test-Path "$env:userprofile\Desktop") {
    $desktopPath = "$env:userprofile\Desktop\Maintenance Results"
    if (!(Test-Path $desktopPath)) {
        New-Item $desktopPath -ItemType Directory
    }
}
else {
    $desktopPath = "$env:userprofile\OneDrive\Desktop\Maintenance Results"
    if (!(Test-Path $desktopPath)) {
        New-Item $desktopPath -ItemType Directory
    }
}

# 2. Disable Sleep
$schemeGuid = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67' 
$schemeName = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'
function assert-ok { if ($LASTEXITCODE -ne 0) { throw } }
$prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
assert-ok
try {
	powercfg -setactive $schemeGuid 2>$null
	if ($LASTEXITCODE -ne 0) { 
    	$null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
    	assert-ok
    	$null = powercfg -changename $schemeGuid $schemeName $schemeDescr
    	$null = powercfg -setactive $schemeGuid
    	assert-ok
    	$settings = 'monitor-timeout-ac', 'monitor-timeout-dc', 'disk-timeout-ac', 'disk-timeout-dc', 'standby-timeout-ac', 'standby-timeout-dc', 'hibernate-timeout-ac', 'hibernate-timeout-dc'
    	foreach ($setting in $settings) {
      	powercfg -change $setting 0 # 0 == Never
      	assert-ok
    }
  }

# 3. Optimize Startup (Manually)
Write-Host "Optimize startup (manually)" -ForegroundColor Cyan 
taskmgr
Write-Host "[DONE] Optimize startup (manually) completed"`n -ForegroundColor Green 

# 4. BatteryInfoView
Write-Host "Running BatteryInfoView" -ForegroundColor Cyan 
$urlBattery = "https://www.nirsoft.net/utils/batteryinfoview.zip"
$destBattery = "$env:TEMP\batteryinfoview.zip"
Invoke-WebRequest -Uri $urlBattery -OutFile $destBattery -Verbose
Expand-Archive $destBattery -DestinationPath "$env:TEMP\BatteryInfoView" -Force
Start-Process "$env:TEMP\BatteryInfoView\BatteryInfoView.exe" -Verb RunAs -Verbose
Write-Host "[DONE] BatteryInfoView completed"`n -ForegroundColor Green 

# 5. Chkdsk On Next Boot
Write-Host "chkdsk on next boot" -ForegroundColor Cyan 
Write-Output 'Y' | chkdsk C: /x /f /r
Write-Host "[DONE] chkdsk on next boot completed"`n -ForegroundColor Green 

# 6. DISM And SFC
Start-Transcript $desktopPath\DISM_SFC.txt
Write-Host ""
Write-Host "DISM and SFC"`n -ForegroundColor Cyan 
Write-Host "Analyze Component Store"`n
Write-Output 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Start Component Cleanup"`n
dism.exe /online /cleanup-image /startcomponentcleanup
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Check Health"`n
dism.exe /online /cleanup-image /checkhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Scan Health"`n
dism.exe /online /cleanup-image /scanhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Restore Health"`n
dism.exe /online /cleanup-image /restorehealth
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "SFC"`n
sfc /scannow
Write-Host ""
Write-Host "[DONE] DISM and SFC completed"`n -ForegroundColor Green 
Stop-Transcript
Write-Host ""

# Stop BatteryInfoView Process
Stop-Process -Name "BatteryInfoView" -Force -ErrorAction SilentlyContinue

# 7. Clear Recent Items
Write-Host "Clear recent items" -ForegroundColor Cyan 
Get-ChildItem $env:appdata\Microsoft\Windows\Recent\* -Recurse | Remove-Item -Force -Recurse
Write-Host "[DONE] Clear recent items completed"`n -ForegroundColor Green 

# 8. Delete Users Temp Files
Write-Host "Deleting User Temp files" -ForegroundColor Cyan 
Remove-Item -Path "C:\Users\*\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Delete users temp files completed"`n -ForegroundColor Green 

# 9. Delete Windows Temp Files 
Write-Host "Deleting Windows Temp files" -ForegroundColor Cyan 
Remove-Item -Path "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Delete Windows temp files completed"`n -ForegroundColor Green 

# 10. Remove Windows.old Folder
if (Test-Path -Path "C:\Windows.old") {
	Write-Host "Deleting Windows.old folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\Windows.old" -Recurse -Force -ErrorAction SilentlyContinue
    	Write-Host "[DONE] Delete Windows temp files completed"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\Windows.old not found."`n -ForegroundColor Green 
}

# 11. Remove Config.Msi Folder
if (Test-Path -Path "C:\Config.Msi") {
	Write-Host "Deleting Config.Msi folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\Config.Msi" -Recurse -Force -ErrorAction SilentlyContinue
   	Write-Host "[DONE]"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\Config.Msi not found."`n -ForegroundColor Green 
}

# 12. Remove Intel Folder
if (Test-Path -Path "C:\Intel") {
	Write-Host "Deleting Intel folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\Intel" -Recurse -Force -ErrorAction SilentlyContinue
    	Write-Host "[DONE]"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\Intel not found."`n -ForegroundColor Green 
}

# 13. Remove PerfLogs Folder
if (Test-Path -Path "C:\PerfLogs") {
	Write-Host "Deleting PerfLogs folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\PerfLogs" -Recurse -Force -ErrorAction SilentlyContinue
    	Write-Host "[DONE]"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\PerfLogs not found."`n -ForegroundColor Green 
}

# 14. Disk Cleanup
Write-Host "Disk Cleanup" -ForegroundColor Cyan 
cleanmgr /sagerun:1 | Out-Null
Start-Sleep 2
Write-Host "[DONE] Disk Cleanup completed"`n -ForegroundColor Green 

# 15. Empty Recycle Bin
Write-Host "Empty Recycle Bin" -ForegroundColor Cyan 
Clear-RecycleBin -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Empty Recycle Bin completed"`n -ForegroundColor Green 

# 16. Windows Updates
Write-Host "Windows updates" -ForegroundColor Cyan 
Install-PackageProvider -Name NuGet -Force
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module -Name PSWindowsUpdate -Force
Import-Module PSWindowsUpdate
Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade' | Out-File "$desktopPath\WindowsUpdates.txt"
Write-Host "[DONE]"`n -ForegroundColor Green 

# 17. App Updates
Start-Transcript $desktopPath\AppUpdates.txt
Write-Host "App updates" -ForegroundColor Cyan 
Write-Output 'Y' | winget upgrade -h --all --include-unknown
Write-Host "[DONE]"`n -ForegroundColor Green 
Stop-Transcript

# 18. Optimize Drives
Write-Host "Optimize drives" -ForegroundColor Cyan 
$Volumes = Get-Volume | Where-Object { $_.DriveType -ne 'Removable' -and $_.DriveLetter }
foreach ($Volume in $Volumes) {
    Write-Host "Optimizing $($Volume.DriveLetter)..." -ForegroundColor Cyan 
    Optimize-Volume -DriveLetter $Volume.DriveLetter 
    Write-Host "[DONE] $($Volume.DriveLetter) Optimized"`n -ForegroundColor Green 
}
Write-Host "[DONE] Optimize drives completed"`n -ForegroundColor Green 

# 19. Re-Enable Sleep Settings
} finally { 
  powercfg -setactive $prevGuid
}

# 20. Restart
Shutdown /r /t 0