# Create Maintenance Results On Desktop
$desktopPath = [Environment]::GetFolderPath("Desktop") + "\Maintenance Results"

if (!(Test-Path $desktopPath)) {
    New-Item $desktopPath -ItemType Directory
}

# Disable Sleep
$schemeGuid = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67' 
$schemeName = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'
function assert-ok { if ($LASTEXITCODE -ne 0) { throw } }
$prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
assert-ok
try {
	powercfg -setactive $schemeGuid 2>$null
	if ($LASTEXITCODE -ne 0) { 
    	$null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
    	assert-ok
    	$null = powercfg -changename $schemeGuid $schemeName $schemeDescr
    	$null = powercfg -setactive $schemeGuid
    	assert-ok
    	$settings = 'monitor-timeout-ac', 'monitor-timeout-dc', 'disk-timeout-ac', 'disk-timeout-dc', 'standby-timeout-ac', 'standby-timeout-dc', 'hibernate-timeout-ac', 'hibernate-timeout-dc'
    	foreach ($setting in $settings) {
      	powercfg -change $setting 0 # 0 == Never
      	assert-ok
    }
  }

# Create a Restore Point
try {
	Write-Host "Create a Restore Point" -ForegroundColor Cyan 
    Checkpoint-Computer -Description "Maintenance" -RestorePointType "MODIFY_SETTINGS"
    Write-Host "[DONE] Create a Restore Point completed"`n -ForegroundColor Green
} catch {
    Write-Error "An error occurred: $_"`n -ForegroundColor Red
}

# Optimize Startup (Manually)
Write-Host "Optimize startup (manually)" -ForegroundColor Cyan 
taskmgr
Write-Host "Click on the Startup tab and manually disable any unecessary startup programs". 
Write-Host "[DONE] Optimize startup (manually) completed"`n -ForegroundColor Green 

# Chkdsk On Next Boot
Write-Host "chkdsk on next boot" -ForegroundColor Cyan 
Write-Output 'Y' | chkdsk C: /x /f /r
Write-Host "[DONE] chkdsk on next boot completed"`n -ForegroundColor Green 

# DISM And SFC
Start-Transcript $desktopPath\DISM_SFC.txt
Write-Host ""
Write-Host "DISM and SFC"`n -ForegroundColor Cyan 
Write-Host "Analyze Component Store"`n
Write-Output 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Start Component Cleanup"`n
dism.exe /online /cleanup-image /startcomponentcleanup
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Check Health"`n
dism.exe /online /cleanup-image /checkhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Scan Health"`n
dism.exe /online /cleanup-image /scanhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Restore Health"`n
dism.exe /online /cleanup-image /restorehealth
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "SFC"`n
sfc /scannow
Write-Host ""
Write-Host "[DONE] DISM and SFC completed"`n -ForegroundColor Green 
Stop-Transcript
Write-Host ""

# Delete Temp Files
Start-Transcript $desktopPath\Temp_Files.txt
Write-Host "Deleting Temp files" -ForegroundColor Cyan

# Get all user profiles from C:\Users (skip system users like Default and Public)
$userProfiles = Get-ChildItem -Path "C:\Users" | Where-Object { $_.Name -notin @("Default", "Public", "All Users") }

# Loop through each user profile
foreach ($userProfile in $userProfiles) {
    $userPath = "C:\Users\$($userProfile.Name)"

    # Clear Recent Items
    Remove-Item -Path "$userPath\AppData\Roaming\Microsoft\Windows\Recent\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Recent Items for user $($userProfile.Name)" -ForegroundColor Yellow

    # Delete User's Temp Files
    Remove-Item -Path "$userPath\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Temp files for user $($userProfile.Name)" -ForegroundColor Yellow

    # Delete User's INetCache (Internet Explorer cache)
    Remove-Item -Path "$userPath\AppData\Local\Microsoft\Windows\INetCache\IE\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted INetCache IE for user $($userProfile.Name)" -ForegroundColor Yellow

    # Delete User's INetCookies
    Remove-Item -Path "$userPath\AppData\Local\Microsoft\Windows\INetCookies\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted INetCookies for user $($userProfile.Name)" -ForegroundColor Yellow

    # Delete User's Temporary Internet Files
    Remove-Item -Path "$userPath\AppData\Local\Microsoft\Windows\Temporary Internet Files\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Temporary Internet Files for user $($userProfile.Name)" -ForegroundColor Yellow

    # Delete User's History
    Remove-Item -Path "$userPath\AppData\Local\Microsoft\Windows\History\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted History for user $($userProfile.Name)" -ForegroundColor Yellow

    # Delete Office WebServiceCache for User
    Remove-Item -Path "$userPath\AppData\Local\Microsoft\Office\16.0\WebServiceCache\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Office WebServiceCache for user $($userProfile.Name)" -ForegroundColor Yellow
}

# Additional System-Wide Folders to Delete

# Delete Windows Temp Files
Remove-Item -Path "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Deleted Windows Temp files" -ForegroundColor Yellow

# Delete SoftwareDistribution Download Folder
Remove-Item -Path "C:\Windows\SoftwareDistribution\Download" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Deleted SoftwareDistribution Download" -ForegroundColor Yellow

# Delete Windows Prefetch
Remove-Item -Path "C:\Windows\Prefetch\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Deleted Windows Prefetch" -ForegroundColor Yellow

# Delete Event Logs
Remove-Item -Path "C:\Windows\System32\winevt\Logs\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Deleted Event Logs" -ForegroundColor Yellow

# Delete DirectX Shader Cache (for all users)
Get-ChildItem "C:\Users" -Recurse -Filter "DirectX" | ForEach-Object {
    Remove-Item -Path $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted DirectX Shader Cache for user $($_.Name)" -ForegroundColor Yellow
}

# Remove Windows.old Folder if Exists
if (Test-Path -Path "C:\Windows.old") {
    Remove-Item -Path "C:\Windows.old" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Windows.old folder" -ForegroundColor Yellow
} else {
    Write-Host "No worries. C:\Windows.old not found." -ForegroundColor Yellow
}

# Remove Config.Msi Folder
if (Test-Path -Path "C:\Config.Msi") {
    Remove-Item -Path "C:\Config.Msi" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Config.Msi folder" -ForegroundColor Yellow
} else {
    Write-Host "No worries. C:\Config.Msi not found." -ForegroundColor Yellow
}

# Remove Intel Folder
if (Test-Path -Path "C:\Intel") {
    Remove-Item -Path "C:\Intel" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted Intel folder" -ForegroundColor Yellow
} else {
    Write-Host "No worries. C:\Intel not found." -ForegroundColor Yellow
}

# Remove PerfLogs Folder
if (Test-Path -Path "C:\PerfLogs") {
    Remove-Item -Path "C:\PerfLogs" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Deleted PerfLogs folder" -ForegroundColor Yellow
} else {
    Write-Host "No worries. C:\PerfLogs not found." -ForegroundColor Yellow
}

Write-Host "[DONE] Deleting Temp files completed"`n -ForegroundColor Green
Stop-Transcript
Write-Host ""

# Disk Cleanup
Write-Host "Disk Cleanup" -ForegroundColor Cyan 
$volumeCachesPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
$desiredCleanupCategories = @(
    "Active Setup Temp Folders",
    "Content Indexer Cleaner",
    "D3D Shader Cache",
    "Delivery Optimization Files",
    "Device Driver Packages",
    "Diagnostic Data Viewer database files",
    "Downloaded Program Files",
    "DownloadsFolder",
    "Internet Cache Files",
    "Language Pack",
    "Offline Pages Files",
    "Old ChkDsk Files",
    "Previous Installations",
    "Recycle Bin",
    "RetailDemo Offline Content",
    "Setup Log Files",
    "System error memory dump files",
    "System error minidump files",
    "Temporary Files",
    "Temporary Setup Files",
    "Temporary Sync Files",
    "Thumbnail Cache",
    "Update Cleanup",
    "Upgrade Discarded Files",
    "User file versions",
    "Windows Defender",
    "Windows Error Reporting Files",
    "Windows ESD installation files",
    "Windows Upgrade Log Files"
)
foreach ($category in $desiredCleanupCategories) {
    $categoryPath = Join-Path -Path $volumeCachesPath -ChildPath $category

    # Check if the registry path exists before trying to modify it
    if (Test-Path -Path $categoryPath) {
        try {
            # Set 'StateFlags0001' to 2, which enables the cleanup option
            Set-ItemProperty -Path $categoryPath -Name "StateFlags0001" -Value 2
            Write-Host "Enabled cleanup for: $category" -ForegroundColor Yellow
        }
        catch {
            Write-Host "Error enabling cleanup for: $category - $($_.Exception.Message)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "Path does not exist: $category" -ForegroundColor Red
    }
}
Start-Process -FilePath "cleanmgr.exe" -ArgumentList "/sagerun:1" -Wait
Write-Host "[DONE] Disk Cleanup completed"`n -ForegroundColor Green

# Windows Updates
Write-Host "Windows updates" -ForegroundColor Cyan 
Install-PackageProvider -Name NuGet -Force
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module -Name PSWindowsUpdate -Force
Import-Module PSWindowsUpdate
Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade' | Out-File "$desktopPath\WindowsUpdates.txt"
Write-Host "[DONE] Windows updates completed"`n -ForegroundColor Green 

# App Updates
Start-Transcript $desktopPath\AppUpdates.txt
Write-Host "App updates" -ForegroundColor Cyan 
Write-Output 'Y' | winget upgrade -h --all --include-unknown
Write-Host "[DONE] App updates completed"`n -ForegroundColor Green 
Stop-Transcript

# Optimize Drives
Write-Host "Optimize drives" -ForegroundColor Cyan 
$Volumes = Get-Volume | Where-Object { $_.DriveType -ne 'Removable' -and $_.DriveLetter }
foreach ($Volume in $Volumes) {
    Write-Host "Optimizing $($Volume.DriveLetter)" -ForegroundColor Cyan 
    try {
        Optimize-Volume -DriveLetter $Volume.DriveLetter -ErrorAction Stop
        Write-Host "[DONE] $($Volume.DriveLetter) Optimized"`n -ForegroundColor Green 
    } catch {
        Write-Host "[DONE] $($Volume.DriveLetter) Not Supported"`n -ForegroundColor Green 
    }
}
Write-Host "[DONE] Optimize drives completed"`n -ForegroundColor Green

# Re-Enable Sleep Settings
} finally { 
  powercfg -setactive $prevGuid
}

# Restart
Shutdown /r /t 0