# Create Maintenance Results On Desktop
$desktopPath = [Environment]::GetFolderPath("Desktop") + "\Maintenance Results"

if (!(Test-Path $desktopPath)) {
    New-Item $desktopPath -ItemType Directory
}

# Disable Sleep
$schemeGuid = 'e03c2dc5-fac9-4f5d-9948-0a2fb9009d67' 
$schemeName = 'Always on'
$schemeDescr = 'Custom power scheme to keep the system awake indefinitely.'
function assert-ok { if ($LASTEXITCODE -ne 0) { throw } }
$prevGuid = (powercfg -getactivescheme) -replace '^.+([-0-9a-f]{36}).+$', '$1'
assert-ok
try {
	powercfg -setactive $schemeGuid 2>$null
	if ($LASTEXITCODE -ne 0) { 
    	$null = powercfg -duplicatescheme SCHEME_MIN $schemeGuid
    	assert-ok
    	$null = powercfg -changename $schemeGuid $schemeName $schemeDescr
    	$null = powercfg -setactive $schemeGuid
    	assert-ok
    	$settings = 'monitor-timeout-ac', 'monitor-timeout-dc', 'disk-timeout-ac', 'disk-timeout-dc', 'standby-timeout-ac', 'standby-timeout-dc', 'hibernate-timeout-ac', 'hibernate-timeout-dc'
    	foreach ($setting in $settings) {
      	powercfg -change $setting 0 # 0 == Never
      	assert-ok
    }
  }

# Optimize Startup (Manually)
Write-Host "Optimize startup (manually)" -ForegroundColor Cyan 
taskmgr
Write-Host "[DONE] Optimize startup (manually) completed"`n -ForegroundColor Green 

# Chkdsk On Next Boot
Write-Host "chkdsk on next boot" -ForegroundColor Cyan 
Write-Output 'Y' | chkdsk C: /x /f /r
Write-Host "[DONE] chkdsk on next boot completed"`n -ForegroundColor Green 

# DISM And SFC
Start-Transcript $desktopPath\DISM_SFC.txt
Write-Host ""
Write-Host "DISM and SFC"`n -ForegroundColor Cyan 
Write-Host "Analyze Component Store"`n
Write-Output 'N' | dism.exe /online /cleanup-image /analyzecomponentstore /norestart
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Start Component Cleanup"`n
dism.exe /online /cleanup-image /startcomponentcleanup
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Check Health"`n
dism.exe /online /cleanup-image /checkhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Scan Health"`n
dism.exe /online /cleanup-image /scanhealth 
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "Restore Health"`n
dism.exe /online /cleanup-image /restorehealth
Write-Host "-----------------------------------------------------------------------------------------------------------`n"
Write-Host "SFC"`n
sfc /scannow
Write-Host ""
Write-Host "[DONE] DISM and SFC completed"`n -ForegroundColor Green 
Stop-Transcript
Write-Host ""

# Clear Recent Items
Write-Host "Clear recent items" -ForegroundColor Cyan 
Get-ChildItem $env:appdata\Microsoft\Windows\Recent\* -Recurse | Remove-Item -Force -Recurse
Write-Host "[DONE] Clear recent items completed"`n -ForegroundColor Green 

# Delete Users Temp Files
Write-Host "Deleting User Temp files" -ForegroundColor Cyan 
Remove-Item -Path "C:\Users\*\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Delete users temp files completed"`n -ForegroundColor Green 

# Delete Windows Temp Files 
Write-Host "Deleting Windows Temp files" -ForegroundColor Cyan 
Remove-Item -Path "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Delete Windows temp files completed"`n -ForegroundColor Green 

# Remove Windows.old Folder
if (Test-Path -Path "C:\Windows.old") {
	Write-Host "Deleting Windows.old folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\Windows.old" -Recurse -Force -ErrorAction SilentlyContinue
    	Write-Host "[DONE] Delete Windows temp files completed"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\Windows.old not found."`n -ForegroundColor Green 
}

# Remove Config.Msi Folder
if (Test-Path -Path "C:\Config.Msi") {
	Write-Host "Deleting Config.Msi folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\Config.Msi" -Recurse -Force -ErrorAction SilentlyContinue
   	Write-Host "[DONE]"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\Config.Msi not found."`n -ForegroundColor Green 
}

# Remove Intel Folder
if (Test-Path -Path "C:\Intel") {
	Write-Host "Deleting Intel folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\Intel" -Recurse -Force -ErrorAction SilentlyContinue
    	Write-Host "[DONE]"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\Intel not found."`n -ForegroundColor Green 
}

# Remove PerfLogs Folder
if (Test-Path -Path "C:\PerfLogs") {
	Write-Host "Deleting PerfLogs folder" -ForegroundColor Cyan 
    	Remove-Item -Path "C:\PerfLogs" -Recurse -Force -ErrorAction SilentlyContinue
    	Write-Host "[DONE]"`n -ForegroundColor Green 
} else {
    	Write-Host "[NO WORRIES] C:\PerfLogs not found."`n -ForegroundColor Green 
}

# Disk Cleanup
Write-Host "Disk Cleanup" -ForegroundColor Cyan 
cleanmgr /sagerun:1 | Out-Null
Start-Sleep 2
Write-Host "[DONE] Disk Cleanup completed"`n -ForegroundColor Green 

# Empty Recycle Bin
Write-Host "Empty Recycle Bin" -ForegroundColor Cyan 
Clear-RecycleBin -Force -ErrorAction SilentlyContinue
Write-Host "[DONE] Empty Recycle Bin completed"`n -ForegroundColor Green 

# Windows Updates
Write-Host "Windows updates" -ForegroundColor Cyan 
Install-PackageProvider -Name NuGet -Force
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module -Name PSWindowsUpdate -Force
Import-Module PSWindowsUpdate
Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -NotTitle 'Upgrade' | Out-File "$desktopPath\WindowsUpdates.txt"
Write-Host "[DONE]"`n -ForegroundColor Green 

# App Updates
Start-Transcript $desktopPath\AppUpdates.txt
Write-Host "App updates" -ForegroundColor Cyan 
Write-Output 'Y' | winget upgrade -h --all --include-unknown
Write-Host "[DONE]"`n -ForegroundColor Green 
Stop-Transcript

# Optimize Drives
Write-Host "Optimize drives" -ForegroundColor Cyan 
$Volumes = Get-Volume | Where-Object { $_.DriveType -ne 'Removable' -and $_.DriveLetter }
foreach ($Volume in $Volumes) {
    Write-Host "Optimizing $($Volume.DriveLetter)..." -ForegroundColor Cyan 
    Optimize-Volume -DriveLetter $Volume.DriveLetter 
    Write-Host "[DONE] $($Volume.DriveLetter) Optimized"`n -ForegroundColor Green 
}
Write-Host "[DONE] Optimize drives completed"`n -ForegroundColor Green 

# Re-Enable Sleep Settings
} finally { 
  powercfg -setactive $prevGuid
}

# Restart
Shutdown /r /t 0