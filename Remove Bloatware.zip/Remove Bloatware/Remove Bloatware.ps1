$AppsList = 
'Clipchamp.Clipchamp',
'Microsoft.3DBuilder',
'Microsoft.Microsoft3DViewer',
'Microsoft.Music.Preview',
'Microsoft.GamingApp',
'Microsoft.BingFinance',
'Microsoft.BingNews',
'Microsoft.BingTravel',
'Microsoft.BingSports',
'Microsoft.BingHealthAndFitness',
'Microsoft.BingFoodAndDrink',
'Microsoft.BingTranslator',
'Microsoft.BingWeather',
'Microsoft.Messaging',
'Microsoft.MicrosoftSolitaireCollection',
'Microsoft.ZuneMusic',
'Microsoft.ZuneVideo',
'Microsoft.WindowsPhone',
'Microsoft.YourPhone',
'Microsoft.MicrosoftOfficeHub',
'Microsoft.Office.OneNote',
'Microsoft.WindowsMaps',
'Microsoft.MicrosoftOfficeHub',
'Microsoft.WindowsFeedbackHub',
'MicrosoftCorporationII.MicrosoftFamily',
'Microsoft.SkypeApp',
'Microsoft.OneConnect',
'Microsoft.Office.Sway',
'Microsoft.Todos',
'MicrosoftTeams',
'Microsoft.MicrosoftStickyNotes',
'Microsoft.NetworkSpeedTest',
'Microsoft.News',
'Microsoft.MixedReality.Portal',
'Microsoft.WindowsAlarms',
'Microsoft.PowerAutomateDesktop',
'Microsoft.WindowsSoundRecorder',
'Microsoft.MicrosoftJournal'
'MixedRealityLearning',
'ACGMediaPlayer',
'ActiproSoftwareLLC',
'AdobeSystemsIncorporated.AdobePhotoshopExpress',
'Amazon.com.Amazon',
'AmazonVideo.PrimeVideo',
'Asphalt8Airborne',
'AutodeskSketchBook',
'CaesarsSlotsFreeCasino',
'COOKINGFEVER',
'CyberLinkMediaSuiteEssentials',
'DisneyMagicKingdoms',
'Disney',
'Dolby',
'DrawboardPDF',
'Duolingo-LearnLanguagesforFree',
'EclipseManager',
'Facebook',
'FarmVille2CountryEscape',
'fitbit',
'Flipboard',
'HiddenCity',
'HULULLC.HULUPLUS',
'iHeartRadio',
'Instagram',
'king.com.BubbleWitch3Saga',
'king.com.CandyCrushSaga',
'king.com.CandyCrushSodaSaga',
'LinkedInforWindows',
'MarchofEmpires',
'Netflix',
'NYTCrossword',
'OneCalendar',
'PandoraMediaInc',
'PhototasticCollage',
'PicsArt-PhotoStudio',
'Plex',
'PolarrPhotoEditorAcademicEdition',
'Royal Revolt',
'Shazam',
'Sidia.LiveWallpaper',
'SlingTV',
'Speed Test',
'Spotify',
'TikTok',
'TuneInRadio',
'Twitter',
'Viber',
'Wunderlist',
'XING',
'Movies & TV',
'Kodi',
'WhatsApp',
'C27EB4BA.DropboxOEM'

# Hide progress bar
$ProgressPreference = 'SilentlyContinue'

ForEach ($App in $AppsList){
$PackageFullName = (Get-AppxPackage $App).PackageFullName
$ProPackageFullName = (Get-AppxProvisionedPackage -online | where {$_.Displayname -eq $App}).PackageName
write-host $PackageFullName
Write-Host $ProPackageFullName
if ($PackageFullName){
Write-Host "Removing Package: $App"
remove-AppxPackage -package $PackageFullName
}
else{
Write-Host "Unable to find package: $App"
}
if ($ProPackageFullName){
Write-Host "Removing Provisioned Package: $ProPackageFullName"
Remove-AppxProvisionedPackage -online -packagename $ProPackageFullName
}
else{
Write-Host "Unable to find provisioned package: $App"
}
}

Write-Host "[DONE] Removing bloatware completed`n" -ForegroundColor Green 

Read-Host "Press Enter to exit"
