# Retrieve a list of installed programs
$uninstallKeys = Get-ChildItem "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall"
$programs = @()

foreach ($key in $uninstallKeys) {
    $program = New-Object PSObject
    $program | Add-Member -MemberType NoteProperty -Name "Name" -Value $key.GetValue("DisplayName")
    $program | Add-Member -MemberType NoteProperty -Name "Version" -Value $key.GetValue("DisplayVersion")
    $program | Add-Member -MemberType NoteProperty -Name "Vendor" -Value $key.GetValue("Publisher")
    $program | Add-Member -MemberType NoteProperty -Name "InstallDate" -Value $key.GetValue("InstallDate")
    $program | Add-Member -MemberType NoteProperty -Name "InstallLocation" -Value $key.GetValue("InstallLocation")
    $programs += $program
}

$programs = $programs | Where-Object {$_.Name -and $_.Vendor} | Sort-Object Name

# Retrieve a list of installed apps
$apps = Get-AppxPackage | Select-Object Name, Version, Publisher, InstallDate, InstallLocation | Sort-Object Name

# Combine the lists of programs and apps
$allItems = $programs + $apps

# Create a base directory for saving files
$baseFolderPath = "$([Environment]::GetFolderPath('Desktop'))\Installed Apps"
if (-not (Test-Path -Path $baseFolderPath -PathType Container)) {
    New-Item -Path $baseFolderPath -ItemType Directory | Out-Null
}

# Create a directory for the CSV file
$csvFolderPath = "$baseFolderPath\Open with Notepad"
if (-not (Test-Path -Path $csvFolderPath -PathType Container)) {
    New-Item -Path $csvFolderPath -ItemType Directory | Out-Null
}

# Create a directory for the Excel file
$excelFolderPath = "$baseFolderPath\Open with Excel"
if (-not (Test-Path -Path $excelFolderPath -PathType Container)) {
    New-Item -Path $excelFolderPath -ItemType Directory | Out-Null
}

# Save the combined list to a CSV file and Excel workbook
$csvFilename = "$csvFolderPath\InstalledApps.csv"
$allItems | Export-Csv -Path $csvFilename -Encoding UTF8 -NoTypeInformation

$xlsxFilename = "$excelFolderPath\InstalledApps.xlsx"
$excel = New-Object -ComObject Excel.Application
$workbook = $excel.Workbooks.Add()
$worksheet = $workbook.Worksheets.Item(1)

# Loop through the data and populate the Excel worksheet cell by cell
$row = 1
$column = 1
foreach ($item in $allItems) {
    foreach ($property in $item.PSObject.Properties) {
        $worksheet.Cells.Item($row, $column).Value2 = $property.Value
        $column++
    }
    $row++
    $column = 1
}

# Auto-fit columns
$usedRange = $worksheet.UsedRange
$usedRange.EntireColumn.AutoFit()

# Save the workbook in XLSX format and close Excel
$workbook.SaveAs($xlsxFilename, 51) # 51 is the XLSX format
$workbook.Close()
$excel.Quit()

# Release the Excel COM objects from memory
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($worksheet) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($workbook) | Out-Null
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null
Remove-Variable excel, workbook, worksheet -ErrorAction SilentlyContinue